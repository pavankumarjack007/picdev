#! /bin/bash

vault_containers="0/1"
  while : ; do
      echo "Checking if vault pods are ready for unseal"
      result=$(kubectl -n vault get po vault-0 | grep vault-0 | awk '{ print $2 }')
      echo "Expecting $vault_containers .. Current $result"
      if [[ "$result" == "$vault_containers" ]]
      then
        break
      fi
      sleep 10
  done

sleep 30

  kubectl -n vault exec vault-0 -- vault operator init -key-shares=1 -key-threshold=1 -format=json > cluster-keys.json
  #kubectl -n vault exec vault-0 -- vault operator init -format=json > cluster-keys.json
  export VAULT_UNSEAL_KEY=$(cat cluster-keys.json | jq -r ".unseal_keys_b64[]")
  export VAULT_TOKEN=$(cat cluster-keys.json | jq -r ".root_token")

  # kubectl -n vault exec vault-0 -- vault operator unseal $VAULT_UNSEAL_KEY
  # kubectl -n vault exec vault-1 -- vault operator unseal $VAULT_UNSEAL_KEY
  # kubectl -n vault exec vault-2 -- vault operator unseal $VAULT_UNSEAL_KEY

  #kubectl -n vault exec vault-2 -- vault operator unseal $VAULT_UNSEAL_KEY

  #Now login and set token
  kubectl -n vault exec vault-0 -- vault login $VAULT_TOKEN

  kubectl -n vault exec vault-0 -- /bin/sh -c "`cat vault_init.sh`"

  