#! /bin/bash
#Script to run backup/restore commands on the MicroCloud platform.
#Requires:- packer (v1.7.4), docker (v20.10.8)

if [[ -z "$HSOP_PROFILE" ]]
then
   abort "HSOP_PROFILE environment variable is not set"
fi

(
  cd ./build

  if [[ "$(docker images -q hsop/driver:1.0 2> /dev/null)" == "" ]];
  then
    packer init driver.pkr.hcl
    packer build driver.pkr.hcl
  fi
)

chmod +x scripts/backuprestore.sh >/dev/null
IFS=' ';args_list="${@}"
docker run --rm --mount src="$(pwd)",target=/deployment,type=bind \
  -w /deployment/scripts -i -t hsop/driver:1.0 ./backuprestore.sh -p $HSOP_PROFILE -a "${args_list}"


