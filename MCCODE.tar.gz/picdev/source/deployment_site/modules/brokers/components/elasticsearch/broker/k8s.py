import base64
import logging

from kubernetes import client, dynamic
from kubernetes.client import ApiException
from tenacity import before_sleep_log
from tenacity import retry as tenacity_retry
from tenacity import (
    retry_if_exception,
    stop_after_attempt,
    stop_after_delay,
    wait_exponential,
)


def retry(*args, **kwargs):
    kwargs["before_sleep"] = kwargs.get(
        "before_sleep", before_sleep_log(logging.getLogger(__name__), logging.WARNING)
    )
    kwargs["reraise"] = kwargs.get("reraise", True)
    kwargs["retry"] = kwargs.get(
        "retry",
        retry_if_exception(
            lambda e: isinstance(e, ApiException) and e.status in (429, 500, 503)
        ),
    )
    kwargs["stop"] = kwargs.get("stop", (stop_after_delay(30) | stop_after_attempt(10)))
    kwargs["wait"] = kwargs.get("wait", wait_exponential(multiplier=1.2, max=10))
    return tenacity_retry(*args, **kwargs)


class KubernetesClient(object):
    MONITORING_GROUP = "monitoring.coreos.com"
    MONITORING_VERSION = "v1"
    MONITORING_PLURAL = "servicemonitors"

    def __init__(self, endpoint, cert, token):
        self.endpoint = endpoint
        self.cert = cert
        self.token = token

        # urllib3 insists on reading CA certs from a file object
        with open("cert.pem", "wb") as cert_f:
            cert_f.write(base64.b64decode(str.encode(self.cert)))
            cert_f.flush()

        api_config = client.Configuration()
        api_config.host = endpoint
        api_config.verify_ssl = False
        api_config.ssl_ca_cert = cert_f.name
        api_config.api_key["authorization"] = bytes.decode(
            base64.b64decode(str.encode(self.token))
        )
        api_config.api_key_prefix["authorization"] = "Bearer"
        self.api_client = client.ApiClient(api_config)

        self.log = logging.getLogger(__name__)
        self.k8s_client = client.CoreV1Api(self.api_client)
        self.k8s_apps_client = client.AppsV1Api(self.api_client)
        self.dynamic_client = dynamic.DynamicClient(self.api_client)

    @retry()
    def deploy_custom_resource(self, group, version, plural, namespace, data):
        try:
            api_instance = client.CustomObjectsApi(self.api_client)
            api_instance.create_namespaced_custom_object(
                group=group,
                version=version,
                plural=plural,
                namespace=namespace,
                body=data,
            )
        except ApiException as e:
            self.log.error(f"Error in deploying service monitor {e}")

    @retry()
    def get_custom_resource_status(self, group, version, plural, namespace, name):
        try:
            api_instance = client.CustomObjectsApi(self.api_client)
            status = api_instance.get_namespaced_custom_object_status(
                group=group,
                version=version,
                plural=plural,
                namespace=namespace,
                name=name,
            )
            if status is None or not("status" in status) or status["status"] is None:
                return None
            return status["status"]["phase"]
        except ApiException as e:
            self.log.error(f"Error in get resource status {e}")

    @retry()
    def delete_custom_resource(self, group, version, plural, namespace, name):
        try:
            api_instance = client.CustomObjectsApi(self.api_client)
            api_instance.delete_namespaced_custom_object(
                group=group,
                version=version,
                plural=plural,
                namespace=namespace,
                name=name,
            )
        except ApiException as e:
            self.log.error(f"Error in deleting service monitor {e}")

    @retry()
    def check_custom_resource(self, group, version, plural, namespace, name):
        try:
            api_instance = client.CustomObjectsApi(self.api_client)
            status = api_instance.get_namespaced_custom_object_status(
                group=group,
                version=version,
                plural=plural,
                namespace=namespace,
                name=name,
            )
            if status is None or status["status"] is None:
                return None
            resource_status = status["status"]["conditions"][0]
            if resource_status is not None and resource_status["status"] == "True":
                return True
            return False
        except ApiException as e:
            self.log.error(f"Error in deleting service monitor {e}")
            return False

    @retry()
    def create_deployment(self, namespace, data):
        self.log.info(f"Creating deployment in namespace {namespace}")
        try:
            self.k8s_apps_client.create_namespaced_deployment(
                namespace=namespace, body=data
            )
        except ApiException as e:
            self.log.error(f"Error in creating deployment {e}")

    @retry()
    def delete_deployment(self, namespace, name):
        self.log.info(f"Deleting the deployment from namespace {namespace}")
        try:
            self.k8s_apps_client.delete_namespaced_deployment(
                namespace=namespace, name=name
            )
        except ApiException as e:
            self.log.error(f"Error in creating deployment {e}")

    def read_from_secret(self, namespace, name, key, is_base64_decode=False):
        self.log.info(f"Getting config map value from {namespace}")
        try:
            secret = self.k8s_client.read_namespaced_secret(
                namespace=namespace, name=name
            )
            if is_base64_decode:
                return base64.b64decode(secret.data[key]).decode("utf-8")
            return secret.data[key]
        except ApiException as e:
            self.log.error(f"Error in creating deployment {e}")

    @retry()
    def pod_status(self, namespace, stateful_set_name):
        self.log.info("Getting the pod status")
        try:
            pod_resp = self.k8s_apps_client.read_namespaced_stateful_set(
                name=stateful_set_name, namespace=namespace
            )
            replicas = pod_resp.spec.replicas
            for idx in range(replicas):
                resp = self.k8s_client.read_namespaced_pod_status(
                    name=f"{stateful_set_name}-{idx}", namespace=namespace
                )
                status = resp.status.phase
                if status == "Pending" or status == "Failed":
                    return status
                container_status = resp.status.container_statuses[0]
                if container_status.started is False or container_status.ready is False:
                    waiting_state = container_status.state.waiting
                    if (
                        waiting_state is not None
                        and waiting_state.message is not None
                        and "Error" in waiting_state.message
                    ):
                        status = "Failed"
                    else:
                        status = "Pending"
                return status
        except ApiException as e:
            self.log.error(f"Error in getting pod status {e}")
            if e.status == 404:
                return "Failed"

    @retry()
    def create_service(self, namespace, data):
        self.log.info(f"Creating service in namespace {namespace}")
        try:
            self.k8s_client.create_namespaced_service(body=data, namespace=namespace)
        except ApiException as e:
            self.log.error(f"Error in creating service {e}")

    @retry()
    def delete_service(self, namespace, name):
        self.log.info(f"Deleting the service {name} from namespace {namespace}")
        try:
            self.k8s_client.delete_namespaced_service(name=name, namespace=namespace)
        except ApiException as e:
            self.log.error(f"Error in deleting service {e}")

    @retry()
    def delete_secret(self, namespace, name):
        try:
            self.k8s_client.delete_namespaced_secret(name=name, namespace=namespace)
        except ApiException as e:
            self.log.error(f"Error in deleting secret {e}")
