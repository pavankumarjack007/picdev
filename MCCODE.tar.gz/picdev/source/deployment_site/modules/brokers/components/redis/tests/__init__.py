import uuid
from unittest import TestCase

from cf_broker_api.catalog import ServiceCatalog
from cf_broker_api.testing import TestClient
from moto import mock_dynamodb2
from nose.tools import nottest

from broker import create_broker, get_broker_model
from config import config_map

test_config = config_map["testing"]

default_service_id = "b2eab96e-1e5e-4700-b267-6a76d78adbf7"
default_plan_id = "f2df267f-47ce-4b79-a407-c3c7862928fb"
catalog = ServiceCatalog(test_config.service_catalog_filename)
plan_map = {
    plan["id"]: plan for plan in catalog.get_service(default_service_id)["plans"]
}


@nottest
def test_data(**kwargs):
    _config = kwargs.get("config", test_config)
    instance_id = kwargs.get("instance_id", str(uuid.uuid4()))
    service_id = kwargs.get("service_id", default_service_id)
    plan_id = kwargs.get("plan_id", default_plan_id)
    plan = plan_map.get(plan_id)
    organization_guid = kwargs.get("organization_guid", "test-org-guid")
    space_guid = kwargs.get("space_guid", "test-space-guid")
    default_tablename = _config.DYNAMODB_TABLE
    tablename = kwargs.get("tablename", default_tablename)
    parameters = kwargs.get("parameters", {})
    default_context = {
        "platform": "cloudfoundry",
        "organization_guid": organization_guid,
        "space_guid": space_guid,
        "instance_name": "testinstance",
        "organization_name": "testorg",
        "space_name": "testspace",
    }
    context = kwargs.get("context", default_context)
    binding_id = kwargs.get("binding_id", "test-binding-id")
    data = {
        "instance_id": instance_id,
        "tablename": tablename,
        "table": tablename,
        "service_id": service_id,
        "plan_id": plan_id,
        "plan": plan,
        "organization_guid": organization_guid,
        "space_guid": space_guid,
        "parameters": parameters,
        "context": context,
        "binding_id": binding_id,
        "region_name": _config.AWS_DEFAULT_REGION,
    }
    return data


class BaseTestCase(TestCase):
    aws_mocks = [mock_dynamodb2()]

    def setUp(self):
        for aws_mock in BaseTestCase.aws_mocks:
            aws_mock.start()
        self.app = create_broker("testing")
        self.model = get_broker_model(test_config)
        self.client = TestClient(self.app.test_client())

    def tearDown(self):
        for aws_mock in self.aws_mocks:
            aws_mock.stop()
