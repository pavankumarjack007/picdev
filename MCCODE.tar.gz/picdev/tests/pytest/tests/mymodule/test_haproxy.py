import os
import json
import time
import pytest

from tests.pytest.tests.conftest import cluster_name

cluster_name = os.environ['cluster']


nodejs_websocket_server = """
const WebSocketServer = require('ws').Server
const ws = new WebSocketServer({ port: process.env.PORT || 4443 });
ws.on('connection', function (socket) {
  socket.send('server: websocket is working ');
  socket.on('message', function (message) {
    socket.send('Server_SENT: ' + message);
  });
});
"""
nodejs_websocket_package = """
{
  "name": "websocket_cf",
  "version": "1.0.0",
  "description": "Basic WebSocket example application for Cloud Foundry on SAP Cloudplatform",
  "main": "client.js",
  "dependencies": {
    "ws": "*"
  },
  "devDependencies": {},
  "engines": {
    "node": "12.x.x"
  }
}
"""

haproxy_headers_tester = """
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if (!function_exists('getallheaders')) {
    function getallheaders() {
    $headers = [];
    foreach ($_SERVER as $name => $value) {
        if (substr($name, 0, 5) == 'HTTP_') {
            $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
        }
    }
    return $headers;
    }
}
$headers =  getallheaders();
echo json_encode($headers);
?>
"""

helloworld_php = """
<?php echo '{"hello":"world"}'; ?>
"""


def generateYmlAPPContent(AppName, buildpack):
    return """
---
applications:
- name: """ + AppName + """\n
  random-route: true
  memory: 256M
  buildpacks:
    - """ + buildpack + "\n"


def generateYmlNodeAPPContent(AppName, buildpack):
    return """
---
applications:
- name: """ + AppName + """\n
  command: node server.js
  buildpacks: 
  - """ + buildpack + """\n
  health-check-type: none
  memory: 128M
  disk_quota: 128M
  random-route: true
"""


def deployNodeApp(con, AppName):
    print(con)
    newpath = '/tmp/' + AppName + '/';
    if not os.path.exists(newpath):
        os.makedirs(newpath)
    print("writing APP")
    f = open(newpath + "server.js", "w")
    f.write("" + con)
    f.close()
    f = open(newpath + "manifest.yml", "w")
    f.write(generateYmlNodeAPPContent(AppName, "https://github.com/cloudfoundry/nodejs-buildpack"))
    f.close()
    f = open(newpath + "package.json", "w")
    f.write(nodejs_websocket_package)
    f.close()
    print("App written locally")
    cwd = os.getcwd()
    os.chdir(newpath)
    print("Pushing APP")
    APPURL = os.popen("cf push|grep 'routes:'|awk {'print $2'}").read();
    print("Delteing generated APP locally")
    print(os.popen("rm -vrf " + newpath).read());
    os.chdir(cwd)
    return APPURL.strip()


def deployApp(fileName, AppContent, AppName):
    newpath = '/tmp/' + AppName + '/';
    if not os.path.exists(newpath):
        os.makedirs(newpath)
    print("writing APP")
    f = open(newpath + fileName, "w")
    f.write(AppContent)
    f.close()
    f = open(newpath + "manifest.yml", "w")
    f.write(generateYmlAPPContent(AppName, "php_buildpack"))
    f.close()
    print("App written locally")
    cwd = os.getcwd()
    os.chdir(newpath)
    print("Pushing APP")
    APPURL = os.popen("cf push|grep 'routes:'|awk {'print $2'}").read();
    print("Delteing generated APP locally")
    print(os.popen("rm -vrf " + newpath).read());
    os.chdir(cwd)
    return APPURL.strip()


@pytest.mark.client
def test_929482_verify_Xforward_header(APPNAME="haproxy_headers_tester"):
    AppURL = deployApp("index.php", haproxy_headers_tester, APPNAME);
    jsondata = os.popen("curl https://" + AppURL).read()
    parsedData = json.loads(jsondata)
    print("Checking if headers are set")
    check = 0;
    if 'X-Forwarded-For' in parsedData:
        print("X-forward-for is set. X-forward-for=" + parsedData['X-Forwarded-For'])
        check = check + 1
    if 'X-Forwarded-Proto' in parsedData:
        print("X-Forwarded-Proto is set. X-forward-Proto=" + parsedData['X-Forwarded-Proto'])
        check = check + 1
    if check == 2:
        print("Passed")
        print(os.popen(" cf delete -f " + APPNAME).read())
        assert True
    else:
        print("Failed")
        print(os.popen(" cf delete -f " + APPNAME).read())
        assert False


@pytest.mark.client
def test_900693_verify_port80_http(APPNAME="haproxy_HTTP_APP"):
    AppURL = deployApp("index.php", helloworld_php, APPNAME);
    jsondata = os.popen("curl http://" + AppURL).read()
    parsedData = json.loads(jsondata)
    print("Checking if Access was made via http")
    check = 0;
    if 'hello' in parsedData:
        print("Recived hello-" + parsedData["hello"])
        print("Passed")
        print(os.popen(" cf delete -f " + APPNAME).read())
        assert True
    else:
        print("Failed to access CF apps via http request on port 80")
        print(os.popen(" cf delete -f " + APPNAME).read())
        assert False


@pytest.mark.client
def test_900693_verify_websocket_connection(port="4443", APPNAME="cf_websocket_tester4443"):
    AppURL = deployNodeApp(nodejs_websocket_server, APPNAME);
    from websocket import create_connection
    ws = create_connection("wss://" + AppURL + ":" + port)
    print("Sending 'Hello, World'...")
    ws.send("Hello, World")
    print("Sent.\n Recviing")
    result = ws.recv()
    if len(result) > 1:
        print("Recived -" + result)
        print("Passed")
        print(os.popen(" cf delete -f " + APPNAME).read())
        assert True
    else:
        print("Failed to connect websocket app over requested port. deleting the app")
        print(os.popen(" cf delete -f " + APPNAME).read())
        assert False

@pytest.mark.disabled
def test_929481_verify_haproxy_autoscalar(clusterName=cluster_name):
    print("Fetchig ASG details...")
    haproxyASG_name = os.popen(
        "aws autoscaling describe-auto-scaling-groups --auto-scaling-group-names|grep -E \'Name.:.*asg.*" + clusterName + "\'|sed \'s/\"//g;s/\\,//g\'|awk {\'print $2\'}").read().strip();
    print("Fetching Ec2 instance Details...")
    haproxyInstancID = os.popen(
        "aws autoscaling describe-auto-scaling-instances |grep " + haproxyASG_name + "  -B4|grep Id|sed \'s/\"//g;s/\\,//g\'|awk {\'print $2\'}").read().strip()
    print("Testing by terminating the instance : " + haproxyInstancID)
    print(os.popen("aws ec2  terminate-instances --instance-ids " + haproxyInstancID).read())
    print("Terminate signal sent")
    retry = 40;
    while retry >= 0:
        print("aws ec2 describe-instance-status --instance-ids " + haproxyInstancID);
        if (len(os.popen("aws ec2 describe-instance-status --instance-ids " + haproxyInstancID).read()) >= 40):
            print(" Shutingdown.. ")
            retry = retry - 1
            time.sleep(1)
        else:
            print("Deleted. succefully ")
            print("Testing if new node is up?...")
            retry2 = 40
            while retry2 >= 0:
                time.sleep(5)
                haproxyInstancID2 = os.popen(
                    "aws autoscaling describe-auto-scaling-instances |grep " + haproxyASG_name + "  -B4|grep Id|sed \'s/\"//g;s/\\,//g\'|awk {\'print $2\'}").read().strip()
                if (haproxyInstancID2 != haproxyInstancID):
                    print("New Instance is Created and Intitilizing [booting may takes some time] : ",
                          haproxyInstancID2);
                    # todo: more operation? check after system is up
                    assert True
                    return
                else:
                    print("Creating..")
                    retry2 = retry2 - 1
            if (retry2 <= 0):
                print("Failed to create instance in Time ")
                assert False
        if (retry <= 0):
            print("Failed to kill server in time.")
            assert False
    print("Failed")
    assert False


@pytest.mark.sat
def test_verify_publicKey_access_to_nodes_via_bastion(clusterName=cluster_name,
                                             VAULT_SEC="/cf/497d89a6-7ae8-4b5f-bdb8-8a569f86f418/secret/"):
    print("Retriving SSH keys and writing to /tmp/key")
    print(os.popen(
        "vault read   -format json " + VAULT_SEC + clusterName + "/kubernetes|jq -r '.data.ssh_private_key'|base64 -d >/tmp/key").read())
    print("Chomoding to 700")
    print(os.popen("chmod 700 /tmp/key").read())

    bastionHost = "bastions" + clusterName[3:]
    print("Pushing key into BastionHost:/tmp/")
    print("scp -o StrictHostKeyChecking=no -i /tmp/key /tmp/key ubuntu@" + bastionHost + ":/tmp/key")
    print(os.popen("scp -o StrictHostKeyChecking=no -i /tmp/key /tmp/key ubuntu@" + bastionHost + ":/tmp/key").read())
    print("ssh -o StrictHostKeyChecking=no -i /tmp/key  ubuntu@" + bastionHost + " 'chmod 700 /tmp/key' ")
    print(os.popen("ssh -o StrictHostKeyChecking=no -i /tmp/key ubuntu@" + bastionHost + " 'chmod 700 /tmp/key' ").read())
    jsonData = json.loads(os.popen("kubectl get nodes -o json|jq").read().strip())
    myBool = True
    for i in range(0, len(jsonData['items'])):
        localIP = os.popen(
            "kubectl get nodes -o json|jq -r '.items[" + str(i) + "].status.addresses[0].address'").read().strip();
        role = os.popen(
            "kubectl get nodes -o json|jq -r \'.items[" + str(
                i) + "].metadata.labels.\"kubernetes.io/role\"\'").read().strip()
        print("Trying to loggint into " + localIP + " of Type: " + role)
        print(
            "ssh -i /tmp/key ubuntu@" + bastionHost + " \"yes yes|ssh -i /tmp/key ubuntu@" + localIP + " 'echo Hello \$(hostname)'\"")
        out = os.popen(
            "ssh -i /tmp/key ubuntu@" + bastionHost + " \"yes yes|ssh -o StrictHostKeyChecking=no -i /tmp/key ubuntu@" + localIP + " 'echo Hello \$(hostname)'\"").read()
        print(out)
        if ("Hello" in out):
            pass
        else:
            myBool = False
        """
        echo 'echo -n "hello " ;hostname'|ssh -i /tmp/key ubuntu@ec2-54-93-72-39.eu-central-1.compute.amazonaws.com "ssh -i /tmp/key ubuntu@172.20.33.121 bash -s" 
        ssh -i /tmp/key ubuntu@ec2-54-93-72-39.eu-central-1.compute.amazonaws.com "ssh -i /tmp/key ubuntu@172.20.33.121 bash -s" < a.sh 
        cat a.sh|ssh -i /tmp/key ubuntu@ec2-54-93-72-39.eu-central-1.compute.amazonaws.com "ssh -i /tmp/key ubuntu@172.20.33.121 bash -s"
        """
    if (myBool == True):
        print("Passed")
        assert True
    else:
        print("Failed to access the nodes")
        assert False
