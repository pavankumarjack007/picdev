#! /bin/bash

token=$(curl -s -d "client_id=admin-cli" \
-d "username=$1" \
-d "password=$2" \
-d "grant_type=password" \
https://identity.$3/auth/realms/master/protocol/openid-connect/token | jq -r .access_token) >/dev/null
# get client ID
client_id=$(curl -s -X GET https://identity.$3/auth/admin/realms/hsop/clients?clientId=kubernetes -H "Authorization: Bearer $token" | jq -r .[].id) >/dev/null
#get client secret
client_secret=$(curl -s -X GET https://identity.$3/auth/admin/realms/hsop/clients/$client_id/client-secret -H "Authorization: Bearer $token" | jq -r .value) >/dev/null
#converting to json format for data type "external"
jq -n --arg client_secret "$client_secret" '{"client_secret":$client_secret}'
