#!/usr/bin/env python
import logging
import os
import sys

from uuid import uuid4
from cf_broker_api.testing import create_test_client


BROKER_USERNAME = os.getenv("BROKER_USERNAME", "")
BROKER_PASSWORD = os.getenv("BROKER_PASSWORD", "")


test_data = dict(
    instance_id="smoke-test-{}".format(str(uuid4())),
    plan_id="e05eceb5-437b-4d63-8b5b-7924c0c4f8ea",
    service_id="0d1f8803-445e-49ca-b0c4-746b29f5da57",
    space_guid="smoke-test-space-guid",
    organization_guid="smoke-test-org-guid",
    context={
        "platform": "cloudfoundry",
        "organization_guid": "smoke-test-org-guid",
        "space_guid": "smoke-test-space-guid",
    },
)


logging.basicConfig(level=logging.DEBUG, format="%(message)s")
log = logging.getLogger("smoketests")


if __name__ == "__main__":
    hostname = sys.argv[1]

    log.info("Running smoketests against {}...".format(hostname))

    client = create_test_client(
        "http",
        base_url="https://{}".format(hostname),
        username=BROKER_USERNAME,
        password=BROKER_PASSWORD,
    )

    log.info("Checking catalog...")
    resp = client.catalog()
    assert resp.status_code == 200

    log.info("Creating test instance...")
    resp = client.provision(test_data)
    assert resp.status_code == 201

    log.info("Deleting test instance...")
    resp = client.deprovision(test_data)
    assert resp.status_code == 200

    log.info("...smoketests passed!")
