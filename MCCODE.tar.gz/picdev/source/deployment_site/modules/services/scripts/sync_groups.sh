#! /bin/bash

while getopts d:u:p:l:m: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        d) domain=${OPTARG};;
        u) user=${OPTARG};;
        p) password=${OPTARG};;
        l) parent=${OPTARG};;
        m) mapper=${OPTARG};;
    esac
done

response=$(curl -sb --location --request POST "https://identity.$domain/auth/realms/master/protocol/openid-connect/token" \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'client_id=admin-cli' \
--data-urlencode "username=$user" \
--data-urlencode "password=$password" \
--data-urlencode 'grant_type=password')

token=$( jq -r ".access_token" <<<"$response" )

response=$(curl -sb --location --request POST "https://identity.$domain/auth/admin/realms/hsop/user-storage/$parent/mappers/$mapper/sync?direction=fedToKeycloak" \
--header "Authorization: Bearer $token")

status=$( jq -r ".status" <<<"$response" )

echo $status
