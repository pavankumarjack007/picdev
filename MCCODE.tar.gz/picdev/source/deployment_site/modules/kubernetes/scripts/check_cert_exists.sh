#! /bin/bash

if [ -f "${1}/${2}_full_chain.pem" ]; then
    if [ -f "${1}/${2}_private_key.pem" ]; then
        echo -n "{\"exists\": \"true\"}"
        exit 0
    fi
fi

echo -n "{\"exists\": \"false\"}"