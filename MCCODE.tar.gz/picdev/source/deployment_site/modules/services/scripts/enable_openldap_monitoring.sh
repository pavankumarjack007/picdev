#! /bin/bash

chmod +x ../ldap-exporter/openldap_exporter

kubectl -n identity cp ../ldap-exporter/openldap_exporter \
 $(kubectl -n identity get po -l app=openldap --no-headers=true -o custom-columns=":metadata.name"):/usr/sbin -c openldap

kubectl -n identity cp ../generated/openldap_exporter_config.yaml \
 $(kubectl -n identity get po -l app=openldap --no-headers=true -o custom-columns=":metadata.name"):/etc/ldap -c openldap

kubectl -n identity exec $(kubectl -n identity get po -l app=openldap --no-headers=true -o custom-columns=":metadata.name") \
 -c openldap -- /usr/sbin/openldap_exporter --config /etc/ldap/openldap_exporter_config.yaml > /dev/null 2> /dev/null &

kubectl apply -f ../ldap-exporter/openldap_exporter_service.yaml