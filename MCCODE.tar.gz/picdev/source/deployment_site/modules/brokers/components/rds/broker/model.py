import logging

from pynamodb.attributes import (
    JSONAttribute,
    ListAttribute,
    MapAttribute,
    NumberAttribute,
    UnicodeAttribute,
)
from pynamodb.exceptions import DoesNotExist
from pynamodb.models import Model

from . import utils

LOG = logging.getLogger(__name__)


class EncryptedAttribute(UnicodeAttribute):
    def __init__(self, key, *args, **kwargs):
        super(EncryptedAttribute, self).__init__(*args, **kwargs)
        self.encryption_key = key

    def serialize(self, value):
        encrypted_value = utils.encrypt_data(value, key=self.encryption_key)
        return super(EncryptedAttribute, self).serialize(encrypted_value)

    def deserialize(self, value):
        decrypted_value = utils.decrypt_data(value, key=self.encryption_key)
        return super(EncryptedAttribute, self).deserialize(decrypted_value)


def get_broker_model(config):
    class BrokerState(Model):
        class Meta:
            table_name = config.DYNAMODB_TABLE
            region = config.AWS_DEFAULT_REGION
            host = config.DYNAMO_DB_HOST
            max_retry_attempts = 10
            base_backoff_ms = 100

        class Credentials(MapAttribute):
            hostname = UnicodeAttribute(null=True)
            password = EncryptedAttribute(key=config.ENCRYPTION_KEY, null=True)
            port = NumberAttribute(null=True)
            username = UnicodeAttribute(null=True)
            db_name = UnicodeAttribute(null=True)
            uri = UnicodeAttribute(null=True)
#            ca_cert = UnicodeAttribute(null=True)
            public_hostname = UnicodeAttribute(null=True)
            public_port = NumberAttribute(null=True)
            public_uri = UnicodeAttribute(null=True)

        class Events(MapAttribute):
            reason = UnicodeAttribute()
            result = UnicodeAttribute()
            message = UnicodeAttribute(null=True)
            time = UnicodeAttribute()

        binding_ids = ListAttribute(default=list)
        credentials = Credentials(default={})
        instance_id = UnicodeAttribute(hash_key=True)
        instance_name = UnicodeAttribute(null=True)
        last_operation = JSONAttribute(default={})
        organization_guid = UnicodeAttribute()
        organization_name = UnicodeAttribute(null=True)
        plan_env = MapAttribute(default={})
        plan_id = UnicodeAttribute()
        plan_name = UnicodeAttribute(null=True)
        service_id = UnicodeAttribute()
        service_name = UnicodeAttribute(null=True)
        service_namespace = UnicodeAttribute(null=True)
        space_guid = UnicodeAttribute()
        space_name = UnicodeAttribute(null=True)
        image = UnicodeAttribute(null=True)
        engine_version = UnicodeAttribute(null=True)
        instance_creation_time = UnicodeAttribute(null=True)
        prometheus_host = UnicodeAttribute(null=True)
        prometheus_port = UnicodeAttribute(null=True)

        def __init__(self, *args, **kwargs):
            super(BrokerState, self).__init__(*args, **kwargs)

        @classmethod
        def get(cls, hash_key, range_key=None, consistent_read=False):
            try:
                record = super(BrokerState, cls).get(
                    hash_key, range_key, consistent_read
                )
            except DoesNotExist:
                record = None
            return record

        @classmethod
        def new_record(cls, *args, **kwargs):
            allowed_attrs = (
                "organization_guid",
                "space_guid",
                "service_id",
                "plan_id",
                "instance_id",
            )
            filtered = {k: v for k, v in kwargs.items() if k in allowed_attrs}
            return cls(*args, **filtered)

        @classmethod
        def init(cls):
            if cls.exists():
                return
            cls.create_table(read_capacity_units=5, write_capacity_units=5, wait=True)

    BrokerState.init()
    return BrokerState
