      #!/bin/bash
      while getopts u:b:p:s: flag
      do
          case "${flag}" in
              u) uri=${OPTARG};;
              b) binddn=${OPTARG};;
              p) bindpw=${OPTARG};;
              s) searchbase=${OPTARG};;
          esac
      done
      if [[ -f /etc/nslcd.conf ]]; then
        sudo chmod 640 /etc/nslcd.conf
      fi
      sudo DEBIAN_FRONTEND=noninteractive apt-get update
      sudo DEBIAN_FRONTEND=noninteractive apt-get install -qq libnss-ldapd
      sudo tee /etc/nslcd.conf > /dev/null <<EOF
      uid nslcd
      gid nslcd
      uri $uri
      base $searchbase
      ldap_version 3
      binddn $binddn
      bindpw $bindpw
      ssl off
      tls_reqcert never
      EOF
