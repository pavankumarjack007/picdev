from copy import deepcopy

from cf_broker_api import HTTP_500_INTERNAL_SERVER_ERROR, reqparse
from cf_broker_api.exceptions import (
    InvalidServiceParameter,
    ServiceInstanceAlreadyExists,
    ServiceInstanceGone,
    ServiceInstanceNotFound,
    ServiceBrokerException
)
from datetime import datetime
from .service import DatabaseBrokerService
from broker.operations import OpState
from broker.utils import RDSUri, generate_random_string, sanitize_label_value
import json

class InternalServerError(ServiceBrokerException):

    code = HTTP_500_INTERNAL_SERVER_ERROR
    description = "Server encountered an internal server error. "

    def __init__(self, status=None):
        if status is not None:
            super(InternalServerError, self).__init__()
            self.description = (
                "Server encountered an internal server error.: {0}. ".format(status)
            )


class BindActions(object):
    GET_CREDENTIALS = "get-credentials"
    LIST_SNAPSHOTS = "list-snapshots"
    DEFAULT = GET_CREDENTIALS
    ALL = [GET_CREDENTIALS, LIST_SNAPSHOTS]


class UpdateActions(object):
    CREATE_SNAPSHOT = "create-snapshot"
    DELETE_SNAPSHOT = "delete-snapshot"
    UPDATE_STORAGE = "update-storage"
    DEFAULT = UPDATE_STORAGE
    ALL = [CREATE_SNAPSHOT, DELETE_SNAPSHOT, UPDATE_STORAGE]

class ProvisionActions(object):
    CREATE_NEW = "create-new"
    RESTORE_SNAPSHOT = "restore-snapshot"
    DEFAULT = CREATE_NEW
    ALL = [CREATE_NEW, RESTORE_SNAPSHOT]

class LenientParamsParser(reqparse.CustomParamsParser):
    def __init__(self, bundle_errors=False, source=None):
        super(reqparse.CustomParamsParser, self).__init__(bundle_errors=bundle_errors)
        if source is not None:
            self.args = deepcopy(source.args)

    def parse_args(self, req=None, strict=False):
        return super(reqparse.CustomParamsParser, self).parse_args(req, False)


class DatabaseBrokerServiceActions(DatabaseBrokerService):
    def provision(self, request, instance_id):
        provision_action = ProvisionActions.DEFAULT
        if (
            "parameters" in request
            and "Action" in request.parameters
            and request.parameters["Action"] is not None
        ):
            provision_action = request.parameters["Action"]
        if provision_action == ProvisionActions.CREATE_NEW:
            return DatabaseBrokerService.provision(self, request, instance_id)
        elif provision_action == ProvisionActions.RESTORE_SNAPSHOT:
            if self.model.get(instance_id) is not None:
                raise ServiceInstanceAlreadyExists(instance_id)
            settings = request.plan["settings"]
            namespace = self.config.K8S_BROKER_NAMESPACE
            service_record = self.model.new_record(**request)
            service_record.instance_id = instance_id
            service_record.instance_name = sanitize_label_value(
                request.context.get("instance_name")
            )
            # service_record.service_namespace = namespace
            service_record.organization_name = sanitize_label_value(
                request.context.get("organization_name")
            )
            service_record.plan_env = settings["env"]
            service_record.space_name = sanitize_label_value(
                request.context.get("space_name")
            )
            service_record.service_id = request.service_id
            service_record.plan_name = request.plan["name"]
            engine = service_record.plan_env["ENGINE"]
            parameters = request.parameters
            backup_name = parameters["backupName"]
            tmp_inst_name = backup_name.split("-")
            tmp_inst_name.pop(-1)
            svc_instance_name = "-".join(tmp_inst_name)
            if "AllocatedStorage" in parameters:
                if parameters["AllocatedStorage"] <= 0 or None:
                    invalid_parameter = InvalidServiceParameter()
                    invalid_parameter.description = "Not a supported value for AllocatedStorage"
                    raise invalid_parameter
                storage = parameters["AllocatedStorage"]
                service_record.plan_env["STORAGE"] = f"{storage}Gi"        
            if "EngineVersion" in parameters:
                image_names = service_record.plan_env["IMAGE_NAME"]
                if parameters["EngineVersion"] in image_names.keys():
                    service_record.image = image_names[parameters["EngineVersion"]]
                    service_record.engine_version = parameters["EngineVersion"]
                else:
                    invalid_parameter = InvalidServiceParameter()
                    invalid_parameter.description = "Not a supported engine version "
                    raise invalid_parameter
            else:
                service_record.image = service_record.plan_env["IMAGE_NAME"]["default"]
                engine_version = service_record.plan_env["IMAGE_NAME"]["default"].split(":")[1]
                service_record.engine_version = engine_version

            service_record.service_name = svc_instance_name
            service_record.service_namespace = (
                f"mysql-{instance_id}" if engine == "mysql" else f"postgres-{instance_id}"
            )
            service_record.save()
            self._provision.create_namespace(service_record)
            port = (
                self.config.MYSQL_STANDARD_PORT
                if engine == "mysql"
                else self.config.POSTGRES_STANDARD_PORT
            )
            hostname = f"{service_record.service_name}.{service_record.service_namespace}.svc.cluster.local"
            username = generate_random_string(16)
            password = generate_random_string(32)
            db_name = service_record.plan_env["DB_NAME"]
            service_record.instance_creation_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            service_record.credentials = self.model.Credentials(
                hostname=hostname,
                port=port,
                username=username,
                password=password,
                db_name=db_name,
                uri=str(RDSUri(engine, username, password, hostname, port, db_name)),
            )
            
            service_record.prometheus_host = self.config.PROMETHEUS_HOST
            service_record.prometheus_port = self.config.PROMETHEUS_PORT
            service_record.save()

            self.log.warning("Restoring snapshot...")
            service_record.last_operation = {
                "state": OpState.IN_PROGRESS,
                "description": "Creating service instance",
            }
            service_record.save()
            self._provision.restore_snapshot(service_record, engine, backup_name)
            return {"operation": "restore_snapshot"}

    def update(self, request):
        update_action = UpdateActions.DEFAULT

        if (
            "parameters" in request
            and "Action" in request.parameters
            and request.parameters["Action"] is not None
        ):
            update_action = request.parameters["Action"]

        if update_action == UpdateActions.UPDATE_STORAGE:
            return DatabaseBrokerService.update(self, request)

        if update_action == UpdateActions.CREATE_SNAPSHOT:
            service_record = self.get_service_record(request.instance_id)
            engine = service_record.plan_env["ENGINE"]
            self._update.create_snapshot(service_record, engine)
            service_record.last_operation = {
                "state": OpState.IN_PROGRESS,
                "description": "Updating service instance",
            }
            service_record.save()
            return {"operation": "create_snapshot"}

        if update_action == UpdateActions.DELETE_SNAPSHOT:
            service_record = self.get_service_record(request.instance_id)
            engine = service_record.plan_env["ENGINE"]
            backup_name = request.parameters["backupName"]
            self._update.delete_snapshot(service_record, engine, backup_name)
            service_record.last_operation = {
                "state": OpState.IN_PROGRESS,
                "description": "Updating service instance",
            }
            service_record.save()
            return {"operation": "delete_snapshot"}

    def deprovision(self, request):
        return DatabaseBrokerService.deprovision(self, request)

    def bind(self, request):
        self.log.warning("Inside Bind Operation of Actions...")
        bind_action = BindActions.DEFAULT
        if (
            "parameters" in request
            and "Action" in request.parameters
            and request.parameters["Action"] is not None
        ):
            bind_action = request.parameters["Action"]

        if bind_action == BindActions.GET_CREDENTIALS:
            return DatabaseBrokerService.bind(self, request)
        elif bind_action == BindActions.LIST_SNAPSHOTS:
            credentials = {}
            snapshots_list = self.instance_snapshots(request.instance_id)
            credentials["snapshot_summaries"] = snapshots_list
            return {"credentials": credentials}

    def last_operation(self, request, instance_id):
        service_record = self.get_service_record(instance_id)
        last_operation = request.get("operation")
        description = "Creating service instance"
        if last_operation == "restore_snapshot":
            state = self._provision.restore_state(service_record)
            service_record.last_operation = {
                "state": state,
                "description": description,
            }
            service_record.save()
            if state == OpState.SUCCEEDED:
                #TODO: read secrets and update service record with creds
                engine = service_record.plan_env["ENGINE"]
                if engine == "mysql":
                    service_record.credentials['password'] = self._provision.read_db_password(service_record)
                else:
                    service_record.credentials['username'] = self._provision.read_db_username(service_record)["POSTGRES_USER"]
                    service_record.credentials['db_name'] = self._provision.read_db_username(service_record)["POSTGRES_DB"]
                    service_record.credentials['password'] = self._provision.read_db_password(service_record)
                service_record.save()
        elif (last_operation == "create_snapshot" or last_operation == "delete_snapshot"):
            state = OpState.SUCCEEDED
        else:
            return super().last_operation(request, instance_id)
        return {"state": state, "description": description}

    def instance_snapshots(self, instance_id):
        service_record = self.get_service_record(instance_id)
        snapshots = self._bind.get_service_backups(
            service_record, 
            service_record.plan_env["ENGINE"]
        )
        snapshots_list = []
        for item in snapshots["items"]:
            snapshot = {}
            snapshot["name"] = item["metadata"]["name"]
            snapshot["namespace"] = item["metadata"]["namespace"]
            snapshot["snapshot_type"] = item["metadata"]["labels"]["backup-type"]

            snapshot["create_time"] = item["metadata"]["creationTimestamp"]
            if "status" in item.keys():
                if "phase" in item["status"].keys():
                    snapshot["status"] = item["status"]["phase"]
            else:
                snapshot["status"] = "Pending"
            snapshots_list.append(snapshot)
        return snapshots_list

    def get_param_parsers(self):
        def bind_action_type(value):
            if value is not None and value not in BindActions.ALL:
                raise ValueError(
                    "Must be one of {}".format(
                        "|".join(["'{}'".format(action) for action in BindActions.ALL])
                    )
                )
            return value
        def update_action_type(value):
            if value is not None and value not in UpdateActions.ALL:
                raise ValueError(
                    "Must be one of {}".format(
                        "|".join(["'{}'".format(action) for action in UpdateActions.ALL])
                    )
                )
            return value
        def provision_action_type(value):
            if value is not None and value not in ProvisionActions.ALL:
                raise ValueError(
                    "Must be one of {}".format(
                        "|".join(["'{}'".format(action) for action in ProvisionActions.ALL])
                    )
                )
            return value

        param_parsers = super().get_param_parsers()

        bind_parser = LenientParamsParser(bundle_errors=True)
        bind_parser.add_argument("Action", type=bind_action_type, store_missing=False)
        param_parsers["bind"] = bind_parser

        update_parser = param_parsers["update"]
        update_parser.add_argument(
            "Action", type=update_action_type, store_missing=False
        )
        update_parser.add_argument(
            "backupName", store_missing=False
        )

        param_parsers["update"] = update_parser

        provision_parser = param_parsers["provision"]
        provision_parser.add_argument(
            "Action", type=provision_action_type, store_missing=False
        )
        provision_parser.add_argument(
            "backupName", store_missing=False
        )
        param_parsers["provision"] = provision_parser

        return param_parsers

    def add_request_hooks(self, broker):
        super().add_request_hooks(broker)
