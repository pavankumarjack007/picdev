#!/usr/bin/env bash
source /home/MC_Jenkins/locals/export_vars.sh
domain_name=$(cat outposts-ams-cicd.tfvars | grep domain_name | cut -d "=" -f2)
export cluster=k8s.$domain_name
export domain_name=$domain_name
export login_vault_addr=$(cat outposts-ams-cicd.tfvars | grep login_vault_addr | cut -d "=" -f2)
./clusterConnect.sh $cluster
./binary/credhub api https://credhub.cf.$domain_name
secret=$(kubectl -n kubecf get secret var-credhub-admin-client-secret -o yaml | yq e '.data.password' - | base64 --decode)
credhub_status=$(./binary/credhub login --client-name=credhub_admin_client --client-secret=$secret)
secret_check=$(./binary/credhub get --name 'cfadminusername' -j | jq -r .value)
if [ "$credhub_status" == "Login Successful" ] && [ "$secret_check" == "admin" ] ;
then
	pytest --html=MicroCloudFunctionalTestReport.html --self-contained-html -m 'sat or client or fat'
else
	echo "Looks like credhub login is unsuccessful or credentials are not present; Exiting the test..."
	exit 1
fi
