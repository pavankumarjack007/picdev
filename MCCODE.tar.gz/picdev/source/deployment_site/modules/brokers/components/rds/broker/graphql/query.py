from functools import wraps
import graphene

from .event import Event
from .log import Log
from .metric import Metric
from .snapshot import Snapshot
from ..cloudfoundry import has_authorities
from .instance import Instance
from .service_catalog import ServiceCatalog


def verify_instance_id(func):
    @wraps(func)
    def wrapper(self, info, *args, **kwargs):
        instance_id = kwargs["instance_id"] if "instance_id" in kwargs else kwargs["id"]
        if not info.context.instance_details(instance_id):
            return None

        permissions = info.context.instance_permissions(instance_id)
        token = info.context.cc.uaa.get_access_token().attrs
        valid_authorities = ["cloud_controller.global_auditor"]
        if not (
                permissions.can_manage_instance or has_authorities(token, valid_authorities)
        ):
            return None

        return func(self, info, *args, **kwargs)

    return wrapper


class Query(graphene.ObjectType):
    instances = graphene.List(Instance)
    instance = graphene.Field(Instance, id=graphene.String())
    instance_snapshots = graphene.List(Snapshot, guid=graphene.String())
    instance_logs = graphene.List(Log, guid=graphene.String())
    instance_events = graphene.List(Event, guid=graphene.String())
    instance_metric = graphene.Field(
        Metric, guid=graphene.String(), metric=graphene.String()
    )
    catalog = graphene.Field(ServiceCatalog)

    def resolve_instances(root, info):
        return info.context.get_rds_instances()

    def resolve_catalog(root, info):
        return info.context.service_catalog()

    @verify_instance_id
    def resolve_instance(self, info, id):
        return info.context.get_rds_instance(id)

    def resolve_instance_snapshots(self, info, guid):
        return info.context.instance_snapshots(guid)

    def resolve_instance_logs(instance, info, guid):
        return info.context.instance_logs(guid)

    def resolve_instance_events(instance, info, guid):
        return info.context.instance_events(guid)

    def resolve_instance_metric(instance, info, guid, metric):
        return info.context.instance_metrics(guid, metric)
