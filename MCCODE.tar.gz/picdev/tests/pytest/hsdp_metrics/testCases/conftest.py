import pytest
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service

from pageObjects.login_hsop_console import LoginPage
from utilities.readProperties import ReadConfig


@pytest.fixture()
def setup():
    s = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=s)
    driver.maximize_window()
    return driver

# It is hook for Adding Environment info to HTML Report
def pytest_configure(config):
    config._metadata['Project Name'] = 'HSDP-Metrics'
    config._metadata['Module Name'] = 'Add Alerts'
