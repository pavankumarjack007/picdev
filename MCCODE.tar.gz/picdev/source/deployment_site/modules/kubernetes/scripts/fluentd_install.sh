#!/bin/bash
sudo tee /tmp/td-agent.conf <<EOT
<source>
    @type tail
    run_interval 30m
    path /var/log/*.log
    pos_file /var/log/td-agent/hsop_pos.pos
    read_from_head true
    path_key tailed_path
    tag vmlogs
    format none
    <parse>
       @type none
    </parse>
</source>
 
<filter vmlogs>
  @type record_transformer
  enable_ruby true
  <record>
    # overwrite full path to file name
    tailed_path \$${File.basename(record["tailed_path"])}
    hostname "#{Socket.gethostname}"
  </record>
</filter>

<match vmlogs>
  @type s3
  aws_key_id  admin 
  aws_sec_key ${minio_password}
  s3_bucket   ${INFRA_LOG_BUCKET_NAME}
  s3_endpoint  http://${master_route53}:30900
  path "vmlogs/${machineName}/#{Socket.gethostname}/\$${tailed_path}"
  s3_object_key_format "%%{path}/%%{time_slice}_#{Socket.gethostname}_%%{index}.%%{file_extension}"
  time_format "%Y-%m-%dT%H:%M:%S.%L"
  force_path_style true
  buffer_path /var/log/td-agent/s3
  time_slice_format "%Y-%m-%dT %H:%M:%S"
  #tell fluentd to accumalate 30minutes worth of logs before uploading to s3
  time_slice_wait 30m
  utc

  #size of buffer to accumalate logs
  buffer_chunk_limit 500m
  <buffer time,tailed_path>
    #flush_at_shutdown true # for test

    #Tell when to flush localchanges out of buffer
    timekey 30m
    #Tell when to write to s3 after flushing
    timekey_wait 5s
    time_key_format "%Y-%m-%dT %H:%M:%S"
  </buffer>

  <format>
    @type single_value
  </format>
</match>
EOT

# Time sync update on Bastion and ha-proxy
sudo tee /etc/systemd/timesyncd.conf > /dev/null <<EOT
# Same as master and worker from KOPS
[Time]
NTP=169.254.169.123
EOT
sudo systemctl restart systemd-timesyncd.service

# Installing fluentd on bastion and ha-proxy
curl -L https://toolbelt.treasuredata.com/sh/install-ubuntu-focal-td-agent4.sh | sh
sudo cp -rpf /tmp/td-agent.conf /etc/td-agent/
sudo chmod 644 /var/log/*.log
sudo systemctl enable td-agent
sudo systemctl restart td-agent
sudo rm -rf /tmp/td-agent.conf
