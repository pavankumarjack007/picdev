import json
import logging
import datetime
import sys

from cf_broker_api import reqparse
from cf_broker_api.exceptions import (
    ServiceInstanceNotFound,
    ServiceInstanceAlreadyExists,
)
from .exceptions import VaultInvalidPathError, VaultInvalidRequestError
from .vault import VaultClient


class VaultService(object):
    def __init__(self, config=None):
        self.config = config
        self.log = logging.getLogger(__name__)
        self.log.setLevel(self.config.log_level)
        self.stream_handler = logging.StreamHandler(sys.stdout)
        self.log_format = self.config.log_format
        self.stream_handler.setFormatter(self.log_format)
        self.log.addHandler(self.stream_handler)
        self.vault = VaultClient(self.config)
        self.secret_id_accessor = None

    def provision(self, request):
        resources = {}
        params = self.service_params(request)
        instance_id = params["instance_id"]

        print("Path: ", params["service_record_key"])

        if self.vault_path_exists(params["service_record_key"]):
            raise ServiceInstanceAlreadyExists(instance_id)
        #self.log.info("Provision request: {0}".format(request.context))

        print("svcbr before mount")

        self.mount_backends(params)
        resources["space_secret_path"] = params["space_secret_path"]
        resources["service_secret_path"] = params["service_secret_path"]
        resources["service_transit_path"] = params["service_transit_path"]

        self.create_policy(params)
        resources["policy"] = params["service_name"]

        self.create_approle(params)
        resources["approle"] = params["service_name"]

        self.create_service_credentials(params)
        resources["credentials"] = params["credentials_key"]

        service_record = self.generate_service_record(params)
        service_record["resources"] = resources
        self.update_service_record(instance_id, service_record)
        self.log.info("Provisioned instance {0}".format(instance_id))

    def deprovision(self, request):
        instance_id = request.instance_id
        service_record_key = "cf/broker/{0}".format(instance_id)
        if self.vault_path_exists(service_record_key):
            self.log.info("Deprovision request for instance {0}".format(instance_id))
        else:
            raise ServiceInstanceNotFound

        service_name = "cf-{0}".format(instance_id)
        self.delete_approle(service_name)
        self.delete_policy(service_name)
        self.unmount_backends(instance_id)

        credentials_key = "cf/broker/{0}/credentials".format(instance_id)
        self.vault.delete(credentials_key)
        self.vault.delete(service_record_key)
        self.log.info("Deprovisioned instance {0}".format(instance_id))

    def bind(self, request):
        creds = {}
        timestamp = self.timestamp()
        data = {
            "instance_id": request.instance_id,
            "binding_id": request.binding_id,
            "created": timestamp,
        }
        service_record_key = "cf/broker/{instance_id}".format(**data)
        credentials_key = "cf/broker/{instance_id}/credentials".format(**data)
        binding_record_key = "cf/broker/{instance_id}/{binding_id}".format(**data)

        if not self.vault_path_exists(service_record_key):
            raise ServiceInstanceNotFound

        if not self.vault_path_exists(binding_record_key):
            self.vault.write(binding_record_key, data=data)
            self.log.info("Created binding {0}".format(binding_record_key))
        else:
            self.log.warn("Binding {0} already exists".format(binding_record_key))

        creds = self.vault.read(credentials_key)["data"]
        creds["endpoint"] =  self.config.VAULT_CLIENT_ENDPOINT
        self.vault.write(credentials_key,data=creds)
        return {"credentials": creds}

    def unbind(self, request):
        ids = {"instance_id": request.instance_id, "binding_id": request.binding_id}
        binding_record_key = "cf/broker/{instance_id}/{binding_id}".format(**ids)

        if self.vault_path_exists(binding_record_key):
            self.vault.delete(binding_record_key)
            self.log.info("Deleted binding {0}".format(binding_record_key))
        else:
            self.log.info(
                "Unable to delete binding {0}, path does not exist".format(
                    binding_record_key
                )
            )

    def update(self, request):
        instance_id = request.instance_id
        service_record_key = "cf/broker/{0}".format(instance_id)
        if self.vault_path_exists(service_record_key):
            msg = ("Update request: {0}, params: {1}").format(
                request.context, request.parameters
            )
            self.log.info(msg)
        else:
            raise ServiceInstanceNotFound

        if request.parameters.get("RotateSecretID", False):
            self.rotate_secret_id(request)
        if "AllowSpaceSecretDeletion" in request.parameters:
            self.allow_space_secret_deletion(request)
        if "EnablePeriodicTokens" in request.parameters:
            self.enable_periodic_tokens(request)

    def rotate_secret_id(self, request):
        instance_id = request.instance_id
        service_record = self.read_service_record(instance_id)
        credentials_key = "cf/broker/{0}/credentials".format(instance_id)
        credentials = self.vault.read(credentials_key)["data"]
        role_name = "cf-{0}".format(instance_id)

        # Delete existing secret ID
        self.vault.delete_secret_id(role_name, credentials["secret_id"])

        # Create new secret ID and write updated credentials object
        timestamp = self.timestamp()
        metadata = {
            "org_id": service_record["org_id"],
            "space_id": service_record["space_id"],
            "modified": timestamp,
        }
        response = self.vault.create_secret_id(role_name, metadata=metadata)["data"]
        secret_id = response["secret_id"]
        secret_id_accessor = response["secret_id_accessor"]
        credentials["secret_id"] = secret_id
        self.vault.write(credentials_key, data=credentials)
        self.log.info("Updated credentials for instance {0}".format(instance_id))
        # Update broker metadata
        service_record["secret_id_accessor"] = secret_id_accessor
        service_record["modified"] = timestamp
        self.update_service_record(instance_id, service_record)

    def allow_space_secret_deletion(self, request):
        instance_id = request.instance_id
        # Default capability
        capabilities = ["create", "read", "update", "list"]
        if request.parameters["AllowSpaceSecretDeletion"] is True:
            capabilities.append("delete")
            msg = "Added delete capability"
        else:
            msg = "Removed delete capability"
        space_path_glob = "cf/{0}/secret/*".format(request.context["space_guid"])
        # Read/update current policy
        policy = "cf-{0}".format(instance_id)
        policy_params = json.loads(self.vault.read_policy(policy))
        policy_params["path"][space_path_glob]["capabilities"] = capabilities
        self.vault.create_policy(policy, policy_params)
        self.log.info("{0} for policy {1}".format(msg, policy))

    def enable_periodic_tokens(self, request):
        approle = "cf-{0}".format(request.instance_id)
        if request.parameters["EnablePeriodicTokens"] is True:
            config = {"period": 3600, "token_max_ttl": 0, "token_ttl": 0}
            msg = "Enabled periodic tokens"
        else:
            config = {"period": 0, "token_max_ttl": 3600, "token_ttl": 3600}
            msg = "Disabled periodic tokens"
        self.vault.create_approle(approle, **config)
        self.log.info("{0} for approle {1}".format(msg, approle))

    def vault_path_exists(self, path):
        result = False
        try:
            self.vault.read(path)
        except VaultInvalidPathError:
            result = False
        else:
            result = True
        return result

    def timestamp(self):
        return "{0}{1}".format(
            datetime.datetime.utcnow().replace(microsecond=0).isoformat(), "Z"
        )

    def service_params(self, request):
        _cf_ids = (
            "instance_id",
            "service_id",
            "organization_guid",
            "space_guid",
            "plan_id",
        )
        cf_ids = {key: value for key, value in request.items() if key in _cf_ids}
        _params = {
            "instance_id": "{instance_id}",
            "service_name": "cf-{instance_id}",
            "service_record_key": "cf/broker/{instance_id}",
            "credentials_key": "cf/broker/{instance_id}/credentials",
            "org_secret_path": "cf/{organization_guid}/secret",
            "space_secret_path": "cf/{space_guid}/secret",
            "service_secret_path": "cf/{instance_id}/secret",
            "service_transit_path": "cf/{instance_id}/transit",
        }
        params = {key: value.format(**cf_ids) for key, value in _params.items()}
        params["cf_ids"] = cf_ids
        return params

    def generate_service_record(self, params):
        timestamp = self.timestamp()
        _service_record = {
            "service_id": "{service_id}",
            "org_id": "{organization_guid}",
            "space_id": "{space_guid}",
            "plan_id": "{plan_id}",
            "secret_id_accessor": self.secret_id_accessor,
            "created": timestamp,
            "modified": "",
        }
        service_record = {
            key: value.format(**params["cf_ids"])
            for key, value in _service_record.items()
        }
        return service_record

    def read_service_record(self, instance_id):
        service_record_key = "cf/broker/{0}".format(instance_id)
        service_record = self.vault.read(service_record_key)["data"]
        return service_record

    def update_service_record(self, instance_id, data):
        service_record_key = "cf/broker/{0}".format(instance_id)
        self.vault.write(service_record_key, data=data)
        self.log.debug("Updated service record {0}".format(service_record_key))

    def mount_backends(self, params):
        # Catch VaultInvalidRequestError here to ignore already-mounted
        # shared backends
        for shared_path in (params["space_secret_path"],):
            try:
                print("Shared Path: ", shared_path)
                self.vault.mount_secret_backend("generic", mount_point=shared_path)
            except VaultInvalidRequestError:
                self.log.debug("Ignoring existing mount {0}".format(shared_path))
                pass

        # FIXME: Read backend types from plan settings
        self.vault.mount_secret_backend(
            "generic", mount_point=params["service_secret_path"]
        )
        self.log.debug("Mounted {0}".format(params["service_secret_path"]))

        self.vault.mount_secret_backend(
            "transit", mount_point=params["service_transit_path"]
        )
        self.log.debug("Mounted {0}".format(params["service_transit_path"]))

    def unmount_backends(self, instance_id):
        service_secret_path = "cf/{0}/secret".format(instance_id)
        service_transit_path = "cf/{0}/transit".format(instance_id)
        self.vault.unmount_secret_backend(service_secret_path)
        self.log.debug("Unmounted {0}".format(service_secret_path))
        self.vault.unmount_secret_backend(service_transit_path)
        self.log.debug("Unmounted {0}".format(service_transit_path))

    def create_policy(self, params):
        # The 'service_path_glob' allows access to (secret|transit) paths as
        # well as other Vault backends we might enable in future
        _path_globs = {
            "space_secret_path_glob": "{space_secret_path}/*",
            "service_path_glob": "cf/{instance_id}/*",
        }
        path_globs = {k: v.format(**params) for k, v in _path_globs.items()}
        policy_params = json.loads(self.config.policy_template.render(**path_globs))
        self.vault.create_policy(params["service_name"], policy_params)
        self.log.debug("Created policy {0}".format(params["service_name"]))

    def delete_policy(self, name):
        self.vault.delete_policy(name)
        self.log.debug("Deleted policy {0}".format(name))

    def create_approle_credentials(self, params):
        timestamp = self.timestamp()
        role_id = self.vault.read_role_id(params["service_name"])

        # Add metadata which is recorded in audit logs for tokens generated
        # with this secret ID
        metadata = {
            "org_id": params["cf_ids"]["organization_guid"],
            "space_id": params["cf_ids"]["space_guid"],
            "modified": timestamp,
        }
        response = self.vault.create_secret_id(
            params["service_name"], metadata=metadata
        )["data"]
        secret_id = response["secret_id"]
        self.secret_id_accessor = response["secret_id_accessor"]
        return {
            "role_id": role_id,
            "secret_id": secret_id,
            "secret_id_accessor": self.secret_id_accessor,
        }

    def create_service_credentials(self, params):
        approle_credentials = self.create_approle_credentials(params)
        _credentials = {
            "role_id": approle_credentials["role_id"],
            "secret_id": approle_credentials["secret_id"],
            "org_secret_path": "/v1/{org_secret_path}",
            "space_secret_path": "/v1/{space_secret_path}",
            "service_secret_path": "/v1/{service_secret_path}",
            "service_transit_path": "/v1/{service_transit_path}",
            "endpoint": self.config.VAULT_CLIENT_ENDPOINT,
        }
        credentials = {
            key: value.format(**params) for key, value in _credentials.items()
        }
        credentials_key = params["credentials_key"]
        self.vault.write(credentials_key, data=credentials)
        self.log.debug("Created service credentials {0}".format(credentials_key))

    def create_approle(self, params):
        approle_params = json.loads(self.config.approle_template.render(**params))
        self.vault.create_approle(params["service_name"], **approle_params)
        self.log.debug("Created approle {0}".format(params["service_name"]))

    def delete_approle(self, name):
        self.vault.delete_approle(name)
        self.log.debug("Deleted approle {0}".format(name))

    @staticmethod
    def get_param_parsers():
        def check_bool(value, name):
            if not isinstance(value, bool):
                raise ValueError("Value must be a boolean".format(name))
            else:
                return value

        update_parser = reqparse.CustomParamsParser(bundle_errors=True)
        update_parser.add_argument(
            "RotateSecretID", type=check_bool, store_missing=False
        )
        update_parser.add_argument(
            "AllowSpaceSecretDeletion", type=check_bool, store_missing=False
        )
        update_parser.add_argument(
            "EnablePeriodicTokens", type=check_bool, store_missing=False
        )
        param_parsers = {"update": update_parser}
        return param_parsers
