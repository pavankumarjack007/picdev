import graphene


class Event(graphene.ObjectType):
    date = graphene.String()
    message = graphene.String()
