# -*- coding: utf-8 -*-
# snapshottest: v1 - https://goo.gl/zC4yUc
from __future__ import unicode_literals

from snapshottest import Snapshot

snapshots = Snapshot()

snapshots["TestGraphQL::test_instances 1"] = {
    "instances": [
        {
            "guid": "215b97be-ec77-4224-9c38-c4f2d86b56c1",
            "name": "s3-bucket",
            "organization": "test-org",
        }
    ]
}

snapshots["TestGraphQL::test_instance 1"] = {
    "instance": {"guid": "215b97be-ec77-4224-9c38-c4f2d86b56c1", "name": "s3-bucket"}
}

snapshots["TestGraphQL::test_instance_details 1"] = {
    "instance": {
        "details": {"name": "test-cf-s3-215b97be-ec77-4224-9c38-c4f2d86b56c1"},
        "guid": "215b97be-ec77-4224-9c38-c4f2d86b56c1",
    }
}

snapshots["TestGraphQL::test_catalog 1"] = {
    "catalog": {
        "name": "hsdp-s3",
        "plans": [
            {
                "bullets": [
                    "AWS S3 Bucket",
                    "Optional user defined region",
                    "STS GetFederationToken permissions",
                ],
                "deprecated": False,
                "description": "S3 Bucket with Security Token Service permissions",
                "name": "s3_bucket",
                "restricted": False,
            },
            {
                "bullets": [
                    "AWS S3 Bucket",
                    "Location constraint on data to ap-northeast-1 (Tokyo) region",
                ],
                "deprecated": True,
                "description": "S3 Bucket in ap-northeast-1",
                "name": "ap-northeast-1",
                "restricted": True,
            },
            {
                "bullets": [
                    "AWS S3 Bucket",
                    "Location constraint on data to ap-southeast-1 (Singapore) region",
                ],
                "deprecated": True,
                "description": "S3 Bucket in ap-southeast-1",
                "name": "ap-southeast-1",
                "restricted": True,
            },
            {
                "bullets": [
                    "AWS S3 Bucket",
                    "Location constraint on data to eu-central-1 (Frankfurt) region",
                ],
                "deprecated": True,
                "description": "S3 Bucket in eu-central-1",
                "name": "eu-central-1",
                "restricted": True,
            },
            {
                "bullets": [
                    "AWS S3 Bucket",
                    "Location constraint on data to eu-west-1 (Ireland) region",
                ],
                "deprecated": True,
                "description": "S3 Bucket in eu-west-1",
                "name": "eu-west-1",
                "restricted": True,
            },
            {
                "bullets": [
                    "AWS S3 Bucket",
                    "Location constraint on data to sa-east-1 (Sao Paulo) region",
                ],
                "deprecated": True,
                "description": "S3 Bucket in sa-east-1",
                "name": "sa-east-1",
                "restricted": True,
            },
            {
                "bullets": ["AWS S3 Bucket", "US Standard region"],
                "deprecated": True,
                "description": "S3 Bucket",
                "name": "US Standard",
                "restricted": True,
            },
            {
                "bullets": [
                    "AWS S3 Bucket",
                    "Location constraint on data to us-west-1 (Northern California) region",
                ],
                "deprecated": True,
                "description": "S3 Bucket in us-west-1",
                "name": "us-west-1",
                "restricted": True,
            },
            {
                "bullets": [
                    "AWS S3 Bucket",
                    "Location constraint on data to us-west-2 (Oregon) region",
                ],
                "deprecated": True,
                "description": "S3 Bucket in us-west-2",
                "name": "us-west-2",
                "restricted": True,
            },
        ],
    }
}

snapshots["TestGraphQL::test_object_search 1"] = {
    "searchObjects": {
        "objects": [{"name": "some-key", "size": "10", "storageClass": "STANDARD"}],
        "pageInfo": {"nextToken": None, "total": 1},
    }
}
