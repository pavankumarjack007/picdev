#!/bin/bash
kubectl create configmap ldap-config --from-file=ldap.toml -n monitoring
kubectl patch deployment hsop-prometheus-grafana -n monitoring --patch-file=hsop-prometheus-grafana.yml
