# Audit and logging Automation

# Table of Contents
- [Audit and logging Automation](#audit-and-logging-automation)
- [Table of Contents](#table-of-contents)
    - [Getting Started](#getting-started)
    - [Prerequisites](#prerequisites)
    - [Folder structure](#folder-structure)
    - [Workflow](#workflow)
    - [Steps for executing the scripts](#steps-for-executing-the-scripts)
    - [Debugging and other tips](#debugging-and-other-tips)


## Getting Started 
This documents provide details how to use the scripts to install audit and logging on tencent or other environments.

## Prerequisites 
Scripts has been tested with following packages,same should be installed on the jump server:
 * Runtime dependencies:
   1. Docker (19.03.6)
   2. Python (3.6.9)
   3. CF CLI (cf version 6.52.0+b086fe522.2020-08-26)
   4. Helm (v3.3.4)
   5. Kubectl (v1.19.0)
 * Python packages:
    1. Jinja2==2.11.2
    2. PyYAML==5.3.1
    3. requests==2.25.0
    4. kubernetes==12.0.1
 
 * On the jump server make sure Docker is installed and running. You can use the following command to check if docker is running.
  ```
  service docker status
  ```
  The response should look like following
  ```
● docker.service - Docker Application Container Engine
   Loaded: loaded (/lib/systemd/system/docker.service; disabled; vendor preset: enabled)
   Active: active (running) since Thu 2020-11-05 09:33:18 CST; 1 months 2 days ago
     Docs: https://docs.docker.com
  ```
* Cf CLI should point to correct environment. Verify using following command
    ```bash
    cf target
    ```
* In cf org **hsop** and under **hsop** org spaces **dev and brokers** should be available
    ```bash
    cf orgs
    cf target -o hsop
    cf spaces
    ```
* Docker registry access. Currently it needs a namespace **eng-foundationcore** on the registry where logstash, kibana and tenant images should be present.

* IAM should already be installed and its endpoints details available.
* Scripts should be run from non-proxied environment
    
## Folder structure
* **MicroCloud** is the main folder
* Scripts resides in the folder **MicroCloud/audit_logging_automation**
* MicroCloud folder structure
```
.
└── MicroCloud
    ├── ansible
    ├── audit-iam-service
    ├── audit_logging_automation
    ├── brokers
    ├── cf-apps
    ├── cf-deployment
    ├── cicd
    ├── cicd_test
    ├── dhr
    ├── manifests
    ├── microcloud-healthcheck
    ├── security
    ├── terraform
    └── wrapper-scripts
```
* audit_logging_automation folder structure(post installation)

    ```bash
    audit_logging_automation/
    ├── automation_audit_logging.log
    ├── controllers
    ├── generated
    ├── hsopaudit
    ├── hsopaudit.zip
    ├── hsoplog
    ├── hsoplog.zip
    ├── hsplogproxy
    ├── hsplogproxy.zip
    ├── install_audit_manually.sh
    ├── install_audit.sh
    ├── install_logging_manually.sh
    ├── install_logging.sh
    ├── main.py
    ├── models
    ├── services
    ├── templates
    ├── unittests
    └── utils
    
    ```
  
## Workflow 

* Execution of the scripts needs to be done as per following automation workflow:
    1. Terraform execution of code happens. As the output of this execution two files are generated which are required by the scripts. These files are stored at location **MicroCloud/cf-deployment**.Files are
        1. terraform.tfvars.json(Terraform output file)
        2. tke_kubeconfig(k8s config file)
    2. All the service brokers are installed during automation. Making following services and plans available in cf environment:
        
        | Name   | Service     | Plan |
        | ----------- | ----------- | ----------- |
        | RabbitMQ    | hsdp-rabbitmq      | large-standalone       |
        | PostgreSQL    | hsdp-rds      | nano-dev       |
        | S3    | hsp-tencent-cos      | Standard       |
        | Redis    | hsdp-redis-sentinel      | nano-dev       |
        | ElasticSearch    | hsdp-elastic      | es6-dev-1       |
        | Vault    | hsdp-vault      | standard       |
        
        Available plans and services can be verified using command
        ```bash
        cf m
        ```
   3. Vault is initialized and unsealed. Vault broker configured.
   4. At this point scripts in folder **MicroCloud/audit_logging_automation** needs to be executed as explained in document 



## Steps for executing the scripts:

1. Once we reach state in automation workflow where all brokers are installed and vault is unsealed and initialized.
First we copy the hsop provided scripts for audit and logging as zipped files in the folder **MicroCloud/audit_logging_automation**.
Currently these files is in the jump server.Later they may be pulled from China Specific artifactory
After zip files are copied, folder structure will be like following
    ```bash
    audit_logging_automation/
    ├── controllers
    ├── generated
    ├── hsopaudit.zip
    ├── hsoplog.zip
    ├── hsplogproxy
    ├── install_audit_manually.sh
    ├── install_audit.sh
    ├── install_logging_manually.sh
    ├── install_logging.sh
    ├── main.py
    ├── models
    ├── services
    ├── templates
    ├── unittests
    └── utils
    ```
2. You need to modify file **install_audit.sh** at location **MicroCloud/audit_logging_automation** in order to provide client requested **oauth client name**, **oauth client password**
and **audit user** information. This information will be used for onboarding the audit user.
In the following snippet of the file install_audit.sh you need to replace values
**'\<add oauth client>', '\<add oauth password>' and '\<add audit user>'**.
    ```bash
      install_audit() {
        unzip -o hsopaudit.zip
        docker load --input ./hsopaudit/binary/release/auditdeployer.tar
        python3.6 main.py -oc <add oauth client> -op <add oauth password> -au <add audit user>
    ```
3. Give executable privilege to the file
   ```bash
    sudo chmod +x install_audit.sh
    ```
4. Run the script from the folder **MicroCloud/audit_logging_automation**
    ```bash
    ./install_audit.sh
    ```
5. **Verification of audit installation using audit_install.sh**
    * If the script run successfully. You should be able to see the smoke test results on console or same could be verified in the log file at location
**MicroCloud/audit_logging_automation/hsopaudit/deploy.log**
    ```bash
    ************************** Verify Response **************************
    Expected Value to be verified in the response= total:1
    ['Pass', 'Response is verified. Verified Text is: total:1']
    
    Verified Headers.   Header Name: Content-Type   and   Header Value: application/json
    Verified Status Code: 200
    
    ************************** Deleting the response file created during runtime **************************
    File is deleted. File Name: AUDIT_QUERY_CORE_FHIR_V3_ACCESS_TOKEN_RESPONSE.json
    
    ########################### Final Test Case Execution Status #################################
    TEST CASE NAME:    AUDIT_QUERY_CORE_FHIR_V3_ACCESS_TOKEN
    EXECUTION STATUS:  PASSED
    API RESPONSE TIME: 0.18686
    ############################### End of Test Case Execution ###################################
    
    EXECUTION SUMMARY:
    ############################################################################## EXECUTION SUMMARY ################################################################################
    
    TEST CASE NAME                          STATUS   RESPONSE TIME   END POINT
    
    =================================================================================================================================================================================
    
    Get Auth Token for CORE Query           PASSED      0.10701      https://iam.somehost/am/authorize/oauth2/token
    
    AUDIT_CREATE_FHIR_V2                    PASSED      0.27342      https://audit-create-hsop-2300.somehost/core/audit/AuditEvent
    
    AUDIT_QUERY_CORE_FHIR_V3_ACCESS_TOKEN   PASSED      0.18686      https://audit-query-hsop-hsdpproduct-2300.somehost/core/audit/AuditEvent/_search?_id=somevalue
    
    =================================================================================================================================================================================
    
    
    
    QUICK SUMMARY
    
    Current UTC TimeStamp:December 07 2020 - 09:48:36
    
    ---------------------------------
    
    TOTAL TEST CASES              :3
    
    TOTAL TEST CASES EXECUTED     :3
    
    TOTAL TEST CASES PASSED       :3
    
    TOTAL TEST CASES FAILED       :0
    
    TOTAL TEST CASES NOT EXECUTED :0

    ```
    **_NOTE:_**  Some times AUDIT_QUERY_CORE_FHIR_V3_ACCESS_TOKEN shows fail but in details it is passed. Look for status 200 in  Verify Response section.

    * A file named **auditautomationconfig.yaml** should be created at path  **MicroCloud/audit_logging_automation/generated/config/**
    This file contains all the details required for creating audit. Make sure following field in this yaml are filled
        1. In yaml field audit->deploy->admin_password
        2. In yaml field audit->deploy->security_org_id.
    
6. This step is specific to ISPM. The audit user created by default does not have admin privileges. The user has to be 
given admin privileges using onboarding apis or self service portal.

7. After successful installation of audit. Logging can be installed. **Note** without audit logging will not be successful.

8. In the directory **MicroCloud/audit_logging_automation** give executable privileges to install_logging.sh
    ```bash
    sudo chmod +x install_logging.sh
    ```
9. From the directory **MicroCloud/audit_logging_automation** run install_logging.sh to install logging
    ```bash
    ./install_logging.sh
    ```
10. **Verification of Logging installation using install_logging.sh**
    * If the script run successfully. You should be able to see the smoke test results on console or same could be verified in the log file at location
**MicroCloud/audit_logging_automation/hsoplog/deploy.log**
    ```bash
       TEST CASE NAME                          STATUS   RESPONSE TIME   END POINT
        
        =================================================================================================================================================================================
        
        GETTENANT-PRODUCTKEY                    PASSED      0.0          https://log-tenantapp-hsop-deploy-2405.somehost/core/log/Tenant/all-tenants
        
        GETDRAINER-URL                          PASSED      0.0          https://log-tenantapp-hsop-deploy-2405.somehost/core/log/Product
        
        GET_AUTH-TOKEN                          PASSED      0.0          https://iam.somehost/am/authorize/oauth2/token
        
        LOGINGESTOR-CORE                        PASSED      0.0          https://logingestor-hsop-deploy-2405.somehost/core/log/LogEvent
        
        DRAINER-APPLOGS                         PASSED      0.0          https://logdrainer-hsop-deploy-2405.somehost/core/log/Product/somevalue
        
        =================================================================================================================================================================================
        
        
        
        QUICK SUMMARY
        
        Current UTC Timestamp:December 07 2020 - 10:25:31---------------------------------
        
        TOTAL TEST CASES              :5
        
        TOTAL TEST CASES EXECUTED     :5
        
        TOTAL TEST CASES PASSED       :5
        
        TOTAL TEST CASES FAILED       :0
        
        TOTAL TEST CASES NOT EXECUTED :0  
    ```
    * A file named **loggingtautomationconfig.yaml** should be created at path  **MicroCloud/audit_logging_automation/generated/config/**
    This file contains all the details required for creating logging. Make sure following field in this yaml is filled
        1. In yaml field logging->deploy->b64_oauth_client_credential
        2. In yaml field logging->deploy->audit_product_key
        3. In yaml field logging->deploy->audit_admin_user
        4. In yaml field logging->deploy->audit_admin_password
        5. In yaml field logging->deploy->security_org_id
        
    * Login into kibana dashboard using credential of the user created after onboarding. Login should be successful.Credential can be taken from **MicroCloud/audit_logging_automation/generated/config/loggingtautomationconfig.yaml**
        ```bash
       deploy:
            audit_admin_user: somevalue
            audit_admin_password: somevalue

        ```
    * You should see two entries in the Kibana dashboard that verifies log event and logdrainer apis. 
        
11. **Installing logproxy to provide logdrain service**

    1. Enter folder **MicroCloud/audit_logging_automation/hsplogproxy**
    2. Run the following commands after modifying parameters as mentioned
        ```bash
        kubectl create ns hsp-logging
        kubectl -n hsp-logging create secret docker-registry regcred --docker-server=<docker registry host> --docker-username=<docker registry username> --docker-password=<docker registry password> --insecure-skip-tls-verify=true
        helm install hsplogproxy --set secret.kms_secret_key=<kms secret key> --set secret.kms_shared_key=<kms shared key> --set secret.secret_key_prefix=<kms secret key prefix> --set secret.tenant_base_url=<tenant base url> --set secret.log_drain_base_url=<logdrain base url> --set secret.product_key=<tenant product key> .
       ```
       1. \<docker registry host>,\<docker registry username> and \<docker registry password> These values can be fetched from  **MicroCloud/audit_logging_automation/generated/loggingautomationconfig.yaml**
           ```bash
            docker:
                        image: logdeployer
                        tag: 1.0
                        docker_registry_url: https://<docker registry host>
                        docker_username: <docker registry username>
                        docker_password: <docker registry password>
                        docker_email_id: 
                        container_name: logdd
                        volumepath:
                            window: 
                            linux: /home/ubuntu/branch/MicroCloud/audit_logging_automation/hsoplog
          ```
       
       2.  \<kms secret key>,\<kms shared key> and \<kms secret key prefix> can also be fetched from **MicroCloud/audit_logging_automation/generated/loggingautomationconfig.yaml**
            ```bash
            deploy:
                        shared_key: <kms shared key>
                        secret_key: <kms secret key>
                        secret_key_prefix: <kms secret key prefix>
            ```
       3. \<tenant base url> and \<logdrain base url> can be fetched as combination of https://log-tenantapp-hsop-deploy-2405.{domain_name} and https://logdrainer-hsop-deploy-2405.{domain_name},{domain_name} can be fetched from **MicroCloud/audit_logging_automation/generated/loggingautomationconfig.yaml**
            ```yaml
            cloud_foundary:
              cf_domain: {domain_name}
            
            ```
       4. \<tenant product key> can be fetched from file **MicroCloud/audit_logging_automation/hsoplog/log_smoke_test/source/config.properties** after successful installation of logging
            ```yaml
            [RUNTIME_PARAMETERS]
            productkey = <tenant product key>
            
            ``` 
    3. Get the nodeport of the logproxy service installed and ip of the k8s node
        ```bash
        kubectl get svc -n hsp-logging
        kubectl get nodes -o wide
        ```
    
    4. Create drain service using following command in the space where logging is required
        ```bash
        cf cups ispm-logdrain-service -l syslog://{node IP}:{Node port of logproxy service}
        ```
    
    5. Cf apps can bind to this service and their logs can seen in kibana.
        ```bash
        cf bind-service spring-music ispm-logdrain-service
        ```

## Debugging and other tips

* Audit installation
  1. Make sure that the following name in the terraform.tfvars.json is not changed and present as it is contracted with the code
      ```yaml
      "cf_admin_password": {
        "sensitive": false,
        "type": "string",
        "value": "somevaule"
      },
       "iam_host": {
        "sensitive": false,
        "type": "string",
        "value": "somevalue"
      },
        "registry_password": {
        "sensitive": false,
        "type": "string",
        "value": "somevalue"
      },
      "registry_server": {
        "sensitive": false,
        "type": "string",
        "value": "somevalue"
      },
      "registry_username": {
        "sensitive": false,
        "type": "string",
        "value": "somevalue"
      },
        "system_domain": {
        "sensitive": false,
        "type": "string",
        "value": "somevalue"
      }
     ```
  2. Once audit is onboarded and python script runs properly. You should not use install_audit.sh but persistinvault.sh and invokedriver.sh at path **MicroCloud/audit_logging_automation/hsopaudit/**. If you use install_audit.sh after onboarding it will complain that user has already been onboarded.
  3. Vault should be unsealed. Following svc should be present in vault namespace 'hashicorp-vault-ui' with nodeport exposed
  4. IaM  should be installed and endpoint reachable
  5. If the python script runs without error and you reach a point where invokedriver.sh is running and after some app installed successfully , some other app fails, in order to save time edit the file **MicroCloud/audit_logging_automation/hsopaudit/DeploymentVault/configurations/release/audit_2300_dev_autoconfig_freshdeployment.json** by toggling few parameters so that installed apps or services do not install again.
      ```yaml
        418         "run_functions":
        419         {
        420                 "01_Create_CF_Services":
        421                 {
        422                         "run_flag": "y"
        423                 },
        424                 "02_Run_Config_Schema":
        425                 {
        426                         "run_flag": "y"
        427                 },
        428                 "03_Run_Audit_Schema":
        429                 {
        430                         "run_flag": "y"
        431                 },
        432                 "04_Deploy_Audit_Create_Service":
        433                 {
        434                         "run_flag": "y"
        435                 },
        436                 "05_Deploy_Audit_Repo_Service":
        437                 {
        438                         "run_flag": "y",
        439                         "pick_product_name_to_deploy": "all"
        440                 },
        441                 "06_Deploy_Audit_Query_Service":
        442                 {
        443                         "run_flag": "y",
        444                         "pick_product_name_to_deploy": "all"
        445                 },
        446                 "07_Deploy_Audit_Admin_Service":
        447                 {
        448                         "run_flag": "y",
        
        ```
      Stop dboperations app from reinstalling
      ```yaml
    
         90                 "push_db_operations_app": "n"
        
        ```
        E.g If Services,Audit schema and config schema are installed you can mark them as following
  
        ```yaml
        418         "run_functions":
        419         {
        420                 "01_Create_CF_Services":
        421                 {
        422                         "run_flag": "n"
        423                 },
        424                 "02_Run_Config_Schema":
        425                 {
        426                         "run_flag": "n"
        427                 },
        428                 "03_Run_Audit_Schema":
        429                 {
        430                         "run_flag": "n"
        431                 },
        432                 "04_Deploy_Audit_Create_Service":
        433                 {
        434                         "run_flag": "y"
        435                 },
        436                 "05_Deploy_Audit_Repo_Service":
        437                 {
        438                         "run_flag": "y",
        439                         "pick_product_name_to_deploy": "all"
        440                 },
        441                 "06_Deploy_Audit_Query_Service":
        442                 {
        443                         "run_flag": "y",
        444                         "pick_product_name_to_deploy": "all"
        445                 },
        446                 "07_Deploy_Audit_Admin_Service":
        447                 {
        448                         "run_flag": "y",
  
   6. After making above changes you need get into folder **MicroCloud/audit_logging_automation/hsopaudit** and run following commands
       ```bash
        ./persistinvault.sh
        ./invokedriver.sh
        ```
   7. If audit schema and logging schema apps are installed it is suggested that they should not be reinstalled. So follow step 4 and 5 to do that
* Logging installation
    1. Please note that audit must install properly. Otherwise logging fails.
    2. install_logging.sh file can be re-run incase of failures. 
    3. If the python script runs without error and you reach a point where invokedriver.sh is running and after some app installed successfully , some other app fails, in order to save time edit the file **MicroCloud/audit_logging_automation/hsoplog/DeploymentVault/configurations/release/log_2405_release_freshdeployment.yaml** by toggling few parameters so that installed apps or services do not install again.
        ```yaml
        372 run_functions:
        373 # Option to Create cf services
        374   01_create_cf_services:
        375     run_flag: y
        376 # Option to Create ES 68 .kibana indexes for hsdp tenant
        377   02_create_elastic_search_index_for_hsdp_tenant:
        378     run_flag: y
        379 # Option to deploy tenant app
        380   03_deploy_tenant_app:
        381     run_flag: y
        382     tenant_docker_repository_name: "logtenant"
        383     tenant_docker_tag: "hsop"
        384 # Option to deploy logingestor app
        385   04_deploy_logingestor_app:
        386     run_flag: y
        387 # Option to deploy logdrainer app
        388   05_deploy_logdrainer_app:
        389     run_flag: y
        390 # Option to deploy logquery app
        391   06_deploy_logquery_app:
        392     run_flag: n
        393 # Option to deploy logadmin app
        394   07_deploy_logadmin_app:
        395     run_flag: n
        396 # Option to deploy kibana app
        397   08_deploy_kibana_app:
        398     run_flag: y
        399 #Option to load and push kibana docker tar file to docker registry
        400     docker_load_and_push_to_repo: "n"
        401 #Kibana docker repo name
        402     kibana_docker_repository_name: "kibana"
        403 #Kibana docker repo tag name
        404     kibana_docker_tag: "hsop"
        405 #Kibana docker tar file name
        406     kibana_docker_tar_file_name: "kibana.tar"
        407 # Option to deploy logstash apps
        408   09_deploy_logstash_apps:
        409     run_flag: y
        410 #logingestor option to push logingestor logstash app
        411     logingestor: "y"
        412 #logdrainer option to push logdrainer logstash app
        413     logdrainer: "y"       
        ```
        E.g If you don't want to install services and 02_create_elastic_search_index_for_hsdp_tenant as it is already installed
  
        ```yaml
        372 run_functions:
        373 # Option to Create cf services
        374   01_create_cf_services:
        375     run_flag: n
        376 # Option to Create ES 68 .kibana indexes for hsdp tenant
        377   02_create_elastic_search_index_for_hsdp_tenant:
        378     run_flag: n
        379 # Option to deploy tenant app
        380   03_deploy_tenant_app:
        381     run_flag: y
        382     tenant_docker_repository_name: "logtenant"
        383     tenant_docker_tag: "hsop"
        384 # Option to deploy logingestor app
        385   04_deploy_logingestor_app:
        386     run_flag: y
        387 # Option to deploy logdrainer app
        388   05_deploy_logdrainer_app:
        389     run_flag: y
        390 # Option to deploy logquery app
        391   06_deploy_logquery_app:
        392     run_flag: n
        393 # Option to deploy logadmin app
        394   07_deploy_logadmin_app:
        395     run_flag: n
        396 # Option to deploy kibana app
        397   08_deploy_kibana_app:
        398     run_flag: y
        399 #Option to load and push kibana docker tar file to docker registry
        400     docker_load_and_push_to_repo: "n"
        401 #Kibana docker repo name
        402     kibana_docker_repository_name: "kibana"
        403 #Kibana docker repo tag name
        404     kibana_docker_tag: "hsop"
        405 #Kibana docker tar file name
        406     kibana_docker_tar_file_name: "kibana.tar"
        407 # Option to deploy logstash apps
        408   09_deploy_logstash_apps:
        409     run_flag: y
        410 #logingestor option to push logingestor logstash app
        411     logingestor: "y"
        412 #logdrainer option to push logdrainer logstash app
        413     logdrainer: "y"       
        ```
   4. After making above changes you need get into folder **MicroCloud/audit_logging_automation/hsoplog** and run following commands
       ```bash
        ./persistinvault.sh
        ./invokedriver.sh
        ```
   