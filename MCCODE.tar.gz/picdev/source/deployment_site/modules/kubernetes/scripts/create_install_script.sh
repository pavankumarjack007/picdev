#! /bin/bash
echo '#! /bin/bash' > ../generated/install_script.sh
echo 'sudo apt-get update' >> ../generated/install_script.sh
chmod +x ../generated/install_script.sh
echo 'sudo apt-get install -y haproxy' >> ../generated/install_script.sh

echo 'echo "frontend stats" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		bind *:8404" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		option http-use-htx" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		http-request use-service prometheus-exporter if { path /metrics }" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		stats enable" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		stats uri /stats" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		stats refresh 30s" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh

echo 'echo "frontend k8s_api_front" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		bind *:6443" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		option tcplog" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		default_backend k8sapi_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "backend k8sapi_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		balance roundrobin" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
#result=$(kubectl get nodes -o wide | grep master | awk '{ print $6 }')
backend="\"		server node0 $1:443 check\""
echo 'echo '$backend' | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh

echo 'echo "frontend forgerock_api_front" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		bind *:32443" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		option tcplog" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		default_backend forgerock_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "backend forgerock_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		balance roundrobin" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		option ssl-hello-chk"| sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh

echo 'echo "frontend cf_api_front" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		bind *:443" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		option tcplog" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		default_backend cf_api_back" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh

echo 'echo "backend cf_api_back" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		mode tcp"| sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		balance roundrobin"| sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		option ssl-hello-chk"| sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
#echo 'echo "        server node0 172.20.35.225:30809 check" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh

#server will be added via dataplane
echo 'echo "frontend ssh_tcp_front" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		bind *:2222" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		option tcplog" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "        default_backend ssh_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh

echo 'echo "backend ssh_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		mode tcp"| sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
echo 'echo "		balance roundrobin"| sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh
#echo 'echo "        server node0 172.20.35.225:30549 check" | sudo tee -a /etc/haproxy/haproxy.cfg' >> ../generated/install_script.sh

echo 'sudo systemctl restart haproxy' >> ../generated/install_script.sh

echo '(' >> ../generated/install_script.sh
echo 'mkdir -p /home/ubuntu/haproxy_dataplane' >> ../generated/install_script.sh
echo 'cd /home/ubuntu/haproxy_dataplane' >> ../generated/install_script.sh
echo "echo $PWD" >> 1.txt
echo 'sudo wget https://github.com/haproxytech/dataplaneapi/releases/download/v2.3.4/dataplaneapi_2.3.4_Linux_x86_64.tar.gz -P /home/ubuntu/haproxy_dataplane' >> ../generated/install_script.sh
echo 'sudo tar -zxvf /home/ubuntu/haproxy_dataplane/dataplaneapi_2.3.4_Linux_x86_64.tar.gz --directory /home/ubuntu/haproxy_dataplane' >> ../generated/install_script.sh
echo 'chmod +x /home/ubuntu/haproxy_dataplane/build/dataplaneapi' >> ../generated/install_script.sh
echo 'sudo cp /home/ubuntu/haproxy_dataplane/build/dataplaneapi /usr/local/bin/' >> ../generated/install_script.sh
echo 'sudo dataplaneapi -f /home/ubuntu/dataplaneapi.hcl' >> ../generated/install_script.sh
echo ')' >> ../generated/install_script.sh

echo 'sudo apt-get update' >> ../generated/install_script.sh
echo 'sudo apt-get install -y prometheus-node-exporter' >> ../generated/install_script.sh

