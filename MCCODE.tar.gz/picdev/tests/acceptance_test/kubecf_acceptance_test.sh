#!/bin/bash
kubectl get qjob --namespace kubecf --output name 2> /dev/null | grep acceptance
kubectl patch quarksjob.quarks.cloudfoundry.org/acceptance-tests --namespace kubecf --type merge --patch '{ "spec": { "trigger": { "strategy": "now" } } }'
echo "Starting acceptance test..."
sleep 20 #wait pod to start
pods=$(kubectl get pods -n kubecf -o=jsonpath='{range .items..metadata}{.name}{"\n"}{end}' | grep acceptance)
pod_name=$(echo $pods | cut -d' ' -f1)
# check_pod_state if completed then, continue or wait till completion. Timeout at 3600 sec
function check_pod_state() {
        status=NA
        while [[ $status != *"Completed"* ]]; do
        status=$(kubectl get pods $pod_name -n kubecf)
          echo "Waiting for test to complete"
          sleep 60
          total_time=$(($total_time+60))
          if (($total_time > 5400)); then
                echo 'KubeCF acceptance test did not complete in required time'
                return 1
          fi
        done
}
check_pod_state
now=$(date +'%Y-%m-%d-%H-%M-%S')
kubectl logs -f $pod_name --namespace kubecf --container acceptance-tests-acceptance-tests >> kubecf_acceptance_result-${now}.txt
kubectl delete pod $pod_name --namespace kubecf
