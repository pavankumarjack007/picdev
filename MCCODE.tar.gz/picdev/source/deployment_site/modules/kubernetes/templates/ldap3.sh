      sudo sed -i 's/case "" in/case "$flag" in/g' /tmp/ldap.sh
      sudo sed -i 's/uri=/uri=${OPTARG}/g' /tmp/ldap.sh
      sudo sed -i 's/binddn=/binddn=${OPTARG}/g' /tmp/ldap.sh
      sudo sed -i 's/bindpw=/bindpw=${OPTARG}/g' /tmp/ldap.sh
      sudo sed -i 's/searchbase=/searchbase=${OPTARG}/g' /tmp/ldap.sh
      sudo sed -i -z 's/uri/uri $uri/2' /tmp/ldap.sh
      sudo sed -i -z 's/base/base $searchbase/2' /tmp/ldap.sh
      sudo sed -i -z 's/binddn/binddn $binddn/2' /tmp/ldap.sh
      sudo sed -i -z 's/bindpw/bindpw $bindpw/2' /tmp/ldap.sh
