import graphene


class Subnet(graphene.ObjectType):
    identifier = graphene.String()

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_identifier(group, _):
        return None
