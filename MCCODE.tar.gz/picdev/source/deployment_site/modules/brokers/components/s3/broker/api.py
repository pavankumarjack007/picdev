from functools import wraps

from flask import Blueprint, Response, abort, current_app, g, redirect, request

from broker import cloudfoundry
from .graphql_view import verify_api_keys

controller = Blueprint("api", __name__, url_prefix="/api")


def verify_bucket_id(func):
    @wraps(func)
    def wrapper(instance_id, *args, **kwargs):
        if not g.service.instance_details(instance_id):
            return abort(404, "Bucket not found")

        permissions = g.cc.instance_permissions(instance_id)
        if not permissions.can_manage_instance:
            return abort(
                403,
                "The logged in account does not have permission to manage "
                "this service instance.",
            )

        return func(instance_id, *args, **kwargs)

    return wrapper


@controller.before_request
def before_request():
    if current_app.config["BROKER_USE_SSL"] and not request.is_secure:
        url = request.url.replace("http://", "https://", 1)
        return redirect(url, code=302)

    g.service = current_app.service_class

    cc_args = current_app.global_config.cc_config.copy()
    cc_args.update({"access_token": request.headers["X-User-Access-Token"]})
    g.cc = cloudfoundry.CloudController.new_instance(**cc_args)

    return verify_api_keys(current_app)


@controller.route("/instances/<instance_id>/objects/<path:object_key>")
@verify_bucket_id
def show_instance_object(instance_id, object_key):
    bucket = g.service.instance_details(instance_id)
    res = bucket.get_object(object_key)
    if res["ContentLength"] > current_app.config["MAX_DOWNLOAD_SIZE"]:
        return abort(
            403, "Size of object is greater than " "max allowed download size."
        )
    content_type = request.args.get("format", None)
    if "text" == content_type:
        content_type = "text/plain"
    else:
        content_type = res.get("ContentType", "text/plain")

    def stream_response(stream, size):
        chunk = stream.read(size)
        while chunk:
            yield chunk
            chunk = stream.read(size)

    return Response(stream_response(res["Body"], 2048), content_type=content_type)
