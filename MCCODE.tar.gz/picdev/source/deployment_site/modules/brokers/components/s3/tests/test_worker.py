from mock import Mock
from moto import mock_dynamodb2
from nose.tools import assert_equal

from broker.model import get_broker_model
from broker.worker import create_worker
from tests import test_config, test_data


@mock_dynamodb2
def test_when_deleted_attribute_is_true():
    model = get_broker_model(test_config)
    record = model.new_record(**test_data())
    record.deleted = True
    record.save()
    mock_service = Mock()
    mock_service.model = model
    mock_service.delete_instance = Mock()
    create_worker("testing", service=mock_service)
    assert_equal(mock_service.delete_instance.call_count, 1)


@mock_dynamodb2
def test_when_deleted_attribute_is_false():
    model = get_broker_model(test_config)
    record = model.new_record(**test_data())
    record.save()
    mock_service = Mock()
    mock_service.model = model
    mock_service.delete_instance = Mock()
    create_worker("testing", service=mock_service)
    assert_equal(mock_service.delete_instance.call_count, 0)
