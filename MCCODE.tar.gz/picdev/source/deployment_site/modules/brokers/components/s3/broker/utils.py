import datetime
import json
import random
import string

from .crypt import crypt

IV_LENGTH = 16


def generate_iv():
    return crypt.generate_iv()[:IV_LENGTH]


def encrypt_data(data, key, iv=None):
    init_vector = iv or generate_iv()
    with crypt(iv=init_vector, key=key) as c:
        encrypted_data = c.encrypt(data)
    if iv is None:
        return init_vector + encrypted_data.decode("utf-8")
    else:
        return encrypted_data.decode("utf-8")


def decrypt_data(data, key, iv=None):
    if iv is None:
        init_vector = data[:IV_LENGTH]
        encrypted_data = data[IV_LENGTH:]
    else:
        init_vector = iv
        encrypted_data = data
    with crypt(iv=init_vector, key=key) as c:
        decrypted_data = c.decrypt(encrypted_data.encode("utf-8"))
    return decrypted_data


class Memoize(object):
    separator = object()  # Sentinel for separating args from kwargs.

    def __init__(self, func):
        self.func = func
        self.memo = {}

    def __call__(self, *args, **kwargs):
        key = args + (Memoize.separator,) + tuple(sorted(kwargs.items()))
        if key not in self.memo:
            return_value = self.func(*args, **kwargs)
            if return_value:
                self.memo[key] = return_value
        return self.memo.get(key)


class CustomJSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (datetime, datetime.date)):
            return o.isoformat()
        return super(CustomJSONEncoder, self).default(o)


def json_dumps(obj, **kwargs):
    return json.dumps(obj, cls=CustomJSONEncoder, **kwargs)


def generate_password(num_bytes):
    chars = string.ascii_letters + string.digits
    return "".join(random.SystemRandom().choice(chars) for _ in range(num_bytes))
