import boto
import os
from boto.s3.connection import S3Connection
import boto3
import pytest


@pytest.mark.sat
def test_verify_bucket_available():
    conn = boto.s3.connect_to_region(os.environ['AWS_REGION'],
                                     aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
                                     aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'],
                                     calling_format=boto.s3.connection.OrdinaryCallingFormat())
    buckets = conn.get_all_buckets()
    print(buckets)


@pytest.mark.sat
def test_verify_outposts_available():
    client = boto3.client('outposts')
    response = client.list_outposts()
    print(response)
    assert "eu-central-1" in str(response)
