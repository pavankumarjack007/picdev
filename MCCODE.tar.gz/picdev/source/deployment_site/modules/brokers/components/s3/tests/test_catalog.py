from nose.tools import assert_equal

from broker import manip_catalog


def test_regional_guid_differences():
    service = manip_catalog("us-west-2")[0]
    assert_equal(service["id"], "da215457-67ce-4916-b0ab-47420161d654")
    us_standard_plan = next(
        plan for plan in service["plans"] if plan["name"] == "US Standard"
    )
    assert_equal(us_standard_plan["id"], "ab439663-d84a-4cde-a031-1fe860ff529f")
    # Region `us-east-1` has anomalous guids for S3 Service and `US Standard` plan.
    service = manip_catalog("us-east-1")[0]
    assert_equal(service["id"], "906c102e-8cc7-41da-b06c-bf1df782cd6c")
    us_standard_plan = next(
        plan for plan in service["plans"] if plan["name"] == "US Standard"
    )
    assert_equal(us_standard_plan["id"], "22b29b79-e6a2-4d71-bc10-e030f9f2719d")


def test_china_region_exposes_single_plan():
    service = manip_catalog("cn-north-1")[0]
    assert_equal(len(service["plans"]), 1)
    assert_equal(service["plans"][0]["name"], "s3_bucket")
