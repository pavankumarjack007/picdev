#!/bin/bash
# Only for internal use. Parameterize and use it for image movements.

TAG=v2.1
SOURCE_REPO=docker.na1.hsdp.io/eng-foundationcore_devteam
DEST_REPO=docker.na1.hsdp.io/eng-hsop

for img in broker-prometheus:test hsdp-prometheus-sd-worker:test1 cfsb-cf-exporter:test alertmanager:test sachet:test cfsb-configmap-reload:test cf-space-exporter:test1 autoscaler-engine:test console-frontend:test4 console-backend:auto hsdp-metrics:ngx
do

docker --config /root/.docker/config-foundationcore pull ${SOURCE_REPO}/${img}
  docker tag ${SOURCE_REPO}/${img} ${DEST_REPO}/${img%%:*}:${TAG}
 
  echo "Source : " ${SOURCE_REPO}/${img} "Destination : " ${DEST_REPO}/${img%%:*}:${TAG}
  docker --config /root/.docker/config-eng-hsop  push ${DEST_REPO}/${img%%:*}:${TAG}
  docker rmi -f ${SOURCE_REPO}/${img} ${DEST_REPO}/${img%%:*}:${TAG}
done
