from flask import Blueprint, current_app, redirect

controller = Blueprint("dashboard", __name__, url_prefix="/dashboard")


@controller.route("/manage/<instance_id>", methods=["GET"])
def manage_instance(instance_id):
    return redirect(current_app.config["CONSOLE_URL"] + "/s3/manage/" + instance_id)


@controller.route("/", defaults={"path": ""})
@controller.route("/<path:path>")
def index(path):
    return redirect(current_app.config["CONSOLE_URL"])
