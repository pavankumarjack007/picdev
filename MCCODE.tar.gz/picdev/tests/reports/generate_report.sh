#!/bin/bash
now=$(date +'%Y-%m-%d-%H-%M-%S')
cat ../smoke/k8s_smoke_result_*.txt ../smoke/kubecf_smoke_result*.txt >test_result_${now}.txt
./text2pdf   ./test_result_${now}.txt >test_result_${now}.pdf
