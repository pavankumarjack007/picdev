import time

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver import ActionChains
from utilities.custom_Logger import LogGen


class LoginPage:
    logger = LogGen.loggen()
    textbox_username_xpath = "//input[@name='username']"
    textbox_password_xpath = "//input[@name='password']"
    button_sign_in_xpath = "//input[@value='Sign in']"
    link_metrics_link_text = "Metrics"
    hsop_brokers_link_text = "hsop - brokers"
    hsop_services_link_text = "hsop - services"
    link_alerts_xpath = "//a[@class='btn btn-primary btn-sm ml-auto']"
    button_add_alerts_xpath = "//button[@class='btn btn-success btn-sm mt-0 ml-3']"
    select_rule_id = "ruleType"
    name_description_id = "ruleName"
    threshold_value_xpath = "//input[@type='selectedRule.rule.threshold.type']"
    duration_id = "ruleDuration"
    severity_id = "ruleSeverity"
    for_app_xpath = "//*//button[contains(text(), 'All Instances')]"
    for_app_select_xpath = "//div[@option='spring-music']"
    for_status_code = "//*//button[contains(text(), 'All Status Codes')]"
    for_status_option = "//div[@option='3XX']"
    add_button = "//span[@class='ladda-label']"
    threshold_cpu = "//div[@class='vue-slider-dot-handle']"
    clear_all = "//*//div[contains(text(), 'Clear All')]"
    choose_an_app = "//*//button[contains(text(), 'Choose an application')]"
    spring_music = "//*//label[contains(text(), 'spring-music')]"
    hsdp_RDS = "//*[@id='manageInstanceCharts']/nav/ul/li[2]/a"
    All_dropdown = "//*[@id='__BVID__72__BV_toggle_']/span"
    All_dropdown_brokers = "//button[@class='btn dropdown-toggle btn-secondary btn-sm']"
    hsdp_Redis = "//*[@id='manageInstanceCharts']/nav/ul/li[3]/a"
    rds_redis_elements_present = "//ul[@class='dropdown-menu show']"
    edit_button = "//tr[1]/td[9]/button[1]/i[@class='fas fa-edit']"
    save_button = "//*/span[contains(text(), 'Save')]"
    alert_not_active = "//*/tr[1]/td[1]/i[@class='fas fa-times-circle']"
    alert_healthy = "//*/tr[1]/td[1]/i[@class='fas fa-check-circle']"
    alert_pending = "//*/tr[1]/td[1]/i[@class='fas fa-exclamation-triangle']"
    alert_firing = "//*/tr[1]/td[1]/i[@class='fas fa-exclamation-circle']"
    delete_button = "//*/tr[1]/td[9]/button/i[@class='fas fa-trash']"
    delete_danger_button = "btn btn-danger"
    philips_hsdp = "//*[@id='app']/header/a"
    sing_in_outlook = "//nav//a[text()='Sign in']"
    email_outlook_xpath = "input#i0116"
    password_outlook_xpath = "input#i0118"
    next_button_outlook = "input#idSIButton9"
    search_outlook = "//input[@aria-label='Search']"
    search_button_outlook = "//i[@data-icon-name='Search']"
    open_message = "//div[@class='pz2Jt yo8hs']"
    message_verification = "//td[@class='x_alert x_alert-warning']"

    def __init__(self, driver):
        self.driver = driver

    def loginCred(self, username, password):
        self.driver.find_element(By.XPATH, self.textbox_username_xpath).clear()
        self.driver.find_element(By.XPATH, self.textbox_username_xpath).send_keys(username)
        self.driver.find_element(By.XPATH, self.textbox_password_xpath).clear()
        self.driver.find_element(By.XPATH, self.textbox_password_xpath).send_keys(password)
        self.driver.implicitly_wait(5)
        self.driver.find_element(By.XPATH, self.button_sign_in_xpath).click()
        self.driver.find_element(By.LINK_TEXT, self.link_metrics_link_text).click()
        self.driver.find_element(By.LINK_TEXT, self.hsop_brokers_link_text).click()
        self.driver.find_element(By.XPATH, self.clear_all).click()
        self.driver.find_element(By.XPATH, self.choose_an_app).click()
        self.driver.find_element(By.XPATH, self.spring_music).click()
        self.driver.find_element(By.XPATH, self.link_alerts_xpath).click()

    def loginCredbench(self, username, password):
        self.driver.find_element(By.XPATH, self.textbox_username_xpath).clear()
        self.driver.find_element(By.XPATH, self.textbox_username_xpath).send_keys(username)
        self.driver.find_element(By.XPATH, self.textbox_password_xpath).clear()
        self.driver.find_element(By.XPATH, self.textbox_password_xpath).send_keys(password)
        self.driver.implicitly_wait(5)
        self.driver.find_element(By.XPATH, self.button_sign_in_xpath).click()
        self.driver.find_element(By.LINK_TEXT, self.link_metrics_link_text).click()

    def hsopServices(self):
        self.driver.find_element(By.LINK_TEXT, self.hsop_services_link_text).click()
        time.sleep(5)
        self.driver.find_element(By.XPATH, self.hsdp_RDS).click()
        self.driver.find_element(By.XPATH, self.All_dropdown).click()

    def hsopBrokers(self):
        self.driver.find_element(By.XPATH, self.philips_hsdp).click()
        self.driver.find_element(By.LINK_TEXT, self.link_metrics_link_text).click()
        self.driver.find_element(By.LINK_TEXT, self.hsop_brokers_link_text).click()
        time.sleep(4)
        self.driver.find_element(By.XPATH, self.hsdp_RDS).click()
        time.sleep(5)
        self.driver.find_element(By.XPATH, self.All_dropdown_brokers).click()

    def saveEdit(self):
        self.driver.find_element(By.XPATH, self.edit_button).click()
        self.driver.find_element(By.XPATH, self.save_button).click()

    def verifyRDSRedis(self):
        RDS = self.driver.find_elements(By.XPATH, self.rds_redis_elements_present)
        for r in RDS:
            return r.text

    def redisclickServices(self):
        self.driver.find_element(By.XPATH, self.hsdp_Redis).click()
        self.driver.find_element(By.XPATH, self.All_dropdown).click()
        self.driver.implicitly_wait(3)

    def selectSpecificRule(self, index):
        self.driver.find_element(By.XPATH, self.button_add_alerts_xpath).click()
        self.driver.find_element(By.ID, self.select_rule_id).click()
        select_rule = Select(self.driver.find_element(By.ID, self.select_rule_id))
        select_rule.select_by_index(index)

    def giveDescription(self, rule_description):
        self.driver.find_element(By.ID, self.name_description_id).send_keys(rule_description)

    def thersholdValue(self, threshold):
        self.driver.find_element(By.XPATH, self.threshold_value_xpath).clear()
        self.driver.find_element(By.XPATH, self.threshold_value_xpath).clear()
        self.driver.find_element(By.XPATH, self.threshold_value_xpath).send_keys(threshold)

    def thersholdforCPU(self):
        element = self.driver.find_element(By.XPATH, self.threshold_cpu)
        ActionChains(self.driver).drag_and_drop_by_offset(element, -300, 0).perform()

    def durationseverityValue(self, index_sev, index_dur):
        self.driver.find_element(By.ID, self.severity_id).click()
        select_rule = Select(self.driver.find_element(By.ID, self.severity_id))
        select_rule.select_by_index(index_sev)
        self.driver.find_element(By.ID, self.duration_id).click()
        select_rule = Select(self.driver.find_element(By.ID, self.duration_id))
        select_rule.select_by_index(index_dur)

    def forInstances(self):
        self.driver.find_element(By.XPATH, self.for_app_xpath).click()
        WebDriverWait(self.driver, 5).until(EC.element_to_be_clickable((By.XPATH, self.for_app_select_xpath))).click()
        self.driver.find_element(By.XPATH, self.add_button).click()

    def forcodeStatus(self):
        self.driver.find_element(By.XPATH, self.for_status_code).click()
        self.driver.find_element(By.XPATH, self.for_status_option).click()

    def deleteButton(self):
        self.driver.find_element(By.XPATH, self.delete_button).click()
        self.driver.find_element(By.CLASS_NAME, self.delete_danger_button).click()

    def alertStates(self):
        try:
            element_not_active = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.XPATH, self.alert_not_active)))
            element_healthy = WebDriverWait(self.driver, 60).until(
                EC.presence_of_element_located((By.XPATH, self.alert_healthy)))
            element_pending = WebDriverWait(self.driver, 60).until(
                EC.presence_of_element_located((By.XPATH, self.alert_pending)))
            element_firing = WebDriverWait(self.driver, 60).until(
                EC.presence_of_element_located((By.XPATH, self.alert_firing)))
            if element_not_active:
                assert True
            elif element_healthy:
                assert True
            elif element_pending:
                assert True
            elif element_firing:
                assert True
        except TimeoutException:
            self.logger.info("Loading took too much time!")

    def outlookLogin(self, email_ID, password_outlook, search_elements_outlook):
        self.driver.implicitly_wait(15)
        self.driver.find_element(By.XPATH, self.sing_in_outlook).click()
        self.driver.find_element(By.CSS_SELECTOR, self.email_outlook_xpath).send_keys(email_ID)
        self.driver.find_element(By.CSS_SELECTOR, self.next_button_outlook).click()
        self.driver.find_element(By.CSS_SELECTOR, self.password_outlook_xpath).send_keys(password_outlook)
        time.sleep(2)
        self.driver.find_element(By.CSS_SELECTOR, self.next_button_outlook).click()
        time.sleep(2)
        self.driver.find_element(By.CSS_SELECTOR, self.next_button_outlook).click()
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.search_outlook).send_keys(search_elements_outlook)
        self.driver.find_element(By.XPATH, self.search_button_outlook).click()
        self.driver.find_element(By.XPATH, self.open_message).click()

    def verifymessageEmail(self):
        text = self.driver.find_element(By.XPATH, self.message_verification).text
        self.logger.info(text)
        return text
