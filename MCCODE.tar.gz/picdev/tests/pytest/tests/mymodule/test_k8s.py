import pytest
import os
import paramiko
import json
import base64

from tests.pytest.tests.conftest import cluster_name


@pytest.mark.sat
def test_verify_node_count():
    output = os.popen('kubectl get nodes | wc -l').read()
    assert int(output) > 4
    print(str(output))

@pytest.mark.sat
def test_verify_node_status():
    output = os.popen('kubectl get nodes | grep Ready | wc -l').read()
    assert int(output) > 3
    print(str(output))

@pytest.mark.sat
def test_verify_k8s_version():
    output = os.popen('kubectl get nodes | awk {\'print $5\'} | tail -1').read()
    assert "v1.21.5" in str(output)
    print(output)

@pytest.mark.sat
def test_897421_897423_verify_multi_master():
    url = cluster_name[3:]
    ha_url = "api.cf" + url
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=ha_url, username="ubuntu", key_filename="pem-key.pem")
    ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command("cat /etc/haproxy/haproxy.cfg | grep -v default | grep \"backend k8sapi_tcp_back\" -A 5 | grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | sort")
    ssh_output = ssh_stdout.read().decode('ascii')
    ssh.close()
    master_nodes = os.popen('kubectl get nodes -o wide | grep master | awk {\'print $6\'} | sort').read()
    master_node_count = os.popen('kubectl get nodes | grep master | wc -l').read()
    assert master_nodes in ssh_output
    print("Nodes from HA: ", ssh_output)
    print("Nodes from k8s: ", master_nodes)
    if int(master_node_count) > 2:
        print("This is multi master deployment")
        # Delete a Master node
        # Wait and verify that a new master node comes
        # Verify new IP in haproxy


@pytest.mark.sat
def test_913174_verify_eck_operator_version():
    output = os.popen('kubectl get statefulset.apps/elastic-operator -o yaml -n managed-es | grep eck-operator:1.9.1').read()
    assert "docker.na1.hsdp.io/eng-hsop/eck-operator:1.9.1" in str(output)
    print(output)
