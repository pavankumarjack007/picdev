import base64
import binascii
import hashlib
import os
import random
import string


def generate_resource_id():
    # Generate a random 8-char hex string used to name Kubernetes resources
    return bytes.decode(binascii.b2a_hex(os.urandom(4)))


def generate_password(num_bytes):
    # Generate a random string suitable for passing to the shell without
    # quoting/escaping
    chars = string.ascii_letters + string.digits
    return ''.join(random.SystemRandom().choice(chars)
                   for _ in range(num_bytes))


def hash_password(password):
    # Convert the password to hash per:
    # https://www.rabbitmq.com/passwords.html#computing-password-hash  # noqa: E501
    pw = str(password)
    salt = os.urandom(4)
    encoded = salt + pw.encode('utf-8')
    salted_hash = salt + hashlib.sha256(encoded).digest()
    password_hash = base64.b64encode(salted_hash)
    return password_hash.decode('utf-8')
