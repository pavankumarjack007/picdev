package testframe

type TestCaseDefintion struct {
	TestName          string                 `hcl:"name"`      //`json:"testname"`
	Modulepath        string                 `hcl:"module"`    //`json:"modulepath`
	In_params_values  map[string]interface{} `hcl:"inparams"`  //`json:"in_params_values`
	Out_params_values map[string]interface{} `hcl:"outparams"` //`json:"out_params_values"`
}

type AllTestCaseDefintion struct {
	AllTestCases []TestCaseDefintion `hcl:"allTestCases,block"` //`json:"catlog_nodes"`

}

type ValidationType string

const (
	TFOut = "TFOut"
	SSH   = "SSH"
	HTTP  = "HTTP"
	K8S   = "K8S"
)

type Validation_Case struct {
	Input_params    map[string]interface{}
	Output_params   map[string]interface{}
	Validation_type ValidationType
}

type Test_Case struct {
	Name              string
	Module_path       string
	Input_params_file string
	Validations       []Validation_Case
}

type AllTestCases struct {
	AllTestCases []Test_Case
}
