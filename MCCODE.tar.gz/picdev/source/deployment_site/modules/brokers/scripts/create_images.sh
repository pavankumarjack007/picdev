#! /bin/bash

if [[ $# -lt 5 && $# -gt 0 ]]
  then
    echo $'\nSample invocation of the script looks as follows:\n\n./create_images.sh registry_hostname registry_prefix registry_username registry_password plat_version pip_extra_index_url(optional, read below)'
    echo $'\nUSAGE: The script needs docker version 18 or above. Give the following six arguments in order. The sixth argument is optional and needed only when the pip_extra_index_url needs to be added to the requirements file by the script'
    echo $'\nArguments:\n'
    echo $'1.app_registry_hostname(docker.na1.hsdp.io)\n2.app_registry_repository_prefix(eng-hsop)\n3.app_registry_username\n4.app_registry_password\n5.platform_version(v2.1)\n6.pip_extra_index_url(ex:https://deploy:*******@pip.cloud.pcftest.com/pypi)(optional, read above)\n'
    echo $'the script can be triggered without any arguments if the above values are already present in the environment.'
    exit
fi

app_registry_hostname=$1
app_registry_repository_prefix=$2
app_registry_username=$3
app_registry_password=$4
platform_version=$5
extra_index_url=$6


export HSOP_VERSION=$(cat ../../../version.txt)
app_registry_hostname=${app_registry_hostname:=$APP_REGISTRY_HOSTNAME}
app_registry_repository_prefix=${app_registry_repository_prefix:=$APP_REGISTRY_REPOSITORY_PREFIX}
app_registry_username=${app_registry_username:=$APP_REGISTRY_USERNAME}
app_registry_password=${app_registry_password:=$APP_REGISTRY_PASSWORD}
platform_version=${platform_version:=$HSOP_VERSION}
extra_index_url=${extra_index_url:=$PIP_EXTRA_INDEX_URL}

#echo $app_registry_hostname $app_registry_repository_prefix $app_registry_username $app_registry_password $platform_version $extra_index_url

echo $app_registry_password | docker login --username $app_registry_username --password-stdin $app_registry_hostname
pwd=`pwd`

while IFS="" read -r LINE;
do
  [[ $LINE = \#* ]] && continue
  folder_path=$(echo $LINE | awk '{print $1}')
  image_name=$(echo $LINE | awk '{print $2}')
  docker_file=$(echo $LINE | awk '{print $3}')
  if [[ -z $docker_file ]]
    then
      docker_file=Dockerfile
  fi
  
  echo $'\n\n'
  printf '%s\n' "$LINE"
  echo $folder_path $image_name $docker_file
  echo "Building and pushing $app_registry_hostname/$app_registry_repository_prefix/$image_name:$platform_version"
  echo 
  cd $folder_path
  if [[ $args==6 ]]
    then
      echo --extra-index-url=${extra_index_url} | cat - requirements.txt > /tmp/out && mv /tmp/out requirements.txt
  fi

  docker build -f $docker_file . -t $app_registry_hostname/$app_registry_repository_prefix/$image_name:$platform_version
  docker push $app_registry_hostname/$app_registry_repository_prefix/$image_name:$platform_version

# If there is a need to remove the pip_extra_index_url after pushing the imags, then uncomment the below line
#  sed -i '1d' requirements.txt

  cd $pwd
done < images.txt
