#!/bin/bash

# Read README.md file

docker_login=xxxxxxxx
docker_password="xxxxxxx"
docker_registry='xxxxxxxxx'
docker_registry_directory="xxxxxxxxx"

echo $docker_password | docker login $docker_registry --username $docker_login --password-stdin

# collect all images available in system
docker images > /tmp/docker_images.txt

sed -i '1d' /tmp/docker_images.txt 

#combine firt two columnets i.e imagename and tag
awk '{ print $1 ":" $2 }' /tmp/docker_images.txt > /tmp/images_final_list.txt

#tag and push all docker images to registry
for i in `cat /tmp/images_final_list.txt`
do
        echo "======================================================"
        docker tag $i $docker_registry/$docker_registry_directory/$i
        echo "pushing docker image $i"
        docker push $docker_registry/$docker_registry_directory/$i
        echo "======================================================"
done

