#!/bin/bash

# Check if the cert-manager crds are created
num_crds="6"
while : ; do
  echo "Checking if all cert-manager crds are available"
  result=$(kubectl get crd -o custom-columns=":metadata.name" | grep .cert-manager.io | wc -l)
  echo "Expecting $num_crds .. Current $result"
  if [[ "$result" == "$num_crds" ]]
  then
    break
  fi
  sleep 10
done