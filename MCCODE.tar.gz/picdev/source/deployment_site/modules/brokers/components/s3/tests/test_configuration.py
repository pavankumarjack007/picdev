from nose.tools import assert_equal

from config import Config


def test_default_addtl_aws_credentials_is_an_empty_array():
    config = Config()
    config.ADDTL_AWS_ACCESS_KEY_IDS = ""
    config.ADDTL_AWS_SECRET_ACCESS_KEYS = ""
    assert_equal(config.addtl_aws_credentials, [])


def test_single_addtl_aws_credentials():
    config = Config()
    config.ADDTL_AWS_ACCESS_KEY_IDS = "access_key_id"
    config.ADDTL_AWS_SECRET_ACCESS_KEYS = "secret_access_key"
    expected_addtl_aws_credentials = [
        {
            "aws_access_key_id": "access_key_id",
            "aws_secret_access_key": "secret_access_key",
        }
    ]
    assert_equal(config.addtl_aws_credentials, expected_addtl_aws_credentials)


def test_multiple_addtl_aws_credentials():
    config = Config()
    config.ADDTL_AWS_ACCESS_KEY_IDS = "access_key_id1,access_key_id2"
    config.ADDTL_AWS_SECRET_ACCESS_KEYS = "secret_access_key1,secret_access_key2"
    expected_addtl_aws_credentials = [
        {
            "aws_access_key_id": "access_key_id1",
            "aws_secret_access_key": "secret_access_key1",
        },
        {
            "aws_access_key_id": "access_key_id2",
            "aws_secret_access_key": "secret_access_key2",
        },
    ]
    assert_equal(config.addtl_aws_credentials, expected_addtl_aws_credentials)


def test_logging_blacklist():
    config = Config()
    # Default
    config.LOGGING_BLACKLIST = ""
    assert_equal(config.logging_config["blacklist"], [])
    # Single
    config.LOGGING_BLACKLIST = "do-not-log.1"
    assert_equal(config.logging_config["blacklist"], ["do-not-log.1"])
    # Multiple
    config.LOGGING_BLACKLIST = "do-not-log.1,do-not-log.2"
    assert_equal(config.logging_config["blacklist"], ["do-not-log.1", "do-not-log.2"])
