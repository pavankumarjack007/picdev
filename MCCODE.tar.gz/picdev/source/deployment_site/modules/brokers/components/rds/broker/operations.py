import logging
import json
import base64
from distutils.util import strtobool

from broker.deployment import (
    UpdateMySQLDeployment,
    UpdatePostgresDeployment,
    DeleteMySQLDeployment,
    DeleteMySQLDeploymentMonitoring,
    DeletePostgresDeployment,
    DeletePostgresDeploymentMonitoring,
    MySQLDeployment,
    MySQLDeploymentWithMonitoring,
    PostgresDeployment,
    PostgresDeploymentWithMonitoring,
)
from broker.k8s import KubernetesClient
from broker.utils import decrypt_data


class OpState(object):
    NOT_STARTED = "not started"
    IN_PROGRESS = "in progress"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class BaseOperation(object):
    def __init__(self, status=None, description=None):
        self.action = self.__class__.__name__
        self.status = status or OpState.IN_PROGRESS
        self.description = description
        self.description = description


class Provision(BaseOperation):
    def __init__(self, config):
        super().__init__()
        self.log = logging.getLogger(__name__)
        self.config = config
        self.client = KubernetesClient(
            config.K8S_API_ENDPOINT, config.K8S_CACERT, config.K8S_BROKER_TOKEN
        )

    def env_map(self, service_record):
        return {
            "CF_INSTANCE_ID": service_record.instance_id,
            "CF_ORG_ID": service_record.organization_guid,
            "CF_PLAN_ID": service_record.plan_id,
            "CF_SPACE_ID": service_record.space_guid,
            "DOCKER_PASSWORD": self.config.DOCKER_REGISTRY_PASSWORD,
            "DOCKER_SERVER": self.config.DOCKER_REGISTRY_HOST,
            "DOCKER_USERNAME": self.config.DOCKER_REGISTRY_USER,
            "NAMESPACE": self.config.K8S_BROKER_NAMESPACE,
            **self.config.static_env,
        }

    def create_namespace(self, service_record):
        self.client.create_namespace(service_record.service_namespace)

    def create_service(self, service_record, engine):
        try:
            deployment = new_instance(
                self.config, self.client, service_record, engine, False
            )
            deployment.deploy()
        except Exception as e:
            logging.error(f"Error in provisioning resource {e}")
            service_record.delete()
            raise e

    def restore_snapshot(self, service_record, engine, backup_name):
        try:
            deployment = new_instance(
                self.config, self.client, service_record, engine, False
            )
            deployment.restore_snapshot(backup_name)
        except Exception as e:
            logging.error(f"Error in provisioning resource {e}")
            service_record.delete()
            raise e

    def ca_certificate(self, service_record):
        return self.client.read_from_secret(
            service_record.service_namespace, "root-db-secret", "ca.crt"
        )
    
    def state(self, service_record):
        pod_status = self.client.pod_status(
            service_record.service_namespace, service_record.service_name
        )
        state = OpState.SUCCEEDED
        if pod_status == "Pending":
            state = OpState.IN_PROGRESS
        elif pod_status == "Failed":
            state = OpState.FAILED
        return state

    def restore_state(self, service_record):
        restore_status = self.client.velero_restore_status(
            f"{service_record.instance_name}-{service_record.instance_id}"
        )
        logging.info(f"restore_status: {restore_status}")
        state = OpState.SUCCEEDED
        if restore_status == "Pending":
            logging.info(f"restore_status: Pending")
            state = OpState.IN_PROGRESS
        elif restore_status == "Failed":
            state = OpState.FAILED
        return state

    def backup_state(self, service_record):
        backup_status = self.client.velero_backup_status(
            f"{service_record.instance_name}-{service_record.instance_id}"
        )
        logging.info(f"backup_status: {backup_status}")
        state = OpState.SUCCEEDED
        if backup_status == "Pending":
            state = OpState.IN_PROGRESS
        elif backup_status == "Failed":
            state = OpState.FAILED
        return state

    def read_db_password(self, service_record):
        secret_name = service_record.service_name
        secret_namespace = service_record.service_namespace
        secret = self.client.get_secrets(secret_namespace, secret_name)
        secret_key = (
            "mysql-password" if service_record.plan_env["ENGINE"] == "mysql" else "pg_password"
        )
        return base64.b64decode(secret.data[secret_key]).decode('utf-8')

    def read_db_username(self, service_record):
        engine = service_record.plan_env["ENGINE"]
        if engine == "mysql":
            configmap_name = f"{service_record.service_name}-config"
            configmap_namsespace = service_record.service_namespace
            configmap = self.client.get_configmap(configmap_namsespace, configmap_name)
        else:
            instance_id = "-".join(service_record.service_name.split("-")[1:])
            configmap_name = f"pg-config-{instance_id}"
            configmap_namsespace = service_record.service_namespace
            configmap = self.client.get_configmap(configmap_namsespace, configmap_name)

        return configmap.data


class Deprovision(BaseOperation):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.client = KubernetesClient(
            config.K8S_API_ENDPOINT, config.K8S_CACERT, config.K8S_BROKER_TOKEN
        )

    def delete_service(self, service_record, engine):
        try:
            delete_deployment = new_instance(
                self.config, self.client, service_record, engine, True
            )
            delete_deployment.delete()
        except Exception as e:
            logging.error(f"Error in deprovisioning resource {e}")
            service_record.save()
            raise e

    def state(self, service_record):
        pod_status = self.client.pod_delete_status(
            service_record.service_namespace, f"{service_record.service_name}-0"
        )
        state = OpState.SUCCEEDED
        if pod_status == "Pending":
            state = OpState.IN_PROGRESS
        elif pod_status == "Failed":
            state = OpState.FAILED
        return state

class Update(BaseOperation):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.client = KubernetesClient(config.K8S_API_ENDPOINT, config.K8S_CACERT, config.K8S_BROKER_TOKEN)
    def update_service(self, service_record, engine):
        try:
            update_deployment = update_instance(self.config, self.client, service_record, engine)
            update_deployment.update()
        except Exception as e:
            logging.error(f"Error in updating service resource {e}")
            service_record.save()
            raise e

    def create_snapshot(self, service_record, engine):
        try:
            update_deployment = create_instance_snapshot(self.config, self.client, service_record, engine)
            update_deployment.create_snapshot()
        except Exception as e:
            logging.error(f"Error in creating snapshot {e}")
            raise e

    def delete_snapshot(self, service_record, engine, backup_name):
        try:
            update_deployment = delete_instance_snapshot(self.config, self.client, service_record, engine)
            update_deployment.delete_snapshot(backup_name)
        except Exception as e:
            logging.error(f"Error in deleting snapshot {e}")
            raise e

    def state(self, service_record):
        pod_status = self.client.pod_status(service_record.service_namespace, service_record.service_name)
        state = OpState.SUCCEEDED
        if pod_status == "Pending":
            state = OpState.IN_PROGRESS
        elif pod_status == "Failed":
            state = OpState.FAILED
        return state

class Bind(BaseOperation):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.client = KubernetesClient(config.K8S_API_ENDPOINT, config.K8S_CACERT, config.K8S_BROKER_TOKEN)

    def get_service_backups(self, service_record, engine):
        backups_list = get_backups_list(self.config, self.client, service_record, engine)
        return backups_list


def new_instance(config, client, service_record, engine, is_delete):
    monitoring_enabled = bool(strtobool(config.MONITORING_ENABLED))
    if is_delete:
        if monitoring_enabled:
            if engine == "mysql":
                instance = DeleteMySQLDeploymentMonitoring(
                    config, client, service_record
                )
            else:
                instance = DeletePostgresDeploymentMonitoring(
                    config, client, service_record
                )
        else:
            if engine == "mysql":
                instance = DeleteMySQLDeployment(config, client, service_record)
            else:
                instance = DeletePostgresDeployment(config, client, service_record)
    else:
        if monitoring_enabled:
            if engine == "mysql":
                instance = MySQLDeploymentWithMonitoring(config, client, service_record)
            else:
                instance = PostgresDeploymentWithMonitoring(
                    config, client, service_record
                )
        else:
            if engine == "mysql":
                instance = MySQLDeployment(config, client, service_record)
            else:
                instance = PostgresDeployment(config, client, service_record)
    return instance

def update_instance(config, client, service_record, engine):
    if engine == "mysql":
        instance = UpdateMySQLDeployment(config, client, service_record)
    else:
        instance = UpdatePostgresDeployment(config, client, service_record)
    return instance

def get_backups_list(config, client, service_record, engine):
    if engine == "mysql":
        backups_list = MySQLDeployment(config, client, service_record).get_backups()
    else:
        backups_list = PostgresDeployment(config, client, service_record).get_backups()
    return backups_list

def create_instance_snapshot(config, client, service_record, engine):
    if engine == "mysql":
        instance = MySQLDeployment(config, client, service_record)
    else:
        instance = PostgresDeployment(config, client, service_record)
    return instance

def delete_instance_snapshot(config, client, service_record, engine):
    if engine == "mysql":
        instance = MySQLDeployment(config, client, service_record)
    else:
        instance = PostgresDeployment(config, client, service_record)
    return instance

