import json
import logging
from datetime import datetime, timedelta

import boto3
from awsretry import AWSRetry
from boto3.session import Session
from botocore.exceptions import ClientError, ParamValidationError
from botocore.utils import EVENT_ALIASES
from cf_broker_api.exceptions import InvalidServiceParameter
from tzlocal import get_localzone

from . import utils
from .session import MinIOClientError, MinIOSession
from .utils import generate_password

LOG = logging.getLogger(__name__)

# Map AWS service id to actual endpoint prefix, e.g. 'emr' to 'elasticmapreduce'
SERVICE_ALIASES = {v: k for k, v in EVENT_ALIASES.items()}

delete_objects_lifecycle = {
    "Rules": [
        {
            "Status": "Enabled",
            "NoncurrentVersionExpiration": {"NoncurrentDays": 1},
            "Filter": {"Prefix": ""},
            "Expiration": {"Days": 1},
            "AbortIncompleteMultipartUpload": {"DaysAfterInitiation": 1},
            "ID": "Delete all objects",
        }
    ]
}


def aws_error_code(e):
    return e.response["Error"]["Code"]


@utils.Memoize
def get_aws_organization_id(**awskwargs):
    orgs = boto3.client("organizations", **awskwargs)
    resp = orgs.describe_organization()
    return resp["Organization"]["Id"]


@utils.Memoize
def get_aws_account_id_from_credentials(**awskwargs):
    @AWSRetry.backoff(
        tries=8, delay=3, added_exceptions=["InvalidClientTokenId", "AccessDenied"]
    )
    def try_get_user():
        try:
            iam = boto3.client("iam", **awskwargs)
            resp = iam.get_user()
            user = resp["User"]
            arn = user["Arn"]
            _account_id = arn.split(":")[4]
            return _account_id
        except ClientError as err:
            LOG.info("Will Retry. IAM.GetUser Failure: {}".format(aws_error_code(err)))
            raise

    account_id = None
    try:
        account_id = try_get_user()
    except ClientError as e:
        if aws_error_code(e) == "AccessDenied":
            # Legacy buckets do not have permission to call iam:GetUser.
            # We just print the error and return None.
            LOG.info(e)
        else:
            raise
    return account_id


class ContextManager(object):
    def __init__(self, primary_credentials, addtl_credentials=None):
        self.credentials = {}
        self.add_credentials(**primary_credentials)
        # Save primary account id as default.
        self._primary_account_id = list(self.credentials.keys())[0]
        # Now add any additional account credentials.
        _addtl_credentials = addtl_credentials or []
        for credentials in _addtl_credentials:
            self.add_credentials(**credentials)

    @property
    def account_with_fewest_buckets(self):
        num_buckets_by_account = {}
        for account, credentials in self.credentials.items():
            s3 = boto3.resource("s3", **credentials)
            num_buckets = len([bucket.name for bucket in s3.buckets.all()])
            num_buckets_by_account[account] = num_buckets
        account_id = min(num_buckets_by_account, key=num_buckets_by_account.get)
        return self.credentials[account_id]

    def add_credentials(self, **kwargs):
        account_id = get_aws_account_id_from_credentials(**kwargs)
        self.credentials[account_id] = {
            "aws_access_key_id": kwargs.get("aws_access_key_id"),
            "aws_secret_access_key": kwargs.get("aws_secret_access_key"),
        }

    def get_context_for_user(self, iam_user):
        account_id = self._get_account_id(
            aws_access_key_id=iam_user.access_key_id,
            aws_secret_access_key=iam_user.secret_access_key,
        )
        return self.credentials[account_id]

    def _get_account_id(self, **creds):
        # Legacy buckets will not have a user policy that allows them
        # to query their IAM account id.  In that case, we return the
        # primary (legacy) account id.
        account_id = get_aws_account_id_from_credentials(**creds)
        return account_id if account_id else self._primary_account_id


class S3(object):
    def __init__(self, *args, endpoint_url=None, **kwargs):
        self.session = Session(*args, **kwargs)
        self._endpoint_url = endpoint_url

    @property
    def is_china_region(self):
        return self.session.region_name[:2] == "cn"

    @property
    def partition(self):
        return "aws-cn" if self.is_china_region else "aws"

    @property
    def available_regions(self):
        regions = self.session.get_available_regions(
            "s3", partition_name=self.partition
        )
        return regions

    @property
    def default_location_constraint(self):
        # Default to US Standard (us-east-1).  If this constraint is not
        # valid for the configured AWS default region (e.g. China), then
        # use the default region itself as the constraint (e.g. cn-north-1).
        default_constraint = "us-east-1"
        valid_constraints = self.available_regions
        if default_constraint not in valid_constraints:
            default_constraint = self.session.region_name
        return default_constraint

    def get_endpoint(self, region):
        domain = "amazonaws.com"
        if self.is_china_region:
            domain += ".cn"
        # Subdomains are slightly different for China and us-east-1.
        if self.is_china_region:
            subdomain = "s3.{}".format(region)
        else:
            if region in [None, "us-east-1", "s3-external-1"]:
                subdomain = "s3-external-1"
            else:
                subdomain = "s3-{}".format(region)
        endpoint = "{}.{}".format(subdomain, domain)
        return endpoint

    def validate_location_constraint(self, constraint):
        valid_constraints = self.available_regions
        if constraint not in valid_constraints:
            valid_list = ", ".join(valid_constraints)
            msg = (
                "Invalid Region parameter '{}'. Must be one of the "
                "following values: [{}]".format(constraint, valid_list)
            )
            raise InvalidServiceParameter(msg)
        # If constraint is US Standard, boto3 api expects None.
        return constraint if constraint != "us-east-1" else None


class AwsResource(object):
    def __call__(self, *args, **kwargs):
        if args[0]:
            self.identifier = args[0]
        self.identifier = kwargs.get("identifier", self.identifier)
        return self

    def __init__(self, *args, **kwargs):
        self.session = Session(*args, **kwargs)
        self.identifier = kwargs.get("identifier")


class MinIOResource(object):
    def __call__(self, *args, **kwargs):
        if args[0]:
            self.identifier = args[0]
        self.identifier = kwargs.get("identifier", self.identifier)
        return self

    def __init__(self, *args, **kwargs):
        self.session = MinIOSession(*args, **kwargs)
        self.identifier = kwargs.get("identifier")


class IamUser(AwsResource):
    def __init__(self, *args, **kwargs):
        super(IamUser, self).__init__(*args, **kwargs)
        self.resource = self.session.resource("iam")
        self.client = self.resource.meta.client
        self.credentials = {"AccessKeyId": None, "SecretAccessKey": None}

    @property
    def access_key_id(self):
        return self.credentials["AccessKeyId"]

    @property
    def secret_access_key(self):
        return self.credentials["SecretAccessKey"]

    @property
    def policy(self):
        return NotImplementedError()

    @policy.setter
    def policy(self, value):
        self._delete_attached_policies()  # Clear out any legacy policies.
        self.client.put_user_policy(
            UserName=self.identifier, PolicyName=self.identifier, PolicyDocument=value
        )

    def _delete_attached_policies(self):
        # Legacy buckets created by this service broker had a dedicated
        # policy (with the same name as the bucket) attached to the IAM
        # user, so we need to make sure to remove those policies if
        # they exist.
        try:
            resp = self.client.list_attached_user_policies(UserName=self.identifier)
        except ClientError:
            policies = []
        else:
            policies = resp["AttachedPolicies"]
        for policy in policies:
            self.client.detach_user_policy(
                UserName=self.identifier, PolicyArn=policy["PolicyArn"]
            )
            if policy["PolicyName"] == self.identifier:
                resp = self.client.list_policy_versions(
                    PolicyArn=policy["PolicyArn"], MaxItems=100
                )
                for version in resp["Versions"]:
                    if not version["IsDefaultVersion"]:
                        self.client.delete_policy_version(
                            PolicyArn=policy["PolicyArn"],
                            VersionId=version["VersionId"],
                        )
                self.client.delete_policy(PolicyArn=policy["PolicyArn"])

    def _generate_credentials(self):
        resp = self.client.create_access_key(UserName=self.identifier)
        key = resp["AccessKey"]
        self.credentials["AccessKeyId"] = key["AccessKeyId"]
        self.credentials["SecretAccessKey"] = key["SecretAccessKey"]

    def create(self, policy=None):
        self.client.create_user(UserName=self.identifier)
        self._generate_credentials()
        if policy:
            self.policy = policy
        return self

    def delete(self):
        self._delete_attached_policies()  # Delete any legacy policies.
        try:
            userpolicies = self.client.list_user_policies(UserName=self.identifier)
            # Delete inline policies since they can only be tied to this user
            for policy in userpolicies["PolicyNames"]:
                self.client.delete_user_policy(
                    UserName=self.identifier, PolicyName=policy
                )
            # Remove all API keys that are attached to the user account.
            user = self.resource.User(self.identifier)
            for key in user.access_keys.all():
                self.client.delete_access_key(
                    UserName=self.identifier, AccessKeyId=key.id
                )
            # Delete the actual user when everything else has been detached
            # and removed.
            self.client.delete_user(UserName=self.identifier)
        except ClientError:
            # If we get a ClientError exception here then the account does
            # not exist and we can move on.
            LOG.error("IAM User Deletion Failure!", exc_info=True)
            pass

    def _delete_existing_api_keys(self):
        resp = self.client.list_access_keys(UserName=self.identifier)
        if "AccessKeyMetadata" in resp:
            for key in resp["AccessKeyMetadata"]:
                self.client.delete_access_key(
                    UserName=self.identifier, AccessKeyId=key["AccessKeyId"]
                )

    def rotate_api_key(self):
        self._delete_existing_api_keys()
        self._generate_credentials()

    def describe(self):
        return self.client.get_user(UserName=self.identifier)

    @property
    def arn(self):
        description = self.describe()
        return description["User"]["Arn"]


class MinIOIamUser(MinIOResource):
    def __init__(self, *args, **kwargs):
        super(MinIOIamUser, self).__init__(*args, **kwargs)
        self.credentials = {"AccessKeyId": None, "SecretAccessKey": None}

    @property
    def access_key_id(self):
        return self.credentials["AccessKeyId"]

    @property
    def secret_access_key(self):
        return self.credentials["SecretAccessKey"]

    @property
    def policy(self):
        return NotImplementedError()

    @policy.setter
    def policy(self, value):
        try:
            self.session.create_policy(self.identifier, value)
            self.session.attach_policy_to_user(self.access_key_id, self.identifier)
        except MinIOClientError:
            LOG.error("Error in creating policy", exc_info=True)

    def create(self, policy=None):
        access_key_id = generate_password(8)
        secret_access_key = generate_password(16)
        try:
            self.session.create_user(access_key_id, secret_access_key)
            self.credentials["AccessKeyId"] = access_key_id
            self.credentials["SecretAccessKey"] = secret_access_key
            if policy:
                self.policy = policy
        except MinIOClientError:
            LOG.error("IAM User Creation Failure!", exc_info=True)
            pass
        return self

    def delete(self, access_key_id):
        try:
            self.session.delete_user(access_key_id)
            self.session.delete_policy(self.identifier)
        except MinIOClientError:
            LOG.error("Error in deleting policy", exc_info=True)

    def rotate_api_key(self):
        return NotImplementedError()

    def describe(self):
        return self.session.get_user(self.identifier)

    def set_quota(self,quota):
        self.session.set_bucket_quota(self.identifier,quota)

    @property
    def arn(self):
        return self.describe()


class S3Bucket(AwsResource):
    def __init__(self, *args, endpoint_url=None, **kwargs):
        super(S3Bucket, self).__init__(*args, **kwargs)
        self.s3 = S3(**kwargs)
        self.resource = self.session.resource(
            "s3",
            region_name=self.s3.default_location_constraint,
            endpoint_url=endpoint_url,
            verify=False,
        )
        self.client = self.resource.meta.client

    @property
    def exists(self):
        try:
            self.client.head_bucket(Bucket=self.identifier)
            return True
        except ClientError as e:
            if aws_error_code(e) == "404":
                return False
            else:
                raise

    @property
    def name(self):
        bucket = self.resource.Bucket(self.identifier)
        return bucket.name

    @property
    def creation_date(self):
        bucket = self.resource.Bucket(self.identifier)
        return bucket.creation_date

    @property
    def location(self):
        res = self.client.get_bucket_location(Bucket=self.identifier)
        if res is not None:
            return res["LocationConstraint"]
        else:
            return None

    @property
    def policy(self):
        try:
            res = self.client.get_bucket_policy(Bucket=self.identifier)
            if res is not None:
                return json.loads(res["Policy"])
            else:
                return None
        except ClientError as e:
            if aws_error_code(e) == "NoSuchBucketPolicy":
                return None
            elif aws_error_code(e) == "NoSuchBucket":
                return None
            else:
                raise

    @policy.setter
    @AWSRetry.backoff(
        tries=7, delay=5, backoff=1.5, added_exceptions=["MalformedPolicy"]
    )
    def policy(self, value):
        if value:
            self.client.put_bucket_policy(Bucket=self.identifier, Policy=value)
        else:
            self.client.delete_bucket_policy(Bucket=self.identifier)

    @property
    def lifecycle(self):
        try:
            res = self.client.get_bucket_lifecycle_configuration(Bucket=self.identifier)
            if res is not None:
                return res["Rules"]
            else:
                return None
        except ClientError as e:
            if aws_error_code(e) == "NoSuchLifecycleConfiguration":
                return None
            else:
                raise

    @lifecycle.setter
    def lifecycle(self, value):
        @AWSRetry.backoff(
            tries=7, delay=5, backoff=1.5, added_exceptions=["AccessDenied"]
        )
        def update_bucket_lifecycle_configuration(bucket, lifecycle):
            if lifecycle:
                self.client.put_bucket_lifecycle_configuration(
                    Bucket=bucket, LifecycleConfiguration=lifecycle
                )
            else:
                self.client.delete_bucket_lifecycle(Bucket=self.identifier)

        try:
            update_bucket_lifecycle_configuration(self.identifier, value)
        except ParamValidationError as e:
            raise InvalidServiceParameter(str(e))

    @property
    def cors(self):
        try:
            res = self.client.get_bucket_cors(Bucket=self.identifier)
            if res is not None:
                return res["CORSRules"]
            else:
                return None
        except ClientError as e:
            if aws_error_code(e) == "NoSuchCORSConfiguration":
                return None
            else:
                raise

    @cors.setter
    def cors(self, value):
        try:
            if value:
                self.client.put_bucket_cors(
                    Bucket=self.identifier, CORSConfiguration=value
                )
            else:
                self.client.delete_bucket_cors(Bucket=self.identifier)
        except ParamValidationError as e:
            raise InvalidServiceParameter(str(e))
        LOG.info("%s CORS Configuration: %s", self.identifier, str(value))

    def create(self, **kwargs):
        create_args = self.build_create_args(**kwargs)
        self.client.create_bucket(**create_args)
        self.modify(**kwargs)
        return self

    def modify(self, **kwargs):
        if "cors_configuration" in kwargs:
            self.cors = kwargs["cors_configuration"]
        if "bucket_lifecycle" in kwargs:
            self.lifecycle = kwargs["bucket_lifecycle"]
        if "bucket_policy" in kwargs:
            self.policy = kwargs["bucket_policy"]
        return self

    def enable_deletion_lifecycle(self):
        self.lifecycle = delete_objects_lifecycle

    def delete_objects(self, max_objects_to_delete):
        keys = []
        client = self.resource.meta.client
        paginator = client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self.identifier, MaxKeys=1000):
            keys += [{"Key": item["Key"]} for item in page.get("Contents", [])]
            if len(keys) >= max_objects_to_delete:
                keys = keys[:max_objects_to_delete]
                is_bucket_empty = False
                break
        else:
            is_bucket_empty = True
        # Now do the deletion.
        for i in range(0, len(keys), 1000):
            LOG.info("Deleting a batch of 1000 objects.")
            client.delete_objects(
                Bucket=self.identifier, Delete={"Objects": keys[i : i + 1000]}
            )
        LOG.info(
            "Bucket is {}.".format(
                "empty" if is_bucket_empty else "not empty, will continue on next cycle"
            )
        )
        return is_bucket_empty

    def delete(self):
        bucket = self.resource.Bucket(self.identifier)
        # All data in the bucket must be deleted before the bucket itself
        # can be deleted.
        try:
            bucket.objects.delete()
            bucket.delete()
        except ClientError as e:
            if aws_error_code(e) == "NoSuchBucket":
                LOG.error("Bucket Deletion Failed: No such bucket %s", self.identifier)
            elif aws_error_code(e) == "AccessDenied":
                LOG.error("Bucket Deletion Failed: Access Denied", exc_info=True)
                raise
            else:
                raise

    def build_create_args(self, **kwargs):
        create_args = {"Bucket": self.identifier}
        if "location_constraint" in kwargs:
            bucket_config = {"LocationConstraint": kwargs["location_constraint"]}
            create_args["CreateBucketConfiguration"] = bucket_config
        return create_args

    def get_object(self, object_key, **kwargs):
        return self.client.get_object(Bucket=self.identifier, Key=object_key, **kwargs)

    def get_objects_by_page(self, **kwargs):
        res = self.client.list_objects_v2(Bucket=self.identifier, **kwargs)
        result = {
            "NextContinuationToken": res.get("NextContinuationToken", None),
            "Contents": res.get("Contents", []),
        }

        return result

    def get_objects(self, **kwargs):
        res = self.client.list_objects_v2(Bucket=self.identifier, **kwargs)
        result = {
            "ContinuationToken": res.get("ContinuationToken", None),
            "Contents": res.get("Contents", []),
        }
        if "NextContinuationToken" in res:
            kwargs["ContinuationToken"] = res["NextContinuationToken"]
        while res.get("IsTruncated", False):
            res = self.client.list_objects_v2(Bucket=self.identifier, **kwargs)
            result["Contents"].extend(res.get("Contents", []))
            if "NextContinuationToken" in res:
                kwargs["ContinuationToken"] = res["NextContinuationToken"]
            else:
                del kwargs["ContinuationToken"]
        return result


class MinIoCloudwatch(MinIOResource):
    def __init__(self, *args, **kwargs):
        super(MinIoCloudwatch, self).__init__(*args, **kwargs)

    def get_number_of_objects(self):
        return self.session.get_bucket_usage(self.identifier, "objectsCount")

    def get_byte_count(self):
        return self.session.get_bucket_usage(self.identifier, "size")


class S3CloudWatch(AwsResource):
    def __init__(self, *args, **kwargs):
        super(S3CloudWatch, self).__init__(*args, **kwargs)
        self.client = self.session.client("cloudwatch")

    def get_number_of_objects(self, storage_type="AllStorageTypes"):
        dp = self.get_metric("NumberOfObjects", storage_type, "Count")
        return int(dp["Datapoints"][0]["Average"]) if len(dp["Datapoints"]) else None

    def get_byte_count(self, storage_type="StandardStorage"):
        dp = self.get_metric("BucketSizeBytes", storage_type, "Bytes")
        return int(dp["Datapoints"][0]["Average"]) if len(dp["Datapoints"]) else None

    def get_metric(self, metric, storage_type, unit):
        # S3 CloudWatch metrics are only collected once per day, so we
        # set our StartTime, EndTime, and Period to ensure that only one
        # result (yesterday, the most recent guaranteed to exist) is returned.
        yesterday = datetime.now(get_localzone()) - timedelta(days=1)
        res = self.client.get_metric_statistics(
            Namespace="AWS/S3",
            MetricName=metric,
            Dimensions=[
                {"Name": "BucketName", "Value": self.identifier},
                {"Name": "StorageType", "Value": storage_type},
            ],
            StartTime=datetime.combine(yesterday, datetime.min.time()),
            EndTime=datetime.combine(yesterday, datetime.max.time()),
            Period=86400,
            Unit=unit,
            Statistics=["Average"],
        )
        return res
