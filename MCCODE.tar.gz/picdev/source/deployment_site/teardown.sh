#! /bin/bash
#Script to destroy the entire deployment.
#Requires:- packer (v1.7.4), docker (v20.10.8)
#Requires aws access_key, secret and region to be set (For example via:- aws configure ...)
#Requires Route53 hosted zone with the name that matches domain_name

abort(){
  echo $1 && exit 1
}

abort_or_continue() {
  if [[ $1 -ne 0 ]];
  then
    echo "Bailing out ..."
    exit 1
  fi
}

log() {
    timestamp=`date +"%F %T"`
    echo -e "${timestamp} : $@";
}

if [[ -z "$HSOP_CONF" ]]
then
   abort "HSOP_CONF environment variable is not set"
fi

if [[ -z "$HSOP_PROFILE" ]]
then
   abort "HSOP_PROFILE environment variable is not set"
fi

if [[ -n "$HSOP_ADD_VOL" ]]
then
  ADD_VOL_ARG="--mount src=""${HSOP_ADD_VOL}"",target=""${HSOP_ADD_VOL}"",type=bind"
else
  ADD_VOL_ARG=
fi

log "Initializing teardown"

versionfile="$(dirname $(realpath $0) )/version.txt"
export HSOP_VERSION=$(cat $versionfile)

(
  cd ./build

  if [[ "$(docker images -q hsop/driver:$HSOP_VERSION 2> /dev/null)" == "" ]];
  then
    packer init driver.pkr.hcl
    packer build driver.pkr.hcl
  fi
)

chmod +x scripts/teardown.sh

log "Starting teardown ..."

docker run --rm --mount src="$(pwd)",target=/deployment,type=bind $ADD_VOL_ARG \
  --env FORCE_UNLOCK=$FORCE_UNLOCK  -w /deployment/scripts -i -t hsop/driver:$HSOP_VERSION ./teardown.sh -c $HSOP_CONF -p $HSOP_PROFILE

log "Teardown complete"