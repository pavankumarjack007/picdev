# HSDP-Vault Service Broker for Cloud Foundry


## Introduction

HSDP-Vault is a [Cloud Foundry service broker][] for secure secret storage and KMS features using [Vault][].

  [Cloud Foundry service broker]: http://docs.cloudfoundry.org/services/overview.html
  [Vault]: https://www.vaultproject.io/

The broker provides a bindable service that returns Vault credentials which can be used to authenticate to Vault and obtain a client token.

The client token has a Vault ACL policy allowing access to the following services:

- **Secret storage**: Read and write secrets or other sensitive runtime data to a durable storage path within Vault. Data written to this path are encrypted by Vault and unreadable without the Vault service itself and possession of a valid client token with permission to read the data

- **Key Management Service (KMS)**: Access to the Vault 'transit' backend. This is a unique encryption service which is similar in some respects to [AWS KMS][] but provides other useful cryptographic features

  [AWS KMS]: https://docs.aws.amazon.com/kms/latest/developerguide/concepts.html

This service broker implements a shared security model. This means that applications running in the same Cloud Foundry org and space are assumed to be trusted to share credentials and Vault resources for a given service instance.


## Registering service broker to use this app

cf create-service-broker vaultservicebroker cf_broker_test Eirini_cf_broker_832 https://vault-sb-app.cf.hsop-test.com

##enabling the broker to be available in all orgs
cf enable-service-access hsdp-vault -b vaultservicebroker -p standard

#updating service broker
cf update-service-broker vaultservicebroker cf_broker_test Eirini_cf_broker_832 https://vault-sb-app.cf.hsop-test.com

## Configuration

Configuration for the broker is provided through environment variables. The tables in the sections below list all available options.

### Cloud Foundry

| Option                | Required | Description
|:----------------------|:--------:|:-----------
| BROKER_USERNAME       | Y        | Broker basic auth username
| BROKER_PASSWORD       | Y        | Broker basic auth password
| PORT                  | N        | Application port (**default**: 8080)

### Vault

Vault approle credentials must be provided by a Vault administrator. See the [For Vault Administrators][] section below for more information

  [For Vault Administrators]: #markdown-header-for-vault-administrators

| Option                | Required | Description
|:----------------------|:--------:|:-----------
| VAULT_ROLE_ID         | Y        | Role ID for Vault approle
| VAULT_ROLE_ID         | Y        | Secret ID for Vault approle
| VAULT_CLIENT_ENDPOINT | Y        | Vault API endpoint for client access, this is provided to service consumers in the credentials object
| VAULT_ENDPOINT        | N        | Vault API endpoint for the region, this must be accessible to the service broker (**default**: 'https://localhost:8443')
| VAULT_TIMEOUT         | N        | Vault connection timeout in seconds (**default**: 90)



## Deployment

A Cloud Foundry manifest file is included in the repo for deployment as a Cloud Foundry application. In order to push the app, you must provide a [variable substitution file](https://docs.cloudfoundry.org/devguide/deploy-apps/manifest.html#variable-substitution).

```bash
$ make -f deploy/Makefile
```

## For Vault Administrators

The service broker requires its own Vault configuration which should be set by an administrator prior to deployment.

1. Mount a `kv` secret backend at `/cf/broker`, this is used to store broker state

        vault secrets enable -path=/cf/broker kv

2. Create a Vault policy (for this example we will use the name **service-broker**) with following rules:

        path "sys/mounts/cf/*" {
          capabilities = ["create", "update", "delete"]
        }

        path "auth/approle/role/cf-*" {
          capabilities = ["create", "read", "update", "delete", "list"]
        }

        path "sys/policy/cf-*" {
          capabilities = ["create", "read", "update", "delete", "list"]
        }

        path "cf/*" {
          capabilities = ["list"]
        }

        path "cf/broker/*" {
          capabilities = ["create", "read", "update", "delete", "list"]
        }

        path "auth/token/lookup-self" {
          capabilities = ["read", "list"]
        }

3. Create an approle which references the Vault policy just created. The `bound_cidr_list` parameter can optionally be specified (the network list would of course be specific to your CF deployment). Here is an example Vault CLI command creating an approle named **service-broker** where CF is deployed on 10.10.0.0/16:

        vault write -f auth/approle/role/service-broker \
          bind_secret_id=true \
          policies=service-broker \
          bound_cidr_list='10.10.0.0/16' \
          token_ttl=3600 \
          token_max_ttl=3600

    The resulting configuration should appear as follows:

        Key                     Value
        ---                     -----
        bind_secret_id          true
        bound_cidr_list         10.10.0.0/16
        period                  0
        policies                [default service-broker]
        secret_id_num_uses      0
        secret_id_ttl           0
        token_max_ttl           3600
        token_num_uses          0
        token_ttl               3600

    Note that `secret_id_ttl` is 0 (no expiry), this prevents the credentials generated for this approle from expiring which is appropriate for this
    use case. However, `token_ttl` and `token_max_ttl` are set for tokens issued by this approle.

4. Fetch the `role_id` for the approle just created:

        vault read auth/approle/role/service-broker/role-id

    Make a note of the `role_id` UUID

5. Generate a `secret_id` for the approle:

        vault write -f auth/approle/role/service-broker/secret-id

    Make a note of the `secret_id` and `secret_id_accessor` UUIDs. Store the `secret_id_accessor` safely as it can be used to revoke the `secret_id` in case of compromise

6. Using a suitably paranoid method of distribution, provide the `role_id` and `secret_id` GUIDs to whomever is responsible for service broker deployment.

    It is essential these credentials are handled carefully and only readable by administrators. If you are ever concerned about compromise of these credentials use the `secret_id_accessor` to delete the `secret_id` using the API endpoint `/auth/approle/role/service-broker/secret-id-accessor/destroy`. Generate and distribute a new `secret_id` and redeploy the service broker with the new credentials to restore service
