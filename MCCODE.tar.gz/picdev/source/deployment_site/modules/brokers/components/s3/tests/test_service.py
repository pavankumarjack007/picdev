import uuid

import mock
from botocore.exceptions import ClientError
from cf_broker_api.exceptions import InvalidServiceParameter
from cf_broker_api.reqparse import Namespace

from tests import BaseTestCase, test_data


class TestService(BaseTestCase):
    def test_instance_details(self):
        data = test_data()
        resp = self.client.provision(data)
        self.assertResponse(resp)
        details = self.app.service_class.instance_details(data["instance_id"])
        self.assertIsNotNone(details)

    def test_invalid_last_operation_raises_exception(self):
        data = test_data()
        record = self.model.new_record(**data)
        record.save()
        with self.assertRaises(InvalidServiceParameter):
            self.app.service_class.last_operation(
                {"operation": "invalid_op"}, data["instance_id"]
            )

    def test_deletion_of_non_empty_bucket_adds_lifecycle_rule(self):
        data = test_data()
        self.client.provision(data)
        # Put some objects in there...
        client = self.s3_resource.meta.client
        for i in range(0, self.config.OBJECT_DELETION_THRESHOLD + 1):
            client.put_object(
                Bucket=data["bucket"], Key=str(uuid.uuid4()), Body=b"test bytes"
            )
        # Now delete...
        self.app.service_class.delete_instance(data["instance_id"])
        lifecycle_rules = self.Bucket(data["bucket"]).lifecycle
        self.assertEqual(len(lifecycle_rules), 1)
        self.assertEqual(lifecycle_rules[0]["ID"], "Delete all objects")

    def test_deletion_of_non_existent_bucket(self):
        data = test_data()
        self.client.provision(data)
        # Manually delete bucket.
        self.Bucket(data["bucket"]).delete()
        # Delete should still succeed.
        self.app.service_class.delete_instance(data["instance_id"])
        with self.assertRaises(ClientError) as context:
            self.s3_resource.meta.client.head_bucket(Bucket=data["bucket"])
        self.assertIn("Not Found", str(context.exception))
        with self.assertRaises(ClientError) as context:
            self.iam_client.get_user(UserName=data["bucket"])
        self.assertIn("NoSuchEntity", str(context.exception))

    def test_deletion_of_non_existent_bucket_iam_user(self):
        data = test_data()
        self.client.provision(data)
        # Manually delete IAM User.
        self.IAM(data["bucket"]).delete()
        # Delete should still succeed.
        self.app.service_class.delete_instance(data["instance_id"])
        with self.assertRaises(ClientError) as context:
            self.s3_resource.meta.client.head_bucket(Bucket=data["bucket"])
        self.assertIn("Not Found", str(context.exception))
        with self.assertRaises(ClientError) as context:
            self.iam_client.get_user(UserName=data["bucket"])
        self.assertIn("NoSuchEntity", str(context.exception))

    def test_deletion_fails_when_unable_to_set_aws_user_context(self):
        data = test_data()
        self.client.provision(data)
        with mock.patch(
            "broker.service.S3ServiceInstanceService._get_service_record"
        ) as mocked_method:
            mocked_method.side_effect = ClientError(
                {"Error": {"Code": "InvalidClientTokenId"}}, operation_name="GetUser"
            )
            self.app.service_class.delete_instance(data["instance_id"])
        record = self.model.get(data["instance_id"])
        self.assertEqual(record.last_operation_state, "failed")


class TestServiceExceptions(BaseTestCase):
    @classmethod
    def setup_class(cls):
        super(TestServiceExceptions, cls).setup_class()
        cls.service = cls.app.service_class

    def test_json_list_params_must_be_a_list(self):
        with self.app.app_context():
            for _, parser in self.service.get_param_parsers().items():
                for param in parser.args:
                    if "json_list" in repr(param.type) and callable(param.type):
                        args = Namespace(parameters={param.name: "a-string-not-a-list"})
                        with self.assertRaises(Exception) as ctx:
                            parser.parse_args(args, strict=True)
                        self.assertIn(
                            param.name,
                            getattr(ctx.exception, "data", {}).get("description"),
                        )
                        self.assertIn(
                            "not a list",
                            getattr(ctx.exception, "data", {}).get("description"),
                        )
