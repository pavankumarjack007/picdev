#! /bin/bash
#Script to destroy the entire deployment

while getopts c:p: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        c) conf=${OPTARG};;
        p) vars=${OPTARG};;
    esac
done

abort(){
  echo $1 && exit 1
}

abort_or_continue() {
  if [[ $1 -ne 0 ]];
  then
    echo "Bailing out ..."
    exit 1
  fi
}

log() {
    timestamp=`date +"%F %T"`
    echo -e "${timestamp} : $@";
}

## Setup paths for modules, configuration & profile
modules="$(dirname $(dirname $(realpath $0)) )/modules"
config="$(dirname $(dirname $(realpath $0)) )/configuration/${conf}.txt"
profile="$(dirname $(dirname $(realpath $0)) )/profiles/${vars}.tfvars"

## Setup env vars for terraform
chmod +x ./setup_env_vars.sh
source ./setup_env_vars.sh $profile

## Setup modules
while IFS= read -r line || [[ -n "$line" ]];
  do
    result=$(echo $line)
    (
        module="$modules/$result"
        cd $module
        wkspace="${result}-${TF_VAR_environment}.${TF_VAR_domain_name}"
        terraform workspace select $wkspace
        terraform destroy -auto-approve
        terraform workspace select default
        terraform workspace delete $wkspace
    )
  done < <(tac $config)

kubectl delete namespace iam
kubectl delete namespace nginx-ingress

cf login -u $CF_USN -p $CF_PWD -o hsop -s iam
#cf target -o hsop -s iam

cf delete -f idmv2-3901-None
cf delete -f asv-3901-None
cf delete -f iam-3901-None
cf delete -f idm-3901-None
cf delete -f ocm-3901-None
cf delete -f aui-3901-None

cf delete-service-key iam-vault iam-vault-service-key -f
cf delete-service iam-vault -f
cf delete-service None -f
