import pytest
import json
import os
from cloudfoundry_client.client import CloudFoundryClient

# @pytest.mark.parametrize("a, b, c", [(10,20, 30), (20,40,60), (11,22,33)])
import requests

from tests.pytest.tests.conftest import cluster_name


@pytest.mark.sat
def test_verify_cf_orgs():
    cf_ep = cluster_name[3:]
    target_endpoint = "https://api.cf" + cf_ep
    orgs = ['']

    cfadminpassword_from_credhub = os.popen('./binary/credhub get --name \'/cfadminpassword\' -j').read()
    cfadminpassword_json = json.loads(cfadminpassword_from_credhub)
    cfadminpassword = cfadminpassword_json["value"]

    client = CloudFoundryClient(target_endpoint, verify=False)
    client.init_with_user_credentials('admin', cfadminpassword )
    for organization in client.v2.organizations:
        print(organization['entity']['name'])
        orgs.append(organization['entity']['name'])
    assert "smoketestorg" in str(orgs)
    assert "hsop" in str(orgs)
