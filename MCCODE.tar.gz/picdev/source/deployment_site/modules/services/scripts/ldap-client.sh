#!/bin/bash

while getopts u:b:p:s: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        u) uri=${OPTARG};;
        b) binddn=${OPTARG};;
        p) bindpw=${OPTARG};;
        s) searchbase=${OPTARG};;
    esac
done

if [[ -f /etc/nslcd.conf ]]; then
  sudo chmod 640 /etc/nslcd.conf
fi

# Install libnns-ldapd silently
sudo DEBIAN_FRONTEND=noninteractive apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -qq libnss-ldapd

sudo tee /etc/nslcd.conf > /dev/null <<EOT
uid nslcd
gid nslcd
uri $uri
base $searchbase
ldap_version 3
binddn $binddn
bindpw $bindpw
ssl off
tls_reqcert never
EOT

sudo tee /etc/nsswitch.conf > /dev/null <<EOT
passwd:       compat  files systemd ldap
group:        compat  files systemd ldap
shadow:       compat  files ldap
sudoers:        ldap files
gshadow:        files
hosts:          files dns
networks:       files
protocols:      db files
services:       db files
ethers:         db files
rpc:            db files
netgroup:       nis
EOT

getent group 1001 || sudo groupadd -g 1001 level1-support
getent group 1002 || sudo groupadd -g 1002 level2-support
getent group 1003 || sudo groupadd -g 1003 level3-support
getent group 1004 || sudo groupadd -g 1004 level4-support
getent group 1005 || sudo groupadd -g 1005 platform-services-support

echo "%level3-support   ALL=(ALL:ALL) ALL" | sudo tee -a  /etc/sudoers

# Enable ldap pub key authentication
sudo apt remove ec2-instance-connect -y

sudo tee /usr/bin/ldap_pub_key >  /dev/null <<EOT
#!/usr/bin/env bash
uid=\$1
binddn=\$(grep "^binddn.*" /etc/nslcd.conf| awk '{print \$2}')
bindpw=\$(grep "^bindpw.*" /etc/nslcd.conf| awk '{print \$2}')
ldap_uri=\$(grep "^uri.*" /etc/nslcd.conf| awk '{print \$2}')
ldap_base=\$(grep "^base.*" /etc/nslcd.conf| awk '{print \$2}')
ldapsearch -x -H "\$ldap_uri" -b "\$ldap_base" -D "\$binddn" -w "\$bindpw" '(&(objectClass=posixAccount)(uid='"\$uid"'))' \
        'sshPublicKey' | sed -n '/^ /{H;d};/sshPublicKey:/x;\$g;s/\\n *//g;s/sshPublicKey: //gp'
EOT

sudo sed -i "s/\\//g" /usr/bin/ldap_pub_key
#sudo sed -i 's/\/n/\\n/g' /usr/bin/ldap_pub_key
sudo chmod +x /usr/bin/ldap_pub_key

sudo sed -i "s/^PasswordAuthentication.*/PasswordAuthentication no/g" /etc/ssh/sshd_config
sudo sed -i "s/^#PubkeyAuthentication yes/PubkeyAuthentication yes/g" /etc/ssh/sshd_config
sudo sed -i "s%^#AuthorizedKeysCommand none%AuthorizedKeysCommand /usr/bin/ldap_pub_key%g" /etc/ssh/sshd_config
sudo sed -i "s%^#AuthorizedKeysCommandUser nobody%AuthorizedKeysCommandUser root%g" /etc/ssh/sshd_config
sudo systemctl restart sshd
sudo systemctl restart systemd-logind
sudo pam-auth-update --enable mkhomedir
sudo /etc/init.d/nscd restart
sudo /etc/init.d/nslcd restart
