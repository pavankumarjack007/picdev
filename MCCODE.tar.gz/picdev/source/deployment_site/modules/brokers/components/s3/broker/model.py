import json

from pynamodb.attributes import (
    BooleanAttribute,
    ListAttribute,
    MapAttribute,
    UnicodeAttribute,
)
from pynamodb.exceptions import DoesNotExist
from pynamodb.models import Model

from . import utils


class EncryptedAttribute(UnicodeAttribute):
    def __init__(self, key, *args, **kwargs):
        super(EncryptedAttribute, self).__init__(*args, **kwargs)
        self.encryption_key = key

    def serialize(self, value):
        encrypted_value = utils.encrypt_data(value, key=self.encryption_key)
        return super(EncryptedAttribute, self).serialize(encrypted_value)

    def deserialize(self, value):
        decrypted_value = utils.decrypt_data(value, key=self.encryption_key)
        return super(EncryptedAttribute, self).deserialize(decrypted_value)


# We have to package this all up so it's based on the app config context.
def get_broker_model(config, ensure_table_exists=True):
    class BrokerState(Model):
        class Meta:
            table_name = config.DYNAMODB_TABLE
            host = config.DYNAMODB_HOST
            region = config.AWS_DEFAULT_REGION

        class IamUser(MapAttribute):

            access_key_id = UnicodeAttribute()
            secret_access_key = EncryptedAttribute(key=config.ENCRYPTION_KEY)

        instance_id = UnicodeAttribute(hash_key=True)

        organization_guid = UnicodeAttribute()
        space_guid = UnicodeAttribute()
        service_id = UnicodeAttribute()
        plan_id = UnicodeAttribute()

        binding_ids = ListAttribute(default=[])

        bucket = UnicodeAttribute()
        region_name = UnicodeAttribute(null=True)

        iam_user = IamUser(null=True)

        last_operation_state = UnicodeAttribute(default="failed")

        deleted = BooleanAttribute(default=False)

        # For backwards-compatibility with the old model.
        _iv = UnicodeAttribute(attr_name="iv", null=True)
        _encrypted_credentials = UnicodeAttribute(attr_name="credentials", null=True)

        def __init__(self, *args, **kwargs):
            super(BrokerState, self).__init__(*args, **kwargs)
            # Maintain backward-compatibility with older broker db records.
            if self._encrypted_credentials:
                # Get the user key/secret from the old credentials field.
                data = json.loads(
                    utils.decrypt_data(
                        data=self._encrypted_credentials,
                        iv=self._iv,
                        key=config.ENCRYPTION_KEY,
                    )
                )
                # Update newer model attributes with data from old credentials.
                if self.iam_user is None:
                    self.iam_user = BrokerState.IamUser(
                        access_key_id=data["api_key"],
                        secret_access_key=data["secret_key"],
                    )
                if self.bucket is None:
                    self.bucket = data["bucket"]
                # Set to None so we no longer output to dynamodb.
                self._encrypted_credentials = None
                self._iv = None
                self.save()

        @classmethod
        def get(cls, hash_key, range_key=None, consistent_read=False):
            try:
                record = super(BrokerState, cls).get(
                    hash_key, range_key, consistent_read
                )
            except DoesNotExist:
                record = None
            return record

        @classmethod
        def new_record(cls, *args, **kwargs):
            allowed_attrs = (
                "organization_guid",
                "space_guid",
                "service_id",
                "plan_id",
                "instance_id",
                "bucket",
            )
            filtered = {k: v for k, v in kwargs.items() if k in allowed_attrs}
            return cls(*args, **filtered)

        @classmethod
        def init(cls):
            if not cls.exists():
                cls.create_table(
                    read_capacity_units=5, write_capacity_units=5, wait=True
                )

    if ensure_table_exists:
        BrokerState.init()

    return BrokerState
