#!/bin/bash

# We time some common actions in Cloud Foundry.
# pushing an application
# restarting an application
# getting a list of services
# getting a list of applications.

# Meant to be run before an upgrade and after with differences compared.
pwd=$(grep  'cf_admin_password:' ../../source/deployment/modules/cloudfoundry/values/kubecf_ext-blobstore_kops.yaml.tpl | tail -n1 | awk '{ print $2}')
domainname=$(sudo cat ../../source/deployment/profiles/outposts-bothell-small.tfvars | grep domain | cut -d '=' -f2 | tr -d '"')
echo $domainname
url=https://api.cf.$domainname

get_python_buildpack() {
    local endpoint=$(cf target | grep endpoint | cut -f3 -d/)

    case $endpoint in
        $url)
            echo "python_buildpack_cached"
            ;;
        *)
            echo "python_buildpack"
            ;;
    esac

}

BUILDPACK=$(get_python_buildpack)

#thisdir=../smoke/binding-post/

pushd ../smoke/binding-post/

UUID=$(uuidgen)
cat manifest.yml.template | sed -e "s/BUILDPACK/$BUILDPACK/" -e "s/UUID/$UUID/" > manifest.yml

date

echo "Application push time"
{ time cf push > /dev/null ; } 2>&1

echo "Application restart time"
{ time cf restart pythonapp > /dev/null ; } 2>&1

echo "Application delete time"
{ time cf delete -f -r pythonapp > /dev/null ; } 2>&1

echo "List services time"
{ time cf services > /dev/null ; } 2>&1

echo "List applications time" 
{ time cf apps > /dev/null ; } 2>&1
