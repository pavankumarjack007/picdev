import graphene


class InstanceMetrics(graphene.ObjectType):
    name = graphene.String()
    object_count = graphene.Int()
    bucket_size = graphene.Float()

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_name(metrics, info):
        return metrics["Name"]

    def resolve_object_count(metrics, info):
        return metrics.get("NumKeys") or 0

    def resolve_bucket_size(metrics, info):
        return metrics.get("Size") or 0
