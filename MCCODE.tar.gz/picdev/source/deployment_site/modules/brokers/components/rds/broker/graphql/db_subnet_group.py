import graphene

from .subnet import Subnet


class DbSubnetGroup(graphene.ObjectType):
    vpc_id = graphene.String()
    name = graphene.String()
    status = graphene.String()
    subnets = graphene.List(Subnet)

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_name(group, _):
        return None

    def resolve_status(group, _):
        return None
