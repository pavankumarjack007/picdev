#!/bin/bash
#fix error introduced by terraform aws provider v4.6.0
AWS_PROVIDER=$(cat <<EOF
{
    "source"  = "hashicorp/aws"
    "version" = ">= 3.34.0, <= 4.4.5"
}
EOF
)

export KOPS_STATE_STORE="s3://${var.bucket_name}/kops"
export ACC_ID=$(aws sts get-caller-identity | jq -r ".Account")
export VAULT_IAM_POLICY_ARN="arn:aws:iam::${ACC_ID}:policy/kms-policy-${TF_VAR_cluster_name}"
# export VELERO_IAM_POLICY_ARN="arn:aws:iam::${ACC_ID}:policy/velero-${TF_VAR_cluster_name}"
export CERT_MANAGER_IAM_POLICY_ARN="arn:aws:iam::${ACC_ID}:policy/cert-manager-policy-${TF_VAR_cluster_name}"
export EXTERNAL_DNS_IAM_POLICY_ARN="arn:aws:iam::${ACC_ID}:policy/external-dns-policy-${TF_VAR_cluster_name}"

cd ../generated/terraform-k8s-private

kops get ${cluster_name} -o yaml > ./cluster-desired-config-private.yaml
#Enable add-ons needed for IRSA on kops cluster
yq -i e '(.|select(.kind == "Cluster").spec.certManager.enabled) |= true' ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.certManager.managed) |= false' ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.podIdentityWebhook.enabled) |= true' ./cluster-desired-config-private.yaml

#Setting up the mappings between k8s service accounts and AWS IAM policies
#Configure IRSA for Vault
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[0].name) |= "vault"'  ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[0].namespace) |= "vault"'  ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[0].aws.policyARNs[0]) |= env(VAULT_IAM_POLICY_ARN)'  ./cluster-desired-config-private.yaml
# #Configure IRSA for Velero
# yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[1].name) |= "velero"'  ./cluster-desired-config-private.yaml
# yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[1].namespace) |= "velero"'  ./cluster-desired-config-private.yaml
# yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[1].aws.policyARNs[0]) |= env(VELERO_IAM_POLICY_ARN)'  ./cluster-desired-config-private.yaml
#Configure IRSA for Cert-Manager
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[1].name) |= "cert-manager"'  ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[1].namespace) |= "cert-manager"'  ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[1].aws.policyARNs[0]) |= env(CERT_MANAGER_IAM_POLICY_ARN)'  ./cluster-desired-config-private.yaml
#Configure IRSA for External-DNS
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[2].name) |= "external-dns"'  ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[2].namespace) |= "kube-system"'  ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[2].aws.policyARNs[0]) |= env(EXTERNAL_DNS_IAM_POLICY_ARN)'  ./cluster-desired-config-private.yaml
#Configure IRSA for Prometheus for EC2 Service Discovery
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[3].name) |= "hsop-prometheus-kube-prome-prometheus"'  ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[3].namespace) |= "monitoring"'  ./cluster-desired-config-private.yaml
yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[3].aws.policyARNs[0]) |= "arn:aws:iam::aws:policy/AmazonEC2ReadOnlyAccess"'  ./cluster-desired-config-private.yaml
#You may repeat the above 3 lines to configure IRSA for additional applications. Ensure IAM policy for that application is already created. Map it with required k8s service account and namespace and its IAM policy


kops replace -f ./cluster-desired-config-private.yaml --name ${cluster_name} --force
#kops update cluster --name=${cluster_name} --out /tmp/kops --target terraform
kops update cluster --name=${cluster_name} --out . --target terraform

#TODO : for now SSF gets deployed on cloud, anything to be edited for SSF ?
if [ "$target_name" == "outpost" ]
then
  #modify kubernetes.tf to add outposts arn
  sed -i 's/gp3/gp2/g' ./kubernetes.tf
  sed -i '/iops                  = 3000/d' ./kubernetes.tf
  sed -i '/throughput            = 125/d' ./kubernetes.tf
  lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_ebs_volume -e aws_subnet))
  for x in "${lines[@]}"; do
    echo Adding Outposts ARN to $x
    hcledit attribute append $x.outpost_arn "$outposts_arn" -f ./kubernetes.tf -u
  done
fi

lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_autoscaling_group))
for x in "${lines[@]}"; do
  echo Removing load_balancers attribute in $x
  hcledit attribute rm $x.load_balancers -f ./kubernetes.tf -u
done

lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_elb -e aws_route53_record))
for x in "${lines[@]}"; do
  echo Removing ELB/Router53Record $x
  hcledit block rm $x -f ./kubernetes.tf -u
done

#remove elb security groups
lines=($(hcledit block list -f ./kubernetes.tf | grep '^resource.aws_security_group\..*-elb-.*'))
for x in "${lines[@]}"; do
  echo Removing security group $x
  hcledit block rm $x -f ./kubernetes.tf -u
done

#remove security group rules
lines=($(hcledit block list -f ./kubernetes.tf | grep '^resource.aws_security_group_rule\..*-elb-.*' | grep -v '^resource.aws_security_group_rule\..*from-bastion-elb-.*-tcp-22to22-.*'))
for x in "${lines[@]}"; do
  echo Removing security group rule $x
  hcledit block rm $x -f ./kubernetes.tf -u
done

#update security group rule
lines=($(hcledit block list -f ./kubernetes.tf | grep '^resource.aws_security_group_rule\..*from-bastion-elb-.*-tcp-22to22-.*'))
for x in "${lines[@]}"; do
  echo Updating security group rule $x
  hcledit attribute rm $x.source_security_group_id -f ./kubernetes.tf -u
  hcledit attribute append $x.cidr_blocks '["0.0.0.0/0"]' -f ./kubernetes.tf -u
done


hcledit block append terraform backend.s3 -f ./kubernetes.tf -u

hcledit attribute set terraform.required_providers.aws "$AWS_PROVIDER" -f ./kubernetes.tf -u
## state lock already in force at this point
terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate"  >/dev/null
wkspace="kops-${TF_VAR_environment}.${TF_VAR_domain_name}"
found=$(terraform workspace list | grep "${wkspace}" | wc -l)
if [[ $found -eq 0 ]]
then
  terraform workspace new $wkspace
else
  terraform workspace select $wkspace
fi
terraform plan -out ./full_auto.plan
terraform apply "./full_auto.plan"