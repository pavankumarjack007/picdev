domain_name=`echo $cluster_name | cut -f 2- -d '.'`
echo "Domain name is $domain_name"
haproxy_private_ip=$(curl -s http://169.254.169.254/latest/meta-data/local-ipv4)
echo "HAproxy Zone id is $haproxy_zone_id"
for i in "ssh.cf" "*.cf" "hsopiam.cf" "api.k8s" ; do
aws route53 change-resource-record-sets --hosted-zone-id $haproxy_zone_id --change-batch '{
    "Comment": "Update record to add new CNAME record",
    "Changes": [
        {
            "Action": "UPSERT",
            "ResourceRecordSet": {
                "Name": "'"$i.$domain_name"'",
                "Type": "A",
                "TTL": 300,
                "ResourceRecords": [
                    {
                        "Value": "'"$haproxy_private_ip"'"
                    }
                ]
            }
        }
    ]
}'
done
