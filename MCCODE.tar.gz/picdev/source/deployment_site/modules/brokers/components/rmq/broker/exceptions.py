from cf_broker_api.exceptions import (ServiceBrokerException,
                                      HTTP_400_BAD_REQUEST,
                                      HTTP_412_PRECONDITION_FAILED)


"""
This module contains all the custom rabbitmq broker exception classes.
"""


class BadConfigMapData(ServiceBrokerException):
    """
    Will be raised when bad config map data is passed
    """
    code = HTTP_400_BAD_REQUEST
    description = 'Bad ConfigMap data passed in.'


class UpdateParameterNotSupported(ServiceBrokerException):
    """
    Thrown when an update parameter is not supported by the broker
    """
    code = HTTP_400_BAD_REQUEST
    description = 'Update parameter not supported.'


class InvalidData(ServiceBrokerException):
    """
    Will be raised when invalid body data is passed
    """
    code = HTTP_400_BAD_REQUEST
    description = 'Invalid parameters when creating resource.'


class UnknownConfigMap(ServiceBrokerException):
    """
    Unknown config map passed in
    """
    code = HTTP_400_BAD_REQUEST
    description = 'Unknown ConfigMap'


class ServiceNotReady(ServiceBrokerException):
    """
    Service is not in a ready state
    """
    code = HTTP_412_PRECONDITION_FAILED
    description = 'Service is not in ready state'
