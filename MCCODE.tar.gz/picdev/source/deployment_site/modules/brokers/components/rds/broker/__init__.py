import logging
import os

from .dashboard import controller as dashboard_controller
from cf_broker_api import ServiceBroker
from cf_broker_api.utils import init_logging

from config import config_map
from . import graphql_view
from .graphql import schema
from .model import get_broker_model
from .service import DatabaseBrokerService, ContextAwareDatabaseServiceInstanceService
from .actions import DatabaseBrokerServiceActions
LOG = logging.getLogger(__name__)


def create_broker(
    config_name=None, catalog=None, service_class=None, exc_mapper=None, parsers=None,graphql_service=None
):
    _config_name = config_name or os.getenv("BROKER_CONFIG", "default")
    _config = config_map[_config_name]

    init_logging(
        level=_config.LOGGING_LEVEL,
        log_format=_config.LOGGING_MSG_FORMAT,
        date_format="%Y-%m-%dT%H:%M:%SZ",
    )
    LOG.info("Using {} configuration...".format(_config_name))

    # _catalog = catalog or _config.service_catalog_filename
    _catalog = catalog or "catalog.yml"
    _model = get_broker_model(_config)
    _service = service_class or DatabaseBrokerServiceActions(model=_model, config=_config)
    _parsers = parsers or _service.get_param_parsers()
    _exc_mapper = exc_mapper or {}

    broker = ServiceBroker(
        service_catalog=_catalog,
        custom_parsers=_parsers,
        service_class=_service,
        exc_mapper=_exc_mapper,
        config=_config,
    )
    # Create a Flask blueprint to hold our Service Dashboard routes.
    broker.register_blueprint(dashboard_controller)

    broker.global_config = _config

    _graphql_service = graphql_service or ContextAwareDatabaseServiceInstanceService
    graphql_view.init_app(
        broker, config=_config, schema=schema, context=_graphql_service
    )
    return broker
