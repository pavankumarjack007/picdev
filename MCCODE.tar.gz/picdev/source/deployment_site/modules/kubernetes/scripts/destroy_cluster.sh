#! /bin/bash
#Script to destroy the entire deployment

cluster_name=$TF_VAR_cluster_name

(
	echo "Destroying the k8s deployment"
	mkdir -p ../generated/terraform-k8s-private
	cd ../generated/terraform-k8s-private
	if [ ! -f kubernetes.tf ]; then
	  cp ../../templates/kubernetes.tf kubernetes.tf
    echo ''>> kubernetes.tf
    echo 'provider "aws" {' >>  kubernetes.tf
    echo 'region = "'$AWS_REGION'"' >> kubernetes.tf
    echo '}' >> kubernetes.tf

    echo 'provider "aws" {' >>  kubernetes.tf
    echo '  alias  = "files"' >>  kubernetes.tf
    echo ' region = "'$AWS_REGION'"' >>  kubernetes.tf
    echo '}'>>  kubernetes.tf
  fi
    ## state lock already in force at this point
    terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate"  >/dev/null
    wkspace="kops-${TF_VAR_environment}.${TF_VAR_domain_name}"	
	  found=$(terraform workspace list | grep "${wkspace}" | wc -l)
  if [[ $found -eq 1 ]]
  then
    terraform workspace select $wkspace
    terraform destroy -auto-approve
    terraform workspace select default
    terraform workspace delete $wkspace
  fi
)

kops delete cluster $cluster_name --state "s3://${TF_VAR_bucket_name}/kops" --yes

