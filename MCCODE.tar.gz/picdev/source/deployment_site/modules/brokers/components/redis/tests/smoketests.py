#!/usr/bin/env python
import logging
import os
import sys
import uuid

import requests
from cf_broker_api.testing import create_test_client

try:
    config_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, config_path)
    from config import config_map
except ImportError:
    config_map = {}
    print("Unable to import configuration!")
    sys.exit(1)


config = config_map["deployment"]

test_data = dict(
    instance_id="smoke-test-{}".format(uuid.uuid4().hex),
    plan_id=config.SMOKETEST_PLAN_ID,
    service_id=config.SMOKETEST_SERVICE_ID,
    space_guid="smoke-test-space-guid",
    organization_guid="smoke-test-org-guid",
    binding_id="test-binding-id",
    context=dict(
        instance_name="test-instance-name",
        organization_name="test-organization-name",
        space_name="test-space-name",
    ),
)

logging.basicConfig(level=logging.DEBUG, format="%(message)s")
log = logging.getLogger("smoketests")


def execute_request(http_verb, url, headers, data):
    return requests.request(
        http_verb,
        headers=headers,
        url=url,
        data=data,
        allow_redirects=False,
        verify=False,
    )


if __name__ == "__main__":
    hostname = sys.argv[1]

    log.info("Running smoketests against {}...".format(hostname))

    client_config = dict(
        base_url="https://{}".format(hostname),
        username=config.BROKER_USERNAME,
        password=config.BROKER_PASSWORD,
    )
    client = create_test_client("http", **client_config)
    client._execute_request = execute_request

    log.info("Checking catalog...")
    resp = client.catalog()
    assert resp.status_code == 200

    log.info("Creating test instance...")
    resp = client.provision(test_data)
    assert resp.status_code == 202
    assert resp.last_resp.status_code == 200

    log.info("Binding test instance...")
    resp = client.bind(test_data)
    assert resp.status_code == 201

    log.info("Unbinding test instance...")
    resp = client.unbind(test_data)
    assert resp.status_code == 200

    log.info("Deleting test instance...")
    resp = client.deprovision(test_data)
    assert resp.status_code == 202
    assert resp.last_resp.status_code == 410

    log.info("...smoketests passed!")
