vault secrets enable -path=/cf/broker kv

cat <<EOF > /home/vault/service-broker.hcl
path "sys/mounts/cf/*" {
   capabilities = ["create", "update", "delete"]
 }
 path "auth/approle/role/cf-*" {
   capabilities = ["create", "read", "update", "delete", "list"]
 }
 path "sys/policy/cf-*" {
   capabilities = ["create", "read", "update", "delete", "list"]
 }
 path "cf/*" {
   capabilities = ["list"]
 }
 path "cf/broker/*" {
   capabilities = ["create", "read", "update", "delete", "list"]
 }
 path "auth/token/lookup-self" {
   capabilities = ["read", "list"]
 }
EOF


vault policy write service-broker /home/vault/service-broker.hcl

vault auth enable approle

vault write -f auth/approle/role/service-broker \
          bind_secret_id=true \
          policies=service-broker \
          token_ttl=3600 \
          token_max_ttl=3600