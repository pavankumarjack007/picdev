import os
from cloudfoundry_client.client import CloudFoundryClient
import time
import requests
from aws_requests_auth.aws_auth import AWSRequestsAuth
import json
import string, random
import base64
import pytest

from tests.pytest.tests.conftest import cluster_name

cluster_name = os.environ['cluster']

productionBrokersPlans = {
    "hsdp-s3": [["hsdp-s3"], ["s3_bucket"]],
    "hsdp-redis-db": [["hsdp-redis-db"], ["nano-dev", "redis-development", "redis-standalone"]],
    "hsdp-rds": [["hsdp-rds"], ["postgres-micro-dev", "postgres-medium-dev", "postgres-5th-gen-large",
                                "postgres-5th-gen-xlarge", "mysql-micro-dev", "mysql-medium-dev",
                                "mysql-large"]],
    "hsdp-rabbitmq": [["hsdp-rabbitmq"], ["medium-standalone", "large-standalone", "nano-dev", "large-cluster",
                                          "xlarge-standalone", "xlarge-cluster"]],
    "hsdp-elastic": [["hsdp-elastic"], ["es6-dev-1", "es6-standard-3", "es7-dev-1", "es7-standard-3"]]
}

cfadminpassword = os.popen("./binary/credhub get --name 'cfadminpassword' -j| jq -r '.value'").read().strip()

brokers = []
sleepFor = 5  # 4 seconds wait


def getRandomString(N):
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=N))


@pytest.mark.sat
def test_verify_available_broker(productionBrokers=productionBrokersPlans.keys(), cf_pass=cfadminpassword):
    print("testing if all production brokers are avialable")
    cf_ep = cluster_name[3:]
    target_endpoint = "https://api.cf" + cf_ep
    client = CloudFoundryClient(target_endpoint, verify=False)
    client.init_with_user_credentials('admin', cf_pass)
    for service_brokers in client.v2.service_brokers:
        brokers.append(service_brokers['entity']['name'])
    print(brokers)
    for P_broker in productionBrokers:
        print(P_broker, "is Avilaable? =", P_broker in brokers)
        assert P_broker in brokers;


@pytest.mark.sat
def test_verify_cf_api_login(target_endpoint=cluster_name[3:], cf_pass=cfadminpassword):
    os.system('cf api https://api.cf' + target_endpoint)
    os.system('cf login -u admin -p ' + cf_pass + ' -o hsop -s services')
    assert True


def create_service(brokerName, planname, serviceName, serviceInstanceName):
    output = os.popen(
        'cf create-service ' + serviceName + ' ' + planname + ' -b' + brokerName + " " + serviceInstanceName).read()
    print('cf create-service ' + serviceName + ' ' + planname + ' -b ' + brokerName + " " + serviceInstanceName);

    retryFor = 40
    while retryFor > 0:
        output = os.popen('cf service ' + serviceInstanceName).read()
        if str(output).find("succeeded") >= 0:
            print("Creation succeeded")
            print(os.popen('cf delete-service ' + serviceInstanceName + " -f").read());
            assert True
            break;
        else:
            print("Service Creating ...[createing]")
            retryFor = retryFor - 1
            time.sleep(sleepFor)
            if (retryFor <= 0):
                print("Failed to Create Service [TIMEDOUT]")
                print(os.popen('cf delete-service ' + serviceInstanceName + " -f").read());
                assert False;
                break


@pytest.mark.sat
def test_913176_verify_create_broker_service_instances():
    for broker in productionBrokersPlans.keys():
        for service in productionBrokersPlans[broker][0]:
            for plan in productionBrokersPlans[broker][1]:
                create_service(broker, plan, service, getRandomString(6));


@pytest.mark.sat
def test_929479_verify_RDS_service_update_storage(serviceInstanceName=getRandomString(6)): #Update manual test case
    print(os.popen('cf create-service hsdp-rds mysql-micro-dev -b hsdp-rds ' + serviceInstanceName).read())
    retryFor = 40
    while retryFor > 0:
        x = os.popen('cf service ' + serviceInstanceName + ' |grep "status:"').read();
        if x.find("succeeded") >= 0:
            print("Service Created ....[created]")
            guid = os.popen('cf service ' + serviceInstanceName + ' --guid').read().strip();
            print("kubectl get pvc -n managed-rds |grep " + guid + " |awk {'print $4'}")
            out = os.popen("kubectl get pvc -n managed-rds |grep " + guid + " |awk {'print $4'}").read().strip()
            print("Persistitent Volume of size " + out + " .  Testing it by changing to 10G")
            os.popen("cf update-service " + serviceInstanceName + " -c '{\"AllocatedStorage\": 10}'").read();
            retryFor2 = 40
            while retryFor2 >= 0:
                print("Serive is being pached.. updateing")
                x = os.popen('cf service ' + serviceInstanceName + '|grep "status:"').read().strip();
                if (x.find("succeeded") >= 0):
                    print("Patch addded sucefully\nTesting if new patch has applied?")
                    out = os.popen("kubectl get pvc -n managed-rds |grep " + guid + " |awk {'print $4'}").read().strip()
                    print("new volume Size is " + out)
                    os.popen('cf delete-service ' + serviceInstanceName + ' -f');
                    if '10Gi' in out:
                        assert True
                    else:
                        print("Service size update dint not suceesful")
                        assert False
                    return;
                else:
                    retryFor2 = retryFor2 - 1
                    time.sleep(sleepFor)
                    print("updating....")
                    if (retryFor2 <= 0):
                        print("Service Created but patch dint affected in time")
                        print(os.popen('cf delete-service ' + serviceInstanceName + ' -f').read());
                        assert False;
                        return;
        else:
            print("Service Creating ...[createing]")
            retryFor = retryFor - 1
            time.sleep(sleepFor)
            if (retryFor <= 0):
                print("Failed to Create Service")
                print(os.popen('cf delete-service ' + serviceInstanceName + ' -f').read());
                assert False;
                break


@pytest.mark.sat
def test_900708_verify_S3_service_update_storage(key="PL4EqjMxFgfpfhefQZMO", secret="R9OMex6tYRPsyu4v3PrWPCxbZmSymqnxHEqBNFmi",
                                      region='eu-central-1', host="https://api.cf" + cluster_name[3:],
                                      serviceInstanceName=getRandomString(6)):
    abroker = "hsdp-s3"
    print(os.popen(
        "cf create-service hsdp-s3 s3_bucket -b " + abroker + " " + serviceInstanceName + " -c '{\"AllocatedStorage\":5}'").read())
    # curl --aws-sigv4 "aws:amz:REGION:s3" -u "KEY:SECRET" -h 'X-Amz-Content-Sha256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' http://s3.cf.dev.hsop.io/minio/admin/v3/get-bucket-quota?bucket=<ID>
    retryFor = 40
    while retryFor > 0:
        x = os.popen('cf service ' + serviceInstanceName + '|grep "status:"').read();
        if x.find("succeeded") >= 0:
            print("Service Created ....[created]")
            guid = os.popen('cf service ' + serviceInstanceName + ' --guid').read().strip();
            print("Persistitent Volume of size 5gb created.  Testing it by changing to 10G")
            os.popen("cf update-service " + serviceInstanceName + " -c '{\"AllocatedStorage\": 10}'").read();
            retryFor2 = 40
            while retryFor2 >= 0:
                print("Serive is being pached.. updateing")
                x = os.popen('cf service ' + serviceInstanceName + '|grep "status:"').read().strip();
                if (x.find("succeeded") >= 0):
                    print("Patch addded sucefully\nTesting if new patch has applied?")
                    # mcli admin bucket quota minio/cf-s3-14a1d3e8-0546-4b7a-80c4-5f831412cead --json
                    # curl --aws-sigv4 "aws:amz:eu-central-1:s3" --user "PL4EqjMxFgfpfhefQZMO:R9OMex6tYRPsyu4v3PrWPCxbZmSymqnxHEqBNFmi" --header 'X-Amz-Content-Sha256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' http://s3.cf.dev.hsop.io/minio/admin/v3/get-bucket-quota?bucket=cf-s3-14a1d3e8-0546-4b7a-80c4-5f831412cead
                    auth = AWSRequestsAuth(aws_access_key=key, aws_secret_access_key=secret, aws_host=host,
                                           aws_region=region, aws_service='s3')
                    response = requests.get('https://' + host + '/minio/admin/v3/get-bucket-quota?bucket=cf-s3-' + guid,
                                            auth=auth, data='')
                    out = int(json.loads(response.content)['quota'] / 10e8)
                    print("new volume Size is ", out)
                    print(os.popen('cf delete-service ' + serviceInstanceName + ' -f').read());
                    if 10 == int(out):
                        print("PASSED")
                        assert True
                    else:
                        print("Failed. Updated Service has not patched")
                        assert False
                    return;
                else:
                    retryFor2 = retryFor2 - 1
                    time.sleep(sleepFor)
                    print("updating....")
                    if (retryFor2 <= 0):
                        print("Service Created but patch dint affected in time")
                        print(os.popen('cf delete-service ' + serviceInstanceName + ' -f').read());
                        assert False;
                        return;
        else:
            print("Service Creating ...[createing]")
            retryFor = retryFor - 1
            time.sleep(sleepFor)
            if (retryFor <= 0):
                print("Failed to Create Service")
                assert False;
                break


@pytest.mark.sat
def test_verify_DockerImages_host_and_namespace():
    # echo [{`kubectl get pods  -A  -o jsonpath='{range .items[*]}{"},"}{"{\"PodName\":\""}{.metadata.name}{"\",\"namespace\":\""}{.metadata.namespace}{"\",\"dockerImage\":["}{range .spec.containers[*]}{"\""}{.image}{"\","}{end}{"\"\"]"}{end}{"}"}'`]
    cmd = 'echo [{`kubectl get pods  -A  -o jsonpath=\'{range .items[*]}{\"},\"}{\"{\\\"PodName\\\":\\\"\"}{.metadata.name}{\"\\\",\\\"namespace\\\":\\\"\"}{.metadata.namespace}{\"\\\",\\\"dockerImage\\\":[\"}{range .spec.containers[*]}{\"\\\"\"}{.image}{\"\\\",\"}{end}{\"\\\"\\\"]\"}{end}{\"}\"}\'`]'
    myBool = True
    x = json.loads(os.popen(cmd).read())
    for i in range(1, len(x)):
        for j in range(0, len(x[i]['dockerImage'])):
            if (len(x[i]["dockerImage"][j]) > 2):
                if (not ("eng" in x[i]["dockerImage"][j])):
                    print(x[i]['namespace'] + "namespaces pod: " + x[i][
                        "PodName"] + ", contins NON eng docker image. ref:" + x[i]["dockerImage"][j])
                    myBool = False
    if (myBool == True):
        print("Passed")
        assert True
    else:
        print("Failed")
        assert False


@pytest.mark.sat
def test_929480_verify_plv8_image_for_postgres(instanceName="awcator_service", brokerName="hsdp-rds"):
    keyName = "awcator_key"
    print("Performing automation on postgres plv8 to check if image is from priavte repo and max connections are 500")
    print(os.popen(
        "cf create-service hsdp-rds postgres-micro-dev " + instanceName + " -b " + brokerName + "  -c '{\"EngineVersion\": 9}'").read());
    retryFor = 40
    while retryFor > 0:
        x = os.popen('cf service ' + instanceName + '|grep "status:"').read();
        if x.find("succeeded") >= 0:
            print("Service Created")
            print(os.popen("cf  create-service-key  " + instanceName + " " + keyName).read());
            guid = os.popen("cf service  " + instanceName + " --guid").read().strip().rstrip("\n");
            podName = os.popen(
                "kubectl get pods -n managed-rds|grep " + guid + "|grep -v exporter|awk {'print $1'}").read().strip();
            jsonData = json.loads(os.popen("cf service-key " + instanceName + " " + keyName + "|tail -n +2").read())
            url = jsonData['uri']
            cmd = 'echo [{`kubectl get pods  -A  -o jsonpath=\'{range .items[*]}{\"},\"}{\"{\\\"PodName\\\":\\\"\"}{.metadata.name}{\"\\\",\\\"namespace\\\":\\\"\"}{.metadata.namespace}{\"\\\",\\\"dockerImage\\\":[\"}{range .spec.containers[*]}{\"\\\"\"}{.image}{\"\\\",\"}{end}{\"\\\"\\\"]\"}{end}{\"}\"}\'`]'
            myBool = True
            x = json.loads(os.popen(cmd).read())
            for i in range(1, len(x)):
                for j in range(0, len(x[i]['dockerImage'])):
                    if (x[i]["namespace"] == 'managed-rds' and len(x[i]["dockerImage"][j]) > 2):
                        if (not ("philips" in x[i]["dockerImage"][j])):
                            print(x[i]['namespace'] + "namespaces pod: " + x[i][
                                "PodName"] + ", contins NON eng docker image. ref:" + x[i]["dockerImage"][j])
                            myBool = False
            if (myBool == True):
                print("Passed repository test")
            else:
                print("Failed repository test")
                assert False
            print("Checking number of max connection at config file")
            cmd = "echo `kubectl -n managed-rds exec -it " + podName + "  -- /bin/bash -c  \"cat /var/lib/postgresql/data/postgresql.conf |grep max_connection\"`|grep max_con|awk {'print $3'} "
            print(cmd)
            maxConnecction = os.popen(cmd).read().strip();
            if (maxConnecction.strip() == "500"):
                print("passed max connectivity")
                assert True
                break;
            else:
                print("Failed. maxconnectivity is " + maxConnecction + " expected 500")
                assert False
                break;
        else:
            print("Service Creating ...[createing]")
            retryFor = retryFor - 1
            time.sleep(sleepFor)
            if (retryFor <= 0):
                print("Failed to Create Service")
                assert False;
                break
            """
                #echo [{`kubectl get pods  -A  -o jsonpath='{range .items[*]}{"},"}{"{\"PodName\":\""}{.metadata.name}{"\",\"namespace\":\""}{.metadata.namespace}{"\",\"dockerImage\":["}{range .spec.containers[*]}{"\""}{.image}{"\","}{end}{"\"\"]"}{end}{"}"}'`] |jq| grep -A4 -B4 postgres|grep philips -A4 -B4
                cmd="kubectl -n managed-rds exec -it postgres-ff249503-688e-4eaf-a7e6-8999274e7a54-0 -- psql postgres://4TAkP5dgpQT0R6wy:1mwr62dNr4eWw9OrVOwchOuvFntecuMh@postgres-ca9b300d-219a-4b0d-86b1-6aba92ed2861.managed-rds.svc.cluster.local:5432/hsdp_pg "
                #numberOfInstance="kubectl -n managed-rds exec -it postgres-ff249503-688e-4eaf-a7e6-8999274e7a54-0  -- /bin/bash -c 'for exe in /proc/*/exe; do ls -l $exe 2>/dev/null | grep psql ; done | wc -l'";
                #Alternative ps inside pod: for exe in /proc/*/exe; do ls -l $exe 2>/dev/null | grep psql ; done | wc -l
                #Stressting psql with 499 instances connectivity isnide pod: for x in {1..499}; do psql postgres://4TAkP5dgpQT0R6wy:1mwr62dNr4eWw9OrVOwchOuvFntecuMh@postgres-ca9b300d-219a-4b0d-86b1-6aba92ed2861.managed-rds.svc.cluster.local:5432/hsdp_pgpsql postgres://4TAkP5dgpQT0R6wy:1mwr62dNr4eWw9OrVOwchOuvFntecuMh@postgres-ca9b300d-219a-4b0d-86b1-6aba92ed2861.managed-rds.svc.cluster.local:5432/hsdp_pg & done
                Finding out max connections : cat /var/lib/postgresql/data/postgresql.conf |grep max_con
                """


@pytest.mark.sat
def test_verify_vault_for_stored_credentials(roleid="d2b05953-89a3-e606-b6ee-79d2e40e07b9",
                                 secret_id="4bdcbad9-fe98-cd63-371e-dbb4903f3c31",
                                 ADDR="https://vproxy.us-east.philips-healthsuite.com",
                                 SEC="/cf/497d89a6-7ae8-4b5f-bdb8-8a569f86f418/secret/"):
    print("Checking if secrets are stored in vault from all modules")
    print(os.popen("export VAULT_ADDR=" + ADDR).read())
    print(os.popen("export VAULT_ADDR=" + ADDR).read())
    token = os.popen(
        " curl -s --request POST --data \'{\"role_id\": \"" + roleid + "\",\"secret_id\": \"" + secret_id + "\"}\' " + ADDR + "/v1/auth/approle/login|jq -r \'.auth.client_token\'").read().strip()
    os.popen("export VAULT_TOKEN=" + token)
    modules = {"infrastructure": [], "kubernetes": ["dataplaneapi_config", "infra_minio_admin_password",
                                                    "infra_mysql_root_password", "kube_config.admin",
                                                    "kube_config.ca_cert",
                                                    "kube_config.client_cert", "kube_config.client_key",
                                                    "kube_config.cluster_name", "kube_config.context", "kube_config.id",
                                                    "kube_config.internal", "kube_config.kube_password",
                                                    "kube_config.kube_user", "kube_config.namespace",
                                                    "kube_config.server",
                                                    "ssh_private_key",
                                                    "ssh_public_key"],
               "cloudfoundry": ["cf_api_url", "cf_app_logs_max", "cf_domain", "cf_password", "cf_skip_ssl_validation",
                                "cf_uaa_client_id", "cf_uaa_client_secret", "cf_user", "tls_certificate_pem",
                                "tls_private_key_pem"],
               "monitoring": ["prometheus_admin_password", "stratos_metric_password"],
               "vault": [],
               "services": ["keycloak_password", "keycloak_url", "keycloak_user", "ldap_base", "ldap_password",
                            "ldap_url", "ldap_user", "metrics_config_dashboard_url", "metrics_config_password",
                            "metrics_config_user", "ops_creds_password", "ops_creds_username",
                            "s3_config_access_key_id", "s3_config_api_url", "s3_config_secret_access_key"],
               "brokers": ["es_broker_password", "es_broker_username", "rds_broker_password", "rds_broker_username",
                           "redis_broker_password", "redis_broker_username", "rmq_broker_password",
                           "rmq_broker_username", "s3_broker_password", "s3_broker_username"], "backup": [],
               "alerting": [], "finalize": []}
    for module in modules:
        try:
            if (len(modules[module]) > 0):
                print("---------------Accessing " + module + " module-------------")
                jsonData = json.loads(
                    os.popen(
                        "vault read -format=json " + SEC + cluster_name + "/" + module + "|jq -r .data").read().strip())
                for sensitiveVars in modules[module]:
                    if (len(jsonData[sensitiveVars]) >= 1):
                        print(sensitiveVars, "\t\t\t", base64.b64decode(jsonData[sensitiveVars]))
                    else:
                        print(
                            "--------------------------->[FAIL]The senstive variable " + sensitiveVars + " was failed to retirve from vault. from module" + module)
            else:
                continue
        except:
            print("Failed to acccess secrets.. in these module: ", module)
            assert False
    print("Passed validation.")
    print("Cheking basics read,write delete operation on the vault instance: ")
    print("Performing write operation: ")
    print(os.popen("vault write " + SEC + cluster_name + "/testingDummy myKey=myVal").read().strip())
    print("Perfroming read opertion")
    jsonData = json.loads(os.popen("vault read -format=json " + SEC + cluster_name + "/testingDummy|jq -r '.data'").read().strip())
    print("reviced mykey=", jsonData["myKey"])
    print("Performing Delete operation ")
    os.popen("vault delete " + SEC + cluster_name + "/testingDummy").read().strip()
    print("Perfroming read opertion")
    jsonData = json.loads(os.popen("vault read -format=json " + SEC + cluster_name + "/testingDummy|jq -r '.data'").read().strip())
    if (len(jsonData["myKey"]) >= 1):
        print("Failed validation")
        assert False
    else:
        print("Passed")
        assert False
    assert True