import os
from abc import ABC, abstractmethod

import yaml
from jinja2 import Environment, FileSystemLoader


class Deployment(ABC):
    def __init__(self, config, client, service_record):
        self.config = config
        self.client = client
        self.service_record = service_record
        self.template_environment = Environment(
            autoescape=False,
            loader=FileSystemLoader(os.path.dirname(__file__) + "/../template"),
            trim_blocks=False,
        )

    @abstractmethod
    def deploy(self):
        pass

    @abstractmethod
    def delete(self):
        pass

    @property
    def render_context(self):
        storage = self.service_record.plan_env["STORAGE"]
        memory_request = self.service_record.plan_env["MEMORY_REQUEST"]
        memory_limit = self.service_record.plan_env["MEMORY_LIMIT"]
        cpu_request = self.service_record.plan_env["CPU_REQUEST"]
        cpu_limit = self.service_record.plan_env["CPU_LIMIT"]
        storage_class = self.config.STORAGE_CLASS
        return {
            "instance_id": self.service_record.instance_id,
            "instance_name": self.service_record.instance_name,
            "org_name": self.service_record.organization_name,
            "org_space": self.service_record.space_name,
            "redis_password": self.service_record.credentials.password,
            "storage_class": storage_class,
            "storage_capacity": storage,
            "memory_request": memory_request,
            "service_name": self.service_record.service_name,
            "cpu_request": cpu_request,
            "memory_limit": memory_limit,
            "cpu_limit": cpu_limit,
            "namespace": self.service_record.service_namespace,
            "monitoring_tag": self.config.MONITORING_TAG,
            "DOCKER_REGISTRY": self.config.DOCKER_REGISTRY,
            "reg_cred": self.config.REG_CRED
        }

    def render_template(self, template_filename, context):
        return self.template_environment.get_template(template_filename).render(context)


class RedisDeployment(Deployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def deploy(self):
        redis_stateful_set = self.render_template(
            "redis-statefulset.yaml", self.render_context
        )
        redis_stateful_set = yaml.safe_load(redis_stateful_set)
        self.client.create_stateful_set(
            self.service_record.service_namespace, redis_stateful_set
        )
        redis_service = self.render_template("redis-service.yaml", self.render_context)
        redis_service = yaml.safe_load(redis_service)
        self.client.create_service(self.service_record.service_namespace, redis_service)

    def delete(self):
        self.client.delete_service(
            self.service_record.service_namespace, self.service_record.service_name
        )
        self.client.delete_stateful_set(
            self.service_record.service_namespace, self.service_record.service_name
        )


class RedisDeploymentWithMonitoring(RedisDeployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def deploy(self):
        super(RedisDeploymentWithMonitoring, self).deploy()
        deployment = self.render_template(
            "exporter/deployment.yaml", self.render_context
        )
        self.client.create_deployment(
            self.service_record.service_namespace, yaml.safe_load(deployment)
        )
        svc = self.render_template("exporter/service.yaml", self.render_context)
        self.client.create_service(
            self.service_record.service_namespace, yaml.safe_load(svc)
        )
        service_monitor = self.render_template(
            "exporter/servicemonitor.yaml", self.render_context
        )
        self.client.create_service_monitor(
            self.service_record.service_namespace, yaml.safe_load(service_monitor)
        )

    def delete(self):
        super(RedisDeploymentWithMonitoring, self).delete()
        name = f"redis-exporter-{self.service_record.instance_id}"
        self.client.delete_deployment(self.service_record.service_namespace, name)
        self.client.delete_service(self.service_record.service_namespace, name)
        self.client.delete_service_monitor(self.service_record.service_namespace, name)
