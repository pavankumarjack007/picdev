#!/bin/bash

# This is the minimum amount of testing that should be done after a
# Cloud Foundry upgrade.
# Requires cf cli, uuidgen

# endpoint is used for region specific things like buildpack naming
# and whether to test windows.
# Added cf login to set the endpoint
pwd=$(grep  'cf_admin_password:' ../../source/deployment/modules/cloudfoundry/values/kubecf_ext-blobstore_kops.yaml.tpl | tail -n1 | awk '{ print $2}')
domainname=$(sudo cat ../../source/deployment/profiles/outposts-bothell-small.tfvars | grep domain | cut -d '=' -f2 | tr -d '"')
echo $domainname
url=https://api.cf.$domainname
echo $url
cf login -a $url -u admin -p $pwd -o hsop -s services --skip-ssl-validation
endpoint=$(cf target | grep endpoint | cut -f3 -d/)

############################################################
# Functions

# Print messages with some spacing
tell() {
    echo ""
    echo "$@"
    echo ""
}

# Returns a space-separated string of buildpack names we
# want to test with.  Their names differ by region.
get_buildbacks() {

    case $endpoint in
        "api.cn1.philips-healthsuite.com.cn")
	    echo "java_buildpack_cached"
            ;;
        *)
	    echo "java_buildpack"
            ;;
    esac
}

get_python_buildpack() {
    local endpoint=$(cf target | grep endpoint | cut -f3 -d/)

    case $endpoint in
        "api.cn1.philips-healthsuite.com.cn")
	    echo "python_buildpack_cached"
            ;;
        *)
	    echo "python_buildpack"
            ;;
    esac

}

# Define region-specific curl options
get_curl_options() {
    case $endpoint in
        "api.cf.hspremise.com"|"api.cf.hspremise.com")
            CURLOPT="--insecure"
            ;;
        *)
            CURLOPT=""
            ;;
    esac
}

# Pause and wait for ENTER key
take_a_break() {
    echo ""
    echo "-----------------"
    echo "press ENTER to continue"
    read
    echo ""
}

# Clean up
cf_delete_app() {
    local UUID="$1"
    local appname="$2"

    cf delete ${appname}-${UUID} -f -r
}

# Push binding-post app
push_binding_post() {
#    local UUID="$1"
    local PYTHON_BUILDPACK=$(get_python_buildpack)
    tell "TEST: Pushing the trivial python application"
    cd ${CURPWD}/binding-post
    cat manifest.yml.template | sed -e "s/UUID/${UUID}/" -e "s/BUILDPACK/$PYTHON_BUILDPACK/" > manifest.yml
    cf push
    if [ "$?" -gt 0 ]; then
	tell "FAILURE: There was a problem pushing a trivial python application. $?"
	cf_delete_app "$UUID" binding-post
	exit 1
    fi
    tell "SUCCESS: Push successful"
}

# Test binding-post app's endpoint
test_binding_post_endpoint() {
#    local UUID="$1"

    tell "TEST: check application endpoint"
    cd ${CURPWD}/binding-post
    local HOST=$(cf apps | grep 512 | awk '{print $6}')

    local URL=https://${HOST}/
    curl -k  ${URL}
    if [ "$?" -gt 0 ]; then
	tell "FAILURE: There was a problem with the application endpoint $URL"
	cf_delete_app "$UUID" binding-post
	exit 1
    fi
    tell "SUCCESS: Endpoint testing successful"
}

# Test restaging the binding-post app
test_binding_post_restage() {
    local UUID="$1"

    tell "TEST: Restaging application"
    cd ${CURPWD}/binding-post
    cf restage ${UUID}
    if [ "$?" -gt 0 ]; then
	tell "FAILURE: There was a problem restaging a trivial python application."
	cf_delete_app "$UUID" binding-post
	exit 1
    fi
    tell "SUCCESS: Restage successful"
}

test_windows() {
    local UUID="$1"
    tell "TEST: Pushing a trivial windows application"
    cd ${CURPWD}/windowsapp
    cat manifest.yml.template | sed -e "s/UUID/${UUID}/" > manifest.yml
    cf push
    if [ "$?" -gt 0 ]; then
	tell "FAILURE: There was a problem pushing a trivial windows application. $?"
	cf_delete_app "$UUID" env
	exit 1
    fi
    tell "SUCCESS: Push successful"
}

# Create or delete hsdp-s3 service instance
# smoketest-s3
hsdp_s3 () {
    local mode="$1"

    # progress_checks * sleep_seconds is the total number of seconds we
    # wait for the service to be created/deleted
    local progress_checks=60
    local sleep_seconds=15
    local rmq_status=""
    local c

    case $mode in
        "create")
	    local cmd="cf create-service hsdp-s3 s3_bucket smoketest-s3"
	    local target_status="acreate succeeded"
            ;;
	"delete")
	    local cmd="cf delete-service smoketest-s3 -f"
	    local target_status="a"
	    ;;
	*)
            tell "ERROR: invalid mode specified. Valid modes are: create, delete"
            exit 1
            ;;
    esac

    # Run create or delete command
    $cmd

    # check on service creation/deletion and wait until it's done or
    # timeout
    echo -n "Waiting for completion: "
    for ((c=1; c<=$progress_checks; c++ )); do
	rmq_status=$(cf service smoketest-s3 | grep -i "Status:" | \
			 awk '{for (i=2; i<NF; i++) printf $i " "; print $NF}')
	if [ "a${rmq_status}" == "${target_status}" ]; then
	    tell "Service creation/deletion complete"
            break
	else
	    echo -n "."
	    sleep $sleep_seconds
	fi
    done

    echo ""
    if [ "a${rmq_status}" != "${target_status}" ]; then
	tell "ERROR: Service creation/deletion timed out"
    fi
}

# Test service binding
test_binding_post_service_bind() {
    local UUID="$1"
    local endpoint=$(cf target | grep endpoint | cut -f3 -d/)

    tell "TEST: create s3 service, bind, unbind, delete"

    cf create-service hsdp-s3 s3_bucket smoketest-s3

    sleep 5

    # Bind and unbind service
    cf bind-service binding-post-${UUID} smoketest-s3
    echo ""
    cf unbind-service binding-post-${UUID} smoketest-s3

    # Delete service
    cf delete-service smoketest-s3 -f

    tell "s3 service tests complete. Check above for errors."
}

# Test Java app with given buildpack
push_java_app() {
    local UUID="$1"
    local JAVABP="$2"
    local STACK="$3"
    if [ -z "$STACK" ]; then
        STACK=cflinuxfs3
    fi

    tell "TEST: Pushing java app with buildpack $JAVABP and stack $STACK"
    cd ${CURPWD}/hello-spring-cloud
    cat manifest.yml.template | sed -e "s/UUID/${UUID}/" -e "s/BUILDPACK/$JAVABP/" -e "s/STACK/$STACK/" > manifest.yml
    cf push
    if [ "$?" -gt 0 ]; then
	tell "FAILURE: There was a problem pushing a trivial java app with the $JAVABP buildpack"
	cf_delete_app "$UUID" hello-spring-cloud
	exit 1
    fi
    cf_delete_app "$UUID" hello-spring-cloud
    tell "SUCCESS: Push of Java app with buildpack $JAVABP successful"
}

############################################################
# Main Program

UUID=$(uuidgen)
CURPWD=$(pwd)

cf target
echo "________________________"
echo "Check that your target org/space above is correct"
echo "If there is a problem, you should CTL-c and fix it"
#take_a_break

# Set some curl options based on region
get_curl_options

ORG=$(cf target | grep ^org: | awk '{print $2}' | tr A-Z a-z )

if [ "$ORG" != "hsop" ]; then
    tell "ERROR: Your organization target needs to be hsop to run smoketests"
    exit 1
fi

# Push binding post and run some tests
push_binding_post "$UUID"
#take_a_break

test_binding_post_endpoint "$UUID"
#take_a_break

test_binding_post_restage "pythonapp"
#take_a_break

# Push a simple Java app using Java buildpacks
#for buildpack in $(get_buildbacks); do
#    push_java_app "hello-spring-cloud"
     cd hello-spring-cloud
     cf push "hello-spring-cloud" 
#    take_a_break
#done

# Test a simple Windows app
#test_windows "$UUID"
#cf_delete_app "$UUID" env
#take_a_break

# Test rabbitmq service binding
#test_binding_post_service_bind "$UUID"
#take_a_break

# Clean up
cf delete pythonapp -f
cf delete hello-spring-cloud -f
cd ${CURPWD}

tell "SUCCESS: Smoketests complete. Have a fun day"

