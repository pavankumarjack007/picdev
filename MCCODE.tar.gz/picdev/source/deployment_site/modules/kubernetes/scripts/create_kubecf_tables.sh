#! /bin/bash

#Create tables
kubectl -n cf-mysql run mysql-client --image=mysql:5.7 -i --rm --restart=Never --\
  mysql -h mysql.cf-mysql.svc.cluster.local --user=root --password=${1} <<EOF
create database IF NOT EXISTS uaa;
create database IF NOT EXISTS cloud_controller;
create database IF NOT EXISTS diego;
create database IF NOT EXISTS network_policy;
create database IF NOT EXISTS network_connectivity;
create database IF NOT EXISTS locket;
create database IF NOT EXISTS credhub;
create database IF NOT EXISTS \`routing-api\`;
EOF