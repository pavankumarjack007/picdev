#/bin/bash
scp -i /home/MC_Jenkins/locals/cicd-key.pem -o StrictHostKeyChecking=no ${WORKSPACE}/MicroCloud.tar.gz ubuntu@3.122.160.170:/home/ubuntu/workspace/
ssh -i /home/MC_Jenkins/locals/cicd-key.pem -o StrictHostKeyChecking=no ubuntu@3.122.160.170 << EOF
#uname -a
cd /home/ubuntu/workspace/
#docker rmi -f $(docker images -aq)
docker system prune -a -f
sudo rm -rf MicroCloud && mkdir -p MicroCloud && tar -zxf MicroCloud.tar.gz -C MicroCloud/
cd /home/ubuntu/workspace/MicroCloud/source/deployment_stable/
cp /home/ubuntu/workspace/outposts-ams-cicd.tfvars profiles/
source /home/ubuntu/workspace/export_vars.sh
sed -i 's/-i -t//g' teardown.sh
sed -i 's/-i -t//g' deploy.sh
bash teardown.sh
bash deploy.sh
EOF
scp -i /home/MC_Jenkins/locals/cicd-key.pem -o StrictHostKeyChecking=no ubuntu@3.122.160.170:/home/ubuntu/workspace/outposts-ams-cicd.tfvars ../tests/pytest/
