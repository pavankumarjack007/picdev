import logging

from flask import Blueprint, current_app, redirect, request

LOG = logging.getLogger(__name__)

controller = Blueprint("dashboard", __name__, url_prefix="/dashboard")


@controller.route("/manage/<instance_id>", methods=["GET"])
def manage_instance(instance_id):
    redirect_from = request.url
    redirect_to = current_app.config["CONSOLE_URL"] + "/rds/manage/" + instance_id
    LOG.info(f"Redirecting <{redirect_from}> to <{redirect_to}>")
    return redirect(redirect_to)


# noinspection PyUnusedLocal
@controller.route("/", defaults={"path": ""}, strict_slashes=False)
@controller.route("/<path:path>")
def index(path):
    redirect_from = request.url
    redirect_to = current_app.config["CONSOLE_URL"]
    LOG.info(f"Redirecting <{redirect_from}> to <{redirect_to}>")
    return redirect(redirect_to)
