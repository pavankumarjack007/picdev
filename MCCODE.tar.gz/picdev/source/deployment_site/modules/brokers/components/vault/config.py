import logging
import os
import uuid
from jinja2 import Environment, FileSystemLoader


class Config(object):
    # Flask-specific
    DEBUG = False
    TESTING = False

    BROKER_USERNAME = os.getenv("BROKER_USERNAME", "")
    BROKER_PASSWORD = os.getenv("BROKER_PASSWORD", "")
    PORT = int(os.getenv("PORT", "3366"))

    VAULT_ROLE_ID = os.getenv("VAULT_ROLE_ID", "2282a82e-db29-aeed-33b8-3b9466719afc")
    VAULT_SECRET_ID = os.getenv("VAULT_SECRET_ID", "9c283c59-8ff1-3409-5260-a7e6a1e9596a")
    #VAULT_ENDPOINT = os.getenv("VAULT_ENDPOINT", "https://localhost:8443")
    VAULT_ENDPOINT = os.getenv("VAULT_ENDPOINT", "http://40.88.52.227:8200")
    VAULT_CLIENT_ENDPOINT = os.getenv("VAULT_CLIENT_ENDPOINT", "")
    VAULT_TIMEOUT = os.getenv("VAULT_TIMEOUT", 30)
    VAULT_SSL_VERIFY = False

    path = os.path.dirname(os.path.realpath(__file__))
    j2 = Environment(loader=FileSystemLoader(path), trim_blocks=True)
    policy_template = j2.get_template("broker/templates/policy_rules.json")
    approle_template = j2.get_template("broker/templates/approle_params.json")

    log_format = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    log_level = int(logging.DEBUG)


class DevelopmentConfig(Config):
    DEBUG = True


class TestingConfig(Config):
    TESTING = True
    DEBUG = False

    BROKER_USERNAME = ""
    BROKER_PASSWORD = ""

    # Allow concurrent test runs
    TEST_RUN_GUID = str(uuid.uuid4())
    PREFIX = "test"


class ProductionConfig(Config):
    DEBUG = False
    VAULT_SSL_VERIFY = True

    log_format = logging.Formatter("[%(levelname)s] %(name)s: %(message)s")
    log_level = int(logging.INFO)


# Global config object
config_map = {
    "development": DevelopmentConfig(),
    "testing": TestingConfig(),
    "production": ProductionConfig(),
    "default": DevelopmentConfig(),
}
