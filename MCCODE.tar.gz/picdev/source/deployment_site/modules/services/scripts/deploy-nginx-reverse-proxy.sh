#!/bin/bash
#kubectl apply -f ../nginx-reverse-proxy/ -n nginx-reverse-proxy

# TODO: to be removed when cert cronjob is done
kubectl get secret router-public-certificate --namespace=certificates -o yaml | grep -v '^\s*namespace:\s' | kubectl apply --namespace=nginx-reverse-proxy -f -

