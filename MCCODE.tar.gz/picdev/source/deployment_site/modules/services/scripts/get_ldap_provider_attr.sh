#! /bin/bash

providerId=$(jq '.components."org.keycloak.storage.UserStorageProvider"[] | select(.providerId=="ldap") | {provider: .id}' ${1}/values-keycloak-hsop-realm.json)

mapperId=$(jq -r '.components."org.keycloak.storage.UserStorageProvider"[] | select(.providerId=="ldap") | .subComponents."org.keycloak.storage.ldap.mappers.LDAPStorageMapper"[] | select(.providerId=="group-ldap-mapper") | {mapper: .id}' ${1}/values-keycloak-hsop-realm.json)

echo $providerId $mapperId | jq -s add
