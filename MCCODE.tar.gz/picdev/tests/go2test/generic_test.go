package main

import (
	"fmt"
	"testing"

	"go2test.com/test/testframe"

	"github.com/gruntwork-io/terratest/modules/terraform"

	"github.com/stretchr/testify/assert"
)

///##################
//https://gitmemory.com/issue/zclconf/go-cty/17/508413998

func Test_module_output_asserting(t *testing.T) {

	allTestDefs := testframe.GetTestDinitions()
	testCases := allTestDefs.AllTestCases

	fmt.Println("Test_output_asserting")

	t.Run("assert_output", func(t *testing.T) {

		fmt.Println("Run each test ")
		for i := 0; i < len(testCases); i++ {

			fmt.Println("Run each test " + testCases[i].Name)
			t.Run(testCases[i].Name, func(t *testing.T) {

				var inputVars map[string]interface{} = testframe.GetInputParams(testCases[i], t)

				terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
					TerraformDir: testCases[i].Module_path,
					Vars:         inputVars,
				})

				// fill the variables

				defer terraform.Destroy(t, terraformOptions)

				terraform.InitAndApply(t, terraformOptions)

				outValid := testframe.ValidateOutput(terraform.OutputAll(t, terraformOptions), testCases[i], t)
				assert.True(t, outValid)
			})
		}

	})

}

func Test_service_endpoint(t *testing.T) {

}
