#! /bin/bash

kubectl -n identity cp ./group_add.ldif \
 $(kubectl -n identity get po -l app=openldap --no-headers=true -o custom-columns=":metadata.name"):/etc/ldap/group_add.ldif -c openldap

kubectl -n identity cp ./group_access.ldif \
 $(kubectl -n identity get po -l app=openldap --no-headers=true -o custom-columns=":metadata.name"):/etc/ldap/group_access.ldif -c openldap

kubectl -n identity exec $(kubectl -n identity get po -l app=openldap --no-headers=true -o custom-columns=":metadata.name") \
 -c openldap -- ldapadd -h localhost -p 389 -D "cn=admin,dc=identity,${2}" -w ${1} -f /etc/ldap/group_add.ldif

kubectl -n identity exec $(kubectl -n identity get po -l app=openldap --no-headers=true -o custom-columns=":metadata.name") \
 -c openldap -- ldapmodify -h localhost -p 389 -D "cn=admin,cn=config" -w ${3} -f /etc/ldap/group_access.ldif

