import graphene
from .instance_details import InstanceDetails


class Instance(graphene.ObjectType):
    guid = graphene.String()
    details = graphene.Field(InstanceDetails)

    @staticmethod
    def resolve_details(instance, info):
        return info.context.instance_details(instance.guid)