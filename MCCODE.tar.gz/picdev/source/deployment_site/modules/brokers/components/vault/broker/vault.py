"""This module provides an interface to selected Vault API endpoints
"""
import logging
import json
import requests
import sys
from .exceptions import (
    vault_exc_mapping,
    VaultInvalidRequestError,
    VaultUnauthorizedError,
    VaultForbiddenError,
    VaultInvalidPathError,
    VaultInternalServerError,
    VaultUnexpectedError,
    VaultDownError,
)
from functools import wraps
from time import sleep


def retry(ExceptionToCheck, tries=3, delay=1, backoff=1.2):
    """Retry calling the decorated function using an exponential backoff.
    This wrapper should only be used for instances of the VaultClient class
    """

    def retry_decorator(func):
        @wraps(func)
        def retry_f(self, *args, **kwargs):
            mtries, mdelay = tries, delay
            while mtries > 1:
                try:
                    return func(self, *args, **kwargs)
                except ExceptionToCheck as e:
                    msg = ("{0}, retrying in {1:0.2f} seconds").format(str(e), mdelay)
                    self.log.error(msg)
                    sleep(mdelay)
                    mtries -= 1
                    mdelay *= backoff
            return func(self, *args, **kwargs)

        return retry_f

    return retry_decorator


class VaultClient(object):
    def __init__(self, config):
        self.config = config
        self.exc_mapping = vault_exc_mapping
        self.log = logging.getLogger(__name__)
        self.log.setLevel(self.config.log_level)
        self.stream_handler = logging.StreamHandler(sys.stdout)
        self.log_format = self.config.log_format
        self.stream_handler.setFormatter(self.log_format)
        self.log.addHandler(self.stream_handler)

        self.token = None
        self.url = self.config.VAULT_ENDPOINT
        self.ssl_verify = self.config.VAULT_SSL_VERIFY
        self.role_id = self.config.VAULT_ROLE_ID
        self.secret_id = self.config.VAULT_SECRET_ID
        self.token = self._get_token()

    @retry(
        (
            requests.HTTPError,
            requests.ConnectionError,
            VaultForbiddenError,
            VaultUnexpectedError,
        )
    )
    def _get_token(self):
        url = "".join((self.url, "/v1/auth/approle/login"))
        print(url)
        params = {"role_id": self.role_id, "secret_id": self.secret_id}
        print(params)
        try:
            response = (
                requests.post(url, json=params, verify=self.ssl_verify)
                .json()
                .get("auth", {})
            )
        except (ValueError, KeyError):
            msg = "Unexpected authentication response"
            self.log.error(msg)
            raise VaultUnexpectedError(msg)

        print(response)
        self.token = response.get("client_token", None)
        self.accessor = response.get("accessor", None)
        if self.token:
            self.log.info("Using new token with accessor {0}".format(self.accessor))
        else:
            msg = "Authentication failed"
            self.log.error(msg)
            raise VaultForbiddenError(msg)
        return self.token

    def read(self, path):
        return self._get("/v1/{0}".format(path))

    def write(self, path, data=None, **kwargs):
        return self._post("/v1/{0}".format(path), data=data, **kwargs)

    def delete(self, path):
        return self._delete("/v1/{0}".format(path))

    def create_policy(self, name, policy):
        if isinstance(policy, dict):
            policy = json.dumps(policy)
        params = {"policy": policy}
        path = "/v1/sys/policy/{0}".format(name)
        response = self._post(path, data=params)
        return response.status_code == 204

    def read_policy(self, name):
        path = "/v1/sys/policy/{0}".format(name)
        try:
            response = self._get(path)["rules"]
        except (ValueError, KeyError):
            raise VaultUnexpectedError("Unable to read policy")
        return response

    def delete_policy(self, name):
        path = "/v1/sys/policy/{0}".format(name)
        response = self._delete(path)
        return response.status_code == 204

    def create_approle(self, role_name, **kwargs):
        path = "/v1/auth/approle/role/{0}".format(role_name)
        response = self._post(path, data=kwargs)
        return response.status_code == 204

    def delete_approle(self, role_name):
        path = "/v1/auth/approle/role/{0}".format(role_name)
        response = self._delete(path)
        return response.status_code == 204

    def read_role_id(self, role_name):
        path = "/v1/auth/approle/role/{0}/role-id".format(role_name)
        response = ""
        try:
            response = self._get(path)["data"]["role_id"]
        except (ValueError, KeyError):
            raise VaultUnexpectedError("Unable to read role_id")
        return response

    def create_secret_id(self, role_name, metadata=None):
        url = "/v1/auth/approle/role/{0}/secret-id".format(role_name)
        params = {}
        response = {}
        if metadata is not None:
            params["metadata"] = json.dumps(metadata)
        try:
            response = self._post(url, data=params)
        except ValueError:
            raise VaultUnexpectedError("Unable to create secret_id")
        return response

    def delete_secret_id(self, role_name, secret_id):
        url = "/v1/auth/approle/role/{0}/secret-id/destroy".format(role_name)
        params = {"secret_id": secret_id}
        response = self._post(url, data=params)
        return response.status_code == 204

    def mount_secret_backend(
        self, backend_type, description=None, mount_point=None, config=None
    ):
        if not mount_point:
            mount_point = backend_type
        params = {"type": backend_type, "description": description, "config": config}
        response = self._post("/v1/sys/mounts/{0}".format(mount_point), data=params)
        return response.status_code == 204

    def unmount_secret_backend(self, mount_point):
        response = self._delete("/v1/sys/mounts/{0}".format(mount_point))
        return response.status_code == 204

    def _renew_token(self):
        self.log.info("Renewing client token with accessor {0}".format(self.accessor))
        response = self._post("/v1/auth/token/renew-self")
        return response.status_code == 200

    def _raise_vault_error(self, status_code):
        error_codes = {
            400: VaultInvalidRequestError,
            401: VaultUnauthorizedError,
            403: VaultForbiddenError,
            404: VaultInvalidPathError,
            500: VaultInternalServerError,
            503: VaultDownError,
        }
        if status_code not in error_codes:
            raise VaultUnexpectedError("Unexpected response from Vault")
        exc = error_codes[status_code]
        description = self.exc_mapping[exc]["description"]
        self.log.error(description)
        raise exc(description)

    # The get/post/delete wrapper methods use our retry decorator on
    # VaultForbiddenError to deal with token expiry. This is a bit of
    # a hack but saves a lot of trouble maintaining token state
    @retry((requests.HTTPError, requests.ConnectionError, VaultForbiddenError))
    def _get(self, path, **kwargs):
        url = "".join((self.url, path))
        ret = None
        response = requests.get(
            url, headers={"X-Vault-Token": self.token}, verify=self.ssl_verify
        )
        if response.status_code == 403:
            self.token = self._get_token()
            self.log.info("Retrying with token accessor {0}".format(self.accessor))
            raise VaultForbiddenError("Token expired")
        else:
            ret = self._handle_response(response)
        return ret

    @retry((requests.HTTPError, requests.ConnectionError, VaultForbiddenError))
    def _post(self, path, data={}):
        url = "".join((self.url, path))
        print("POST url: ", url)
        ret = None
        response = requests.post(
            url,
            headers={"X-Vault-Token": self.token},
            json=data,
            verify=self.ssl_verify,
        )
        if response.status_code == 403:
            self.token = self._get_token()
            self.log.info("Retrying with token accessor {0}".format(self.accessor))
            raise VaultForbiddenError("Token expired")
        else:
            ret = self._handle_response(response)
        return ret

    @retry((requests.HTTPError, requests.ConnectionError, VaultForbiddenError))
    def _delete(self, path):
        url = "".join((self.url, path))
        ret = None
        response = requests.delete(
            url, headers={"X-Vault-Token": self.token}, verify=self.ssl_verify
        )
        if response.status_code == 403:
            self.token = self._get_token()
            self.log.info("Retrying with token accessor {0}".format(self.accessor))
            raise VaultForbiddenError("Token expired")
        else:
            ret = self._handle_response(response)
        return ret

    def _handle_response(self, response):
        if not response.ok:
            self._raise_vault_error(response.status_code)
        try:
            ret = response.json()
        except ValueError:
            ret = response
        return ret
