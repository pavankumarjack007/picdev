import base64
import logging

from kubernetes import client
from kubernetes.client.rest import ApiException
from tenacity import before_sleep_log
from tenacity import retry as tenacity_retry
from tenacity import (
    retry_if_exception,
    stop_after_attempt,
    stop_after_delay,
    wait_exponential,
)


def retry(*args, **kwargs):
    kwargs["before_sleep"] = kwargs.get(
        "before_sleep", before_sleep_log(logging.getLogger(__name__), logging.WARNING)
    )
    kwargs["reraise"] = kwargs.get("reraise", True)
    kwargs["retry"] = kwargs.get(
        "retry",
        retry_if_exception(
            lambda e: isinstance(e, ApiException) and e.status in (429, 500, 503)
        ),
    )
    kwargs["stop"] = kwargs.get("stop", (stop_after_delay(30) | stop_after_attempt(10)))
    kwargs["wait"] = kwargs.get("wait", wait_exponential(multiplier=1.2, max=10))
    return tenacity_retry(*args, **kwargs)


class K8SClient:
    MONITORING_GROUP = "monitoring.coreos.com"
    MONITORING_VERSION = "v1"
    MONITORING_PLURAL = "servicemonitors"

    def __init__(self, endpoint, cert, token):

        self.endpoint = endpoint
        self.cert = cert
        self.token = token

        # urllib3 insists on reading CA certs from a file object
        with open("cert.pem", "wb") as cert_f:
            cert_f.write(base64.b64decode(str.encode(self.cert)))
            cert_f.flush()

        api_config = client.Configuration()
        api_config.host = endpoint
        api_config.verify_ssl = False
        api_config.ssl_ca_cert = cert_f.name
        api_config.api_key["authorization"] = bytes.decode(
            base64.b64decode(str.encode(self.token))
        )
        api_config.api_key_prefix["authorization"] = "Bearer"
        self.api_client = client.ApiClient(api_config)

        self.log = logging.getLogger(__name__)
        self.k8s_client = client.CoreV1Api(self.api_client)
        self.k8s_apps_client = client.AppsV1Api(self.api_client)

    def namespace_exists(self, name):
        self.log.info(f" Checking if name space {name} exists")
        try:
            response = self.k8s_client.read_namespace(name)
        except ApiException as e:
            if e.status == 404:
                return False
        else:
            status = response.status
            return status.phase == "Active"

    @retry()
    def create_namespace(self, name):
        self.log.info(f"Creating name space {name}")
        try:
            self.k8s_client.create_namespace(
                client.V1Namespace(metadata=client.V1ObjectMeta(name=name))
            )
        except ApiException as e:
            self.log.error(f"Error in creating name space {e}")

    @retry()
    def create_stateful_set(self, namespace, data):
        self.log.info(f"Creating stateful set in namespace {namespace}")
        try:
            self.k8s_apps_client.create_namespaced_stateful_set(
                body=data, namespace=namespace
            )
        except ApiException as e:
            logging.error(f"Error in creating statefulset {e}")

    @retry()
    def delete_stateful_set(self, namespace, name):
        self.log.info(f"deleting statefulset {name} from namespace {namespace}")
        try:
            self.k8s_apps_client.delete_namespaced_stateful_set(
                name=name, namespace=namespace
            )
        except ApiException as e:
            self.log.error(f"Error in deleting stateful set {e}")

    @retry()
    def create_service(self, namespace, data):
        self.log.info(f"Creating service in namespace {namespace}")
        try:
            self.k8s_client.create_namespaced_service(body=data, namespace=namespace)
        except ApiException as e:
            self.log.error(f"Error in creating service {e}")

    @retry()
    def get_service(self, namespace, name):
        self.log.info(f"Getting service name {name} from namespace {namespace}")
        try:
            return self.k8s_client.read_namespaced_service(
                name=name, namespace=namespace
            )
        except ApiException as e:
            self.log.error(f"Error in getting service name {e}")

    @retry()
    def delete_service(self, namespace, name):
        self.log.info(f"Deleting the service {name} from namespace {namespace}")
        try:
            self.k8s_client.delete_namespaced_service(name=name, namespace=namespace)
        except ApiException as e:
            self.log.error(f"Error in deleting service {e}")

    @retry()
    def pod_status(self, namespace, stateful_set_name):
        self.log.info("Getting the pod status")
        try:
            pod_resp = self.k8s_apps_client.read_namespaced_stateful_set(
                name=stateful_set_name, namespace=namespace
            )
            replicas = pod_resp.spec.replicas
            for idx in range(replicas):
                resp = self.k8s_client.read_namespaced_pod_status(
                    name=f"{stateful_set_name}-{idx}", namespace=namespace
                )
                status = resp.status.phase
                container_status = resp.status.container_statuses[0]
                if container_status.started is False or container_status.ready is False:
                    waiting_state = container_status.state.waiting
                    if (
                        waiting_state.message is not None
                        and "Error" in waiting_state.message
                    ):
                        status = "Failed"
                    else:
                        status = "Pending"
                return status
        except ApiException as e:
            self.log.error(f"Error in getting pod status {e}")
            if e.status == 404:
                return "Failed"

    @retry()
    def pod_delete_status(self, namespace, name):
        self.log.info(f" Checking if pod {name} exists")
        try:
            response = self.k8s_client.read_namespaced_pod(
                name=name, namespace=namespace
            )
            if response.metadata.deletion_timestamp is not None:
                return "Pending"
            else:
                return "Failed"
        except ApiException as e:
            if e.status == 404:
                return "Deleted"

    @retry()
    def create_deployment(self, namespace, data):
        self.log.info(f"Creating deployment in namespace {namespace}")
        try:
            self.k8s_apps_client.create_namespaced_deployment(
                namespace=namespace, body=data
            )
        except ApiException as e:
            self.log.error(f"Error in creating deployment {e}")

    @retry()
    def delete_deployment(self, namespace, name):
        self.log.info(f"Deleting the deployment from namespace {namespace}")
        try:
            self.k8s_apps_client.delete_namespaced_deployment(
                namespace=namespace, name=name
            )
        except ApiException as e:
            self.log.error(f"Error in creating deployment {e}")

    @retry()
    def create_service_monitor(self, namespace, data):
        self.log.info(f" Creating service monitor in {namespace}")
        try:
            api_instance = client.CustomObjectsApi(self.api_client)
            api_instance.create_namespaced_custom_object(
                group=K8SClient.MONITORING_GROUP,
                version=K8SClient.MONITORING_VERSION,
                plural=K8SClient.MONITORING_PLURAL,
                namespace=namespace,
                body=data,
            )
        except ApiException as e:
            self.log.error(f"Error in creating service monitor {e}")

    @retry()
    def delete_service_monitor(self, namespace, name):
        self.log.info(f" Creating service monitor in {namespace}")
        try:
            api_instance = client.CustomObjectsApi(self.api_client)
            api_instance.delete_namespaced_custom_object(
                group=K8SClient.MONITORING_GROUP,
                version=K8SClient.MONITORING_VERSION,
                plural=K8SClient.MONITORING_PLURAL,
                namespace=namespace,
                name=name,
            )
        except ApiException as e:
            self.log.error(f"Error in deleting service monitor {e}")
