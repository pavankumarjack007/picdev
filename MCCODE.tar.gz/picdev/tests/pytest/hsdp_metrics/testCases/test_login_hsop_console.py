import time

from pageObjects.login_hsop_console import LoginPage
from utilities.readProperties import ReadConfig
from utilities.custom_Logger import LogGen


class Test_Login_hsop_console():
    consoleURL = ReadConfig.getConsoleURL()
    # baseURL = ReadConfig.getApplicationURL()
    username = ReadConfig.getUsername()
    password = ReadConfig.getPassword()
    password_benchmark = ReadConfig.getbenchmarkpassword()
    threshold_disk = ReadConfig.getThresholdDisk()
    threshold_latency = ReadConfig.getThresholdLatency()
    threshold_rate = ReadConfig.getThresholdRate()
    threshold_codes = ReadConfig.getThresholdCodes()
    threshold_instances = ReadConfig.getThresholdInstances()
    rule_description = ReadConfig.getruleDescription()
    rule_description_cpu = ReadConfig.getruleDescriptionCPU()
    rule_description_disk = ReadConfig.getruleDescriptionDisk()
    rule_description_latency = ReadConfig.getruleDescriptionLatency()
    rule_description_rate = ReadConfig.getruleDescriptionRate()
    rule_description_code = ReadConfig.getruleDescriptionCode()
    rule_description_instances = ReadConfig.getruleDescriptionInstances()
    threshold = ReadConfig.getThreshold()
    logger = LogGen.loggen()
    benchmarkURL = ReadConfig.getbenchmarkURL()
    password_cicd1 = ReadConfig.getcicd1Password()
    cicd1URL = ReadConfig.getcicd1URL()
    exp_RDS_element = ReadConfig.gettupleRDS()
    exp_Redis_element = ReadConfig.gettupleRedis()
    exp_RDS_element_brokers = ReadConfig.gettupleRDSBrokers()
    outlook_url = ReadConfig.getoutlookURL()
    email_ID = ReadConfig.getEmailID()
    password_outlook = ReadConfig.getPasswordOutlook()
    search_elements_outlook = ReadConfig.getsearchElementsOutlook()
    message_verification_content = ReadConfig.getmessageVerify()

    def test_login(self, setup):
        self.logger.info("Test_Login_hsop_console")
        self.logger.info("Started Login Test")
        self.driver = setup
        self.driver.get(self.consoleURL)
        self.driver.implicitly_wait(15)
        self.lp = LoginPage(self.driver)
        self.lp.loginCred(self.username, self.password)
        self.logger.info("Started to add the new alert for Memory")
        self.lp.selectSpecificRule(2)
        self.lp.giveDescription(self.rule_description)
        self.lp.thersholdValue(self.threshold)
        self.lp.durationseverityValue(1, 0)
        self.lp.forInstances()
        self.logger.info("Successfully added new alert for Memory")
        self.driver.refresh()
        self.lp.saveEdit()
        self.lp.alertStates()
        self.driver.get(self.outlook_url)
        time.sleep(120)
        self.lp.outlookLogin(self.email_ID, self.password_outlook, self.search_elements_outlook)
        self.logger.info("Successfully logged in to the outlook account and verified")

        if self.lp.verifymessageEmail() == self.message_verification_content:
            self.logger.info("Memory usage for spring-music alert is firing")
            assert True

        self.logger.info("Started to add the new alert for CPU")

        self.lp.selectSpecificRule(1)
        self.lp.giveDescription(self.rule_description_cpu)
        self.lp.thersholdforCPU()
        self.lp.durationseverityValue(1, 0)
        self.lp.forInstances()
        self.logger.info("Successfully added new alert for CPU")
        self.driver.refresh()
        self.lp.saveEdit()
        self.lp.alertStates()

        self.logger.info("Started to add the new alert for Disk")

        self.lp.selectSpecificRule(3)
        self.lp.giveDescription(self.rule_description_disk)
        self.lp.thersholdValue(self.threshold_disk)
        self.lp.durationseverityValue(1, 0)
        self.lp.forInstances()
        self.logger.info("Successfully added new alert for Disk")
        self.driver.refresh()
        self.lp.saveEdit()
        self.lp.alertStates()

        self.logger.info("Started to add the new alert for Latency")

        self.lp.selectSpecificRule(4)
        self.lp.giveDescription(self.rule_description_latency)
        self.lp.thersholdValue(self.threshold_latency)
        self.lp.durationseverityValue(1, 0)
        self.lp.forInstances()
        self.logger.info("Successfully added new alert for Latency")
        self.driver.refresh()
        self.lp.saveEdit()
        self.lp.alertStates()

        self.logger.info("Started to add the new alert for Rate")

        self.lp.selectSpecificRule(5)
        self.lp.giveDescription(self.rule_description_rate)
        self.lp.thersholdValue(self.threshold_rate)
        self.lp.durationseverityValue(1, 0)
        self.lp.forInstances()
        self.logger.info("Successfully added new alert for Rate")
        self.driver.refresh()
        self.lp.saveEdit()
        self.lp.alertStates()

        self.logger.info("Started to add the new alert for Codes")

        self.lp.selectSpecificRule(6)
        self.lp.giveDescription(self.rule_description_code)
        self.lp.thersholdValue(self.threshold_codes)
        self.lp.forcodeStatus()
        self.lp.durationseverityValue(1, 0)
        self.lp.forInstances()
        self.logger.info("Successfully added new alert for Codes")
        self.driver.refresh()
        self.lp.saveEdit()
        self.lp.alertStates()

        self.logger.info("Started to add the new alert for Instances")

        self.lp.selectSpecificRule(7)
        self.lp.giveDescription(self.rule_description_instances)
        self.lp.thersholdValue(self.threshold_instances)
        self.lp.durationseverityValue(1, 0)
        self.lp.forInstances()
        self.logger.info("Successfully added new alert for Instances")
        self.driver.refresh()
        self.lp.saveEdit()
        self.lp.alertStates()

        self.driver.close()

    def test_hsdp_metrics_Redis_RDS(self, setup):
        self.logger.info("Logging into the hsdp-services")
        self.driver = setup
        self.driver.get(self.cicd1URL)
        self.driver.implicitly_wait(10)
        self.lp = LoginPage(self.driver)
        self.lp.loginCredbench(self.username, self.password_cicd1)
        self.lp.hsopServices()
        RDS_element = self.lp.verifyRDSRedis()
        self.logger.info("The listed instances at RDS are" + self.exp_RDS_element)

        if self.exp_RDS_element in RDS_element:
            assert True

        self.lp.redisclickServices()

        Redis_element = self.lp.verifyRDSRedis()
        self.logger.info("The listed instances at Redis are" + self.exp_Redis_element)
        if self.exp_Redis_element in Redis_element:
            assert True
        self.logger.info("Logging into the hsdp-brokers")
        self.lp.hsopBrokers()
        self.driver.implicitly_wait(5)
        RDS_element_brokers = self.lp.verifyRDSRedis()
        self.logger.info("The listed instances at RDS are" + self.exp_RDS_element_brokers)

        if self.exp_RDS_element_brokers in RDS_element_brokers:
            assert True
        self.driver.close()
