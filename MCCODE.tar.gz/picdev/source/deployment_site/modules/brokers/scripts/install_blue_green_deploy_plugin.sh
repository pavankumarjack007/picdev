#!/bin/bash

PLUGIN=blue-green-deploy
if [[ ! -f "$PLUGIN" ]]; then
  wget -c https://github.com/bpandola/cf-blue-green-deploy/releases/download/v1.5.0a/blue-green-deploy.linux64 -O ../bin/blue-green-deploy
fi
cf install-plugin ../bin/blue-green-deploy -f