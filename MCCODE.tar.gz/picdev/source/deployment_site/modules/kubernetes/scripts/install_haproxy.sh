#!/bin/bash
sudo apt-get update
#Installing aws cli on ha-proxy node
echo "*****************INSTALLING AWS CLI ON HAPROXY NODE **********************"
sudo apt-get -qq install jq -y
sudo apt-get -qq install python3 -y
sudo apt-get -qq install python3-pip -y
sudo pip3 install --upgrade pip --quiet
sudo pip3 install awscli --quiet
echo "*********DONE INSTALLING AWS CLI ON HAPROXY NODE *************************"
(
mkdir -p /home/ubuntu/haproxy_dataplane
cd /home/ubuntu/haproxy_dataplane
sudo wget https://github.com/haproxytech/dataplaneapi/releases/download/v2.3.4/dataplaneapi_2.3.4_Linux_x86_64.tar.gz -P /home/ubuntu/haproxy_dataplane
sudo tar -zxvf /home/ubuntu/haproxy_dataplane/dataplaneapi_2.3.4_Linux_x86_64.tar.gz --directory /home/ubuntu/haproxy_dataplane
chmod +x /home/ubuntu/haproxy_dataplane/build/dataplaneapi
sudo cp /home/ubuntu/haproxy_dataplane/build/dataplaneapi /usr/local/bin/
sudo dataplaneapi -f /home/ubuntu/dataplaneapi.hcl &
)
sudo apt-get install -y prometheus-node-exporter
tag="etc-haproxy-$cluster_name"
#Get Instnace ID
Instance_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
echo "Instance_ID -> $Instance_ID"
# check the volume exists with haproxyetc tag
List_volumes=`aws ec2 describe-volumes --filters Name=tag:Name,Values=$tag --query 'Volumes' --region $region`
if [[ $List_volumes == [] ]]; then
        #create volume
        Volumeid=`aws ec2 create-volume --availability-zone $zone_name --volume-type gp2 --size 10 --tag-specifications 'ResourceType=volume,Tags=[{Key=Name,Value="'"$tag"'"}]' --outpost-arn $outposts_arn --query "VolumeId" --region $region | sed 's/"//g'`
        echo "Volumeid -> $Volumeid"
        sleep 30
        # attach volme haproxy instnace
        aws ec2 attach-volume --volume-id $Volumeid --instance-id $Instance_ID --device /dev/sdf --region $region
        sleep 60
        mkfs.ext4 /dev/nvme1n1
        mkdir /etc/haproxy
        mount /dev/nvme1n1 /etc/haproxy
        sudo apt-get install -y haproxy
######################
echo "resolvers masterresolver" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "	parse-resolv-conf" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "" | sudo tee -a /etc/haproxy/haproxy.cfg

echo "frontend http" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  mode http" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  bind 127.0.0.1:80 name v4" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  http-request set-var(txn.base) base" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  use_backend %[var(txn.path_match),field(1,.)]" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "frontend https" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  mode http" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  bind 127.0.0.1:443 name v4" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  http-request set-var(txn.base) base" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  use_backend %[var(txn.path_match),field(1,.)]" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "frontend healthz" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  bind 127.0.0.1:1042 name v4" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  mode http" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  monitor-uri /healthz" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "  option dontlog-normal" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "frontend stats" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        bind *:8404" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        option http-use-htx" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        http-request use-service prometheus-exporter if { path /metrics }" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        stats enable" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        stats uri /stats" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        stats refresh 30s" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "frontend k8s_api_front" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        bind *:6443" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        option tcplog" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        default_backend k8sapi_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "backend k8sapi_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        balance roundrobin" | sudo tee -a /etc/haproxy/haproxy.cfg
COUNTER=0
for i in `echo '${master_node_private_ip}' | sed 's/,/ /g'`; do
COUNTER=$(( COUNTER + 1 ))
done
echo "        server-template masterNode $COUNTER api.internal.$cluster_name:443 check resolvers masterresolver init-addr none" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "frontend forgerock_api_front" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        bind *:32443" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        option tcplog" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        default_backend forgerock_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "backend forgerock_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        balance roundrobin" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        option ssl-hello-chk"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "frontend cf_api_front" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        bind *:443 name ssl" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        option tcplog" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        capture request header X-Forwarded-For len 100" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        default_backend cf_api_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "backend cf_api_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        balance roundrobin"| sudo tee -a /etc/haproxy/haproxy.cfg
if [[ "$TF_VAR_cf_for_k8s" == "false" ]]
then
  echo "        option ssl-hello-chk"| sudo tee -a /etc/haproxy/haproxy.cfg
fi
echo "frontend ssh_tcp_front" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        bind *:2222" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        option tcplog" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        default_backend ssh_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "backend ssh_tcp_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode tcp"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "        balance roundrobin"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "frontend port80_front" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        bind *:80" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode tcp" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        option tcplog" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        default_backend port80_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "backend port80_back" | sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode tcp"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "        balance roundrobin"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "frontend cf_ws_secure_front"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "        mode http"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "        timeout client 5000"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "        default_backend cf_ws_secure_back"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "backend cf_ws_secure_back"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "          mode http"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "          balance roundrobin"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "          option http-server-close"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "          option http-pretend-keepalive"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "          option forwardfor"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "          timeout queue 5000"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "          timeout tunnel 1h"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "          timeout server 86400000"| sudo tee -a /etc/haproxy/haproxy.cfg
echo "          timeout connect 86400000"| sudo tee -a /etc/haproxy/haproxy.cfg

sudo systemctl restart haproxy

else
        sudo apt-get install -y haproxy
        #Get the volume accroding to tag
        Get_Volume_id=`aws ec2 describe-volumes --filters Name=tag:Name,Values=$tag --query "Volumes[0].VolumeId" --region $region | sed 's/"//g'`
        #attache the volume
        aws ec2 attach-volume --volume-id $Get_Volume_id --instance-id $Instance_ID --device /dev/sdf --region $region
        sleep 60
        mkdir /etc/haproxy
        mount /dev/nvme1n1 /etc/haproxy
        sudo systemctl restart haproxy
fi
#Prerequisites for haproxy ingress controller
haproxyCounter=0
while [ $haproxyCounter -le 10 ];
do
    if [ -d "/etc/haproxy" ]; then
        sudo mkdir -p /etc/haproxy/maps
        sudo touch /etc/haproxy/maps/host.map;
        sudo touch /etc/haproxy/maps/path-exact.map;
        sudo touch /etc/haproxy/maps/path-prefix.map;
        break
    else
        echo "Info: Waiting for /etc/haproxy/maps folder to get created";
        sleep 30;
        haproxyCounter=$(($haproxyCounter + 1))
    fi
done
