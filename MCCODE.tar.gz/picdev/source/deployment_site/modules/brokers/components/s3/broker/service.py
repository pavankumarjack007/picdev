import logging

from botocore.exceptions import ClientError
from cf_broker_api import reqparse
from cf_broker_api.exceptions import (
    InvalidServiceParameter,
    ServiceInstanceAlreadyExists,
    ServiceInstanceGone,
    ServiceInstanceNotFound,
)
from jinja2 import Environment, PackageLoader

from broker.aws import SERVICE_ALIASES
from . import aws, cloudfoundry

LOG = logging.getLogger(__name__)


class ContextAwareS3ServiceInstanceService(object):
    def __init__(self, request, app, config):
        self.app = app
        self.config = config
        self.request = request
        self.service_class = self.app.service_class

        try:
            LOG.debug("creating cc")
            cc_args = config.cc_config.copy()
            cc_args.update({"access_token": request.headers["X-User-Access-Token"]})
            self.cc = cloudfoundry.CloudController.new_instance(**cc_args)
        except Exception as e:
            LOG.error("Failed to create CC client!:", exc_info=True)

            raise e

    def get_s3_instances(self):
        return cloudfoundry.get_s3_instances(self.cc)

    def instance_permissions(self, instance_id):
        return self.cc.instance_permissions(instance_id)

    def service_catalog(self):
        plans = []
        name = self.app.service_catalog.services[0]["name"]
        for plan in self.app.service_catalog.services[0]["plans"]:
            plans.append(plan)

        res = self.cc.services().get_by_name(name, "label")
        service = res.resources[0]
        accessible_plans = []
        res = self.cc.services(service.guid, "service_plans").get()
        for plan in res.resources:
            accessible_plans.append(plan.unique_id)

        # Now set restrictions
        for plan in plans:
            if plan["id"] not in accessible_plans:
                plan["restricted"] = True

        return {"name": name, "plans": plans}

    def instance_details(self, instance_id):
        return self.service_class.instance_details(instance_id)

    def instance_metrics(self, instance_id):
        return self.service_class.instance_metrics(instance_id)


class S3ServiceInstanceService(object):
    def __init__(self, model, config=None):
        self.model = model
        self.config = config
        self.instance_prefix = self.config.INSTANCE_PREFIX
        if config.BROKER_ENVIRONMENT == "cloud":
            self.aws_ctx_mngr = aws.ContextManager(
                primary_credentials=self.config.aws_config,
                addtl_credentials=self.config.addtl_aws_credentials,
            )
        self._aws_creds = {}
        self.S3 = None
        if config.BROKER_ENVIRONMENT == "cloud":
            self.IamUser = None
            self.CloudWatch = None
        else:
            self.MinIOIamUser = None
            self.CloudWatch = None
        self.S3Bucket = None
        # This will initialize all of our AWS objects.
        self.aws_creds = self.config.aws_config

    @property
    def aws_creds(self):
        return self._aws_creds

    @aws_creds.setter
    def aws_creds(self, value):
        self._aws_creds = value
        self.S3 = aws.S3(**self._aws_creds)
        self.S3Bucket = aws.S3Bucket(**self._aws_creds)
        if self.config.BROKER_ENVIRONMENT == "cloud":
            self.IamUser = aws.IamUser(**self._aws_creds)
            self.CloudWatch = aws.S3CloudWatch(**self._aws_creds)
        else:
            self.MinIOIamUser = aws.MinIOIamUser(**self._aws_creds)
            self.CloudWatch = aws.MinIoCloudwatch(**self._aws_creds)

    def _set_aws_context(
        self,
        aws_access_key_id,
        aws_secret_access_key,
        region_name=None,
        endpoint_url=None,
    ):
        context = {
            "aws_access_key_id": aws_access_key_id,
            "aws_secret_access_key": aws_secret_access_key,
            "endpoint_url": endpoint_url,
        }
        if region_name:
            context["region_name"] = region_name
        else:
            context["region_name"] = self.config.AWS_DEFAULT_REGION
        self.aws_creds = context

    def _get_service_record(self, instance_id):
        service_record = self.model.get(instance_id)
        if service_record is None:
            raise ServiceInstanceNotFound(instance_id)
        # When we pull our service record, we also need to set the
        # appropriate AWS credentials context for interacting with
        # this particular service instance.
        region_name = service_record.region_name or self.S3.default_location_constraint
        if self.config.BROKER_ENVIRONMENT == "cloud":
            context = self.aws_ctx_mngr.get_context_for_user(service_record.iam_user)
            self._set_aws_context(
                aws_access_key_id=context["aws_access_key_id"],
                aws_secret_access_key=context["aws_secret_access_key"],
                region_name=region_name,
            )
        else:
            self._set_aws_context(
                aws_access_key_id=self.config.aws_config["aws_access_key_id"],
                aws_secret_access_key=self.config.aws_config["aws_secret_access_key"],
                endpoint_url=self.config.aws_config["endpoint_url"],
                region_name=region_name,
            )
        return service_record

    def provision(self, request, instance_id):
        if self.model.get(instance_id) is not None:
            raise ServiceInstanceAlreadyExists(instance_id)
        if self.config.BROKER_ENVIRONMENT == "cloud":
            self._set_aws_context(**self.aws_ctx_mngr.account_with_fewest_buckets)
        aws_instance_id = self.bucket_identifier(instance_id)
        service_record = self.model.new_record(bucket=aws_instance_id, **request)
        policy = UserPolicy(
            aws_instance_id, self.config.BROKER_ENVIRONMENT, self.aws_creds
        ).render()
        if self.config.BROKER_ENVIRONMENT == "cloud":
            iam_user = self.IamUser(aws_instance_id).create(policy=policy)
        else:
            iam_user = self.MinIOIamUser(aws_instance_id).create(policy=policy)
        service_record.iam_user = self.model.IamUser(
            access_key_id=iam_user.access_key_id,
            secret_access_key=iam_user.secret_access_key,
        )
        bucket_args = self._create_args(service_record, request)
        self.S3Bucket(aws_instance_id).create(**bucket_args)
        if "AllocatedStorage" in request.parameters:
            if request.parameters["AllocatedStorage"] >0:
                self.MinIOIamUser(aws_instance_id).set_quota(request.parameters["AllocatedStorage"])
            else:
                invalid_parameter = InvalidServiceParameter()
                invalid_parameter.description = "Not a supported value for AllocatedStorage."
                raise invalid_parameter
        # TODO: If bucket creation fails, we should delete the IAM user.
        service_record.region_name = bucket_args.get("location_constraint")
        service_record.last_operation_state = "succeeded"
        service_record.save()
        return {"operation": "provision"}

    def update(self, request, instance_id):
        if self.config.BROKER_ENVIRONMENT == "microcloud":
            service_record = self._get_service_record(instance_id)
            aws_instance_id = service_record.bucket
            bucket_args = self._modify_args(service_record, request)
            if "AllocatedStorage" in request.parameters:
                if request.parameters["AllocatedStorage"] >0:
                    self.MinIOIamUser(aws_instance_id).set_quota(request.parameters["AllocatedStorage"])
                else:
                    invalid_parameter = InvalidServiceParameter()
                    invalid_parameter.description = "Not a supported value for AllocatedStorage."
                    raise invalid_parameter
            service_record.last_operation_state = "succeeded"
            service_record.save()
        elif self.config.BROKER_ENVIRONMENT == "cloud":
            service_record = self._get_service_record(instance_id)
            aws_instance_id = service_record.bucket
            bucket_args = self._modify_args(service_record, request)
            self.S3Bucket(aws_instance_id).modify(**bucket_args)
            if "RotateApiKey" in request.parameters:
                if request.parameters["RotateApiKey"]:
                    iam_user = self.IamUser(aws_instance_id)
                    iam_user.rotate_api_key()
                    service_record.iam_user = self.model.IamUser(
                        access_key_id=iam_user.access_key_id,
                        secret_access_key=iam_user.secret_access_key,
                    )
                    service_record.save()
            # TODO: This really should be done with a proper plan migration...
            if "RefreshPolicy" in request.parameters:
                if request.parameters["RefreshPolicy"]:
                    policy = UserPolicy(
                        aws_instance_id, self.config.BROKER_ENVIRONMENT, self.aws_creds
                    ).render()
                    self.IamUser(aws_instance_id).policy = policy
            service_record.last_operation_state = "succeeded"
            service_record.save()
        return {"operation": "update"}

    def deprovision(self, request):
        service_record = self.model.get(request.instance_id)
        if service_record is None:
            raise ServiceInstanceNotFound(request.instance_id)
        # Bucket will be deleted via a worker process.
        service_record.deleted = True
        service_record.last_operation_state = "in progress"
        service_record.save()
        return {"operation": "deprovision"}

    def delete_instance(self, instance_id):
        try:
            service_record = self._get_service_record(instance_id)
            aws_instance_id = service_record.bucket
        except ClientError as e:
            # Getting the service record also tries to set the AWS context from
            # the bucket IAM user.  If the IAM User is not valid (for whatever
            # reason, but most likely because it was already deleted somehow)
            # we can't proceed.
            if e.response["Error"]["Code"] == "InvalidClientTokenId":
                LOG.exception("Could not set AWS Context in order to delete instance!")
                service_record = self.model.get(instance_id)
                service_record.last_operation_state = "failed"
                service_record.save()
                return
            else:
                raise
        if self.S3Bucket(aws_instance_id).exists:
            self.S3Bucket(aws_instance_id).enable_deletion_lifecycle()
            bucket_empty = self.S3Bucket(aws_instance_id).delete_objects(
                self.config.OBJECT_DELETION_THRESHOLD
            )
            if not bucket_empty:
                return
            self.S3Bucket(aws_instance_id).delete()
        if self.config.BROKER_ENVIRONMENT == "cloud":
            self.IamUser(aws_instance_id).delete()
        else:
            self.MinIOIamUser(aws_instance_id).delete(
                service_record.iam_user.access_key_id
            )
        service_record.last_operation_state = "succeeded"
        service_record.save()

    def last_operation(self, request, instance_id):
        service_record = self.model.get(instance_id)
        if service_record is None:
            raise ServiceInstanceNotFound(instance_id)
        last_operation = request.get("operation")
        if last_operation == "deprovision":
            # In production, the deletion is carried out via a worker process.
            if self.config.DEBUG or self.config.TESTING:
                self.delete_instance(request.instance_id)
                service_record = self.model.get(request.instance_id)
            # When the worker process is complete, it will set last_operation_state.
            if service_record.last_operation_state == "succeeded":
                service_record.delete()
                raise ServiceInstanceGone(instance_id)
        elif last_operation not in ["provision", "update"]:
            raise InvalidServiceParameter(
                "Invalid [operation] parameter: {}".format(last_operation)
            )
        return {
            "state": service_record.last_operation_state,
            "description": "{} operation {}".format(
                last_operation, service_record.last_operation_state
            ),
        }

    def bind(self, request, instance_id):
        service_record = self._get_service_record(instance_id)
        binding_id = request.binding_id
        if binding_id not in service_record.binding_ids:
            service_record.binding_ids.append(binding_id)
            service_record.save()
        iam_user = service_record.iam_user
        if self.config.BROKER_ENVIRONMENT == "cloud":
            endpoint = self.S3.get_endpoint(service_record.region_name)
        else:
            endpoint = (
                self.config.AWS_S3_HOST.split("//")[-1].split("/")[0].split("?")[0]
            )
        uri = "https://{}:{}@{}/{}".format(
            iam_user.access_key_id,
            iam_user.secret_access_key,
            endpoint,
            service_record.bucket,
        )
        credentials = {
            "api_key": iam_user.access_key_id,
            "bucket": service_record.bucket,
            "endpoint": endpoint,
            "location_constraint": service_record.region_name,
            "secret_key": iam_user.secret_access_key,
            "uri": uri,
        }
        return {"credentials": credentials}

    def unbind(self, request, instance_id):
        service_record = self._get_service_record(instance_id)
        binding_id = request.binding_id
        for index, value in enumerate(service_record.binding_ids):
            if value == binding_id:
                del service_record.binding_ids[index]
        service_record.save()

    def instance_details(self, instance_id):
        service_record = self._get_service_record(instance_id)
        return self.S3Bucket(service_record.bucket)

    def instance_metrics(self, instance_id):
        service_record = self._get_service_record(instance_id)
        cw = self.CloudWatch(service_record.bucket)
        size_bytes = cw.get_byte_count()
        num_objects = cw.get_number_of_objects()
        return {
            "Name": service_record.bucket,
            "Size": size_bytes,
            "NumKeys": num_objects,
        }

    def bucket_identifier(self, instance_id):
        return "{}-{}".format(self.instance_prefix, instance_id)

    def get_location_constraint(self, plan, parameters):
        default_constraint = self.S3.default_location_constraint
        location_constraint = default_constraint
        if plan["settings"]["location_constraint"]:
            location_constraint = plan["settings"]["location_constraint"]
        # Overwrite location_constraint if user specified Region parameter.
        if "Region" in parameters:
            if parameters["Region"] is None:
                parameters["Region"] = default_constraint
            location_constraint = parameters["Region"]
        location_constraint = self.S3.validate_location_constraint(location_constraint)
        if self.config.BROKER_ENVIRONMENT != "cloud" and location_constraint is None:
            return self.config.AWS_DEFAULT_REGION
        return location_constraint

    def _create_args(self, service_record, request):
        plan = request.plan
        parameters = request.parameters
        create_args = {}
        location_constraint = self.get_location_constraint(plan, parameters)
        if location_constraint:
            create_args["location_constraint"] = location_constraint
        if "CORSConfiguration" in parameters:
            create_args["cors_configuration"] = parameters["CORSConfiguration"]
        if "BucketLifecycle" in parameters:
            create_args["bucket_lifecycle"] = parameters["BucketLifecycle"]
        if any(key in parameters for key in BucketPolicy.options):
            policy = BucketPolicy(
                service_record,
                self.aws_creds,
            ).render(**parameters)
            create_args["bucket_policy"] = policy
        if "AllocatedStorage" in parameters:
            create_args["AllocatedStorage"] = parameters["AllocatedStorage"]
        return create_args

    def _modify_args(self, service_record, request):
        parameters = request.parameters
        modify_args = {}
        if "CORSConfiguration" in parameters:
            modify_args["cors_configuration"] = parameters["CORSConfiguration"]
        if "BucketLifecycle" in parameters:
            modify_args["bucket_lifecycle"] = parameters["BucketLifecycle"]
        if any(key in parameters for key in BucketPolicy.options):
            policy = BucketPolicy(
                service_record,
                self.aws_creds,
            ).render(**parameters)
            modify_args["bucket_policy"] = policy
        if "AllocatedStorage" in parameters:
            modify_args["AllocatedStorage"] = parameters["AllocatedStorage"]            
        return modify_args

    @staticmethod
    def get_param_parsers():
        def json_list(value):
            if not isinstance(value, list):
                raise ValueError("Supplied value is not a list!")
            return value

        base_parser = reqparse.CustomParamsParser(bundle_errors=True)
        base_parser.add_argument(
            "EnforceServerSideEncryption", type=bool, store_missing=False
        )
        base_parser.add_argument(
            "EnforceSecureCommunications", type=bool, store_missing=False
        )
        base_parser.add_argument("BucketLifecycle", type=dict, store_missing=False)
        base_parser.add_argument("CORSConfiguration", type=dict, store_missing=False)
        base_parser.add_argument("GrantAccess", type=json_list, store_missing=False)

        provision = base_parser.copy()
        provision.add_argument("Region", store_missing=False)
        provision.add_argument("AllocatedStorage", type=int, store_missing=False)

        update = base_parser.copy()
        update.add_argument("RefreshPolicy", type=bool, store_missing=False)
        update.add_argument("RotateApiKey", type=bool, store_missing=False)
        update.add_argument("RevokeAccess", type=json_list, store_missing=False)
        update.add_argument("AllocatedStorage", type=int, store_missing=False)
        return {"provision": provision, "update": update}

    def add_request_hooks(self, broker):
        def validate_access_lists(request):
            for action in ["Grant", "Revoke"]:
                access_list = request.parameters.get(f"{action}Access")
                if access_list is None:
                    continue
                principals = []
                services = []
                for name in access_list:
                    if name.startswith("arn:"):
                        principals.append(name)
                    elif name not in self.config.BUCKET_GRANTED_SERVICES_ALLOWLIST:
                        raise InvalidServiceParameter(
                            f"[{name}] is not a valid ARN or AWS Service Name."
                        )
                    else:
                        service = SERVICE_ALIASES.get(name, name)
                        service_principal = f"*:role/{service}/*"
                        services.append(service_principal)
                # Update request params with our validated lists.
                request.parameters[f"{action}Access"] = principals
                request.parameters[f"{action}ServiceAccess"] = services

        broker.register_hook(
            func="provision",
            event="post_request_parsing",
            hook=validate_access_lists,
        )

        broker.register_hook(
            func="update", event="post_request_parsing", hook=validate_access_lists
        )


class UserPolicy(object):

    policy_template = "policies/user.j2"
    policy_template_minio = "policies/user_minio.j2"

    def __init__(self, user_id, broker_environment, aws_creds):
        self.instance_id = user_id
        self.broker_environment = broker_environment
        if broker_environment == "cloud":
            self.aws_account_id = aws.get_aws_account_id_from_credentials(**aws_creds)
        else:
            self.aws_account_id = None

        self.s3 = aws.S3(**aws_creds)

    def render(self):
        j2 = Environment(loader=PackageLoader("broker", "templates"), trim_blocks=True)
        template = j2.get_template(
            self.policy_template
            if self.broker_environment == "cloud"
            else self.policy_template_minio
        )
        policy = template.render(
            account_id=self.aws_account_id,
            instance_id=self.instance_id,
            partition=self.s3.partition,
        )
        return policy


class BucketPolicy(object):

    policy_template = "policies/bucket.j2"

    options = [
        "EnforceServerSideEncryption",
        "EnforceSecureCommunications",
        "GrantAccess",
        "RevokeAccess",
        "GrantServiceAccess",
        "RevokeServiceAccess",
    ]

    options_to_sids = {
        "EnforceServerSideEncryption": [
            "DenyIncorrectEncryptionHeader",
            "DenyUnEncryptedObjectUploads",
        ],
        "EnforceSecureCommunications": ["DenyUnsecuredCommunications"],
    }

    def __init__(self, service_record, aws_creds):
        self.owner = aws.IamUser(**aws_creds)(service_record.bucket)
        self.bucket = aws.S3Bucket(**aws_creds)(service_record.bucket)
        self.cf_organization_id = service_record.organization_guid
        self.aws_organization_id = aws.get_aws_organization_id(**aws_creds)

    def render(self, **options):
        policy = self._build_bucket_policy(
            self.bucket.identifier, self.bucket.policy, **options
        )
        return policy

    @staticmethod
    def _get_bucket_policy_options(**kwargs):
        option_keys = [
            "EnforceServerSideEncryption",
            "EnforceSecureCommunications",
            "GrantedPrincipals",
            "GrantedServices",
        ]
        options = {}
        for key in option_keys:
            if key in kwargs:
                options.update({key: kwargs[key]})
        return options

    @staticmethod
    def _get_bucket_policy_options_from_policy(policy):
        options_to_sids = {
            "EnforceServerSideEncryption": [
                "DenyIncorrectEncryptionHeader",
                "DenyUnEncryptedObjectUploads",
            ],
            "EnforceSecureCommunications": ["DenyUnsecuredCommunications"],
        }
        options = {}
        if policy:
            policy_sids = [item["Sid"] for item in policy["Statement"]]
            for option, sids in options_to_sids.items():
                for sid in sids:
                    if sid in policy_sids:
                        options[option] = True
        return options

    @staticmethod
    def _get_principals(policy, sid, condition):
        principals = []
        if policy:
            searching = [
                statement
                for statement in policy["Statement"]
                if statement.get("Sid") == sid
            ]
            if len(searching) > 0:
                principals = searching[0]["Condition"][condition]["aws:PrincipalArn"]
            # The unit tests that use Moto for mocking AWS will never hit this conditional,
            # but the real AWS backend stores single-item lists as a string.
            if isinstance(principals, str):
                principals = [principals]
        return principals

    @staticmethod
    def _calculate_principal_list(policy, option_kwargs):
        principals = set(
            BucketPolicy._get_principals(policy, "GrantPrincipalAccess", "ArnEquals")
        )
        principals.update(option_kwargs.get("GrantAccess", {}))
        principals.difference_update(option_kwargs.get("RevokeAccess", {}))
        return list(principals)

    @staticmethod
    def _calculate_granted_service_list(policy, option_kwargs):
        services = set(
            BucketPolicy._get_principals(policy, "GrantServiceAccess", "StringLike")
        )
        services.update(option_kwargs.get("GrantServiceAccess", {}))
        services.difference_update(option_kwargs.get("RevokeServiceAccess", {}))
        return list(services)

    def _create_bucket_policy_options(self, policy=None, **option_kwargs):
        options = self._get_bucket_policy_options_from_policy(policy)
        option_kwargs["GrantedPrincipals"] = self._calculate_principal_list(
            policy, option_kwargs
        )
        option_kwargs["GrantedServices"] = self._calculate_granted_service_list(
            policy, option_kwargs
        )

        options.update(self._get_bucket_policy_options(**option_kwargs))
        # Only return options set to True (or truthy).
        return {k: v for k, v in options.items() if v}

    def _build_bucket_policy(self, bucket_name, policy=None, **option_kwargs):
        options = self._create_bucket_policy_options(policy, **option_kwargs)
        policy = None
        j2 = Environment(loader=PackageLoader("broker", "templates"), trim_blocks=True)
        template = j2.get_template(self.policy_template)
        if options:
            policy = template.render(
                aws_instance_id=bucket_name,
                owner_arn=self.owner.arn,
                partition=self.bucket.s3.partition,
                cf_organization_id=self.cf_organization_id,
                aws_organization_id=self.aws_organization_id,
                options=options,
            )
        return policy
