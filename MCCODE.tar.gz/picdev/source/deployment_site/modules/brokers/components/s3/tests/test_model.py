import json

import boto3

import broker.utils as utils
from tests import BaseTestCase, test_data


class TestModel(BaseTestCase):
    def test_broker_schema_change(self):
        credentials = {
            "api_key": "api-key",
            "bucket": "test-cf-s3-bogus",
            "endpoint": "s3-us-west-2.amazonaws.com",
            "location_constraint": "us-west-2",
            "secret_key": "secret-key",
            "uri": "s3://api-key:secret-key@s3-us-west-2.amazonaws.com/test-cf-s3-bogus",
        }
        iv = utils.generate_iv()
        encrypted_creds = utils.encrypt_data(
            data=json.dumps(credentials), iv=iv, key=self.config.ENCRYPTION_KEY
        )
        dynamodb = boto3.resource("dynamodb", **self.config.aws_config)
        table = dynamodb.Table(self.config.DYNAMODB_TABLE)
        # Generate record using old schema (with credentials and iv attributes).
        table.put_item(
            Item={
                "instance_id": "instance-id",
                "organization_guid": "test-org-guid",
                "plan_id": "test-plan-id",
                "service_id": "test-service-id",
                "space_guid": "test-space-guid",
                "binding_ids": [],
                "credentials": encrypted_creds,
                "iv": iv,
                "region_name": None,
            }
        )
        # Now read it in with new model.
        record = self.model.get("instance-id")
        self.assertEqual(record.iam_user.access_key_id, credentials["api_key"])
        self.assertEqual(record.iam_user.secret_access_key, credentials["secret_key"])
        self.assertEqual(record.bucket, credentials["bucket"])
        self.assertIsNone(record.region_name)
        self.assertIsNone(record._iv)
        self.assertIsNone(record._encrypted_credentials)
        self.assertEqual(record.last_operation_state, "failed")
        self.assertFalse(record.deleted)

    def test_last_operation_attribute_defaults_to_failed(self):
        record = self.model.new_record(**test_data())
        record.save()
        self.assertEqual(record.last_operation_state, "failed")

    def test_deleted_attribute_defaults_to_false(self):
        record = self.model.new_record(**test_data())
        record.save()
        self.assertFalse(record.deleted)
