# This is the rabbitman module from [0], here because the current pip
# package is broken. We've added Retry from urllib3 to help deal with
# connection failures.
#
# [0] https://github.com/davidszotten/rabbitman

try:
    # python 2.x
    from urllib import quote
except ImportError:
    # python 3.x
    from urllib.parse import quote

import requests
from requests.packages.urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter


def _quote(value):
    return quote(value, '')


class Client(object):
    """RabbitMQ Management plugin api

    Usage::

        >>> client = Client('http://localhost:15672', 'guest', 'guest')
        >>> client.get_vhosts()

    """

    def __init__(self, url, username, password):
        self._base_url = '{}/api'.format(url)
        self._session = requests.Session()
        self._session.auth = (username, password)
        self._session.headers['content-type'] = 'application/json'
        self._retries = Retry(total=3, backoff_factor=0.2)
        self._session.mount('http://', HTTPAdapter(max_retries=self._retries))

    def _build_url(self, args):
        args = map(_quote, args)
        return '{}/{}'.format(
            self._base_url,
            '/'.join(args),
        )

    def _request(self, method, *args, **kwargs):
        body = kwargs.pop('body', None)
        url = self._build_url(args)
        result = self._session.request(method, url, json=body, verify=False)
        result.raise_for_status()
        if result.content:
            return result.json()

    def create_cluster_name(self, cluster_name):
        """Name identifying this RabbitMQ cluster.

        """
        return self._request('PUT', 'cluster-name', body=cluster_name)

    def create_users_by_name(self, name, user):
        """An individual user. To PUT a user, you will need a body looking
        something like this:

        ::

            {
                "password":<<your password here>>,
                "tags": "administrator"
            }



        :param str name:
        """
        return self._request('PUT', 'users', name, body=user)

    def create_vhost(self, vhostsName):
        return self._request('PUT', 'vhosts', vhostsName)

    def create_permissions_by_vhost_and_user(self, vhost, user, permission):
        """An individual permission of a user and virtual host. To PUT a
        permission, you will need a body looking something like this:

        ::

            {
                "write": ".*",
                "read": ".*",
                "configure": ".*"
            }



        :param str vhost:
        :param str user:
        """
        return self._request('PUT', 'permissions', vhost, user, body=permission)     # noqa: E501
