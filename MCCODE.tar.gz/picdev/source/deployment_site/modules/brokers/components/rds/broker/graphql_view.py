import logging
from functools import wraps

from flask import jsonify, request
from flask_graphql import GraphQLView

LOG = logging.getLogger(__name__)


def validate_uaa_access_token(cc, access_token):
    try:
        res = cc.uaa.request("userinfo").set_bearer_auth(access_token).get()

        if not res.data or "user_id" not in res.data:
            return False

    except Exception:
        LOG.error("Cannot validate UAA token!:", exc_info=True)
        return False

    return True


def verify_api_keys(app):
    error = {"errors": [{"message": "Unauthorized"}]}
    api_key = request.headers["X-Api-Key"] if "X-Api-Key" in request.headers else None

    if api_key is not None and api_key != app.config["BROKER_API_KEY"]:
        return jsonify(error), 401

    if "X-User-Access-Token" not in request.headers:
        return jsonify(error), 403


def auth_required(func, app):
    @wraps(func)
    def decorated_view(*args, **kwargs):
        if should_skip_auth(app):
            return func(*args, **kwargs)

        error = verify_api_keys(app)
        if error:
            return error

        return func(*args, **kwargs)

    return decorated_view


def should_skip_auth(app):
    return app.config["GRAPHQL_SKIP_AUTH"]


class ContextGraphQLView(GraphQLView):
    def __init__(self, **kwargs):
        _context = kwargs["context"] if "context" in kwargs else None
        if "context" in kwargs:
            del kwargs["context"]

        super(self.__class__, self).__init__(**kwargs)

        self.config = kwargs["config"]
        self.app = kwargs["app"]
        self._context = _context

    def get_context(self, request):
        if callable(self._context):
            return self._context(request, self.app, self.config)
        elif self._context:
            return self._context
        else:
            return request


def init_app(app, config, schema, context):
    gql_view = ContextGraphQLView.as_view(
        "graphql", schema=schema, graphiql=True, config=config, app=app, context=context
    )

    gql_view = auth_required(gql_view, app)
    app.add_url_rule("/graphql", view_func=gql_view)
