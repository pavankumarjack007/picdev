import logging
import os

import yaml
from cf_broker_api import ServiceBroker
from cf_broker_api.utils import init_logging

from config import config_map
from . import graphql_view, model
from .api import controller as api_controller
from .dashboard import controller as dashboard_controller
from .graphql import schema
from .service import ContextAwareS3ServiceInstanceService, S3ServiceInstanceService

LOG = logging.getLogger(__name__)


def manip_catalog(region_name):
    with open("catalog.yml") as f:
        catalog = yaml.safe_load(f.read())
    # We have to manually adjust some of the guid values based on the
    # cf/aws region because the pcftest S3 broker was initially created
    # with some guids that didn't match what was configured in the other
    # regions.
    if region_name == "us-east-1":
        s3_service = next(svc for svc in catalog if svc["name"] == "hsdp-s3")
        s3_service["id"] = "906c102e-8cc7-41da-b06c-bf1df782cd6c"
        us_standard_plan = next(
            plan for plan in s3_service["plans"] if plan["name"] == "US Standard"
        )
        us_standard_plan["id"] = "22b29b79-e6a2-4d71-bc10-e030f9f2719d"
    # Adjust catalog for China to only show single plan.
    if region_name == "cn-north-1":
        plans = [plan for plan in catalog[0]["plans"] if plan["name"] == "s3_bucket"]
        catalog[0]["plans"] = plans
    return catalog


def create_broker(
    config_name=None,
    catalog=None,
    service_class=None,
    exc_mapper=None,
    parsers=None,
    graphql_service=None,
):
    _config_name = config_name or os.getenv("BROKER_CONFIG", "default")
    _config = config_map[_config_name]

    init_logging(**_config.logging_config)
    LOG.info("Using {} configuration...".format(_config_name))

    _catalog = catalog or "catalog.yml"
    _model = model.get_broker_model(_config)
    _service = service_class or S3ServiceInstanceService(model=_model, config=_config)
    _parsers = parsers or S3ServiceInstanceService.get_param_parsers()
    _exc_mapper = exc_mapper or {}

    broker = ServiceBroker(
        service_catalog=_catalog,
        custom_parsers=_parsers,
        service_class=_service,
        exc_mapper=_exc_mapper,
        config=_config,
    )

    if hasattr(_service, "add_request_hooks"):
        getattr(_service, "add_request_hooks")(broker)

    broker.register_blueprint(dashboard_controller)
    broker.register_blueprint(api_controller)

    broker.global_config = _config

    _graphql_service = graphql_service or ContextAwareS3ServiceInstanceService
    graphql_view.init_app(
        broker, config=_config, schema=schema, context=_graphql_service
    )

    return broker
