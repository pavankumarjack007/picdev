import logging

from datetime import datetime
from cf_broker_api import reqparse
from cf_broker_api.exceptions import (
    InvalidServiceParameter,
    ServiceInstanceAlreadyExists,
    ServiceInstanceGone,
    ServiceInstanceNotFound,
)

from broker import cloudfoundry
from broker.operations import Deprovision, OpState, Provision, Update, Bind
from broker.utils import RDSUri, generate_random_string, sanitize_label_value
from broker.k8s import KubernetesClient

LOG = logging.getLogger(__name__)


class ContextAwareDatabaseServiceInstanceService(object):
    def __init__(self, request, app, config):
        self.app = app
        self.config = config
        self.request = request
        self.service_class = self.app.service_class

        try:
            cc_args = config.cc_config.copy()
            cc_args.update({"access_token": request.headers["X-User-Access-Token"]})
            self.cc = cloudfoundry.CloudController.new_instance(**cc_args)
        except Exception as e:
            raise e

    def __getattr__(self, item):
        return getattr(self.service_class, item)

    def get_rds_instance(self, instance_id):
        return cloudfoundry.get_rds_instance(self.cc, instance_id)

    def get_rds_instances(self):
        service_labels = [
            service["name"] for service in self.app.service_catalog.services
        ]
        return cloudfoundry.get_rds_instances(self.cc, service_labels)

    def instance_permissions(self, instance_id):
        return self.cc.instance_permissions(instance_id)

    def service_catalog(self):
        name = self.app.service_catalog.services[0]["name"]

        plans = []
        service_labels = []
        for service in self.app.service_catalog.services:
            service_labels.append(service["name"])
            for plan in service["plans"]:
                plans.append(plan)

        accessible_plans = cloudfoundry.get_rds_plans(self.cc, service_labels)
        accessible_plan_ids = [plan.unique_id for plan in accessible_plans]

        # Now set restrictions
        for plan in plans:
            if plan["id"] not in accessible_plan_ids:
                plan["restricted"] = True

        return {"name": name, "plans": plans}

    def instance_details(self, instance_id):
        return self.service_class.instance_details(instance_id)

    def instance_snapshots(self, instance_id):
        return self.service_class.instance_snapshots(instance_id)

    def instance_events(self, instance_id):
        return self.service_class.instance_events(instance_id)

    def instance_metrics(self, instance_id, metric):
        return self.service_class.instance_metrics(instance_id, metric)

    def instance_logs(self, instance_id):
        return self.service_class.instance_logs(instance_id)

    def get_log_file(self, instance_id, filename):
        return self.service_class.get_log_file(instance_id, filename)

    def modify_instance(self, instance_id, settings):
        return self.service_class.modify_instance(instance_id, settings)

    def delete_snapshot(self, snapshot_id, instance_id):
        return self.service_class.delete_snapshot(snapshot_id, instance_id)

    def reboot_instance(self, instance_id):
        return self.service_class.reboot_instance(instance_id)


class DatabaseBrokerService:
    def __init__(self, config, model):
        self.config = config
        self.log = logging.getLogger(__name__)
        self.model = model
        self.prefix = self.config.SERVICE_PREFIX
        self._provision = Provision(config)
        self._deprovision = Deprovision(config)
        self._update = Update(config)
        self._bind = Bind(config)

    def get_service_record(self, instance_id):
        service_record = self.model.get(instance_id)
        if service_record is None:
            raise ServiceInstanceNotFound(instance_id)
        return service_record

    def provision(self, request, instance_id):
        if self.model.get(instance_id) is not None:
            raise ServiceInstanceAlreadyExists(instance_id)
        settings = request.plan["settings"]
        namespace = self.config.K8S_BROKER_NAMESPACE
        service_record = self.model.new_record(**request)
        service_record.instance_id = instance_id
        service_record.instance_name = sanitize_label_value(
            request.context.get("instance_name")
        )
        # service_record.service_namespace = namespace
        service_record.organization_name = sanitize_label_value(
            request.context.get("organization_name")
        )
        service_record.plan_env = settings["env"]
        service_record.space_name = sanitize_label_value(
            request.context.get("space_name")
        )
        service_record.service_id = request.service_id
        service_record.plan_name = request.plan["name"]
        engine = service_record.plan_env["ENGINE"]
        parameters = request.parameters
        if "AllocatedStorage" in parameters:
            if parameters["AllocatedStorage"] <= 0 or None:
                invalid_parameter = InvalidServiceParameter()
                invalid_parameter.description = "Not a supported value for AllocatedStorage"
                raise invalid_parameter
            storage = parameters["AllocatedStorage"]
            service_record.plan_env["STORAGE"] = f"{storage}Gi"        
        if "EngineVersion" in parameters:
            image_names = service_record.plan_env["IMAGE_NAME"]
            if parameters["EngineVersion"] in image_names.keys():
                service_record.image = image_names[parameters["EngineVersion"]]
                service_record.engine_version = parameters["EngineVersion"]
            else:
                invalid_parameter = InvalidServiceParameter()
                invalid_parameter.description = "Not a supported engine version "
                raise invalid_parameter
        else:
            service_record.image = service_record.plan_env["IMAGE_NAME"]["default"]
            engine_version = service_record.plan_env["IMAGE_NAME"]["default"].split(":")[1]
            service_record.engine_version = engine_version

        service_record.service_name = (
            f"mysql-{instance_id}" if engine == "mysql" else f"postgres-{instance_id}"
        )
        service_record.service_namespace = service_record.service_name
        service_record.save()
        self._provision.create_namespace(service_record)
        port = (
            self.config.MYSQL_STANDARD_PORT
            if engine == "mysql"
            else self.config.POSTGRES_STANDARD_PORT
        )
        hostname = f"{service_record.service_name}.{service_record.service_namespace}.svc.cluster.local"
        public_hostname = f"{service_record.service_name}.rds.{self.config.DOMAIN_NAME}"
        username = generate_random_string(16)
        password = generate_random_string(32)
        db_name = service_record.plan_env["DB_NAME"]
        service_record.instance_creation_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        service_record.credentials = self.model.Credentials(
            hostname=hostname,
            port=port,
            username=username,
            password=password,
            db_name=db_name,
            uri=str(RDSUri(engine, username, password, hostname, port, db_name)),
            public_hostname=public_hostname,
        )
        service_record.last_operation = {
            "state": OpState.IN_PROGRESS,
            "description": "Creating service instance",
        }
        service_record.prometheus_host = self.config.PROMETHEUS_HOST
        service_record.prometheus_port = self.config.PROMETHEUS_PORT
        service_record.save()
        self._provision.create_service(service_record, engine)
        return {"operation": "provision"}

    def deprovision(self, request):
        service_record = self.get_service_record(request.instance_id)
        engine = service_record.plan_env["ENGINE"]
        self._deprovision.delete_service(service_record, engine)
        service_record.last_operation = {
            "state": OpState.IN_PROGRESS,
            "description": "Deleting service instance",
        }
        service_record.save()
        return {"operation": "deprovision"}

    def update(self, request):
        service_record = self.get_service_record(request.instance_id)
        engine = service_record.plan_env["ENGINE"]
        storage = service_record.plan_env["STORAGE"]
        storage = storage.replace('Gi', '')
        if "AllocatedStorage" in request.parameters:
            if request.parameters["AllocatedStorage"] <= 0 or None:
                invalid_parameter = InvalidServiceParameter()
                invalid_parameter.description = "Not a supported value for AllocatedStorage"
                raise invalid_parameter
            if request.parameters["AllocatedStorage"] <= int(storage):
                invalid_parameter = InvalidServiceParameter()
                invalid_parameter.description = "Requested AllocatedStorage less than existing storage.Please provide higher value"
                raise invalid_parameter                
            service_record.allocatedStorage = request.parameters["AllocatedStorage"]
            service_record.plan_env["STORAGE"] = f"{service_record.allocatedStorage}Gi"
        self._update.update_service(service_record, engine)
        service_record.last_operation = {
            "state": OpState.IN_PROGRESS,
            "description": "Updating service instance",
        }
        service_record.save()
        return {"operation": "update"}

    def bind(self, request):
        service_record = self.get_service_record(request.instance_id)
        binding_id = request.binding_id
#        if service_record.credentials.ca_cert is None:
#            ca_cert = self._provision.ca_certificate(service_record)
#            service_record.credentials.ca_cert = ca_cert
        self.client = KubernetesClient(
            self.config.K8S_API_ENDPOINT, self.config.K8S_CACERT, self.config.K8S_BROKER_TOKEN
        )
        svc_info = self.client.get_service(service_record.service_namespace, service_record.service_name)
        svc_json = svc_info.to_dict()
        service_record.credentials.public_port = svc_json["spec"]["ports"][0]["node_port"]
        service_record.credentials.public_uri=str(RDSUri(service_record.plan_env["ENGINE"], service_record.credentials.username, service_record.credentials.password, service_record.credentials.public_hostname, service_record.credentials.public_port, service_record.credentials.db_name))
        if binding_id not in service_record.binding_ids:
            service_record.binding_ids.append(binding_id)
            service_record.save()
        else:
            self.log.warning(
                f"Binding {binding_id} already exists for instance {request.instance_id}"
            )
        return {"credentials": service_record.credentials.attribute_values}

    def unbind(self, request):
        service_record = self.get_service_record(request.instance_id)
        for index, value in enumerate(service_record.binding_ids):
            if value == request.binding_id:
                del service_record.binding_ids[index]
                service_record.save()
                break

    def last_operation(self, request, instance_id):
        service_record = self.get_service_record(instance_id)
        last_operation = request.get("operation")
        description = "Creating service instance"
        if last_operation == "provision" or last_operation == "update":
            state = self._provision.state(service_record)
            service_record.last_operation = {
                "state": state,
                "description": description,
            }
            service_record.save()
        elif last_operation == "deprovision":
            description = "Deleting service instance"
            state = self._deprovision.state(service_record)
            if state == OpState.SUCCEEDED:
                service_record.delete()
                raise ServiceInstanceGone(instance_id)
        elif last_operation == "update":
            description = "Updating service instance"
            state = self._update.state(service_record)
            service_record.last_operation = {
                "state": state,
                "description": description,
            }
            service_record.save()

        else:
            raise InvalidServiceParameter(
                "Invalid [operation] parameter: {}".format(last_operation)
            )
        return {"state": state, "description": description}

    def instance_details(self, instance_id):
        try:
            service_record = self.get_service_record(instance_id)
            engine = service_record.plan_env["ENGINE"]
            port = (
                self.config.MYSQL_STANDARD_PORT
                if engine == "mysql"
                else self.config.POSTGRES_STANDARD_PORT
            )
            external_host = f"mysql-exporter-{instance_id}.{service_record.service_namespace}.svc.cluster.local:9104"
            if engine == "postgresql":
                external_host = f"postgres-exporter-{instance_id}.{service_record.service_namespace}.svc.cluster.local"

            instance = {}
            instance["availability_zone"] = "-"
            instance["db_instance_identifier"] = "-"
            instance["db_name"] = service_record.plan_env["DB_NAME"]
            instance["db_instance_status"] = "available"
            instance["storage_type"] = "gp2"
            instance["storage_encrypted"] = True
            instance_creation_time = service_record.instance_creation_time
            if instance_creation_time is None:
                instance_creation_time = ""
            instance["instance_create_time"] = instance_creation_time
            instance["read_replica_db_instance_identifiers"] = []
            instance["pending_modified_values"] = {}
            instance["db_parameter_groups"] = [
                {
                    "db_parameter_group_name": "-",
                    "parameter_apply_status": "-",
                }
            ]
            instance["db_subnet_group"] = {
                "db_subnet_group_name": "-",
                "db_subnet_group_description": "-",
                "subnet_group_status": "-",
                "subnets": [
                    {
                        "subnet_identifier": "-",
                        "subnet_status": "-",
                        "subnet_availability_zone": {"name": "-"},
                    }
                ],
            }
            instance["endpoint"] = {
                "address": f"{service_record.service_name}.{service_record.service_namespace}.svc.cluster.local",
                "port": port,
            }

            instance["exporterHostname"] = external_host
            instance["engine"] = engine
            # Added to handle existing instance
            engine_version = service_record.engine_version
            if engine_version is None:
                engine_version = service_record.image
            instance["engine_version"] = engine_version
            storage = service_record.plan_env["STORAGE"]
            storage = storage.replace('Gi', '')
            instance["allocated_storage"] = storage
            instance["max_allocated_storage"] = storage
            instance["disk_storage"] = storage
            instance["license_model"] = "mysql-license" if engine == "mysql" else "postgresql-license"
            instance["master_username"] = service_record.credentials.attribute_values['username']
            return instance
        except Exception as e:
            if e.__class__.__name__ == 'ServiceInstanceNotFound':
                self.log.error('Instance guid does not exist: {}'.format(
                    instance_id))
                return None
            else:
                raise

    def instance_metrics(self, instance_id, metric):
        return None

    def instance_events(self, instance_id):
        return None

    def instance_snapshots(self, instance_id):
        return None

    def instance_logs(self, instance_id):
        return None

    def get_log_file(self, instance_id, log_file_name):
        return None

    def delete_snapshot(self, snapshot_id, instance_id):
        return None

    def modify_instance(self, instance_id, formdata):
        return None

    def reboot_instance(self, instance_id):
        pass

    @staticmethod
    def get_param_parsers():
        base = reqparse.CustomParamsParser(bundle_errors=True)
        base.add_argument("AllocatedStorage", type=int, store_missing=False)
        base.add_argument("EngineVersion", store_missing=False)
        provision = base.copy()
        provision.add_argument("DBName", store_missing=False)
        update = base.copy()
        update.add_argument("ResetMasterUserPassword", type=bool, store_missing=False)
        update.add_argument("AllocatedStorage", type=int, store_missing=False)
        return {"provision": provision, "update": update}
