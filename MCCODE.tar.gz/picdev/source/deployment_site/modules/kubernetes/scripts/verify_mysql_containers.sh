#! /bin/bash

#CHECK if mysql is up
mysql_containers="1/1"
while : ; do
    echo "Checking if all containers for mysql pod are ready"
    result=$(kubectl -n cf-mysql get po | grep mysql | awk '{ print $2 }')
    echo "Expecting $mysql_containers .. Current $result"
    if [[ "$result" == "$mysql_containers" ]]
    then
      break
    fi
    sleep 10
done