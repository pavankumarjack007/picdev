#! /bin/bash
#Script to provisions the base platform for MicroCloud.
#Requires:- kOps (v1.21), terraform (v1.0.4)
#Requires: kubectl (1.15.5), aws-cli, jq
#Requires aws access_key, secret and region to be set (For example via:- aws configure ...)
#Requires Route53 hosted zone with the name that matches cluster_name




## Setup env vars for terraform
while read line
  do
    result=$(echo $line)
    #echo $result
    if [[ ! "$line" =~ ^#.*$ ]]
    then
      export TF_VAR_$result
      #echo ""
    fi
  done < ../generated/globals.tfvars

export cluster_name=$TF_VAR_cluster_name

#export outposts_arn=$(aws outposts get-outpost --outpost-id $TF_VAR_outpost_id | jq '.Outpost.OutpostArn')
export TF_VAR_zoneid_cf="$TF_VAR_zoneid"
#export TF_VAR_cf_domain="cf.$TF_VAR_cluster_name"

##### Used by the tf modules in source/deployment_from_sh
#export TF_VAR_domain_name="$TF_VAR_cluster_name"

while read line
    do
      result=$(echo $line)
      #echo $result
      if [[ ! "$line" =~ ^#.*$ ]]
      then
        export $result
      fi
    done < ../generated/deployment.vars

export TF_VAR_master_node_tag="master-${ZONES}.masters.${cluster_name}"
export TF_VAR_bastion_node_tag="bastions.${cluster_name}"
export TF_VAR_routerapi="*.$TF_VAR_cf_domain"
export TF_VAR_k8sapi="api.$TF_VAR_cluster_name"
export TF_VAR_sshapi="ssh.$TF_VAR_cf_domain"
export TF_VAR_api_elb_sg_name="api-elb.$TF_VAR_cluster_name"
export TF_VAR_nodes_sg_name="nodes.$TF_VAR_cluster_name"
export TF_VAR_forgerockapi="hsopiam.$TF_VAR_cf_domain"
export TF_VAR_cf_password=$cf_password
export TF_VAR_certificate_owner_email=$certbot_email
export TF_VAR_nodes_role="nodes.${cluster_name}"

export key_name=$(echo $cluster_name | tr '.' '_')
export TF_VAR_key_name="$key_name.pub"
export TF_VAR_private_key_name="$key_name"