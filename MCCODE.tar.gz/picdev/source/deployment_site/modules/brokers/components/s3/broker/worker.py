import logging
import os
import time

from cf_broker_api.utils import init_logging

from broker.model import get_broker_model
from broker.service import S3ServiceInstanceService
from config import config_map

LOG = logging.getLogger(__name__)


def delayed_deletion(service):
    LOG.info("Asynchronous Deletion: {:.4f}".format(time.time()))
    items = service.model.scan()
    for item in items:
        if item.deleted is True:
            LOG.info("Deleting instance: {}".format(item.instance_id))
            try:
                service.delete_instance(item.instance_id)
            except Exception:
                LOG.exception("Deletion Failed for some reason.")


def do_worker(config, func, *args):
    def tick_generator():
        t = time.time()
        count = 0
        while True:
            count += 1
            yield max(t + count * config.WORKER_INTERVAL - time.time(), 0)

    g = tick_generator()
    while True:
        time.sleep(next(g))
        func(*args)
        # This is an infinite loop.  If we're testing,
        # we break after one iteration.
        if config.TESTING:
            break


def create_worker(config_name=None, service=None):
    _config_name = config_name or os.getenv("BROKER_CONFIG", "default")
    _config = config_map[_config_name]

    init_logging(**_config.logging_config)
    LOG.info("Using {} configuration...".format(_config_name))

    model = get_broker_model(_config)
    s3_service = service or S3ServiceInstanceService(model, _config)
    do_worker(_config, delayed_deletion, s3_service)
