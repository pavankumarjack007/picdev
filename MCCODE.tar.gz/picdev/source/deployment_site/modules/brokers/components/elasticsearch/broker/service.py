import logging

from cf_broker_api import reqparse
from cf_broker_api.exceptions import (
    InvalidServiceParameter,
    ServiceInstanceAlreadyExists,
    ServiceInstanceGone,
    ServiceInstanceNotFound,
)

from broker.operation import Deprovision, OpState, Provision
from broker.utils import ElasticSearchURI, remove_dashes, sanitize_label_value


class ElasticSearchBrokerService:
    def __init__(self, config, model):
        self.config = config
        self.log = logging.getLogger(__name__)
        self.model = model
        self._provision = Provision(config)
        self._deprovision = Deprovision(config)

    def get_service_record(self, instance_id):
        service_record = self.model.get(instance_id)
        if service_record is None:
            raise ServiceInstanceNotFound(instance_id)
        return service_record

    def provision(self, request, instance_id):
        instance_id = remove_dashes(instance_id)
        if self.model.get(instance_id) is not None:
            raise ServiceInstanceAlreadyExists(instance_id)
        settings = request.plan["settings"]
        namespace = self.config.K8S_BROKER_NAMESPACE
        service_record = self.model.new_record(**request)
        service_record.instance_id = instance_id
        service_record.instance_name = sanitize_label_value(
            request.context.get("instance_name")
        )
        service_record.service_namespace = namespace
        service_record.organization_name = sanitize_label_value(
            request.context.get("organization_name")
        )
        service_record.plan_env = settings["env"]
        service_record.space_name = sanitize_label_value(
            request.context.get("space_name")
        )
        service_record.service_id = request.service_id
        service_record.plan_name = request.plan["name"]
        parameters = request.parameters
        if "ElasticVersion" in parameters:
            service_record.version = service_record.plan_env["version"][
                parameters["ElasticVersion"]
            ]
        else:
            service_record.version = service_record.plan_env["version"]["default"]
        service_record.apm_rum_agent_enabled = False
        server_urls = None
        if "EnableAPMServer" in parameters:
            service_record.apm_enabled = parameters["EnableAPMServer"]
            service_record.apm_server_count = 1
            server_urls = (
                f"http://apm-{instance_id}-apm-http.{namespace}.svc.cluster.local:8200"
            )
        else:
            service_record.apm_enabled = False
            service_record.apm_server_count = 0
        service_record.node_count = service_record.plan_env["node_count"]
        service_record.service_name = f"es-{instance_id}-es-default"
#        hostname = f"{service_record.service_name}.{namespace}.svc.cluster.local"
        hostname = f"{service_record.service_name}.es.{self.config.DOMAIN_NAME}"
        service_record.credentials = self.model.Credentials(
            hostname=hostname, username="elastic", port=30920, server_urls=server_urls
        )
        service_record.last_operation = {
            "state": OpState.IN_PROGRESS,
            "description": "Creating service instance",
        }
        service_record.save()
        self._provision.create_service(service_record)
        return {"operation": "provision"}

    def deprovision(self, request):
        instance_id = remove_dashes(request.instance_id)
        service_record = self.get_service_record(instance_id)
        self._deprovision.delete_service(service_record)
        service_record.last_operation = {
            "state": OpState.IN_PROGRESS,
            "description": "Deleting service instance",
        }
        service_record.save()
        return {"operation": "deprovision"}

    def bind(self, request):
        instance_id = remove_dashes(request.instance_id)
        service_record = self.get_service_record(instance_id)
        binding_id = request.binding_id
        if service_record.credentials.password is None:
            credentials = self._provision.credentials(service_record)
            service_record.credentials.password = credentials["password"]
            service_record.credentials.uri = str(
                ElasticSearchURI(
                    "elastic",
                    credentials["password"],
                    service_record.credentials.hostname,
                    service_record.credentials.port,
                    service_record.service_name,
                    self.config.DOMAIN_NAME
                )
            )
            if service_record.apm_enabled:
                service_record.credentials.secret_token = credentials["secret_token"]
        if service_record.credentials.ca_cert is None:
            ca_cert = self._provision.ca_certificate(service_record)
#            service_record.credentials.ca_cert = ca_cert

        if binding_id not in service_record.binding_ids:
            service_record.binding_ids.append(binding_id)
            service_record.save()
        else:
            self.log.warning(
                f"Binding {binding_id} already exists for instance {request.instance_id}"
            )
        return {"credentials": service_record.credentials.attribute_values}

    def unbind(self, request):
        instance_id = remove_dashes(request.instance_id)
        service_record = self.get_service_record(instance_id)
        for index, value in enumerate(service_record.binding_ids):
            if value == request.binding_id:
                del service_record.binding_ids[index]
                service_record.save()
                break

    def last_operation(self, request, instance_id):
        instance_id = remove_dashes(instance_id)
        service_record = self.get_service_record(instance_id)
        last_operation = request.get("operation")
        description = "Creating service instance"
        if last_operation == "provision":
            state = self._provision.state(service_record)
            service_record.last_operation = {
                "state": state,
                "description": description,
            }
            service_record.save()
        elif last_operation == "deprovision":
            description = "Deleting service instance"
            state = self._deprovision.state(service_record)
            if state == OpState.SUCCEEDED:
                service_record.delete()
                raise ServiceInstanceGone(instance_id)
        else:
            raise InvalidServiceParameter(
                "Invalid [operation] parameter: {}".format(last_operation)
            )
        return {"state": state, "description": description}

    @staticmethod
    def get_param_parsers():
        base = reqparse.CustomParamsParser(bundle_errors=True)
        base.add_argument("EnableAPMServer", type=bool, store_missing=False)
        provision = base.copy()
        provision.add_argument("ElasticVersion", store_missing=False)
        update = base.copy()
        update.add_argument("RotateCredentials", type=bool, store_missing=False)
        update.add_argument("UpgradeService", type=bool, store_missing=False)
        return {"provision": provision, "update": update}
