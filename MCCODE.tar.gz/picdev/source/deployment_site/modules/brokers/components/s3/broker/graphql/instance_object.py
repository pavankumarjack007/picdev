import graphene


class InstanceObject(graphene.ObjectType):
    name = graphene.String()
    size = graphene.String()
    last_modified = graphene.String()
    storage_class = graphene.String()

    ####################################################
    # Resolve Methods
    ####################################################

    @staticmethod
    def resolve_name(item, _):
        return item["Key"]

    @staticmethod
    def resolve_size(item, _):
        return item["Size"]

    @staticmethod
    def resolve_last_modified(item, _):
        return item["LastModified"]

    @staticmethod
    def resolve_storage_class(item, _):
        return item["StorageClass"]
