#!/bin/bash


add_port_to_kops_config() {

kops export kubecfg ${1} --admin

#Add 6443 to kubecfg
cp ~/.kube/config ~/.kube/config_orig_3
export target_cluster_name=${1}
export k8s_api_server=$(yq e '.clusters[] | select(.name==env(target_cluster_name)) | .cluster | .server' ~/.kube/config)
export k8s_api_server_with_port=$k8s_api_server:6443
yq e '(.clusters[] | select(.name==env(target_cluster_name)).cluster.server) |= env(k8s_api_server_with_port)' -i ~/.kube/config	
}

add_port_to_kops_config ${1}

sleep 60
# Running below commands to recreate the cert-manager pods so that they'll be enabled with IRSA
export OLD_CERT_MANAGER_POD=$(kubectl get pod -n cert-manager -l app=cert-manager -o jsonpath="{.items[0].metadata.name}")
sleep 60
echo $OLD_CERT_MANAGER_PODo
kubectl delete pod $OLD_CERT_MANAGER_POD -n cert-manager
sleep 60  #Giving a minute for the cert-manager pod to re-provision
export NEW_CERT_MANAGER_POD=$(kubectl get pod -n cert-manager -l app=cert-manager -o jsonpath="{.items[0].metadata.name}")
echo $NEW_CERT_MANAGER_POD  #Verifying if the new cert-manager pod has been re-spawned or not