import os

from cf_broker_api import ServiceBroker
from config import config_map
from . import graphql_view
from .graphql import schema
from .service import RabbitmqServiceInstanceService,ContextAwareRabbitMqServiceInstanceService
from flask import Blueprint, redirect


def create_broker(config_name=None,
                  catalog=None,
                  service_class=None,
                  exc_mapper=None,
                  parsers=None, graphql_service=None):
    _config_name = config_name or os.getenv('BROKER_CONFIG', 'default')
    _config = config_map[_config_name]
    _catalog = catalog or 'catalog.yml'
    _service = service_class or RabbitmqServiceInstanceService(config=_config)
    _parsers = parsers or _service.get_param_parsers()

    broker = ServiceBroker(
        service_catalog=_catalog,
        custom_parsers=_parsers,
        service_class=_service,
        config=_config)
    broker.global_config = _config

    # Create a Flask blueprint to hold our Service Dashboard routes.
    dashboard = Blueprint('dashboard', 'dashboard', url_prefix='/dashboard')

    @dashboard.route('/manage/<instance_id>', methods=['GET'])
    def manage_instance(instance_id):
        return _service.manage_instance(instance_id)

    broker.register_blueprint(dashboard)

    broker.global_config = _config

    _graphql_service = graphql_service or ContextAwareRabbitMqServiceInstanceService
    graphql_view.init_app(
        broker, config=_config, schema=schema, context=_graphql_service
    )

    return broker
