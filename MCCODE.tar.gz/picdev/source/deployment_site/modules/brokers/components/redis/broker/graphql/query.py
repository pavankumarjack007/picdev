from functools import wraps

import graphene
from .instance import Instance
from .service_catalog import ServiceCatalog
from ..cloudfoundry import has_authorities


def verify_instance_id(func):
    @wraps(func)
    def wrapper(self, info, *args, **kwargs):
        instance_id = kwargs["instance_id"] if "instance_id" in kwargs else kwargs["id"]
        if not info.context.instance_details(instance_id):
            return None

        permissions = info.context.instance_permissions(instance_id)
        token = info.context.cc.uaa.get_access_token().attrs
        valid_authorities = ["cloud_controller.global_auditor"]
        if not (
                permissions.can_manage_instance or has_authorities(token, valid_authorities)
        ):
            return None

        return func(self, info, *args, **kwargs)

    return wrapper


class Query(graphene.ObjectType):
    instances = graphene.List(Instance)
    instance = graphene.Field(Instance, id=graphene.String())
    catalog = graphene.Field(ServiceCatalog)

    def resolve_instances(self, info):
        return info.context.get_instances()

    def resolve_catalog(self, info):
        return info.context.service_catalog()

    @verify_instance_id
    def resolve_instance(self, info, id):
        instances = info.context.get_instances()

        service_instance = next(i for i in instances if i.guid == id)

        return service_instance
