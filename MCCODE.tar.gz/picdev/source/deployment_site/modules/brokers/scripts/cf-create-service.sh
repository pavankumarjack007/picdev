#!/bin/bash

while getopts d:u:p:o:s:b:c:n:a: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        d) domain=${OPTARG};;
        u) username=${OPTARG};;
        p) password=${OPTARG};;
        o) organization=${OPTARG};;
        s) space=${OPTARG};;
        b) broker=${OPTARG};;
        c) catplan=${OPTARG};;
        n) name=${OPTARG};;
        a) arg=${OPTARG};;
    esac
done
	
cf login -a api."$domain" -u "$username" -p "$password" -o "$organization" -s "$space" --skip-ssl-validation
echo create-service $broker $catplan $name $arg
cf create-service $broker $catplan $name $arg
    for i in {1..20}
    do
        serviceStatus=$(cf service "$name" | grep status:)
		 if [[ $serviceStatus == *"succeeded"* ]] || [[ "$serviceStatus" ==  *"failed"* ]]
		 then
			  echo "Create Service $name done"
			  break
		  else
			  echo "Waiting for $name  service to get ready"
			  sleep 10
		  fi
    done
