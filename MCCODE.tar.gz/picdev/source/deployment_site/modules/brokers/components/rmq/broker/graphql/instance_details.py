import graphene


class InstanceDetails(graphene.ObjectType):
    exporter_hostname = graphene.String()
    hostname = graphene.String()

    @staticmethod
    def resolve_exporter_hostname(details, _):
        return details["exporterHostname"]

    @staticmethod
    def resolve_hostname(details, _):
        return details["hostname"]