#!/bin/bash
LOG_FILE_NAME="deployment_details"
LOG_FILE=$(echo "${LOG_FILE_NAME}.txt")
exec > >(tee -i $(pwd)/$LOG_FILE)
echo "--------------------------Deployment details-------------------------------"
echo ""
version=$(cat ../../../../version.txt)
MASTERCOUNT=$(kubectl get nodes | grep master | wc -l)
NODE_COUNT=$(kubectl get nodes | grep node | wc -l)
k8s_version=$(kubectl get nodes | awk '{print $5'} | tail -1)

echo "MicroCloud version : $version"
echo "Number of nodes    : $NODE_COUNT"
echo "Number of Master   : $MASTERCOUNT"
echo "k8s_version        : $k8s_version"
echo "Cluster name       : ${TF_VAR_cluster_name}"
echo ""
echo "---------------------------------------------------------------------------"
