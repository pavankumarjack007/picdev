#!/bin/bash

while getopts d:u:p:n: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        d) domain=${OPTARG};;
        u) username=${OPTARG};;
        p) password=${OPTARG};;
        n) name=${OPTARG};;
    esac
done

cf login -a api."$domain" -u "$username" -p "$password" -o system --skip-ssl-validation
cf target -o system
# shellcheck disable=SC2256
status=$(cf orgs | grep $"name" | wc -l)
if [ $? -eq 0 ]
then cf create-org "$name"
else echo "Org $name already exists"
fi
