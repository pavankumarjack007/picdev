import graphene


class ServicePlan(graphene.ObjectType):
    id = graphene.String()
    name = graphene.String()
    description = graphene.String()
    vendor = graphene.String()
    bullets = graphene.List(graphene.String)
    restricted = graphene.Boolean()
    deprecated = graphene.Boolean()

    def resolve_id(plan, _):
        return plan["id"]

    def resolve_name(plan, _):
        return plan["name"]

    def resolve_vendor(plan, _):
        return None

    def resolve_description(plan, _):
        return plan["description"]

    def resolve_bullets(plan, _):
        return plan["metadata"]["bullets"]

    def resolve_restricted(plan, _):
        return plan["restricted"] if "restricted" in plan else False

    def resolve_deprecated(plan, _):
        return plan["deprecated"] if "deprecated" in plan else False
