import datetime
import random
import re
import secrets
import string
from base64 import b64decode, b64encode

import nacl.secret


def timestamp():
    now = datetime.datetime.utcnow().replace(microsecond=0).isoformat()
    return f"{now}Z"


def encrypt_data(data, key, iv=None):
    box = nacl.secret.SecretBox(key.encode("utf-8"))
    encrypted_value = box.encrypt(data.encode("utf-8"))
    return b64encode(encrypted_value).decode("utf-8")


def decrypt_data(data, key, iv=None):
    box = nacl.secret.SecretBox(key.encode("utf-8"))
    decrypted_value = box.decrypt(b64decode(data.encode("utf-8")))
    return decrypted_value.decode("utf-8")


def random_alphanum(length=20, lowercase=False):
    chars = string.digits
    if lowercase:
        chars += string.ascii_lowercase
    else:
        chars += string.ascii_letters
    return "".join(secrets.choice(chars) for _ in range(length))


def truncate_id(guid):
    return str(guid.split("-")[0])


def sanitize_label_value(value):
    # Transform CF object names into valid Kubernetes label values
    # See: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/#syntax-and-character-set

    # Truncate at max length
    value = value[0:63]
    # Replace invalid chars with underscore
    value = re.sub("[^a-zA-Z0-9_.-]+", "_", value)
    valid = re.compile("(([A-Za-z0-9][-A-Za-z0-9_.]*)?[A-Za-z0-9])?")
    if not valid.fullmatch(value):
        # Now we have either leading or trailing non-alphanum chars, trim
        # those away and re-validate. If this fails, give up and return an
        # empty string (which is a valid value)
        value = value.lstrip("_.-")
        value = value.rstrip("_.-")
        if not valid.fullmatch(value):
            value = ""
    return value


def generate_random_string(num_bytes):
    chars = string.ascii_letters + string.digits
    return "".join(random.SystemRandom().choice(chars) for _ in range(num_bytes))


class RDSUri(object):
    """
    Represent the components of a URL used to connect to a database.

    All initialization parameters are available as public attributes.

    :param engine: the name of the RDS database engine.

    :param username: The user name.

    :param password: database password.

    :param host: The name of the host.

    :param port: The port number.

    :param database: The database name.

    """

    RDS_ENGINE_TO_SCHEME_MAP = {
        "mysql": "mysql",
        "postgresql": "postgres",
    }

    def __init__(
        self, engine, username=None, password=None, host=None, port=None, database=None,
    ):
        self.engine = str(engine).lower()
        self.username = username
        self.password = password
        self.host = host
        if port is not None:
            self.port = int(port)
        else:
            self.port = None
        self.database = database

    def __to_string__(self, hide_password=True):
        s = self.scheme + "://"
        if self.username is not None:
            s += self.username
            if self.password is not None:
                s += ":" + ("[REDACTED]" if hide_password else self.password)
            s += "@"
        if self.host is not None:
            s += self.host
        if self.port is not None:
            s += ":" + str(self.port)
        if self.database is not None:
            s += "/" + self.database
        return s

    @property
    def scheme(self):
        return self.RDS_ENGINE_TO_SCHEME_MAP.get(self.engine, self.engine)

    def __str__(self):
        return self.__to_string__(hide_password=False)

    def __repr__(self):
        return self.__to_string__()
