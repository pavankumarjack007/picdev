import graphene


class DbParameterGroup(graphene.ObjectType):
    name = graphene.String()
    parameter_apply_status = graphene.String()
    description = graphene.String()
    group_family = graphene.String()
    group_arn = graphene.String()

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_name(group, _):
        return None

    def resolve_group_family(group, info):
        return None

    def resolve_group_arn(group, _):
        return None
