import graphene

from .instance_object import InstanceObject


class ObjectSearchResultPageInfo(graphene.ObjectType):
    next_token = graphene.String()
    total = graphene.Int()

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_next_token(results, _):
        return results.get("NextContinuationToken", None)

    def resolve_total(results, _):
        return len(results.get("Contents", []))


class ObjectSearchResult(graphene.ObjectType):
    page_info = graphene.Field(ObjectSearchResultPageInfo)
    objects = graphene.List(InstanceObject)

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_objects(results, _):
        return results.get("Contents", [])

    def resolve_page_info(results, _):
        return results
