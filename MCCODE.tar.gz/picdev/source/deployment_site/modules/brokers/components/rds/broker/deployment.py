import base64
import os
import time
from abc import ABC, abstractmethod

import yaml
from jinja2 import Environment, FileSystemLoader
from kubernetes import client
#import logging


class Deployment(ABC):
    CERT_ISSUE_GROUP = "cert-manager.io"
    CERT_ISSUE_VERSION = "v1"
    CERT_ISSUE_PLURAL = "issuers"

    CERT_REQUEST_GROUP = "cert-manager.io"
    CERT_REQUEST_VERSION = "v1"
    CERT_REQUEST_PLURAL = "certificates"

    VELERO_API_GROUP = "velero.io"
    VELERO_API_VERSION = "v1"
    VELERO_SCHEDULE_PLURAL = "schedules"
    VELERO_BACKUP_PLURAL = "backups"
    VELERO_RESTORE_PLURAL = "restores"
    VELERO_NAMESPACE = "velero"

    def __init__(self, config, client, service_record):
        self.config = config
        self.client = client
        self.service_record = service_record
        self.template_environment = Environment(
            autoescape=False,
            loader=FileSystemLoader(os.path.dirname(__file__) + "/../template"),
            trim_blocks=False,
        )

    @abstractmethod
    def deploy(self):
        pass

    @property
    def render_context(self):
        namespace = self.service_record.service_namespace
        storage = self.service_record.plan_env["STORAGE"]
        memory_request = self.service_record.plan_env["MEMORY_REQUEST"]
        memory_limit = self.service_record.plan_env["MEMORY_LIMIT"]
        cpu_request = self.service_record.plan_env["CPU_REQUEST"]
        cpu_limit = self.service_record.plan_env["CPU_LIMIT"]
        image = self.service_record.image
        storage_class = self.config.STORAGE_CLASS
        password_bytes = self.service_record.credentials.password.encode("ascii")

        base64_bytes = base64.b64encode(password_bytes)
        base64_string = base64_bytes.decode("ascii")
        return {
            "namespace": namespace,
            "instance_id": self.service_record.instance_id,
            "instance_name": self.service_record.instance_name,
            "org_name": self.service_record.organization_name,
            "org_space": self.service_record.space_name,
            "db_password": base64_string,
            "root_password": self.service_record.credentials.password,
            "db_host": self.service_record.credentials.hostname,
            "storage_class": storage_class,
            "storage": storage,
            "memory_request": memory_request,
            "service_name": self.service_record.service_name,
            "cpu_request": cpu_request,
            "memory_limit": memory_limit,
            "cpu_limit": cpu_limit,
            "db_user": self.service_record.credentials.username,
            "db_name": self.service_record.credentials.db_name,
            "image_name": image,
            "monitoring_tag": self.config.MONITORING_TAG,
            "prometheus_host": self.service_record.prometheus_host,
            "prometheus_port": self.service_record.prometheus_port,
            "DOCKER_REGISTRY": self.config.DOCKER_REGISTRY,
            "reg_cred": self.config.REG_CRED,
            "domain_name": self.config.DOMAIN_NAME,
            "broker_sa": self.config.K8S_BROKER_SA,
            "broker_ns": self.config.K8S_BROKER_NAMESPACE,
            "timestamp": time.strftime("%Y%m%d%H%M%S", time.localtime())
        }

    def render_template(self, template_filename, context):
        return self.template_environment.get_template(template_filename).render(context)


class DeleteDeployment(ABC):
    def __init__(self, config, client, service_record):
        self.config = config
        self.client = client
        self.service_record = service_record

    @abstractmethod
    def delete(self):
        pass


class UpdateDeployment(ABC):
    def __init__(self, config, client, service_record):
        self.config = config
        self.client = client
        self.service_record = service_record

    @abstractmethod
    def update(self):
        pass


class MySQLDeployment(Deployment):
    def __init__(self, config, client, service_record):
#        self.log = logging.getLogger(__name__)
        super().__init__(config, client, service_record)

    def deploy(self):
        # Check if root ca is present if not create
        iss_ca_available = self.client.check_custom_resource(
            Deployment.CERT_ISSUE_GROUP,
            Deployment.CERT_ISSUE_VERSION,
            Deployment.CERT_ISSUE_PLURAL,
            self.service_record.service_namespace,
            "db-ca-issuer",
        )
        if not iss_ca_available:
            self_signed_issuer = self.render_template(
                "cacerts/selfsigned-issuer.yaml", self.render_context
            )
            self.client.deploy_custom_resource(
                Deployment.CERT_ISSUE_GROUP,
                Deployment.CERT_ISSUE_VERSION,
                Deployment.CERT_ISSUE_PLURAL,
                self.service_record.service_namespace,
                yaml.safe_load(self_signed_issuer),
            )
            self_signed_ca = self.render_template(
                "cacerts/selfsigned-ca.yaml", self.render_context
            )
            self.client.deploy_custom_resource(
                Deployment.CERT_REQUEST_GROUP,
                Deployment.CERT_REQUEST_VERSION,
                Deployment.CERT_REQUEST_PLURAL,
                self.service_record.service_namespace,
                yaml.safe_load(self_signed_ca),
            )
            self_signed_ca_issuer = self.render_template(
                "cacerts/selfsigned-ca-issuer.yaml", self.render_context
            )
            self.client.deploy_custom_resource(
                Deployment.CERT_ISSUE_GROUP,
                Deployment.CERT_ISSUE_VERSION,
                Deployment.CERT_ISSUE_PLURAL,
                self.service_record.service_namespace,
                yaml.safe_load(self_signed_ca_issuer),
            )
        # Create Role and RoleBinding
        role = self.render_template(
            "mysql/role.yaml", self.render_context
        )
        self.client.create_role(
            self.service_record.service_namespace, yaml.safe_load(role)
        )

        role_binding = self.render_template(
            "mysql/rolebinding.yaml", self.render_context
        )
        self.client.create_rolebinding(
            self.service_record.service_namespace, yaml.safe_load(role_binding)
        )

        # Issue certificate
        certificate = self.render_template(
            "mysql/certificate.yaml", self.render_context
        )
        self.client.deploy_custom_resource(
            Deployment.CERT_REQUEST_GROUP,
            Deployment.CERT_REQUEST_VERSION,
            Deployment.CERT_REQUEST_PLURAL,
            self.service_record.service_namespace,
            yaml.safe_load(certificate),
        )

        # Copy regcred secret
        sec  = client.V1Secret()
        sec.metadata = client.V1ObjectMeta(name="regcred")
        reg_cred_data = {}
        reg_cred_data[".dockerconfigjson"] = self.client.read_from_secret(
            self.config.K8S_BROKER_NAMESPACE, 
            self.config.REG_CRED,
            ".dockerconfigjson"
        )
        sec.type = "kubernetes.io/dockerconfigjson"
        sec.data = reg_cred_data

        self.client.create_secret(
            self.service_record.service_namespace, 
            sec
        )

        # Copy router-public-certificate secret
        sec  = client.V1Secret()
        sec.metadata = client.V1ObjectMeta(name="router-public-certificate")
        pub_cert_data = {}
#        print(self.client.read_from_secret(
#            "certificates",
#            "router-public-certificate",
#            "tls.crt"
#        ))
#        print(self.client.read_from_secret(
#            "certificates",
#            "router-public-certificate",
#            "tls.key"
#        ))
        pub_cert_data["tls.crt"] = self.client.read_from_secret(
            "certificates",
            "router-public-certificate",
            "tls.crt"
        )
        pub_cert_data["tls.key"] = self.client.read_from_secret(
            "certificates",
            "router-public-certificate",
            "tls.key"
        )
        sec.type = "kubernetes.io/tls"
        sec.data = pub_cert_data

        self.client.create_secret(
            self.service_record.service_namespace,
            sec
        )

        secret = self.render_template("mysql/mysql-secret.yaml", self.render_context)
        self.client.create_secret(
            self.service_record.service_namespace, yaml.safe_load(secret)
        )
        # config
        if "5.7" in self.service_record.engine_version:
            mysql_config = self.render_template(
                "mysql/mysql-configmap-v5-7.yaml", self.render_context
            )
        else:
            mysql_config = self.render_template(
                "mysql/mysql-configmap.yaml", self.render_context
            )
        self.client.create_configmap(
            self.service_record.service_namespace, yaml.safe_load(mysql_config)
        )
        # Create deployment
        deployment = self.render_template(
            "mysql/mysql-statefulset.yaml", self.render_context
        )
        self.client.create_stateful_set(
            self.service_record.service_namespace, yaml.safe_load(deployment)
        )
        # Create service
        svc = self.render_template("mysql/mysql-service.yaml", self.render_context)
        self.client.create_service(
            self.service_record.service_namespace, yaml.safe_load(svc)
        )

        # Create backup schedule
        backup_schedule = self.render_template("mysql/backup-schedule.yaml", self.render_context)
        self.client.deploy_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_SCHEDULE_PLURAL,
            Deployment.VELERO_NAMESPACE,
            yaml.safe_load(backup_schedule)
        )
    def get_backups(self):
        backups = self.client.get_backups(
            self.service_record.service_namespace, 
            f"velero.io/schedule-name=mysql-{self.service_record.instance_id}"
        )
        return backups

    def create_snapshot(self):
        manual_backup = self.render_template("mysql/backup.yaml", self.render_context)
        self.client.deploy_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_BACKUP_PLURAL,
            Deployment.VELERO_NAMESPACE,
            yaml.safe_load(manual_backup)
        )

    def delete_snapshot(self, backup_name):
        self.client.delete_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_BACKUP_PLURAL,
            Deployment.VELERO_NAMESPACE,
            backup_name
        )

    def restore_snapshot(self, backup_name):
        restore_context = self.render_context
        restore_context["backup_name"] = backup_name

        describe_backup = self.client.get_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_BACKUP_PLURAL,
            Deployment.VELERO_NAMESPACE,
            backup_name
        )
        restore_context["original_namespace"] = describe_backup["spec"]["includedNamespaces"][0]
        if describe_backup["status"]["phase"] == "Completed":
            restore_manifest = self.render_template("mysql/restore.yaml", restore_context)
            self.client.deploy_custom_resource(
                Deployment.VELERO_API_GROUP,
                Deployment.VELERO_API_VERSION,
                Deployment.VELERO_RESTORE_PLURAL,
                Deployment.VELERO_NAMESPACE,
                yaml.safe_load(restore_manifest)
            )


class MySQLDeploymentWithMonitoring(MySQLDeployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def deploy(self):
        super(MySQLDeploymentWithMonitoring, self).deploy()
        deployment = self.render_template(
            "mysql/exporter/deployment.yaml", self.render_context
        )
        self.client.create_deployment(
            self.service_record.service_namespace, yaml.safe_load(deployment)
        )
        svc = self.render_template("mysql/exporter/service.yaml", self.render_context)
        self.client.create_service(
            self.service_record.service_namespace, yaml.safe_load(svc)
        )
        service_monitor = self.render_template(
            "mysql/exporter/servicemonitor.yaml", self.render_context
        )
        self.client.create_service_monitor(
            self.service_record.service_namespace, yaml.safe_load(service_monitor)
        )


class PostgresDeployment(Deployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def deploy(self):
        # Check if root ca is present if not create
        iss_ca_available = self.client.check_custom_resource(
            Deployment.CERT_ISSUE_GROUP,
            Deployment.CERT_ISSUE_VERSION,
            Deployment.CERT_ISSUE_PLURAL,
            self.service_record.service_namespace,
            "db-ca-issuer",
        )
        if not iss_ca_available:
            self_signed_issuer = self.render_template(
                "cacerts/selfsigned-issuer.yaml", self.render_context
            )
            self.client.deploy_custom_resource(
                Deployment.CERT_ISSUE_GROUP,
                Deployment.CERT_ISSUE_VERSION,
                Deployment.CERT_ISSUE_PLURAL,
                self.service_record.service_namespace,
                yaml.safe_load(self_signed_issuer),
            )
            self_signed_ca = self.render_template(
                "cacerts/selfsigned-ca.yaml", self.render_context
            )
            self.client.deploy_custom_resource(
                Deployment.CERT_REQUEST_GROUP,
                Deployment.CERT_REQUEST_VERSION,
                Deployment.CERT_REQUEST_PLURAL,
                self.service_record.service_namespace,
                yaml.safe_load(self_signed_ca),
            )
            self_signed_ca_issuer = self.render_template(
                "cacerts/selfsigned-ca-issuer.yaml", self.render_context
            )
            self.client.deploy_custom_resource(
                Deployment.CERT_ISSUE_GROUP,
                Deployment.CERT_ISSUE_VERSION,
                Deployment.CERT_ISSUE_PLURAL,
                self.service_record.service_namespace,
                yaml.safe_load(self_signed_ca_issuer),
            )

        # Create Role and RoleBinding
        role = self.render_template(
            "postgres/role.yaml", self.render_context
        )
        self.client.create_role(
            self.service_record.service_namespace, yaml.safe_load(role)
        )

        role_binding = self.render_template(
            "postgres/rolebinding.yaml", self.render_context
        )
        self.client.create_rolebinding(
            self.service_record.service_namespace, yaml.safe_load(role_binding)
        )

        # Issue certificate
        certificate = self.render_template(
            "postgres/certificate.yaml", self.render_context
        )
        self.client.deploy_custom_resource(
            Deployment.CERT_REQUEST_GROUP,
            Deployment.CERT_REQUEST_VERSION,
            Deployment.CERT_REQUEST_PLURAL,
            self.service_record.service_namespace,
            yaml.safe_load(certificate),
        )

        # Copy regcred secret
        sec  = client.V1Secret()
        sec.metadata = client.V1ObjectMeta(name="regcred")
        reg_cred_data = {}
        reg_cred_data[".dockerconfigjson"] = self.client.read_from_secret(
            self.config.K8S_BROKER_NAMESPACE, 
            self.config.REG_CRED,
            ".dockerconfigjson"
        )
        sec.type = "kubernetes.io/dockerconfigjson"
        sec.data = reg_cred_data

        self.client.create_secret(
            self.service_record.service_namespace, 
            sec
        )

        # Copy router-public-certificate secret
        sec  = client.V1Secret()
        sec.metadata = client.V1ObjectMeta(name="router-public-certificate")
        pub_cert_data = {}
#        print(self.client.read_from_secret(
#            "certificates", 
#            "router-public-certificate",
#            "tls.crt"
#        ))
#        print(self.client.read_from_secret(
#            "certificates", 
#            "router-public-certificate",
#            "tls.key"
#        ))
        pub_cert_data["tls.crt"] = self.client.read_from_secret(
            "certificates", 
            "router-public-certificate",
            "tls.crt"
        )
        pub_cert_data["tls.key"] = self.client.read_from_secret(
            "certificates", 
            "router-public-certificate",
            "tls.key"
        )
        sec.type = "kubernetes.io/tls"
        sec.data = pub_cert_data

        self.client.create_secret(
            self.service_record.service_namespace, 
            sec
        )

        config_map = self.render_template(
            "postgres/postgres-configmap.yaml", self.render_context
        )
        self.client.create_configmap(
            self.service_record.service_namespace, yaml.safe_load(config_map)
        )
        if float(self.service_record.engine_version) < 11:
            init_config_map = self.render_template(
                "postgres/postgres-init-jit-disabled-configmap.yaml", self.render_context
            )
        else:
            init_config_map = self.render_template(
                "postgres/postgres-init-jit-enabled-configmap.yaml", self.render_context
            )
        self.client.create_configmap(
            self.service_record.service_namespace, yaml.safe_load(init_config_map)
        )
        # Create secret
        secret = self.render_template(
            "postgres/postgres-secret.yaml", self.render_context
        )
        self.client.create_secret(
            self.service_record.service_namespace, yaml.safe_load(secret)
        )
        # Create deployment
        deployment = self.render_template(
            "postgres/postgres-statefulset.yaml", self.render_context
        )
        self.client.create_stateful_set(
            self.service_record.service_namespace, yaml.safe_load(deployment)
        )
        # Create service
        svc = self.render_template(
            "postgres/postgres-service.yaml", self.render_context
        )
        self.client.create_service(
            self.service_record.service_namespace, yaml.safe_load(svc)
        )

        # Create backup schedule
        backup_schedule = self.render_template("postgres/backup-schedule.yaml", self.render_context)
        self.client.deploy_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_SCHEDULE_PLURAL,
            Deployment.VELERO_NAMESPACE,
            yaml.safe_load(backup_schedule)
        ) 

    def get_backups(self):
        backups = self.client.get_backups(
            self.service_record.service_namespace, 
            f"velero.io/schedule-name=postgres-{self.service_record.instance_id}"
        )
        return backups

    def create_snapshot(self):
        manual_backup = self.render_template("postgres/backup.yaml", self.render_context)
        self.client.deploy_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_BACKUP_PLURAL,
            Deployment.VELERO_NAMESPACE,
            yaml.safe_load(manual_backup)
        )

    def delete_snapshot(self, backup_name):
        self.client.delete_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_BACKUP_PLURAL,
            Deployment.VELERO_NAMESPACE,
            backup_name
        )

    def restore_snapshot(self, backup_name):

        # Create Role and RoleBinding
        role = self.render_template(
            "postgres/role.yaml", self.render_context
        )
        self.client.create_role(
            self.service_record.service_namespace, yaml.safe_load(role)
        )

        role_binding = self.render_template(
            "postgres/rolebinding.yaml", self.render_context
        )
        self.client.create_rolebinding(
            self.service_record.service_namespace, yaml.safe_load(role_binding)
        )

        restore_context = self.render_context
        restore_context["backup_name"] = backup_name

        describe_backup = self.client.get_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_BACKUP_PLURAL,
            Deployment.VELERO_NAMESPACE,
            backup_name
        )

        restore_context["original_namespace"] = describe_backup["spec"]["includedNamespaces"][0]
        restore_manifest = self.render_template("postgres/restore.yaml", restore_context)
        if describe_backup["status"]["phase"] == "Completed":
            self.client.deploy_custom_resource(
                Deployment.VELERO_API_GROUP,
                Deployment.VELERO_API_VERSION,
                Deployment.VELERO_RESTORE_PLURAL,
                Deployment.VELERO_NAMESPACE,
                yaml.safe_load(restore_manifest)
            )

class PostgresDeploymentWithMonitoring(PostgresDeployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def deploy(self):
        super(PostgresDeploymentWithMonitoring, self).deploy()
        config_map = self.render_template(
            "postgres/exporter/configmap.yaml", self.render_context
        )
        self.client.create_configmap(
            self.service_record.service_namespace, yaml.safe_load(config_map)
        )
        # Create Exporter Deployment
        deployment = self.render_template(
            "postgres/exporter/deployment.yaml", self.render_context
        )
        self.client.create_deployment(
            self.service_record.service_namespace, yaml.safe_load(deployment)
        )
        # Create Exporter Service
        svc = self.render_template(
            "postgres/exporter/service.yaml", self.render_context
        )
        self.client.create_service(
            self.service_record.service_namespace, yaml.safe_load(svc)
        )
        # Create ServiceMonitor
        service_monitor = self.render_template(
            "postgres/exporter/servicemonitor.yaml", self.render_context
        )
        self.client.create_service_monitor(
            self.service_record.service_namespace, yaml.safe_load(service_monitor)
        )


class DeleteMySQLDeployment(DeleteDeployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def delete(self):
        name = f"mysql-{self.service_record.instance_id}"
        self.client.delete_service(self.service_record.service_namespace, name)
        self.client.delete_pvc_replica(self.service_record.service_namespace, f"data-{name}", name)
        self.client.delete_stateful_set(self.service_record.service_namespace, name)
        self.client.delete_secret(self.service_record.service_namespace, name)
        cert_name = f"mysql-server-{self.service_record.instance_id}"
        self.client.delete_custom_resource(
            Deployment.CERT_REQUEST_GROUP,
            Deployment.CERT_REQUEST_VERSION,
            Deployment.CERT_REQUEST_PLURAL,
            self.service_record.service_namespace,
            cert_name,
        )
        cert_secret = f"mysql-server-{self.service_record.instance_id}-secret"
        self.client.delete_secret(self.service_record.service_namespace, cert_secret)
        config = f"mysql-{self.service_record.instance_id}-config"
        self.client.delete_configmap(self.service_record.service_namespace, config)
        backup_schedule_name = f"mysql-{self.service_record.instance_id}-backup-schedule"
        self.client.delete_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_SCHEDULE_PLURAL,
            Deployment.VELERO_NAMESPACE,
            backup_schedule_name,
        )
        rolebinding_name = f"rolebinding-{self.service_record.instance_id}"
        self.client.delete_rolebinding(self.service_record.service_namespace, rolebinding_name)
        role_name = f"role-{self.service_record.instance_id}"
        self.client.delete_role(self.service_record.service_namespace, role_name)


class DeleteMySQLDeploymentMonitoring(DeleteMySQLDeployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def delete(self):
        super(DeleteMySQLDeploymentMonitoring, self).delete()
        name = f"mysql-exporter-{self.service_record.instance_id}"
        self.client.delete_deployment(self.service_record.service_namespace, name)
        self.client.delete_service(self.service_record.service_namespace, name)
        self.client.delete_service_monitor(self.service_record.service_namespace, name)
        self.client.delete_namespace(self.service_record.service_namespace)


class DeletePostgresDeployment(DeleteDeployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def delete(self):
        name = f"postgres-{self.service_record.instance_id}"
        configmap = f"pg-config-{self.service_record.instance_id}"
        init_config_map = f"postgres-init-config-{self.service_record.instance_id}"
        self.client.delete_service(self.service_record.service_namespace, name)
        self.client.delete_pvc_replica(
            self.service_record.service_namespace, f"postgredb-{name}", name
        )
        self.client.delete_stateful_set(self.service_record.service_namespace, name)
        self.client.delete_secret(self.service_record.service_namespace, name)
        self.client.delete_configmap(self.service_record.service_namespace, configmap)
        self.client.delete_configmap(
            self.service_record.service_namespace, init_config_map
        )
        cert_name = f"postgres-server-{self.service_record.instance_id}"
        self.client.delete_custom_resource(
            Deployment.CERT_REQUEST_GROUP,
            Deployment.CERT_REQUEST_VERSION,
            Deployment.CERT_REQUEST_PLURAL,
            self.service_record.service_namespace,
            cert_name,
        )
        cert_secret = f"postgres-server-{self.service_record.instance_id}-secret"
        self.client.delete_secret(self.service_record.service_namespace, cert_secret)
        backup_schedule_name = f"postgres-{self.service_record.instance_id}-backup-schedule"
        self.client.delete_custom_resource(
            Deployment.VELERO_API_GROUP,
            Deployment.VELERO_API_VERSION,
            Deployment.VELERO_SCHEDULE_PLURAL,
            Deployment.VELERO_NAMESPACE,
            backup_schedule_name,
        )
        rolebinding_name = f"rolebinding-{self.service_record.instance_id}"
        self.client.delete_rolebinding(self.service_record.service_namespace, rolebinding_name)
        role_name = f"role-{self.service_record.instance_id}"
        self.client.delete_role(self.service_record.service_namespace, role_name)


class DeletePostgresDeploymentMonitoring(DeletePostgresDeployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def delete(self):
        super(DeletePostgresDeploymentMonitoring, self).delete()
        name = f"postgres-exporter-{self.service_record.instance_id}"
        configmap = f"postgres-exporter-{self.service_record.instance_id}"
        self.client.delete_deployment(self.service_record.service_namespace, name)
        self.client.delete_service(self.service_record.service_namespace, name)
        self.client.delete_configmap(self.service_record.service_namespace, configmap)
        self.client.delete_service_monitor(self.service_record.service_namespace, name)
        self.client.delete_namespace(self.service_record.service_namespace)


class UpdateMySQLDeployment(UpdateDeployment):

    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def update(self):
        name = f"mysql-{self.service_record.instance_id}"
        self.client.update_pvc(self.service_record.service_namespace, f"data-{name}", name,
                               self.service_record.allocatedStorage)
        self.client.delete_pod(self.service_record.service_namespace, name)


class UpdatePostgresDeployment(UpdateDeployment):
    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def update(self):
        name = f"postgres-{self.service_record.instance_id}"
        self.client.update_pvc(self.service_record.service_namespace, f"postgredb-{name}", name,
                               self.service_record.allocatedStorage)
        self.client.delete_pod(self.service_record.service_namespace, name)
