from collections import OrderedDict


class VaultError(Exception):
    def __init__(self, message=None):
        self.message = message or self.message
        super(VaultError, self).__init__(self.message)


class VaultInvalidRequestError(VaultError):
    pass


class VaultUnauthorizedError(VaultError):
    pass


class VaultForbiddenError(VaultError):
    pass


class VaultInvalidPathError(VaultError):
    pass


class VaultInternalServerError(VaultError):
    pass


class VaultDownError(VaultError):
    pass


class VaultConnectionError(VaultError):
    pass


class VaultUnexpectedError(VaultError):
    pass


def vault_exc_mapping():
    return OrderedDict(
        [
            (
                VaultInvalidRequestError,
                {
                    "status_code": 400,
                    "description": "Invalid request, missing or invalid data",
                },
            ),
            (
                VaultUnauthorizedError,
                {"status_code": 401, "description": "Unauthorized request"},
            ),
            (
                VaultForbiddenError,
                {
                    "status_code": 403,
                    "description": "Forbidden, authentication failure or access denied",
                },
            ),
            (
                VaultInvalidPathError,
                {"status_code": 404, "description": "Path does not exist"},
            ),
            (
                VaultInternalServerError,
                {"status_code": 500, "description": "Internal error, try again later"},
            ),
            (
                VaultDownError,
                {
                    "status_code": 503,
                    "description": "Vault is down for maintenance or currently sealed",
                },
            ),
            (VaultConnectionError, {"description": "Connection error"}),
            (VaultUnexpectedError, {"description": "Unexpected error"}),
            (VaultError, {"description": "Unknown Vault error"}),
        ]
    )


vault_exc_mapping = vault_exc_mapping()
