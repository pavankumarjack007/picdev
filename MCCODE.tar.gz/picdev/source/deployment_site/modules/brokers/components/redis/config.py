import logging
from os import environ, getenv


class Config:
    DEBUG = False
    TESTING = False

    BROKER_IS_ASYNC = True
    BROKER_USERNAME = environ.get("BROKER_USERNAME", "")
    BROKER_PASSWORD = environ.get("BROKER_PASSWORD", "")
    BROKER_VERSION = environ.get("BROKER_VERSION", "")
    LOGGING_LEVEL = environ.get("LOGGING_LEVEL", logging.getLevelName(logging.DEBUG))
    LOGGING_MSG_FORMAT = environ.get(
        "LOGGING_MSG_FORMAT", "%(asctime)s %(levelname)s %(name)s %(message)s"
    )
    PORT = int(environ.get("PORT", "8080"))

    AWS_ACCESS_KEY_ID = environ.get("AWS_ACCESS_KEY_ID", "")
    AWS_SECRET_ACCESS_KEY = environ.get("AWS_SECRET_ACCESS_KEY", "")
    AWS_DEFAULT_REGION = environ.get("AWS_DEFAULT_REGION", "ap-south-1")
    DOCKER_REGISTRY_HOST = environ.get("DOCKER_REGISTRY_HOST", "docker.na1.hsdp.io")
    DOCKER_REGISTRY_USER = environ.get("DOCKER_REGISTRY_USER", "")
    DOCKER_REGISTRY_PASSWORD = environ.get("DOCKER_REGISTRY_PASSWORD", "")
    DYNAMODB_TABLE = environ.get("DYNAMODB_TABLE", "hsdp_redis_service_broker")
    K8S_BROKER_NAMESPACE = environ.get("K8S_BROKER_NAMESPACE", "redis")
    K8S_API_ENDPOINT = environ.get("K8S_API_ENDPOINT", "")
    K8S_BROKER_TOKEN = environ.get("K8S_BROKER_TOKEN", "")
    K8S_CACERT = environ.get("K8S_CACERT", "")
    K8S_IMAGE_PULL_SECRET = environ.get("K8S_IMAGE_PULL_SECRET", "hsdp-registry")
    STORAGE_CLASS = environ.get("STORAGE_CLASS")
    DYNAMO_DB_HOST = environ.get("DYNAMO_DB_HOST", None)
    ENCRYPTION_KEY = environ.get("ENCRYPTION_KEY")
    MONITORING_ENABLED = environ.get("MONITORING_ENABLED", "true")
    MONITORING_TAG = environ.get("MONITORING_TAG", "hsop-prometheus")
    REG_CRED = environ.get("REG_CRED", "regcred")
    SERVICE_PREFIX = "redis-"

    CF_DOCKER_USERNAME = environ.get('DOCKER_USERNAME', '')
    CF_DOCKER_PASSWORD = environ.get('CF_DOCKER_PASSWORD', '')
    CF_DOCKER_REGISTRY = environ.get('DOCKER_REGISTRY', '')
    DOCKER_REGISTRY = environ.get('DOCKER_REGISTRY', '')

    REDIS_DOCKER_IMAGE = environ.get('REDIS_DOCKER_IMAGE', '')
    CF_API_ENDPOINT = environ.get("CF_API_ENDPOINT", "<cf-api-endpoint>")
    UAA_OAUTH_CLIENT_ID = environ.get("UAA_OAUTH_CLIENT_ID", "<client-id>")
    UAA_OAUTH_CLIENT_SECRET = environ.get("UAA_OAUTH_CLIENT_SECRET", "<client-secret>")
    BROKER_API_KEY= environ.get("BROKER_API_KEY", "<broker_api_key>")
    GRAPHQL_SKIP_AUTH = False

    @property
    def service_catalog_filename(self):
        from pathlib import Path

        # We assume catalog (and this config file) are in the same (project root) directory.
        root = Path(__file__).parent
        catalog_file = root / "catalog.yml"
        return str(catalog_file)

    @property
    def cc_config(self):
        return {
            "base_url": self.CF_API_ENDPOINT,
            "client_id": self.UAA_OAUTH_CLIENT_ID,
            "client_secret": self.UAA_OAUTH_CLIENT_SECRET,
        }


class DevelopmentConfig(Config):
    DEBUG = True


class TestingConfig(Config):
    TESTING = True
    DEBUG = False
    BROKER_USERNAME = ""
    BROKER_PASSWORD = ""
    GRAPHQL_SKIP_AUTH = True


class ProductionConfig(Config):
    DEBUG = False
    LOGGING_LEVEL = environ.get("LOGGING_LEVEL", logging.getLevelName(logging.INFO))
    LOGGING_MSG_FORMAT = environ.get(
        "LOGGING_MSG_FORMAT", "%(levelname)s %(name)s %(message)s"
    )


class DeploymentConfig(ProductionConfig):
    CF_APP_NAME = environ.get("CF_APP_NAME", "hsdp-redis-test")
    BGD_CF_APP_NAME = "{}-new".format(CF_APP_NAME)

    CF_BUILDPACK = environ.get("CF_BUILDPACK", "python_buildpack")
    CF_URL = environ.get("CF_URL", "<cf-url>")
    CF_ORG = environ.get("CF_ORG", "<cf-org>")
    CF_SPACE = environ.get("CF_SPACE", "<cf-space>")
    CF_USER = environ.get("CF_USER", "<cf-user>")
    CF_PASSWORD = environ.get("CF_PASSWORD", "<cf-password>")

    DEPLOY_WITH_SMOKETESTS = environ.get("DEPLOY_WITH_SMOKETESTS", "true")
    BROKER_CONFIG = environ.get("BROKER_CONFIG", "production")

    SMOKETEST_SERVICE_ID = getenv(
        "SMOKETEST_SERVICE_ID", "b2eab96e-1e5e-4700-b267-6a76d78adbf7"
    )
    SMOKETEST_PLAN_ID = getenv(
        "SMOKETEST_PLAN_ID", "f2df267f-47ce-4b79-a407-c3c7862928fb"
    )


# Global config object
config_map = {
    "development": DevelopmentConfig(),
    "testing": TestingConfig(),
    "production": ProductionConfig(),
    "deployment": DeploymentConfig(),
    "default": DevelopmentConfig(),
}
