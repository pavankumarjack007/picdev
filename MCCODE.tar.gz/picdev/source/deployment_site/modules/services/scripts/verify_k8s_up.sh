#! /bin/bash


#verify cluster is "up"
while : ; do
    echo "Checking if control plane is ready"
    result=$(kubectl get nodes | grep control-plane | awk '{ print $2 }')
    #echo "Expecting $total_nodes .. Current $result"
    return=$(echo $result |awk '{print $1}')
    if [[ "$return" == "Ready" ]]
    then
      echo "Control plane is up"
      break
    fi
    sleep 10
done

