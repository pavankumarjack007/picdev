import graphene

from .instance_details import InstanceDetails
from .instance_metrics import InstanceMetrics


class Instance(graphene.ObjectType):
    guid = graphene.String()
    organization = graphene.String()
    space = graphene.String()
    name = graphene.String()
    created_dt = graphene.String()
    plan_name = graphene.String()

    details = graphene.Field(InstanceDetails)
    metrics = graphene.Field(InstanceMetrics)

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_details(instance, info):
        return info.context.instance_details(instance.guid)

    def resolve_metrics(instance, info):
        return info.context.instance_metrics(instance.guid)
