import os
import pytest
import urllib3
import json
import base64

urllib3.disable_warnings()

cluster_name = os.environ['cluster']


@pytest.fixture(scope="session")
@pytest.mark.order(0)
def setup_kubectl():
    print("\n(----------------Pre-setup----------------)")
    os.system("source export_vars")
    os.system('bash clusterConnect.sh ' + cluster_name)
    cluster = os.popen('kubectl cluster-info').read()  # os.system("kubectl cluster-info")
    assert cluster_name in str(cluster)


@pytest.fixture(scope="session", autouse=True)
@pytest.mark.order(1)
def setup_credhub():
    cf_url = cluster_name[3:]
    cf_credhub_url = "https://credhub.cf" + cf_url
    print()
    os.popen('./binary/credhub api ' + cf_credhub_url).read()
    credhub_admin_secret = os.popen(
        'kubectl -n kubecf get secret var-credhub-admin-client-secret -o yaml | yq e \'.data.password\' - | base64 '
        '--decode').read()
    login_output = os.popen('./binary/credhub login --client-name=credhub_admin_client --client-secret=' + str(
        credhub_admin_secret)).read()
    assert "Successf" in str(login_output)
    private_key_from_credhub = os.popen('./binary/credhub get --name \'/sshprivatekey\' -j').read()
    private_key_json = json.loads(private_key_from_credhub)
    private_key = base64.b64decode(private_key_json["value"]).decode('utf-8')
    pem_file = open("pem-key.pem", "w")
    pem_file.write(private_key)
    pem_file.close()
