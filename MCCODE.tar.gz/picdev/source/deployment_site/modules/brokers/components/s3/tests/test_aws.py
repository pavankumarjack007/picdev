import boto3
from moto import mock_iam
from nose.tools import assert_equal

from broker.aws import IamUser
from . import test_config


@mock_iam
def test_rotate_api_key_removes_all_previous_keys():
    iam_user_name = "test-user"
    iam = IamUser(**test_config.aws_config)
    resource = iam(iam_user_name).create()
    resource.rotate_api_key()
    # We should only ever have one key, even after a rotation (i.e. 1 active, 0 inactive).
    iam_client = boto3.client("iam", **test_config.aws_config)
    resp = iam_client.list_access_keys(UserName=iam_user_name)
    access_keys = resp.get("AccessKeyMetadata", [])
    assert_equal(len(access_keys), 1)
    assert_equal(access_keys[0]["Status"], "Active")
