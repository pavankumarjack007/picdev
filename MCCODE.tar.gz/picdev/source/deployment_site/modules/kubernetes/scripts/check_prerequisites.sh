#! /bin/bash
#Script to provisions the base platform for MicroCloud.
#Requires:- kOps (v1.21), terraform (v1.0.4)
#Requires: kubectl (1.15.5), aws-cli, jq
#Requires aws access_key, secret and region to be set (For example via:- aws configure ...)
#Requires Route53 hosted zone with the name that matches cluster_name

#check pre-requisites

abort(){
  echo $1 && exit 1
}

abort_or_continue() {
  if [[ $1 -ne 0 ]];
  then
    echo "Bailing out ..."
    exit 1
  fi
}

for i in yq jq kubectl aws kops envsubst hcledit terraform ssh-keygen cf curl ed
do
 if ! which $i; then
  abort "$i is not installed."
 fi
done

#check_yq_version() {
#  yq -V | grep -q "4.12.0"
#  if [[ $? -ne 0 ]];
#  then
#    echo "yq is not installed. exiting"
#    exit 1
#  fi
#}
#
#check_yq_version
