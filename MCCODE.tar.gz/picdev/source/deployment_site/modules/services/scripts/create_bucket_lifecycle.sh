#! /bin/bash

counter=0
while getopts u:a:s:n:b: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        u) url=${OPTARG};;
        a) key=${OPTARG};;
        s) secret=${OPTARG};;
        n) name=${OPTARG};;
        b) bucket=${OPTARG};;
    esac
done
#Checking pod status
while [ $counter -lt 10 ]; do
  pod=$(kubectl -n logging get pods -l tool-name=minio-client --no-headers -o custom-columns=":metadata.name")
  counter=$((counter+1))
  if [ -z "$pod" ]; then
        echo "Waiting for minio-client pod to come up" && sleep 5;
  else
        break
  fi
done
#Checking pod readiness
while [[ $(kubectl -n logging get pods -l tool-name=minio-client -o 'jsonpath={..status.conditions[?(@.type=="Ready")].status}') != "True" ]]; do 
  echo "Waiting for MinoIO clinet pod to be in ready state" && sleep 5; 
done
echo "MinIO client pod name is $pod"
kubectl -n logging exec -it $pod -- mc alias set $name $url $key $secret --api S3v4
found=$(kubectl -n logging exec -it $pod -- mc ls $name | grep $bucket | wc -l)
if [[ $found -eq 0 ]]
then
  kubectl -n logging exec -it $pod -- mc mb $name/$bucket
fi
kubectl -n logging exec -it $pod -- mc ilm import ${name}/${bucket} < logs_lifecycle.json
