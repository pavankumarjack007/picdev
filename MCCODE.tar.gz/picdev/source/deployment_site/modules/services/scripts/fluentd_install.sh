#!/bin/bash

# Time sync update on Bastion and ha-proxy
sudo tee /etc/systemd/timesyncd.conf > /dev/null <<EOT
# Same as master and worker from KOPS
[Time]
NTP=169.254.169.123
EOT
sudo systemctl restart systemd-timesyncd.service

# Installing fluentd on bastion and ha-proxy 
curl -L https://toolbelt.treasuredata.com/sh/install-ubuntu-focal-td-agent4.sh | sh
sudo cp -rpf /tmp/td-agent.conf /etc/td-agent/
sudo chmod 644 /var/log/*.log
sudo systemctl enable td-agent
sudo systemctl restart td-agent
