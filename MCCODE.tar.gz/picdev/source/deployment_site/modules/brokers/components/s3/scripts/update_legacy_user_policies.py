"""Update Legacy IAM User Policies

This script will add the `iam:GetUser` permission to any managed or inline
user policies that do not currently have it.

For the IAM users created to access brokered S3 buckets, we made a change
from managed to inline policies in May of 2017.  As of October 2017, the
inline policies include the `iam:GetUser` permission.

This script requires the following environment variables to be set
properly for each region where the changes need to occur:

AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
AWS_DEFAULT_REGION
ENCRYPTION_KEY

Note: the AWS credentials require the `iam:CreatePolicyVersion` permission,
which the S3 Service Broker user does not have.  You may have to run the
script using an admin account or an account with extra permissions.

When run, the script will do the following:

    * Scan the `hsdp_s3_service_broker` DynamoDB table in AWS_DEFAULT_REGION
      for all service instances.
    * For each service instance, try to call the `iam:GetUser` API method.
    * If the method fails, enumerate all managed and inline policies
      belonging to the service instance's IAM user.
    * For each inline or managed policy whose name matches that of the
      service instance's IAM user, check if the `iam:GetUser` permission
      is present.
    * If the permission is not present, add a statement to the policy
      that includes the `iam:GetUser` permission.  Do not modify the
      policy in any other way.
    * Verify that the change was successful by retrying the `iam:GetUser`
      API call.

This script is idempotent and can be run as often as needed.  However, after
a single successful run (in each required region), any entities that required
a policy update should have been updated.

See `CFSB-212` for more information.
"""
from __future__ import print_function, unicode_literals

import json

import boto3
from botocore.exceptions import ClientError
from tenacity import Retrying, retry_if_result, stop_after_attempt, wait_exponential

from broker import model
from config import config_map

config = config_map["production"]


def try_get_account_id_from_credentials(**aws_creds):
    iam = boto3.client("iam", **aws_creds)
    try:
        resp = iam.get_user()
        user = resp["User"]
        arn = user["Arn"]
        account_id = arn.split(":")[4]
    except ClientError:
        account_id = None
    return account_id


def verify_permission_change(**aws_creds):
    # The retry stuff here is a little verbose, but it can
    # take a while for the change to propagate through AWS.
    def return_last_value(retry_state):
        return retry_state.outcome.result()

    def is_none(value):
        return value is None

    retry = Retrying(
        retry=retry_if_result(is_none),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        stop=stop_after_attempt(8),
        retry_error_callback=return_last_value,
    )
    return retry(try_get_account_id_from_credentials, **aws_creds)


def has_get_user_permission(policy_document):
    has_permission = False
    for statement in policy_document["Statement"]:
        for action in statement["Action"]:
            if action == "iam:GetUser":
                has_permission = True
    return has_permission


def generate_updated_policy_document(policy_document, user):
    account_id = user.arn.split(":")[4]
    resource = "arn:{partition}:iam::{account_id}:user/{user_id}".format(
        account_id=account_id,
        user_id=user.name,
        partition="aws-cn" if config.is_china_region else "aws",
    )
    get_user_statement = {
        "Effect": "Allow",
        "Action": ["iam:GetUser"],
        "Resource": resource,
    }
    policy_document["Statement"].append(get_user_statement)
    return policy_document


def update_attached_policy(policy, user):
    has_permission = has_get_user_permission(policy.default_version.document)
    if has_permission:
        print("Found iam:GetUser permission.  Aborting update!")
        return
    print("Adding iam:GetUser permission to attached policy document...")
    document = generate_updated_policy_document(policy.default_version.document, user)
    policy.create_version(PolicyDocument=json.dumps(document), SetAsDefault=True)


def update_inline_policy(policy, user):
    has_permission = has_get_user_permission(policy.policy_document)
    if has_permission:
        print("Found iam:GetUser permission.  Aborting update!")
        return
    print("Adding iam:GetUser permission to inline policy document...")
    document = generate_updated_policy_document(policy.policy_document, user)
    policy.put(PolicyDocument=json.dumps(document))


def main():
    print("<*********BEGIN SCRIPT*********>")
    print("Updating policies in {}".format(config.AWS_DEFAULT_REGION))
    print("DynamoDB Table: {}".format(config.DYNAMODB_TABLE))
    iam_resource = boto3.resource("iam", **config.aws_config)
    broker_state = model.get_broker_model(config)
    for instance in broker_state.scan():
        print(instance.instance_id)
        aws_creds = dict(
            aws_access_key_id=instance.iam_user.access_key_id,
            aws_secret_access_key=instance.iam_user.secret_access_key,
        )
        account_id = try_get_account_id_from_credentials(**aws_creds)
        if account_id:
            continue
        try:
            instance_name = (
                instance.bucket
            )  # User/Policy/Bucket names are all the same.
            print("<---------BEGIN UPDATE--------->")
            print("Instance: {}".format(instance_name))
            user = iam_resource.User(instance_name)
            for attached_policy in user.attached_policies.all():
                if attached_policy.policy_name == user.name:
                    print(
                        "Found attached policy: {}".format(attached_policy.policy_name)
                    )
                    update_attached_policy(attached_policy, user)
                    break
            else:
                print("No attached policies found...")
            for user_policy in user.policies.all():
                if user_policy.policy_name == user.name:
                    print("Found inline policy: {}".format(user_policy.policy_name))
                    update_inline_policy(user_policy, user)
                    break
            else:
                print("No inline policies found...")
            print("Checking if successfully applied...")
            account_id = verify_permission_change(**aws_creds)
            print("...FAILED!" if account_id is None else "...SUCCESS!")
        except Exception as e:
            print(str(e))
        finally:
            print("<---------END UPDATE----------->")
    print("<*********END SCRIPT***********>")


if __name__ == "__main__":
    main()
