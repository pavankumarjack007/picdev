import logging
from distutils.util import strtobool

from broker.deploy import ElasticSearchDeployment, ElasticSearchDeploymentWithMonitoring
from broker.k8s import KubernetesClient


class OpState(object):
    NOT_STARTED = "not started"
    IN_PROGRESS = "in progress"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class BaseOperation(object):
    def __init__(self, status=None, description=None):
        self.action = self.__class__.__name__
        self.status = status or OpState.IN_PROGRESS
        self.description = description
        self.description = description


class Provision(BaseOperation):
    def __init__(self, config):
        super().__init__()
        self.log = logging.getLogger(__name__)
        self.config = config
        self.client = KubernetesClient(
            config.K8S_API_ENDPOINT, config.K8S_CACERT, config.K8S_BROKER_TOKEN
        )

    def create_service(self, service_record):
        try:
            deployment = new_instance(self.config, self.client, service_record)
            deployment.deploy()
        except Exception as e:
            logging.error(f"Error in provisioning resource {e}")
            service_record.delete()
            raise e

    def state(self, service_record):
        namespace = service_record.service_namespace
        name = f"es-{service_record.instance_id}"
        resource_status = self.client.get_custom_resource_status(
            ElasticSearchDeployment.ELASTIC_GROUP,
            ElasticSearchDeployment.ELASTIC_VERSION,
            ElasticSearchDeployment.ELASTIC_PLURALS,
            namespace,
            name,
        )
        if resource_status is not None and resource_status == "Ready":
            state = OpState.SUCCEEDED
        else:
            pod_status = self.client.pod_status(
                service_record.service_namespace, service_record.service_name
            )
            state = OpState.SUCCEEDED
            if pod_status == "Pending":
                state = OpState.IN_PROGRESS
            elif pod_status == "Failed":
                state = OpState.FAILED
        return state

    def credentials(self, service_record):
        secret_name = f"es-{service_record.instance_id}-es-elastic-user"
        secret_token = None
        password = self.client.read_from_secret(
            service_record.service_namespace, secret_name, "elastic", True
        )
        if service_record.apm_enabled:
            apm_secret_name = f"apm-{service_record.instance_id}-apm-token"
            secret_token = self.client.read_from_secret(
                service_record.service_namespace, apm_secret_name, "secret-token", True
            )
        return {"password": password, "secret_token": secret_token}

    def ca_certificate(self, service_record):
        return self.client.read_from_secret(
            service_record.service_namespace, "root-elastic-secret", "ca.crt"
        )


class Deprovision(BaseOperation):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.client = KubernetesClient(
            config.K8S_API_ENDPOINT, config.K8S_CACERT, config.K8S_BROKER_TOKEN
        )

    def delete_service(self, service_record):
        try:
            deployment = new_instance(self.config, self.client, service_record)
            deployment.delete()
        except Exception as e:
            logging.error(f"Error in deprovisioning resource {e}")
            service_record.save()
            raise e

    def state(self, service_record):
        namespace = service_record.service_namespace
        name = f"es-{service_record.instance_id}"
        resource_status = self.client.get_custom_resource_status(
            ElasticSearchDeployment.ELASTIC_GROUP,
            ElasticSearchDeployment.ELASTIC_VERSION,
            ElasticSearchDeployment.ELASTIC_PLURALS,
            namespace,
            name,
        )
        state = OpState.IN_PROGRESS
        if resource_status is None:
            state = OpState.SUCCEEDED
        return state


def new_instance(config, client, service_record):
    monitoring_enabled = bool(strtobool(config.MONITORING_ENABLED))
    if monitoring_enabled:
        return ElasticSearchDeploymentWithMonitoring(config, client, service_record)
    return ElasticSearchDeployment(config, client, service_record)
