import string

import pytest
import os
import paramiko
import random
import json
import base64
from subprocess import PIPE, Popen
from openpyxl import load_workbook


domain = os.environ['domain_name']
login_vault_addr = os.environ['login_vault_addr']
role_id = os.environ['LOGIN_APPROLE_ROLE_ID']
secret_id = os.environ['LOGIN_APPROLE_SECRET_ID']
secret_path = os.environ['VAULT_GENERIC_SECRET_PATH']


# Verify LSC is deployed along with identity components
@pytest.mark.ldap
def test_lsc_deployment_check():
    keycloak_verify = os.popen('kubectl get pods -n identity | grep keycloak-0 | grep -v keycloak-postgresql-0 | awk '
                               '\'{print $2}\'').read()
    assert "1/1" in str(keycloak_verify)
    keycloak_postgres_verify = os.popen(
        'kubectl get pods -n identity | grep keycloak-postgresql-0 | awk \'{print $2}\'').read()
    assert "1/1" in str(keycloak_postgres_verify)
    openldap_verify = os.popen('kubectl get pods -n identity | grep openldap | awk \'{print $2}\'').read()
    assert "1/1" in str(openldap_verify)
    crone_name = os.popen('kubectl get all -n identity | grep cronjob.batch/lscsync | awk \'{print $1}\'').read()
    assert "cronjob.batch/lscsync" in str(crone_name)
    crone_schedule = os.popen(
        'kubectl get all -n identity | grep cronjob.batch/lscsync | awk \'{ print $2 }\' # */20').read()
    assert "*/20" in str(crone_schedule)
    crone_schedule = os.popen(
        'kubectl get all -n identity | grep cronjob.batch/lscsync | awk \'{ print $2 }\' # */20').read()
    assert "*/20" in str(crone_schedule)


# Generic function to parse user details from user.xslx
def read_users(level):
    workbook = load_workbook("users.xlsx")
    sheet = workbook.active
    if level == "Level_1":
        username = sheet.cell(row=2, column=2)
        password = sheet.cell(row=2, column=3)
        key = sheet.cell(row=2, column=4)
        return username.value, password.value, key.value
    elif level == "Level_2":
        username = sheet.cell(row=3, column=2)
        password = sheet.cell(row=3, column=3)
        key = sheet.cell(row=3, column=4)
        return username.value, password.value, key.value
    elif level == "Level_3":
        username = sheet.cell(row=4, column=2)
        password = sheet.cell(row=4, column=3)
        key = sheet.cell(row=4, column=4)
        return username.value, password.value, key.value
    elif level == "Level_4":
        username = sheet.cell(row=5, column=2)
        password = sheet.cell(row=5, column=3)
        key = sheet.cell(row=5, column=4)
        return username.value, password.value, key.value
    else:
        print("Invalid Level")


# Generic SSH function to check SSH access to haproxy node using ldap user's private key file
def sshfunction(username, keyfile):
    api_url = "api.cf." + domain
    k = paramiko.RSAKey.from_private_key_file(f"{keyfile}")
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    print("connecting")

    c.connect(hostname=f"{api_url}", username=f"{username}", pkey=k)
    print("connected")
    commands = ["hostname", "w"]
    for command in commands:
        print("Executing {}".format(command))
        stdin, stdout, stderr = c.exec_command(command)
        print(stdout.read())
        stderr.read()
    c.close()


# Generic function to set up kubecfg for any level of user. This function returns user's token.
def setkubeconfig(username, password):

    vault_secret = os.popen('curl --location --request POST \''+login_vault_addr+'/v1/auth'
                            '/approle/login\' --header \'Content-Type: text/plain\' --data-raw \'{  "role_id": '
                            '"'+role_id+'",  "secret_id": '
                            '"'+secret_id+'"}\' | jq -r .auth.client_token').read()
    client_secret = os.popen('curl --location --request GET \''+login_vault_addr+'/v1/'+secret_path+'/k8s.'+domain+'/services\' --header \'X-Vault-Token: '+str(vault_secret)+'\' | jq -r .data.keycloak_client_password | base64 --decode').read()

    os.popen('rm ~/.kube/config').read()

    os.popen('kubectl config set-credentials ' + username + ' \
    --exec-api-version=client.authentication.k8s.io/v1beta1 \
    --exec-command=kubectl \
    --exec-arg=oidc-login \
    --exec-arg=get-token \
    --exec-arg=--oidc-issuer-url=https://identity.cf.' + domain + '/auth/realms/hsop \
    --exec-arg=--oidc-client-id=kubernetes \
    --exec-arg=--oidc-client-secret=' + client_secret + '').read()

    os.popen('kubectl config set-cluster k8s.' + domain + ' \
    --server=https://api.k8s.' + domain + ':6443 \
    --insecure-skip-tls-verify=true').read()

    os.popen('kubectl config set-context k8s.' + domain + ' \
    --user=' + username + ' \
    --cluster=k8s.' + domain + '').read()

    os.popen('kubectl config use-context k8s.' + domain + '').read()

    user_token = os.popen('curl -s -X POST \
      --data-urlencode "client_id=kubernetes" \
      --data-urlencode "client_secret=' + client_secret + '" \
      --data-urlencode "username=' + username + '" \
      --data-urlencode "password=' + password + '" \
      --data-urlencode "grant_type=password" \
      --data-urlencode "scope=openid" \
      https://identity.cf.' + domain + '/auth/realms/hsop/protocol/openid-connect/token | jq -r .id_token ').read()

    return user_token


# Level 1 Users access check - covering all layers.
@pytest.mark.ldap
def test_level1_user_access():
    username, password, keyfile = read_users("Level_1")

    print("-------------------CF access Level 1 user-------------------")
    login_output = os.popen(
        'cf login -a api.cf.' + domain + ' -u ' + username + ' -p ' + password + ' -o hsop -s brokers').read()
    print(str(login_output))
    assert "No org or space targeted" in str(login_output)
    check_a = os.popen('cf a').read()
    assert "No org" in str(check_a)
    p = Popen("cf create-org random3", shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = p.communicate()
    assert "You are not authorized to perform the requested action" in str(stderr)
    p = Popen("cf create-space random3 -o hsop", shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = p.communicate()
    assert "not found" in str(stderr)
    p = Popen("cf push tests/mymodule/manifest.yml", shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = p.communicate()
    assert "No org targeted" in str(stderr)

    print("-------------------Grafana Access Level 1 user-------------------")
    output = os.popen('curl https://' + username + ':' + password + '@metrics.cf.' + domain + '/api/org').read()
    assert "Main Org." in str(output)

    print("-------------------SSH access - Level 1 User-------------------")
    sshfunction(username, keyfile)  # Calling generic SSH function

    print("-------------------k8s access - Level 1 User-------------------")
    user_token = setkubeconfig(username, password)  # Set kubecfg function. Returns token - used for kubectl queries.

    out = Popen('kubectl get nodes --token=' + user_token + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "nodes is forbidden: User" in str(stderr)
    print("Nodes are not listed")

    out = Popen('kubectl get pods --token=' + user_token + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "pods is forbidden: User" in str(stderr)
    print("pods are not listed")

    out = Popen('kubectl get secrets --token=' + user_token + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "secrets is forbidden: User" in str(stderr)
    print("secrets are not listed")

    out = Popen('kubectl create ns level1_user_ns --token=' + user_token + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "namespaces is forbidden: User" in str(stderr)
    print("No namespace access")

    os.popen('rm ~/.kube/config').read()


@pytest.mark.ldap
def test_level2_user_access():

    username, password, keyfile = read_users("Level_2")
    login_output = os.popen(
        'cf login -a api.cf.' + domain + ' -u ' + username + ' -p ' + password + ' -o hsop -s brokers').read()
    print(str(login_output))
    assert "OK" in str(login_output)
    check_a = os.popen('cf a | grep hsdp-rabbitmq | awk \'{print $3}\'').read()
    assert "1" in str(check_a)

    # create_org = os.popen('cf create-org random5').read()
    # assert "You are not authorized to perform the requested action" in str(create_org)

    # create_space = os.popen('cf create-space random5').read()
    # assert "You are not authorized to perform the requested action" in str(create_space)

    # create_space = os.popen('cf create-user rand 12345readser').read()
    # assert "You are not authorized to perform the requested action" in str(create_space)
    #
    # cf_push = os.popen('cf push tests/mymodule/manifest.yml').read()
    # assert "You are not authorized to perform the requested action" in str(cf_push)

    print("-------------------Grafana Access Level 2 user-------------------")
    output = os.popen('curl https://' + username + ':' + password + '@metrics.cf.' + domain + '/api/org').read()
    assert "Main Org." in str(output)
    print("User is able to login to Grafana")

    print("-------------------SSH access - Level 2 User-------------------")
    sshfunction(username, keyfile)

    print("-------------------k8s access - Level 2 User-------------------")
    user_token = setkubeconfig(username, password)
    out = Popen('kubectl get nodes --token=' + user_token + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "nodes is forbidden: User" in str(stderr)
    print("Nodes are not listed")

    ns = os.popen('kubectl get ns --token=' + user_token).read()
    assert "certificates" in str(ns)
    print("Pods are listed")

    os.popen('rm ~/.kube/config').read()


@pytest.mark.ldap
def test_level3_user_access():

    username, password, keyfile = read_users("Level_3")
    uname = ''.join(random.choices(string.ascii_uppercase +
                                   string.digits, k=6))
    pwd = ''.join(random.choices(string.ascii_uppercase + string.ascii_lowercase, k=5))
    org = ''.join(random.choices(string.ascii_uppercase +
                                 string.digits, k=6))
    space = ''.join(random.choices(string.ascii_uppercase +
                                   string.digits, k=6))

    print("-------------------CF Access Level 3 user-------------------")
    login_output = os.popen(
        'cf login -a api.cf.' + domain + ' -u ' + username + ' -p ' + password + ' -o hsop -s brokers').read()
    assert "OK" in str(login_output)

    check_a = os.popen('cf a | grep hsdp-rabbitmq | awk \'{print $3}\'').read()
    assert "1" in str(check_a)

    out = Popen('cf create-org ' + org + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "Assigning role OrgManager to user" in str(stdout)
    print("Created ORG", org)

    out = Popen('cf create-space ' + space + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "Assigning role SpaceDeveloper to user" in str(stdout)
    print("Created Space", space)

    out = Popen('cf create-user ' + uname + ' ' + pwd + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "OK" in str(stdout)
    print("Created User", uname + " With Password ", pwd)

    out = Popen('cf delete-user ' + uname + ' -f ', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "OK" in str(stdout)
    print("Deleted User", uname)

    out = Popen('cf delete-space ' + space + ' -f ', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "OK" in str(stdout)
    print("Deleted Space", uname)

    out = Popen('cf delete-org ' + org + ' -f ', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "OK" in str(stdout)
    print("Deleted Space", uname)

    print("-------------------Grafana Access Level 3 user-------------------")
    output = os.popen(
        'curl https://' + username + ':' + password + '@metrics.cf.' + domain + '/api/org | jq -r .name').read()
    assert "Main Org." in str(output)

    print("-------------------SSH access - Level 3 User-------------------")
    sshfunction(username, keyfile)

    print("-------------------k8s access - Level 3 User-------------------")

    user_token = setkubeconfig(username, password)

    out = Popen('kubectl get nodes --token=' + user_token + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "internal" in str(stdout)
    print("Nodes are listed")

    ns = os.popen('kubectl get ns --token=' + user_token).read()
    assert "certificates" in str(ns)
    print("Pods are listed")

    ns = os.popen('kubectl create ns testauto --token=' + user_token).read()
    assert "namespace/testauto created" in str(ns)
    print("Namespace created")

    ns = os.popen('kubectl delete ns testauto --token=' + user_token).read()
    assert "deleted" in str(ns)
    print("Namespace Deleted")

    os.popen('rm ~/.kube/config').read()


@pytest.mark.ldap
def test_level4_user_access():

    username, password, keyfile = read_users("Level_4")

    print("-------------------CF Access Level 4 user-------------------")
    login_output = os.popen(
        'cf login -a api.cf.' + domain + ' -u ' + username + ' -p ' + password + ' -o hsop -s brokers').read()
    assert "OK" in str(login_output)

    check_a = os.popen('cf a | grep hsdp-rabbitmq | awk \'{print $3}\'').read()
    assert "1" in str(check_a)

    create_org = os.popen('cf create-org random6').read()
    assert "FAILED" in str(create_org)

    out = Popen('cf create-org level4user_org', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "You are not authorized to perform the requested action" in str(stderr)

    # out = Popen('cf create-space level4user_org', shell=True, stdout=PIPE, stderr=PIPE)
    # stdout, stderr = out.communicate()
    # assert "You are not authorized to perform the requested action" in str(stderr)

    out = Popen('cf push tests/mymodule/manifest.yml', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "You are not authorized to perform the requested action" in str(stderr)

    print("-------------------Grafana Access Level 4 user-------------------")
    output = os.popen(
        'curl https://' + username + ':' + password + '@metrics.cf.' + domain + '/api/org | jq -r .name').read()
    assert "Main Org." in str(output)
    print("-------------------SSH access - Level 4 User-------------------")
    sshfunction(username, keyfile)
    print("-------------------k8s access - Level 4 User-------------------")
    user_token = setkubeconfig(username, password)

    out = Popen('kubectl get nodes --token=' + user_token + '', shell=True, stdout=PIPE, stderr=PIPE)
    stdout, stderr = out.communicate()
    assert "nodes is forbidden: User" in str(stderr)
    print("Nodes are not listed")

    ns = os.popen('kubectl get ns --token=' + user_token).read()
    assert "certificates" in str(ns)
    print("Pods are listed")

    os.popen('rm ~/.kube/config').read()
