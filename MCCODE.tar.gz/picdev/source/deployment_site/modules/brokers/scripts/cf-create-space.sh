#!/bin/bash

while getopts d:u:p:o:n: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        d) domain=${OPTARG};;
        u) username=${OPTARG};;
        p) password=${OPTARG};;
        o) organization=${OPTARG};;
        n) name=${OPTARG};;
    esac
done

cf login -a api."$domain" -u "$username" -p "$password" -o "$organization" --skip-ssl-validation
# shellcheck disable=SC2256
status=$(cf spaces | grep $"name" | wc -l)
if [ $? -eq 0 ]
then cf create-space "$name"
else echo "Space $name already exists"
fi