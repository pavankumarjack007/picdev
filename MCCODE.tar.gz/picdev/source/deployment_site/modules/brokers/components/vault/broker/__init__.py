import os
from cf_broker_api import ServiceBroker
from jinja2 import FileSystemLoader

from config import config_map
from .exceptions import vault_exc_mapping
from .service import VaultService


def create_broker(
    config_name=None, catalog=None, service_class=None, exc_mapper=None, parsers=None
):

    _config_name = config_name or os.getenv("BROKER_CONFIG", "default")
    _config = config_map[_config_name]
    _catalog = catalog or "catalog.yml"
    _service = service_class or VaultService(config=_config)
    _parsers = parsers or _service.get_param_parsers()
    _exc_mapper = exc_mapper or vault_exc_mapping

    broker = ServiceBroker(
        service_catalog=_catalog,
        custom_parsers=_parsers,
        service_class=_service,
        exc_mapper=_exc_mapper,
        config=_config,
    )

    path = os.path.dirname(os.path.realpath(__file__))
    template_dir = os.path.join(path, "templates")
    broker.jinja_loader = FileSystemLoader(template_dir)
    broker.global_config = _config

    return broker
