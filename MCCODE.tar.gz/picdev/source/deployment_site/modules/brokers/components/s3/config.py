import logging
import uuid
from os import getenv


class Config(object):
    DEBUG = False
    TESTING = False

    AWS_ACCESS_KEY_ID = getenv("AWS_ACCESS_KEY_ID", "")
    AWS_DEFAULT_REGION = getenv("AWS_DEFAULT_REGION", "")
    AWS_SECRET_ACCESS_KEY = getenv("AWS_SECRET_ACCESS_KEY", "")
    AWS_S3_HOST = getenv("AWS_S3_HOST")

    ADDTL_AWS_ACCESS_KEY_IDS = getenv("ADDTL_AWS_ACCESS_KEY_IDS", "")
    ADDTL_AWS_SECRET_ACCESS_KEYS = getenv("ADDTL_AWS_SECRET_ACCESS_KEYS", "")

    BROKER_API_KEY = getenv("BROKER_API_KEY", "<api_key>")
    BROKER_IS_ASYNC = True
    BROKER_USE_SSL = getenv("BROKER_USE_SSL", "false") != "false"
    BROKER_USERNAME = getenv("BROKER_USERNAME", "")
    BROKER_PASSWORD = getenv("BROKER_PASSWORD", "")
    BROKER_ENVIRONMENT = getenv("BROKER_ENVIRONMENT", "cloud")

    BUCKET_GRANTED_SERVICES_ALLOWLIST = ["emr"]

    CF_API_ENDPOINT = getenv("CF_API_ENDPOINT", "<cf-api-endpoint>")

    HSDP_REGION = getenv("HSDP_REGION", "us-east-1")
    CONSOLE_URL = getenv(
        "CONSOLE_URL", "https://console.{}.hsdp.io".format(HSDP_REGION)
    )

    DYNAMODB_TABLE = getenv("DYNAMODB_TABLE", "hsdp_s3_service_broker_dev")
    DYNAMODB_HOST = getenv("DYNAMODB_HOST")

    ENCRYPTION_KEY = getenv("ENCRYPTION_KEY")

    GRAPHQL_SKIP_AUTH = False

    INSTANCE_PREFIX = getenv("INSTANCE_PREFIX", "cf-s3")

    LOGGING_BLACKLIST = getenv("LOGGING_BLACKLIST", "")
    LOGGING_LEVEL = getenv("LOGGING_LEVEL", logging.getLevelName(logging.DEBUG))
    LOGGING_MSG_FORMAT = getenv(
        "LOGGING_MSG_FORMAT", "%(asctime)s:%(levelname)s:%(name)s:%(message)s"
    )

    MAX_DOWNLOAD_SIZE = int(getenv("MAX_DOWNLOAD_SIZE", 100 * 1024 * 1024))

    PORT = int(getenv("PORT", "8080"))

    SECRET_KEY = getenv("SECRET_KEY", "")

    UAA_OAUTH_CLIENT_ID = getenv("UAA_OAUTH_CLIENT_ID", "<client-id>")
    UAA_OAUTH_CLIENT_SECRET = getenv("UAA_OAUTH_CLIENT_SECRET", "<client-secret>")

    WORKER_INTERVAL = int(getenv("WORKER_INTERVAL", 60))
    OBJECT_DELETION_THRESHOLD = int(getenv("OBJECT_DELETION_THRESHOLD", 10000))

    DOCKER_USERNAME = getenv('DOCKER_USERNAME', '')
    CF_DOCKER_PASSWORD = getenv('CF_DOCKER_PASSWORD', '')
    DOCKER_REGISTRY = getenv('DOCKER_REGISTRY','')    

    S3_DOCKER_IMAGE = getenv('S3_DOCKER_IMAGE','')
    S3_WORKER_DOCKER_IMAGE = getenv('S3_WORKER_DOCKER_IMAGE','')

    @property
    def aws_config(self):
        return {
            "aws_access_key_id": self.AWS_ACCESS_KEY_ID,
            "aws_secret_access_key": self.AWS_SECRET_ACCESS_KEY,
            "endpoint_url": self.AWS_S3_HOST,
            "region_name": self.AWS_DEFAULT_REGION,
        }

    @property
    def addtl_aws_credentials(self):
        accounts = []
        api_keys = (
            self.ADDTL_AWS_ACCESS_KEY_IDS.split(",")
            if self.ADDTL_AWS_ACCESS_KEY_IDS
            else []
        )
        api_secrets = (
            self.ADDTL_AWS_SECRET_ACCESS_KEYS.split(",")
            if self.ADDTL_AWS_SECRET_ACCESS_KEYS
            else []
        )
        for i, key in enumerate(api_keys):
            accounts.append(
                {"aws_access_key_id": key, "aws_secret_access_key": api_secrets[i]}
            )
        return accounts

    @property
    def cc_config(self):
        return {
            "base_url": self.CF_API_ENDPOINT,
            "client_id": self.UAA_OAUTH_CLIENT_ID,
            "client_secret": self.UAA_OAUTH_CLIENT_SECRET,
        }

    @property
    def logging_config(self):
        return {
            "level": self.LOGGING_LEVEL,
            "log_format": self.LOGGING_MSG_FORMAT,
            "blacklist": self.LOGGING_BLACKLIST.split(",")
            if self.LOGGING_BLACKLIST
            else [],
        }

    @property
    def is_china_region(self):
        return self.AWS_DEFAULT_REGION[:2] == "cn"


class DevelopmentConfig(Config):
    DEBUG = True
    BROKER_USE_SSL = False

    INSTANCE_PREFIX = "test-cf-s3"


class ProductionConfig(Config):
    DEBUG = False
    DYNAMODB_TABLE = getenv("DYNAMODB_TABLE", "hsdp_s3_service_broker")
    BROKER_USE_SSL = True

    LOGGING_LEVEL = getenv("LOGGING_LEVEL", logging.getLevelName(logging.INFO))


class TestingConfig(Config):
    DEBUG = False
    TESTING = True

    BROKER_USE_SSL = False

    BROKER_USERNAME = ""
    BROKER_PASSWORD = ""

    # Table name uuid allows concurrent test runs.
    # Env var override is helpful when cleaning up aborted test runs.
    TEST_RUN_GUID = getenv("TEST_RUN_GUID", str(uuid.uuid4()))
    DYNAMODB_TABLE = "hsdp_s3_service_broker_test-{}".format(TEST_RUN_GUID)

    GRAPHQL_SKIP_AUTH = True

    INSTANCE_PREFIX = "test-cf-s3"

    CF_API_ENDPOINT = "http://api.cf.example.com"

    WORKER_INTERVAL = 1

    OBJECT_DELETION_THRESHOLD = 1


class CloudFoundryConfig(ProductionConfig):
    # Don't need timestamp. It's provided by Cloud Foundry.
    LOGGING_MSG_FORMAT = getenv(
        "LOGGING_MSG_FORMAT", "%(levelname)s:%(name)s:%(message)s"
    )


class DeploymentConfig(CloudFoundryConfig):
    CF_APP_NAME = getenv("CF_APP_NAME", "test-hsdp-s3")

    CF_WORKER_NAME = "{}-worker".format(CF_APP_NAME)

    BGD_CF_APP_NAME = "{}-new".format(CF_APP_NAME)

    CF_BUILDPACK = getenv("CF_BUILDPACK", "python_buildpack")

    CF_STAGING_TIMEOUT = int(getenv("CF_STAGING_TIMEOUT", 15))

    CF_URL = getenv("CF_URL", "<cf-url>")
    CF_ORG = getenv("CF_ORG", "<cf-org>")
    CF_SPACE = getenv("CF_SPACE", "<cf-space>")
    CF_USER = getenv("CF_USER", "<cf-user>")
    CF_PASSWORD = getenv("CF_PASSWORD", "<cf-password>")

    DEPLOY_WITH_SMOKETESTS = getenv("DEPLOY_WITH_SMOKETESTS", "true")

    SMOKETEST_SERVICE_ID = getenv(
        "SMOKETEST_SERVICE_ID", "da215457-67ce-4916-b0ab-47420161d654"
    )
    SMOKETEST_PLAN_ID = getenv(
        "SMOKETEST_PLAN_ID", "aeffc520-35d6-48e7-a9b0-b3239d02009b"
    )

    BROKER_CONFIG = getenv("BROKER_CONFIG", "cloudfoundry")


config_map = {
    "development": DevelopmentConfig(),
    "testing": TestingConfig(),
    "integration": TestingConfig(),
    "production": ProductionConfig(),
    "cloudfoundry": CloudFoundryConfig(),
    "deployment": DeploymentConfig(),
    "default": DevelopmentConfig(),
}
