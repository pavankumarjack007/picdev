Changelog
=========

v16 (2018-09-04)
----------------

Maintenance release.  No application features added or changed.  One defect fixed.

- Fixed object download regression. (`CFSB-218`_)
- Removed uWSGI threads argument. (`CFSB-217`_)
- Improved logging. (`CFSB-223`_)
- Improved audit script. (`CFSB-213`_)
- Improved smoke tests. (`CFSB-224`_)
- Improved deployment. (`CFSB-225`_)
- Updated dependencies. (`CFSB-215`_, `CFSB-221`_)
- Cleaned up various aspects of the codebase. (`CFSB-222`_, `CFSB-226`_)
- Removed obsolete code. (`CFSB-178`_)

.. _CFSB-178: https://healthsuite.atlassian.net/browse/CFSB-178
.. _CFSB-213: https://healthsuite.atlassian.net/browse/CFSB-213
.. _CFSB-215: https://healthsuite.atlassian.net/browse/CFSB-215
.. _CFSB-217: https://healthsuite.atlassian.net/browse/CFSB-217
.. _CFSB-218: https://healthsuite.atlassian.net/browse/CFSB-218
.. _CFSB-221: https://healthsuite.atlassian.net/browse/CFSB-221
.. _CFSB-222: https://healthsuite.atlassian.net/browse/CFSB-222
.. _CFSB-223: https://healthsuite.atlassian.net/browse/CFSB-223
.. _CFSB-224: https://healthsuite.atlassian.net/browse/CFSB-224
.. _CFSB-225: https://healthsuite.atlassian.net/browse/CFSB-225
.. _CFSB-226: https://healthsuite.atlassian.net/browse/CFSB-226

v15 (2018-06-14)
----------------

- Added UAA Client Credentials support for Graphql endpoint. (`CFSB-147`_)
- Fixed audit script. (`CFSB-19`_)

.. _CFSB-147: https://healthsuite.atlassian.net/browse/CFSB-147
.. _CFSB-19: https://healthsuite.atlassian.net/browse/CFSB-19

v14 (2018-04-17)
----------------

- Removed Service Dashboard and Added support for new unified Console. (`CFSB-98`_)

.. _CFSB-98: https://healthsuite.atlassian.net/browse/CFSB-98

v13 (2018-03-22)
----------------

- Removed Service Dashboard and Added support for new unified Console. (`CFSB-78`_)
- Updated documentation. (`CFSB-55`_, `CFSB-59`_)

.. _CFSB-55: https://healthsuite.atlassian.net/browse/CFSB-55
.. _CFSB-59: https://healthsuite.atlassian.net/browse/CFSB-59
.. _CFSB-78: https://healthsuite.atlassian.net/browse/CFSB-78

v12 (2018-01-26)
----------------

- Added ability to rotate API keys. (`CFSB-13`_)
- Added needed changes for China region. (`CFSB-48`_)
- Added integration test to verify STS access. (`CFSB-24`_)
- Added integration test to verify broker IAM policy. (`CFSB-39`_)
- Fixed issue with UAA authentication. (`CFSB-31`_)
- Fixed object count on Service Dashboard. (`CFSB-11`_)
- Fixed issue with newer versions of ``boto3`` library. (`CFSB-15`_)
- Fixed issue with AWS partitions in the bucket policy. (`CFSB-49`_)

.. _CFSB-11: https://healthsuite.atlassian.net/browse/CFSB-11
.. _CFSB-13: https://healthsuite.atlassian.net/browse/CFSB-13
.. _CFSB-15: https://healthsuite.atlassian.net/browse/CFSB-15
.. _CFSB-24: https://healthsuite.atlassian.net/browse/CFSB-24
.. _CFSB-31: https://healthsuite.atlassian.net/browse/CFSB-31
.. _CFSB-39: https://healthsuite.atlassian.net/browse/CFSB-39
.. _CFSB-48: https://healthsuite.atlassian.net/browse/CFSB-48
.. _CFSB-49: https://healthsuite.atlassian.net/browse/CFSB-49

v11 (2017-10-18)
----------------

- Added AWS multi-account support to work around Amazon S3 bucket count limits.
- Refactored to use ``pynamodb`` package for dynamodb operations.
- Refactored to use ``cf-broker-api`` package.
- Added test suite.

v10 (2017-08-24)
----------------

- Added ability to enforce secure bucket communications.

v9 (2017-07-31)
---------------

- Added s3:RestoreObject permissions to bucket user accounts.


v8 (2017-07-19)
---------------

- Fixed Service Dashboard CSS issues for users with large numbers of buckets.

v7 (2017-07-03)
---------------

- Added Service Dashboard.

v6 (2017-05-18)
---------------

- Added mulitpart upload permissions to bucket user accounts.

v5 (2017-05-10)
---------------

- Changed bucket user policies to inline vs managed.

v4 (2016-12-16)
---------------

- Added ability to bucket CORS configuration.

v3 (2016-11-01)
---------------

- Added ability to enforce server-side encryption on buckets.

v2 (2016-10-20)
---------------

- Added ability to update bucket lifecycle configuration.

v1 (2015-10-20)
---------------

- Initial release.