import graphene


class Log(graphene.ObjectType):
    size = graphene.String()
    last_written = graphene.String()
    log_file_name = graphene.String()
