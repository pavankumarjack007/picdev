#!/bin/bash
echo "----------------Build----------------"
scp -i /home/MC_Jenkins/locals/cicd-key.pem -o StrictHostKeyChecking=no ${WORKSPACE}/MicroCloud.tar.gz ubuntu@63.122.160.170:/home/ubuntu/workspace/
ssh -i /home/MC_Jenkins/locals/cicd-key.pem -o StrictHostKeyChecking=no ubuntu@3.122.160.170 << EOF
cd /home/ubuntu/workspace/
docker system prune -a -f
sudo rm -rf MicroCloud && mkdir -p MicroCloud && tar -zxf MicroCloud.tar.gz -C MicroCloud/
source /home/ubuntu/workspace/export_vars.sh
cd /home/ubuntu/workspace/MicroCloud/source/deployment_stable/modules/brokers/scripts/
chmod +x create_images.sh && ./create_images.sh
/home/ubuntu/workspace/imagetest.sh
EOF
