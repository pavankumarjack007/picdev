from broker.worker import create_worker

if __name__ == "__main__":
    create_worker()
