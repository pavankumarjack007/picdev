from Crypto.Cipher import AES


class EncryptWriter:
    BUFF_LENGTH = 1 << 14
    NONCE_LENGTH = 12
    START_FILLER = "00"
    END_FILLER = "80"

    def __init__(self, key, nonce, cipher_text=[]):
        self.key = key
        self.nonce = nonce + bytes.fromhex(EncryptWriter.START_FILLER) * (
            EncryptWriter.NONCE_LENGTH - len(nonce)
        )
        self.cipher_text = cipher_text
        self.sequence = 0
        _, initial_tag = self._encrypt(data=bytearray())
        self.start_block_associated_data = (
            bytes.fromhex(EncryptWriter.START_FILLER) + initial_tag
        )
        self.end_block_associated_data = (
            bytes.fromhex(EncryptWriter.END_FILLER) + initial_tag
        )

    def write(self, data):
        if len(data) <= EncryptWriter.BUFF_LENGTH:
            self._close(data)
            return
        encrypted_data, digest = self._encrypt(
            data[0 : EncryptWriter.BUFF_LENGTH], self.start_block_associated_data
        )
        self.cipher_text.append(encrypted_data)
        self.cipher_text.append(digest)
        data = data[EncryptWriter.BUFF_LENGTH :]
        while len(data) > EncryptWriter.BUFF_LENGTH:
            encrypted_data, digest = self._encrypt(
                data[0 : EncryptWriter.BUFF_LENGTH], self.start_block_associated_data
            )
            self.cipher_text.append(encrypted_data)
            self.cipher_text.append(digest)
            data = data[EncryptWriter.BUFF_LENGTH :]
        self._close(data)

    def _encrypt(self, data=None, associated_data=None):
        nonce = self._next_nonce()
        enc = AES.new(self.key, AES.MODE_GCM, nonce)
        if associated_data is not None:
            enc.update(associated_data)
        if data is not None:
            return enc.encrypt_and_digest(data)

    def _close(self, data):
        encrypted_data, digest = self._encrypt(data, self.end_block_associated_data)
        self.cipher_text.append(encrypted_data)
        self.cipher_text.append(digest)

    def _next_nonce(self):
        nonce = bytearray(self.nonce[:])
        nonce[8] = self.sequence
        nonce[9] = self.sequence >> 8
        nonce[10] = self.sequence >> 16
        nonce[11] = self.sequence >> 24
        self.sequence = self.sequence + 1
        return nonce


class DecryptReader(EncryptWriter):
    MAC_LEN = 16

    def __init__(self, key, salt, nonce):
        super(DecryptReader, self).__init__(key, nonce)
        self.salt = salt
        self.sequence = 1

    def read(self, cipher_text):
        plain_text = []
        while (len(cipher_text)) > EncryptWriter.BUFF_LENGTH:
            data = cipher_text[0 : EncryptWriter.BUFF_LENGTH]
            digest = data[len(data) - DecryptReader.MAC_LEN :]
            data = data[0 : len(data) - DecryptReader.MAC_LEN]
            plain_text.append(
                self._decrypt(data, digest, self.start_block_associated_data)
            )
            cipher_text = cipher_text[EncryptWriter.BUFF_LENGTH :]
        digest = cipher_text[len(cipher_text) - DecryptReader.MAC_LEN :]
        cipher_text = cipher_text[0 : len(cipher_text) - DecryptReader.MAC_LEN]
        plain_text.append(
            self._decrypt(cipher_text, digest, self.end_block_associated_data)
        )
        return b"".join(plain_text)

    def _decrypt(self, data=None, digest=None, associated_data=None):
        nonce = self._next_nonce()
        enc = AES.new(self.key, AES.MODE_GCM, nonce)
        enc.update(associated_data)
        return enc.decrypt_and_verify(data, digest)
