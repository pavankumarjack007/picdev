#! /bin/bash
#TODO pass in the org and space from the invoking app
cf target -o $1 -s $2
cf push