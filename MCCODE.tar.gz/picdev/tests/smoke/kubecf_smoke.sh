#!/bin/bash
echo "-------------------------------------------------------------------------------------"
kubectl get qjob --namespace kubecf --output name 2> /dev/null | grep smoke-tests #Get smoke test Job
kubectl patch quarksjob.quarks.cloudfoundry.org/smoke-tests --namespace kubecf --type merge --patch '{ "spec": { "trigger": { "strategy": "now" } } }' #patch
echo 'Smoke test is running'
sleep 20 #wait pod to start
pods=$(kubectl get pods -n kubecf -o=jsonpath='{range .items..metadata}{.name}{"\n"}{end}' | grep smoke) #get pod names
pod_name=$(echo $pods | cut -d' ' -f1)
now=$(date +'%Y-%m-%d-%H-%M-%S')
function check_pod_state() {
        status=NA
        while [[ $status != *"Completed"* ]]; do
        status=$(kubectl get pods $pod_name -n kubecf)
          echo "Waiting for test to complete"
          sleep 30
          total_time=$(($total_time+30))
          if (($total_time > 600)); then
                echo 'Test did not complete in required time'
                return 1
          fi
        done
}
check_pod_state
kubectl logs -f $pod_name --namespace kubecf --container smoke-tests-smoke-tests >> kubecf_smoke_result-${now}.txt  #export logs into result file
kubectl delete pod $pod_name --namespace kubecf #delete the pod
echo "-------------------------------------------------------------------------------------"
