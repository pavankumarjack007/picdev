error_exit(){
	if [ $? -eq 0 ];then
		echo "--------------------------------$1 is success--------------------------------"
	else
		echo "--------------------------------$1 is failed---------------------------------"
		exit 1
	fi
}

remote_build(){
	${WORKSPACE}/CICD/remote_build.sh
	error_exit "Docker image build"
}

if [[ $BUILD_TYPE =~ ^(GATED|DAY|NIGHTLY|RELEASE|UPDATE) ]]; then
	remote_build
else
	echo "Skipping remote build"
fi  
