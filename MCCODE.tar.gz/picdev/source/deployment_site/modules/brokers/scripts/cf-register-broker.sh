#!/bin/bash

while getopts d:u:p:o:s:b:m:n:r: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        d) domain=${OPTARG};;
        u) username=${OPTARG};;
        p) password=${OPTARG};;
        o) organization=${OPTARG};;
        s) space=${OPTARG};;
        b) broker=${OPTARG};;
        m) uname=${OPTARG};;
        n) passd=${OPTARG};;
        r) svc=${OPTARG};;
    esac
done

cf login -a api."$domain" -u "$username" -p "$password" -o "$organization" -s "$space" --skip-ssl-validation
if [[ $? -eq 0 ]];
then
  found=$(cf service-brokers | grep -c "$broker")
  
  #old credentials may not be valide now
  if [[ $found ]];
  then 
    cf delete-service-broker "$broker" -f
  fi

  if [[ "$TF_VAR_cf_for_k8s" == "true" ]]
  then
    cf create-service-broker "$broker" "$uname" "$passd" https://"$svc".apps."$domain"
  else
    cf create-service-broker "$broker" "$uname" "$passd" https://"$svc"."$domain"
  fi
  cf enable-service-access "$broker"
  
 fi
