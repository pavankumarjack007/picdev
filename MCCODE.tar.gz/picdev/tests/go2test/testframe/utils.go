package testframe

import (
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
	"reflect"
	"testing"

	http_helper "github.com/gruntwork-io/terratest/modules/http-helper"
	"github.com/gruntwork-io/terratest/modules/ssh"
	"github.com/gruntwork-io/terratest/modules/terraform"
)

func GetTestDinitions() AllTestCases {

	file, _ := ioutil.ReadFile("testdefinition.json")

	allTestDefs := AllTestCases{}
	_ = json.Unmarshal([]byte(file), &allTestDefs)

	return allTestDefs
}

func GetInputParams(tc Test_Case, t *testing.T) map[string]interface{} {

	var inputVars map[string]interface{} //= tc.Input_params

	if tc.Input_params_file != "" {
		terraform.GetAllVariablesFromVarFile(t, tc.Input_params_file, &inputVars)
	}

	return inputVars
}

func ValidateOutput(output map[string]interface{}, tc Test_Case, t *testing.T) bool {

	var isValid bool = false
	var validations []Validation_Case = tc.Validations
	for i := 0; i < len(validations); i++ {
		if validations[i].Validation_type == TFOut {
			isValid = reflect.DeepEqual(output, validations[i].Output_params)
		} else if validations[i].Validation_type == HTTP {
			isValid = ValidatHttp(validations[i], t)
		} else if validations[i].Validation_type == SSH {
			isValid = ValidatSSH(validations[i], t)
		}
	}
	return isValid
}

func ValidatHttp(vc Validation_Case, t *testing.T) bool {
	var isValid bool = false

	/// only HTTPGet is creating http client from "http.DefaultTransport",
	/// whereas HTTPDo creating new transport --> http_proxy will not passed om in these cases

	//http_helper.HttpGetWithRetry(t, "http://google.com", nil, 200, "Hello, World!", 30, 5*time.Second)

	os.Setenv("https_proxy", "http://185.46.212.98:10015")
	os.Setenv("http_proxy", "http://185.46.212.98:10015")
	//http_helper.ContinuouslyCheckUrl(t, "", true, 20)
	status, resp := http_helper.HttpGet(t, "https://google.com", &tls.Config{InsecureSkipVerify: true})
	if status != 200 {
		fmt.Println(status)
	} else {
		fmt.Println(resp)
	}

	return isValid
}

func ValidatSSH(vc Validation_Case, t *testing.T) bool {
	var isValid bool = false

	os.Setenv("https_proxy", "http://185.46.212.98:10015")
	os.Setenv("http_proxy", "http://185.46.212.98:10015")

	for key, element := range vc.Input_params {

		input_params := element.(map[string]interface{})

		public_host := ssh.Host{
			Hostname:    input_params["PublicHost"].(string),
			CustomPort:  input_params["Port"].(int),
			SshUserName: input_params["Username"].(string),
			SshKeyPair:  &ssh.KeyPair{input_params["PublicKey"].(string), input_params["PrivateKey"].(string)},
		}
		ssh.CheckSshConnection(t, public_host)
		private_host := ssh.Host{
			Hostname:    input_params["PrivateHost"].(string),
			CustomPort:  input_params["Port"].(int),
			SshUserName: input_params["Username"].(string),
			SshKeyPair:  &ssh.KeyPair{input_params["PublicKey"].(string), input_params["PrivateKey"].(string)},
		}
		resp := ssh.CheckPrivateSshConnection(t, public_host, private_host, input_params["Command"].(string))
		isValid = vc.Output_params[key] == resp
	}
	return isValid
}
