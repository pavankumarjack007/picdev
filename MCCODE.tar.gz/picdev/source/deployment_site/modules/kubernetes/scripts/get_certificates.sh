#! /bin/bash

#letsencrypt and cetbot based certs
(
  mkdir -p ../generated/letsencrypt
    docker run -it --rm --name certbot \
    --env AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID \
    --env AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY \
    -v "$PWD/../generated/letsencrypt:/etc/letsencrypt" \
    -v "$PWD/../generated/letsencrypt:/var/lib/letsencrypt" \
    certbot/dns-route53 certonly \
    --dns-route53 \
    -d $cf_domain \
    -d "*.$cf_domain" \
    -d "*.es.$domain_name" \
    -m $certbot_email \
    --agree-tos \
    --non-interactive \
    --preferred-challenges=dns \
    --server https://acme-v02.api.letsencrypt.org/directory
    abort_or_continue $?

#    cp $PWD/letsencrypt/live/$cf_domain/fullchain.pem terraform-helm/.
#    cp $PWD/letsencrypt/live/$cf_domain/privkey.pem terraform-helm/.
)
