from cf_broker_api.testing import create_test_client
from cloud_mockery import mock_cf
from cloud_mockery.v2 import cf_backends
from flask import url_for

from tests import TEST_RESOURCES_FILE, BaseTestCase, test_config, test_data

# Stop nose sniffer from trying to run this as a test...
create_test_client.__test__ = False


class TestAPI(BaseTestCase):

    MOCKS = BaseTestCase.MOCKS + [mock_cf()]

    @classmethod
    def setup_class(cls):
        super(TestAPI, cls).setup_class()
        backend = cf_backends[cls.app.global_config.CF_API_ENDPOINT]
        backend.create_from_resources_file(TEST_RESOURCES_FILE)

    def setUp(self):
        super(TestAPI, self).setUp()
        self.app_context = self.app.app_context()
        self.app_context.push()

    def tearDown(self):
        super(TestAPI, self).tearDown()
        self.app_context.pop()

    def test_object_download(self):
        data = test_data(
            instance_id="215b97be-ec77-4224-9c38-c4f2d86b56c1",
            organization_guid="e4de7294-4e76-44ac-bf40-08b01282f478",
            space_guid="70021a4c-2407-4625-9ed7-a7259bc9e261",
            plan_id="aeffc520-35d6-48e7-a9b0-b3239d02009b",
        )
        self.client.provision(data)
        record = self.model.get(data["instance_id"])
        object_key = "test-object"
        object_data = b"this here be some test data"
        self.s3_client.put_object(
            Bucket=record.bucket, Key=object_key, Body=object_data
        )
        with self.app.test_request_context():
            self.app.preprocess_request()
            url = url_for(
                "api.show_instance_object",
                instance_id=data["instance_id"],
                object_key=object_key,
            )
            resp = self.app.test_client().get(
                url,
                headers={
                    "X-User-Access-Token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
                    ".eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4i"
                    "OnRydWV9.TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HgQ",
                    "X-Api-Key": test_config.BROKER_API_KEY,
                },
            )
            self.assertEqual(resp.data, object_data)
