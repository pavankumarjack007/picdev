#! /bin/bash

#CHECK if minio is up
minio_containers="1/1"
while : ; do
    echo "Checking if all containers for minio pod are ready"
    result=$(kubectl -n minio get po minio-0 | grep minio-0 | awk '{ print $2 }')
    echo "Expecting $minio_containers .. Current $result"
    if [[ "$result" == "$minio_containers" ]]
    then
      break
    fi
    sleep 10
done