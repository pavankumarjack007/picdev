#! /bin/bash
#Script to destroy the entire deployment

while getopts c:p:f: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        c) conf=${OPTARG};;
        p) vars=${OPTARG};;
        f) annihilate=${OPTARG};;
    esac
done

abort(){
  echo $1 && exit 1
}

abort_or_continue() {
  if [[ $1 -ne 0 ]];
  then
    echo "Bailing out ..."
    exit 1
  fi
}

log() {
    timestamp=`date +"%F %T"`
    echo -e "${timestamp} : $@";
}

show_banner(){
  (
    printf "\n"
    toilet -f pagga HealthSuite
    toilet -f pagga OnPremise
    printf "\n"
    toilet -f wideterm --metal MicroCloud $HSOP_VERSION
    printf "\n"
  )
}

login_to_k8s(){
  found=$(aws s3 ls s3://$TF_VAR_bucket_name/kops/ | grep $TF_VAR_cluster_name | wc -l)
  if [[ $found -eq 1 ]];
  then
    (
      scripts="$modules/kubernetes/scripts"
      cd $scripts
      export KOPS_STATE_STORE="s3://${TF_VAR_bucket_name}/kops"
      ## Removed updating permissions to avoid unneccesary git status changes
      #chmod +x proxy_aware_kops_export_kubecfg.sh
      ./proxy_aware_kops_export_kubecfg.sh $TF_VAR_cluster_name >/dev/null
    )
  fi
}

login_to_cf(){
  (
    echo "terraform {" > temp.tf
    echo "  backend \"s3\" {}" >> temp.tf
    echo "}" >> temp.tf
    lockTable="${TF_VAR_environment}.${TF_VAR_domain_name}"
    terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate"  -backend-config="dynamodb_table=$lockTable" >/dev/null
    if [[ $? -eq 0 ]];
    then
      wkspace="cloudfoundry-${TF_VAR_environment}.${TF_VAR_domain_name}"
      found=$(terraform workspace list | grep "${wkspace}" | wc -l)
      if [[ $found -eq 1 ]]
      then
        terraform workspace select "${wkspace}" >/dev/null
        force_unlock $wkspace
        if [[ $? -eq 0 ]];
        then
          domain=$TF_VAR_cf_domain
          cf_api="api.${domain}"
          (
            export VAULT_ADDR=$TF_VAR_login_vault_addr
            token=`curl --request POST --data '{"role_id": "'$login_approle_role_id'","secret_id": "'$login_approle_secret_id'"}' $VAULT_ADDR/v1/auth/approle/login| jq -r '.auth.client_token'`
            vault login token=$token
            cf_user=`vault read -format=json $vault_generic_secret_path/k8s.$TF_VAR_domain_name/cloudfoundry |jq -r '.data.cf_user'`
            cf_pwd=`vault read -format=json $vault_generic_secret_path/k8s.$TF_VAR_domain_name/cloudfoundry |jq -r '.data.cf_password'`
            cf l -a $cf_api -u $cf_user -p $cf_pwd -o system >/dev/null
          )
          rm -rf .terraform
        else
          echo "Failed to select workspace"
          rm temp.tf
          rm -rf .terraform
          exit 1
        fi
      else
        echo "Cloudfoundry has not been initialized."
        rm -rf .terraform
      fi
    else
      echo "Failed to initialize terraform"
      rm temp.tf
      exit 1
    fi
    rm temp.tf
  )
  abort_or_continue $?
}

#if all else fails, brute force destroy the cluster
#the aws cli output format needs to be set to json
brute_force_destroy() {

  haproxy_tag="tf-haproxy-single-k8s.${TF_VAR_domain_name}"
  instance_id=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=${haproxy_tag}" | jq -r '.Reservations[].Instances[].InstanceId')

  echo ${instance_id}

  aws ec2 terminate-instances --instance-ids ${instance_id}

  k8s_cluster="k8s.${TF_VAR_domain_name}"


  kops delete cluster ${k8s_cluster} --yes

  key_pair_prefix=$(echo ${k8s_cluster} | tr '.' '_')
  key_pair="${key_pair_prefix}_key_pair"
  echo ${key_pair}

  aws ec2 delete-key-pair --key-name ${key_pair}

  #delete velero specific IAM policy
  name="velero-policy.${k8s_cluster}"
  query='Policies[?PolicyName==`'
  query2="${query}${name}"
  query3='`].Arn'
  query4="${query2}${query3}"

  policy_arn=$(aws iam list-policies --query "${query4}" | jq -r '.[]')
  aws iam delete-policy --policy-arn ${policy_arn}

  #delete route53 entries for CF and forgerock

  domain_name=${TF_VAR_domain_name}
  hosted_zone_id=$(
  aws route53 list-hosted-zones \
    --output text \
    --query 'HostedZones[?Name==`'$domain_name'.`].Id'
  )

  aws route53 list-resource-record-sets \
  --hosted-zone-id $hosted_zone_id |
  jq -c '.ResourceRecordSets[]' |
  while read -r resourcerecordset; do
    read -r name type <<<$(echo $(jq -r '.Name,.Type' <<<"$resourcerecordset"))
    if [ $type != "NS" -a $type != "SOA" ]; then
      echo "Deleting ${resourcerecordset}"
      aws route53 change-resource-record-sets \
        --hosted-zone-id $hosted_zone_id \
        --change-batch '{"Changes":[{"Action":"DELETE","ResourceRecordSet":
            '"$resourcerecordset"'
          }]}' \
        --output text --query 'ChangeInfo.Id'
    fi
  done
  
}

cleanup(){
  (
    cd $deployment
    find ./* -type d -name .terraform -exec rm -rf {} \; 2>/dev/null
    find ./* -type f -name .terraform.lock.hcl -exec rm -f {} \; 2>/dev/null
  )
}

delete_state_table(){
stateTable=${TF_VAR_environment}.${TF_VAR_domain_name}
table=$(echo $(aws dynamodb list-tables|grep $stateTable))
if [[ -n $table ]]
then 
  lockid=$(aws dynamodb scan --table-name $stateTable | grep -Ewo '[[:xdigit:]]{8}(-[[:xdigit:]]{4}){3}-[[:xdigit:]]{12}')
  if [[ -z $lockid ]] 
  then
    aws dynamodb delete-table --table-name $stateTable >/dev/null
  else 
    echo "State table is not deleted, unreleased locks exist"
   fi
 fi 
}

#Delete /etc/haproxy volume attached to haproxynode
delete_haproxy_volume(){

  echo "running deleting the volume"

  k8s_cluster="k8s.${TF_VAR_domain_name}"
  hatag="etc-haproxy-$k8s_cluster"
  Get_Volume_id=`aws ec2 describe-volumes --filters Name=tag:Name,Values=$hatag --query "Volumes[0].VolumeId" --region ${TF_VAR_aws_region} | sed 's/"//g'`
  aws ec2 delete-volume --volume-id $Get_Volume_id

}

force_unlock(){
stateLockTable=${TF_VAR_environment}.${TF_VAR_domain_name}
if [[ $FORCE_UNLOCK ==  "yes" ]]
then
  cmdd="aws dynamodb get-item --table-name $stateLockTable --key '{\"LockID\": {\"S\": \"$TF_VAR_bucket_name/env:/$1/tfstate\"}}' | grep -Ewo '[[:xdigit:]]{8}(-[[:xdigit:]]{4}){3}-[[:xdigit:]]{12}'"
  lockid=$(eval "$cmdd")
  [[ -z $lockid ]] || terraform force-unlock -force $lockid
fi
}

## Setup paths for modules, configuration & profile
deployment="$(dirname $(dirname $(realpath $0)) )"
modules="$(dirname $(dirname $(realpath $0)) )/modules"
config="$(dirname $(dirname $(realpath $0)) )/configuration/${conf}.txt"
profile="$(dirname $(dirname $(realpath $0)) )/profiles/${vars}.tfvars"
version="$(dirname $(dirname $(realpath $0)) )/version.txt"

export HSOP_VERSION=$(cat $version)

## Setup env vars for terraform
## Removed updating permissions to avoid unneccesary git status changes
#chmod +x ./setup_env_vars.sh
source ./setup_env_vars.sh $profile

show_banner
login_to_k8s
login_to_cf
cleanup

## Setup modules
while IFS=$'\n' read -r line || [[ -n "$line" ]];
  do
    result=$(echo $line)
    if [ -z "$result" ];
    then
      continue
    fi
    (
        printf "\nTeardown module %s ...\n\n" $result
        module="$modules/$result"
        cd $module 
        stateTable="${TF_VAR_environment}.${TF_VAR_domain_name}"
        terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate"  -backend-config="dynamodb_table=$stateTable" >/dev/null
		wkspace="${result}-${TF_VAR_environment}.${TF_VAR_domain_name}"
        found=$(terraform workspace list | grep "${wkspace}" | wc -l)
        if [[ $found -eq 1 ]]
        then
          terraform workspace select $wkspace >/dev/null
        fi
        force_unlock $wkspace
        n=0
        success=0
        until [ "$n" -ge 3 ]
        do
          echo "Destroy attempt ${n}..."
          terraform destroy -auto-approve
          if [[ $? -eq 0 ]];
          then
            success=1
            break
          fi
          n=$((n+1))
          sleep 15
        done
        terraform workspace select default
        if [[ $found -eq 1 ]]
        then
          terraform workspace delete $wkspace >/dev/null
        fi
		
        if [[ $result == "infrastructure" ]]
        then
          delete_haproxy_volume
          delete_state_table
        fi

    )
  done < <(tac $config)

if [ "${annihilate}" == "yes" ];
then
  brute_force_destroy
fi
