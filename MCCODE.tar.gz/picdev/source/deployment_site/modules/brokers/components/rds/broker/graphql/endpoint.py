import graphene


class Endpoint(graphene.ObjectType):
    address = graphene.String()
    port = graphene.Int()
