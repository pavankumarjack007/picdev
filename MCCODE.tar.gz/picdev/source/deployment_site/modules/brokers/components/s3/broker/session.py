import json
from urllib.error import HTTPError

import requests
from requests_auth_aws_sigv4 import AWSSigV4

from broker.crypto_util import encrypt


class MinIOSession:
    MINIO_ADMIN_PREFIX = "/minio/admin/v3"

    def __init__(self, *args, **kwargs):
        self.endpoint_url = kwargs.get("endpoint_url")
        self.access_key_id = kwargs.get("aws_access_key_id")
        self.secret_access_key = kwargs.get("aws_secret_access_key")
        self.auth = AWSSigV4(
            "s3",
            aws_access_key_id=self.access_key_id,
            aws_secret_access_key=self.secret_access_key,
            region="us-east-1",
        )

    def create_user(self, access_key_id, secret_access_key):
        data = {"secretKey": secret_access_key, "status": "enabled"}
        encrypted_data = encrypt(self.secret_access_key, json.dumps(data).encode())
        params = {"accessKey": access_key_id}
        self._execute("PUT", "add-user", body=encrypted_data, params=params)

    def delete_user(self, access_key_id):
        params = {"accessKey": access_key_id}
        self._execute("DELETE", "remove-user", params=params)

    def create_policy(self, name, policy):
        params = {"name": name}
        self._execute("PUT", "add-canned-policy", body=policy.encode(), params=params)

    def delete_policy(self, name):
        params = {"name": name}
        self._execute("DELETE", "remove-canned-policy", params=params)

    def attach_policy_to_user(self, user_name, policy_name):
        params = {
            "policyName": policy_name,
            "userOrGroup": user_name,
            "isGroup": "false",
        }
        self._execute("PUT", "set-user-or-group-policy", params=params)

    def get_user(self, user_name):
        params = {"accessKey": user_name}
        res = self._execute("GET", "user-info", params=params)
        return res.json()

    def get_bucket_usage(self, bucket_name, metrics):
        res = self._execute("GET", "datausageinfo")
        return res.json()["bucketsUsageInfo"][bucket_name][metrics]

    def get_bucket_quota(self, name):
        params = {"bucket": name}
        res = self._execute("GET","get-bucket-quota",body=None,params=params)
        return res.json()

    def set_bucket_quota(self, name, quota_size):
        quota_size = quota_size*1024*1024*1024
        params = {"bucket": name}
        body= {"quota":quota_size,"quotatype":"hard"}
        self._execute("PUT","set-bucket-quota",body=json.dumps(body),params=params)

    def _execute(self, method, uri_path, body=None, params=None):
        try:
            res = requests.request(
                method,
                f"{self.endpoint_url}" f"{MinIOSession.MINIO_ADMIN_PREFIX}/{uri_path}",
                data=body,
                params=params,
                auth=self.auth,
                verify=False,
            )
            res.raise_for_status()
            if res.status_code != 200:
                raise MinIOClientError(
                    f"Execution of API failed with status status={res.status_code}"
                )
            return res
        except HTTPError as http_err:
            raise MinIOClientError(f"HTTP error occurred: {http_err}")
        except Exception as err:
            raise MinIOClientError(f"HTTP error occurred: {err}")


class MinIOClientError(Exception):
    def __init__(self, message):
        super(MinIOClientError, self).__init__(message)
