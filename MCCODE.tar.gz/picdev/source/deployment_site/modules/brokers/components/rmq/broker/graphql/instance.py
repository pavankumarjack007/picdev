import graphene

from .instance_details import InstanceDetails


class LastOperationType(graphene.Enum):
    CREATE = 1
    UPDATE = 2
    DELETE = 3


class LastOperationState(graphene.Enum):
    IN_PROGRESS = 1
    SUCCEEDED = 2
    FAILED = 3


class LastOperation(graphene.ObjectType):
    type = graphene.Field(LastOperationType)
    state = graphene.Field(LastOperationState)
    description = graphene.String()
    updated_at = graphene.String()

    @staticmethod
    def resolve_type(self, _):
        switch = {
            'create': LastOperationType.CREATE,
            'update': LastOperationType.UPDATE,
            'delete': LastOperationType.DELETE
        }

        print(switch.get(self.get('type'), None))

        return switch.get(self.get('type'), None)

    @staticmethod
    def resolve_state(self, _):
        switch = {
            'in progress': LastOperationState.IN_PROGRESS,
            'succeeded': LastOperationState.SUCCEEDED,
            'failed': LastOperationState.FAILED
        }

        return switch.get(self.get('state'), None)

    @staticmethod
    def resolve_description(self, _):
        return self.get('description', None)

    @staticmethod
    def resolve_updated_at(self, _):
        return self.get('updated_at', None)


class Instance(graphene.ObjectType):
    guid = graphene.String()
    organization = graphene.String()
    space = graphene.String()
    name = graphene.String()
    created_dt = graphene.String()
    plan_name = graphene.String()
    last_operation = graphene.Field(LastOperation)
    details = graphene.Field(InstanceDetails)

    @staticmethod
    def resolve_details(instance, info):
        return info.context.instance_details(instance.guid)