import os
from abc import ABC, abstractmethod

import yaml
from jinja2 import Environment, FileSystemLoader


class Deployment(ABC):
    def __init__(self, config, client, service_record):
        self.config = config
        self.client = client
        self.service_record = service_record
        self.template_environment = Environment(
            autoescape=False,
            loader=FileSystemLoader(os.path.dirname(__file__) + "/../template"),
            trim_blocks=False,
        )

    @abstractmethod
    def deploy(self):
        pass

    @abstractmethod
    def delete(self):
        pass

    @property
    def render_context(self):
        namespace = self.service_record.service_namespace
        storage = self.service_record.plan_env["storage"]
        memory_request = self.service_record.plan_env["memory_request"]
        memory_limit = self.service_record.plan_env["memory_limit"]
        cpu_request = self.service_record.plan_env["cpu_request"]
        cpu_limit = self.service_record.plan_env["cpu_limit"]
        storage_class = self.config.STORAGE_CLASS
        heapsize = self.service_record.plan_env["heap_size"]
        return {
            "namespace": namespace,
            "instance_id": self.service_record.instance_id,
            "elasticsearch_name": f"es-{self.service_record.instance_id}",
            "storage_class": storage_class,
            "storage": storage,
            "memory_request": memory_request,
            "cpu_request": cpu_request,
            "memory_limit": memory_limit,
            "cpu_limit": cpu_limit,
            "monitoring_tag": self.config.MONITORING_TAG,
            "count": self.service_record.node_count,
            "version": self.service_record.version,
            "apm_server_count": self.service_record.apm_server_count,
            "heapsize": heapsize,
            "es_host": self.service_record.credentials.hostname,
            "elastic_user": "elastic",
            "domain_name": f"*.{namespace}.svc.cluster.local",
            "DOCKER_REGISTRY": self.config.DOCKER_REGISTRY,
            "reg_cred": self.config.REG_CRED
        }

    def render_template(self, template_filename, context):
        return self.template_environment.get_template(template_filename).render(context)


class ElasticSearchDeployment(Deployment):
    ELASTIC_GROUP = "elasticsearch.k8s.elastic.co"
    ELASTIC_VERSION = "v1"
    ELASTIC_PLURALS = "elasticsearches"
    APM_GROUP = "apm.k8s.elastic.co"
    APM_VERSION = "v1"
    APM_PLURALS = "apmservers"
    CERT_ISSUE_GROUP = "cert-manager.io"
    CERT_ISSUE_VERSION = "v1"
    CERT_ISSUE_PLURAL = "issuers"

    CERT_REQUEST_GROUP = "cert-manager.io"
    CERT_REQUEST_VERSION = "v1"
    CERT_REQUEST_PLURAL = "certificates"

    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def deploy(self):
        # Check if root ca is present if not create
        iss_ca_available = self.client.check_custom_resource(
            ElasticSearchDeployment.CERT_ISSUE_GROUP,
            ElasticSearchDeployment.CERT_ISSUE_VERSION,
            ElasticSearchDeployment.CERT_ISSUE_PLURAL,
            self.service_record.service_namespace,
            "elastic-ca-issuer",
        )
        if not iss_ca_available:
            self_signed_issuer = self.render_template(
                "cacerts/selfsigned-issuer.yaml", self.render_context
            )
            self.client.deploy_custom_resource(
                ElasticSearchDeployment.CERT_ISSUE_GROUP,
                ElasticSearchDeployment.CERT_ISSUE_VERSION,
                ElasticSearchDeployment.CERT_ISSUE_PLURAL,
                self.service_record.service_namespace,
                yaml.safe_load(self_signed_issuer),
            )
            self_signed_ca = self.render_template(
                "cacerts/selfsigned-ca.yaml", self.render_context
            )
            self.client.deploy_custom_resource(
                ElasticSearchDeployment.CERT_REQUEST_GROUP,
                ElasticSearchDeployment.CERT_REQUEST_VERSION,
                ElasticSearchDeployment.CERT_REQUEST_PLURAL,
                self.service_record.service_namespace,
                yaml.safe_load(self_signed_ca),
            )
            self_signed_ca_issuer = self.render_template(
                "cacerts/selfsigned-ca-issuer.yaml", self.render_context
            )
            self.client.deploy_custom_resource(
                ElasticSearchDeployment.CERT_ISSUE_GROUP,
                ElasticSearchDeployment.CERT_ISSUE_VERSION,
                ElasticSearchDeployment.CERT_ISSUE_PLURAL,
                self.service_record.service_namespace,
                yaml.safe_load(self_signed_ca_issuer),
            )

        # Issue certificate
        certificate = self.render_template("certificate.yaml", self.render_context)
        self.client.deploy_custom_resource(
            ElasticSearchDeployment.CERT_REQUEST_GROUP,
            ElasticSearchDeployment.CERT_REQUEST_VERSION,
            ElasticSearchDeployment.CERT_REQUEST_PLURAL,
            self.service_record.service_namespace,
            yaml.safe_load(certificate),
        )
        deployment = self.render_template("elasticsearch.yaml", self.render_context)
        self.client.deploy_custom_resource(
            ElasticSearchDeployment.ELASTIC_GROUP,
            ElasticSearchDeployment.ELASTIC_VERSION,
            ElasticSearchDeployment.ELASTIC_PLURALS,
            self.service_record.service_namespace,
            yaml.safe_load(deployment),
        )
        if self.service_record.apm_enabled:
            apm_deployment = self.render_template("apm.yaml", self.render_context)
            self.client.deploy_custom_resource(
                ElasticSearchDeployment.APM_GROUP,
                ElasticSearchDeployment.APM_VERSION,
                ElasticSearchDeployment.APM_PLURALS,
                self.service_record.service_namespace,
                yaml.safe_load(apm_deployment),
            )

    def delete(self):
        es_name = f"es-{self.service_record.instance_id}"
        self.client.delete_custom_resource(
            ElasticSearchDeployment.ELASTIC_GROUP,
            ElasticSearchDeployment.ELASTIC_VERSION,
            ElasticSearchDeployment.ELASTIC_PLURALS,
            self.service_record.service_namespace,
            es_name,
        )
        if self.service_record.apm_enabled:
            apm_server_name = f"apm-{self.service_record.instance_id}"
            self.client.delete_custom_resource(
                ElasticSearchDeployment.APM_GROUP,
                ElasticSearchDeployment.APM_VERSION,
                ElasticSearchDeployment.APM_PLURALS,
                self.service_record.service_namespace,
                apm_server_name,
            )
        cert_name = f"elastic-server-{self.service_record.instance_id}"
        self.client.delete_custom_resource(
            ElasticSearchDeployment.CERT_REQUEST_GROUP,
            ElasticSearchDeployment.CERT_REQUEST_VERSION,
            ElasticSearchDeployment.CERT_REQUEST_PLURAL,
            self.service_record.service_namespace,
            cert_name,
        )
        cert_secret = f"elastic-server-{self.service_record.instance_id}-secret"
        self.client.delete_secret(self.service_record.service_namespace, cert_secret)


class ElasticSearchDeploymentWithMonitoring(ElasticSearchDeployment):
    MONITORING_GROUP = "monitoring.coreos.com"
    MONITORING_VERSION = "v1"
    MONITORING_PLURAL = "servicemonitors"

    def __init__(self, config, client, service_record):
        super().__init__(config, client, service_record)

    def deploy(self):
        super(ElasticSearchDeploymentWithMonitoring, self).deploy()
        deployment = self.render_template(
            "exporter/deployment.yaml", self.render_context
        )
        self.client.create_deployment(
            self.service_record.service_namespace, yaml.safe_load(deployment)
        )
        service = self.render_template("exporter/service.yaml", self.render_context)
        self.client.create_service(
            self.service_record.service_namespace, yaml.safe_load(service)
        )
        service_monitor = self.render_template(
            "exporter/servicemonitor.yaml", self.render_context
        )
        self.client.deploy_custom_resource(
            ElasticSearchDeploymentWithMonitoring.MONITORING_GROUP,
            ElasticSearchDeploymentWithMonitoring.MONITORING_VERSION,
            ElasticSearchDeploymentWithMonitoring.MONITORING_PLURAL,
            self.service_record.service_namespace,
            yaml.safe_load(service_monitor),
        )

    def delete(self):
        super(ElasticSearchDeploymentWithMonitoring, self).delete()
        name = f"elastic-exporter-{self.service_record.instance_id}"
        self.client.delete_deployment(self.service_record.service_namespace, name)
        self.client.delete_service(self.service_record.service_namespace, name)
        self.client.delete_custom_resource(
            ElasticSearchDeploymentWithMonitoring.MONITORING_GROUP,
            ElasticSearchDeploymentWithMonitoring.MONITORING_VERSION,
            ElasticSearchDeploymentWithMonitoring.MONITORING_PLURAL,
            self.service_record.service_namespace,
            name,
        )
