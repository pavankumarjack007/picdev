import logging
import os
from distutils.util import strtobool

from jinja2 import Environment, FileSystemLoader

from .deployment import RedisDeployment, RedisDeploymentWithMonitoring
from .k8s import K8SClient


class OpState(object):
    NOT_STARTED = "not started"
    IN_PROGRESS = "in progress"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class BaseOperation(object):
    def __init__(self, status=None, description=None):
        self.action = self.__class__.__name__
        self.status = status or OpState.IN_PROGRESS
        self.description = description


class Provision(BaseOperation):
    def __init__(self, config):
        super().__init__()
        self.log = logging.getLogger(__name__)
        self.config = config
        self.client = K8SClient(
            config.K8S_API_ENDPOINT, config.K8S_CACERT, config.K8S_BROKER_TOKEN
        )
        self.template_environment = Environment(
            autoescape=False,
            loader=FileSystemLoader(os.path.dirname(__file__) + "/../template"),
            trim_blocks=False,
        )

    def env_map(self, service_record):
        return {
            "CF_INSTANCE_ID": service_record.instance_id,
            "CF_ORG_ID": service_record.organization_guid,
            "CF_PLAN_ID": service_record.plan_id,
            "CF_SPACE_ID": service_record.space_guid,
            "DOCKER_PASSWORD": self.config.DOCKER_REGISTRY_PASSWORD,
            "DOCKER_SERVER": self.config.DOCKER_REGISTRY_HOST,
            "DOCKER_USERNAME": self.config.DOCKER_REGISTRY_USER,
            **self.config.static_env,
        }

    def create_namespace(self, service_record):
        self.client.create_namespace(service_record.service_namespace)

    def create_service(self, service_record):
        try:
            deployment = new_instance(self.config, self.client, service_record)
            deployment.deploy()
        except Exception as e:
            logging.error(f"Error in provisioning resource {e}")
            service_record.delete()
            raise e

    def state(self, service_record):
        pod_status = self.client.pod_status(
            service_record.service_namespace, service_record.service_name
        )
        state = OpState.SUCCEEDED
        if pod_status == "Pending":
            state = OpState.IN_PROGRESS
        elif pod_status == "Failed":
            state = OpState.FAILED
        return state

    def _render_template(self, template_filename, context):
        return self.template_environment.get_template(template_filename).render(context)


class Deprovision(BaseOperation):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.client = K8SClient(
            config.K8S_API_ENDPOINT, config.K8S_CACERT, config.K8S_BROKER_TOKEN
        )

    def delete_service(self, service_record):
        try:
            deployment = new_instance(self.config, self.client, service_record)
            deployment.delete()
        except Exception as e:
            logging.error(f"Error in deprovisioning resource {e}")
            service_record.save()
            raise e

    def state(self, service_record):
        pod_status = self.client.pod_delete_status(
            service_record.service_namespace, f"{service_record.service_name}-0"
        )
        state = OpState.SUCCEEDED
        if pod_status == "Pending":
            state = OpState.IN_PROGRESS
        elif pod_status == "Failed":
            state = OpState.FAILED
        return state


def new_instance(config, client, service_record):
    monitoring_enabled = bool(strtobool(config.MONITORING_ENABLED))
    if monitoring_enabled:
        return RedisDeploymentWithMonitoring(config, client, service_record)
    return RedisDeployment(config, client, service_record)
