import base64
import json
import yaml
from kubernetes.client.rest import ApiException
from cf_broker_api.exceptions import ServiceInstanceNotFound
from .exceptions import BadConfigMapData, InvalidData, UnknownConfigMap
from jinja2 import Environment, FileSystemLoader
from kubernetes import client as kubernetes_client


class UpdateOp(object):

    def __init__(self, details=None, *args, **kwargs):
        if details is None:
            return
        # We are only supporting updating the rabbitmq container version
        body = [{"op": "replace",
                 "path": "/spec/template/spec/containers/0/image",
                 "value": "{0}/hsdp/rabbitmq:{1}".format(
                     details.image_host,
                     details.request_parameters['UpgradeVersion'])}]
        try:
            details.client.apps_api.patch_namespaced_stateful_set(
                name=details.service_record.data['statefulset'],
                body=body,
                namespace=details.service_record.metadata.namespace)
        except ApiException as e:
            err = json.loads(e.body)
            details.log.error('Update patch failed: {0} {1}'.format(
                e.status, err['message']))
            raise
        details.log.info('Updated StatefulSet {}'.format(
            details.service_record.data['statefulset']))


class Update(object):

    def update_configmap(self, details):
        try:
            details.client.core_api.patch_namespaced_config_map(
                name=details.name,
                body=details.misc,
                namespace=details.namespace)
        except ApiException as e:
            err = json.loads(e.body)
            details.log.error('Update Config Map: {0} {1}'.format(
                e.status, err['message']))
            raise
        details.log.info('Updated ConfigMap {0}'.format(details.name))

    def update_secret(self, details):
        try:
            if details.password is not None:
                password = bytes.decode(base64.b64encode(str.encode(
                    details.password)))
            updated_credentials = yaml.safe_load(
                details.config.credentials_update_template.render(
                    {'name_resource_id': details.name,
                     'password_b64': password}))
            details.client.core_api.patch_namespaced_secret(
                name=details.name,
                body=updated_credentials,
                namespace=details.namespace)
            details.log.info('Updated secrets {0}'.format(details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Updating secret failed: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData


class Read(object):

    def list_configmap(self, details, label=None):
        configmap = None
        if label == 'selector':
            try:
                configmap = details.client.core_api.list_namespaced_config_map(
                    namespace=details.namespace,
                    label_selector=details.misc).items[0]
            except IndexError:
                raise ServiceInstanceNotFound
            except ApiException as e:
                body = json.loads(e.body)
                details.log.error('Get Service Record: {0} {1}'.format(
                    e.status, body['message']))
        else:
            raise UnknownConfigMap
        return configmap

    def read_service(self, details):
        try:
            service = details.client.core_api.read_namespaced_service(
                details.name, details.namespace)
            return service
        except (AttributeError, IndexError, TypeError):
            # Hostname not yet updated
            return
        except ApiException as e:
            # Service may have been deprovisioned
            if e.status == 404:
                return
            else:
                body = json.loads(e.body)
                details.log.error('Get LB Status: {0} {1}'.format(
                    e.status, body['message']))
                return

    def read_secret(self, details):
        try:
            secret = details.client.core_api.read_namespaced_secret(
                details.name, details.namespace)
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Failed to get credentials: {0} {1}'.format(
                e.status, body['message']))

        credentials = {}
        for k, v in secret.data.items():
            # Mangle values by casting str->int where needed
            try:
                v = bytes.decode(base64.b64decode(str.encode(v)))
                v = int(v)
            except ValueError:
                pass
            credentials[k] = v
        return credentials

    def read_stateful_set(self, details):
        try:
            statefulset = details.client.apps_api.read_namespaced_stateful_set(
                details.name, details.namespace)
            return statefulset
        except (AttributeError, IndexError):
            return
        except ApiException as e:
            # StatefulSet may have been deprovisioned
            if e.status == 404:
                return
            else:
                body = json.loads(e.body)
                details.log.error('Get Pod Status: {0} {1}'.format(
                    e.status, body['message']))


class Provision(object):

    def create_configmap(self, details, configmap=None):
        try:
            if configmap == 'broker_template':
                broker = yaml.safe_load(details.config.broker_template.render(
                    **details.settings))
            elif configmap == 'configmap_template':
                broker = yaml.safe_load(
                    details.config.configmap_template.render(
                        **details.settings))
            else:
                raise UnknownConfigMap
            details.client.core_api.create_namespaced_config_map(
                body=broker, namespace=details.settings['namespace'])
            details.log.info('Created {0} configmap {1}'.format(
                configmap, details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('{0} {1}'.format(e.status, body['message']))
            raise BadConfigMapData

    def create_role(self, details, role=None):
        try:
            if role == 'node':
                role_details = yaml.safe_load(
                    details.config.role_template.render(**details.settings))
            elif role == 'exporter':
                role_details = yaml.safe_load(
                    details.config.exporter_role_template.render(
                        **details.settings))
            details.client.rbac_api.create_namespaced_role(
                body=role_details, namespace=details.settings['namespace'])
            details.log.info('Created {0} Role {1}'.format(
                role, details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('Error Role Creation: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData

    def create_rolebinding(self, details, binding=None):
        try:
            if binding == 'node':
                rolebinding = yaml.safe_load(
                    details.config.rolebinding_template.render(
                        **details.settings))
            elif binding == 'exporter':
                rolebinding = yaml.safe_load(
                    details.config.exporter_rolebinding_template.render(
                        **details.settings))
            details.client.rbac_api.create_namespaced_role_binding(
                body=rolebinding, namespace=details.settings['namespace'])
            details.log.info('Created {0} RoleBinding {1}'.format(
                binding, details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('RoleBinding: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData

    def create_serviceaccount(self, details, account=None):
        try:
            if account == 'node':
                serviceaccount = yaml.safe_load(
                    details.config.serviceaccount_template.render(
                        **details.settings))
            elif account == 'exporter':
                serviceaccount = yaml.safe_load(
                    details.config.exporter_serviceaccount_template.render(
                        **details.settings))
            details.client.core_api.create_namespaced_service_account(
                body=serviceaccount, namespace=details.settings['namespace'])
            details.log.info('Created {0} ServiceAccount {1}'.format(
                account, details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('ServiceAccount: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData

    def create_networkpolicy(self, details, policy=None):
        try:
            if policy == 'node':
                networkpolicy = yaml.safe_load(
                    details.config.networkpolicy_template.render(
                        **details.settings))
            elif policy == 'exporter':
                networkpolicy = yaml.safe_load(
                    details.config.exporter_networkpolicy_template.render(
                        **details.settings))
            details.client.networking_api.create_namespaced_network_policy(
                body=networkpolicy, namespace=details.settings['namespace'])
            details.log.info('Created {0} NetworkPolicy {1}'.format(
                policy, details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('NetworkPolicy: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData

    def create_service(self, details, svctype=None):
        try:
            if svctype == 'node':
                service = yaml.safe_load(
                    details.config.service_template.render(**details.settings))
            elif svctype == 'exporter':
                service = yaml.safe_load(
                    details.config.exporter_service_template.render(
                        **details.settings))
            details.client.core_api.create_namespaced_service(
                body=service, namespace=details.settings['namespace'])
            details.log.info('Created {0} Service {1}'.format(
                svctype, details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('Service: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData

    def create_headless_service(self, details):
        try:
            service = yaml.safe_load(
                details.config.service_headless_template.render(
                    **details.settings))
            details.client.core_api.create_namespaced_service(
                body=service, namespace=details.settings['namespace'])
            details.log.info('Created Headless Service rmq-{}'.format(
                details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('Service: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData

    def create_secret(self, details, secret=None):
        try:
            if secret == 'rabbit':
                credentials = yaml.safe_load(
                    details.config.credentials_template.render(
                        **details.settings))
            elif secret == 'exporter':
                credentials = yaml.safe_load(
                    details.config.exporter_secret_template.render(
                        **details.settings))
            print(credentials)
            details.client.core_api.create_namespaced_secret(
                body=credentials, namespace=details.settings['namespace'])
            details.log.info('Created {0} Secret rmq-{1}'.format(
                secret, details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('Secret: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData

    def create_statefulset(self, details):
        try:
            statefulset = yaml.safe_load(
                details.config.statefulset_template.render(**details.settings))
            details.client.apps_api.create_namespaced_stateful_set(
                body=statefulset, namespace=details.settings['namespace'])
            details.log.info('Created StatefulSet rmq-{}'.format(
                details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('StatefulSet: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData

    def create_pdb(self, details):
        try:
            pdb = yaml.safe_load(details.config.pdb_template.render(
                **details.settings))
            details.client.policy_api.create_namespaced_pod_disruption_budget(
                body=pdb, namespace=details.settings['namespace'])
            details.log.info('Creating PDB rmq-{}'.format(
                details.settings['resource_id']))
        except ValueError:
            # Resource creation succeeds, but client throws exception
            # here due to new attribute validations [0]
            # [0] https://github.com/kubernetes-client/python/issues/376
            details.log.info('Created PDB rmq-{}'.format(
                details.settings['resource_id']))
            pass

    def create_deployment(self, details):
        try:
            deployment = yaml.safe_load(
                details.config.exporter_deployment_template.render(
                    **details.settings))
            details.client.apps_api.create_namespaced_deployment(
                namespace=details.settings['namespace'], body=deployment)
            details.log.info('Created exporter Deployment {0}'.format(
                details.settings['resource_id']))
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('StatefulSet: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData

    def create_servicemonitor(self, details):

        j2 = Environment(loader=FileSystemLoader('./'), trim_blocks=True)

        #creating service monitor
        api_instance = details.client.custom_api

        svm_template = j2.get_template('broker/templates/exporter-servicemonitor.yaml')
        svm_yaml = yaml.safe_load( svm_template.render(**details.settings))


        group = 'monitoring.coreos.com' # str | The custom resource's group name
        version = 'v1' # str | The custom resource's version
        plural = 'servicemonitors' # str | The custom resource's plural name. For TPRs this would be lowercase plural kind.

        try:
            api_response = api_instance.create_namespaced_custom_object(group,version,details.namespace, plural, svm_yaml)
            print('successfully deployed service monitor')
        except ApiException as e:
            print("Exception when calling CustomObjectsApi->create_namespaced_custom_object: %s\n" % e)

    def create_ingress(self, details):
        try:
            ingress = yaml.safe_load(
                details.config.exporter_ingress_template.render(**details.settings))  # noqa: E501
            details.client.ext_api.create_namespaced_ingress(details.namespace, ingress)  # noqa: E501
            details.log.info('Created exporter ingress {}'.format(details.settings['resource_id']))  # noqa: E501
        except ApiException as e:
            Deprovision().all_resources(details, failure=True)
            body = json.loads(e.body)
            details.log.error('StatefulSet: {0} {1}'.format(
                e.status, body['message']))
            raise InvalidData


class Deprovision(object):

    def delete_statefulset(self, details):
        try:
            details.client.apps_api.delete_namespaced_stateful_set(
                details.name, details.namespace,
                body={'propagationPolicy': 'Background'})
            details.log.info('Deleted StatefulSet {}'.format(
                details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete StatefulSet: {0} {1}'.format(
                e.status, body['message']))

    def delete_pvc(self, details):
        label_selector = 'app={}'.format(details.name)
        try:
            details.client.core_api.delete_collection_namespaced_persistent_volume_claim(   # noqa: E501
                details.namespace, label_selector=label_selector)
            details.log.info('Deleted PVCs for {}'.format(details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error(
                'Delete PVC: {0} {1}'.format(e.status, body['message']))

    def delete_secret(self, details):
        try:
            details.client.core_api.delete_namespaced_secret(
                details.name, details.namespace, body={})
            details.log.info('Deleted Secret {}'.format(details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete Secret: {0} {1}'.format(
                e.status, body['message']))

    def delete_configmap(self, details, config=None):
        try:
            if config == 'broker':
                details.client.core_api.delete_namespaced_config_map(
                    details.service_record.metadata.name,
                    details.namespace,
                    body={})
            elif not config:
                details.client.core_api.delete_namespaced_config_map(
                    details.name, details.namespace, body={})
            details.log.info('Deleted ConfigMap {}'.format(details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete ConfigMap: {0} {1}'.format(
                e.status, body['message']))

    def delete_rolebinding(self, details):
        try:
            details.client.rbac_api.delete_namespaced_role_binding(
                details.name, details.namespace, body={})
            details.log.info('Deleted RoleBinding {}'.format(
                details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete RoleBinding: {0} {1}'.format(
                e.status, body['message']))

    def delete_role(self, details):
        try:
            details.client.rbac_api.delete_namespaced_role(
                details.name, details.namespace, body={})
            details.log.info('Deleted Role {}'.format(details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete Role: {0} {1}'.format(
                e.status, body['message']))

    def delete_serviceaccount(self, details):
        try:
            details.client.core_api.delete_namespaced_service_account(
                details.name, details.namespace, body={})
            details.log.info('Deleted ServiceAccount {}'.format(
                details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete ServiceAccount: {0} {1}'.format(
                e.status, body['message']))

    def delete_networkpolicy(self, details):
        try:
            details.client.networking_api.delete_namespaced_network_policy(
                details.name, details.namespace, body={})
            details.log.info('Deleted NetworkPolicy {}'.format(
                details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete NetworkPolicy: {0} {1}'.format(
                e.status, body['message']))

    def delete_pdb(self, details):
        try:
            details.client.policy_api.delete_namespaced_pod_disruption_budget(
                details.name, details.namespace, body={})
            details.log.info('Deleted PDB {}'.format(details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete PDB: {0} {1}'.format(
                e.status, body['message']))

    def delete_deployment(self, details):
        try:
            details.client.apps_api.delete_namespaced_deployment(
                details.name,
                details.namespace,
                body={'propagationPolicy': 'Background'})
            details.log.info('Deleted Deployment {}'.format(details.name))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error(
                'Delete Deployment (Exporter): {0} {1}'.format(
                    e.status, body['message']))

    def delete_service(self, details, svctype=None, svcname=None):
        try:
            if svctype == 'node':
                details.client.core_api.delete_namespaced_service(
                    details.name, details.namespace)
            elif svctype == 'headless':
                sname = svcname + '-{}'.format(
                    details.service_record.data['resource_id'])
                details.client.core_api.delete_namespaced_service(
                    sname, details.namespace)
            details.log.info('Deleted {0} Service {1}'.format(
                svctype, details.service_record.data['resource_id']))
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete Service: {0} {1}'.format(
                e.status, body['message']))

    def delete_ingress(self, details):
        try:
            details.client.ext_api.delete_namespaced_ingress(details.name,
                                                             details.namespace)
            details.log.info('Deleted exporter ingress {}'.format(details.service_record.data['resource_id']))  # noqa: E501
        except ApiException as e:
            body = json.loads(e.body)
            details.log.error('Delete ingress: {0} {1}'.format(
                e.status, body['message']))

    def delete_servicemonitor(self, details):

        #deleting service monitor
        api_instance = details.client.custom_api

        group = 'monitoring.coreos.com' # str | The custom resource's group name
        version = 'v1' # str | The custom resource's version
        plural = 'servicemonitors' # str | The custom resource's plural name. For TPRs this would be lowercase plural kind.
        name = 'rmq-exporter-' + details.request.instance_id

        try:
            api_response = api_instance.delete_namespaced_custom_object(group,version,details.namespace, plural, name, kubernetes_client.V1DeleteOptions(propagation_policy='Foreground'))
            print('successfully deleted service monitor')
        except ApiException as e:
            print("Exception when calling CustomObjectsApi->delete_namespaced_custom_object: %s\n" % e)

    # This function exists because it needs to be called in the case k8s
    # returns a failure on resource creation.  The entire deployment is
    # destroyed to avoid a messy clean up effort.
    def all_resources(self, details, resource=None, failure=False):
        if resource is None:
            self.delete_service(details, svctype='node')
            self.delete_service(details,
                                svctype='headless',
                                svcname='rmq-headless')
            self.delete_pdb(details)
            self.delete_statefulset(details)
            self.delete_pvc(details)
            self.delete_secret(details)
            self.delete_configmap(details)
            if failure:
                self.delete_configmap(details, config='broker')
            self.delete_rolebinding(details)
            self.delete_role(details)
            self.delete_serviceaccount(details)
            self.delete_networkpolicy(details)

        elif resource == 'exporter':
            self.delete_networkpolicy(details)
            self.delete_rolebinding(details)
            self.delete_role(details)
            self.delete_serviceaccount(details)
            self.delete_service(details, svctype='node')
            self.delete_secret(details)
            self.delete_deployment(details)
            self.delete_ingress(details)
            self.delete_servicemonitor(details)

