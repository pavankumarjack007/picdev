from unittest import TestCase

from botocore.exceptions import ClientError

from broker import manip_catalog
from tests import BaseTestCase, example_cors, example_lifecycle, test_data


class TestCatalog(TestCase):
    def test_catalog_east_region(self):
        service = manip_catalog("us-east-1")[0]
        self.assertEqual(service["id"], "906c102e-8cc7-41da-b06c-bf1df782cd6c")
        external_plan = next(
            plan for plan in service["plans"] if plan["name"] == "US Standard"
        )
        self.assertEqual(external_plan["id"], "22b29b79-e6a2-4d71-bc10-e030f9f2719d")

    def test_catalog_non_east_region(self):
        service = manip_catalog("us-west-2")[0]
        self.assertEqual(service["id"], "da215457-67ce-4916-b0ab-47420161d654")
        external_plan = next(
            plan for plan in service["plans"] if plan["name"] == "US Standard"
        )
        self.assertEqual(external_plan["id"], "ab439663-d84a-4cde-a031-1fe860ff529f")


class TestBroker(BaseTestCase):
    def test_provision(self):
        data = test_data()
        resp = self.client.provision(data)
        self.assertResponse(resp)
        db_record = self.model.get(data["instance_id"])
        self.assertIsNotNone(db_record)

    def test_provision_with_region(self):
        data = test_data(parameters={"Region": "us-west-2"})
        resp = self.client.provision(data)
        self.assertResponse(resp)
        location = self.Bucket(data["bucket"]).location
        self.assertEqual(data["parameters"]["Region"], location)
        db_record = self.model.get(data["instance_id"])
        self.assertIsNotNone(db_record)
        self.assertEqual(db_record.region_name, location)

    def test_refresh_policy(self):
        data = test_data()
        resp = self.client.provision(data)
        self.assertResponse(resp)
        data["parameters"] = {"RefreshPolicy": True}
        resp = self.client.update(data)
        self.assertResponse(resp)

    def test_provision_with_lifecycle(self):
        data = test_data(parameters={"BucketLifecycle": example_lifecycle})
        resp = self.client.provision(data)
        self.assertResponse(resp)
        self.assertIsNotNone(self.Bucket(data["bucket"]).lifecycle)

    def test_provision_with_cors(self):
        data = test_data(parameters={"CORSConfiguration": example_cors})
        resp = self.client.provision(data)
        self.assertResponse(resp)
        self.assertIsNotNone(self.Bucket(data["bucket"]).cors)

    def test_bind(self):
        data = test_data()
        resp = self.client.provision(data)
        self.assertResponse(resp)
        resp = self.client.bind(data)
        self.assertEqual(resp.status_code, 201)
        credentials = resp.json["credentials"]
        db_record = self.model.get(data["instance_id"])
        self.assertEqual(len(db_record.binding_ids), 1)
        self.assertEqual(db_record.binding_ids[0], data["binding_id"])
        self.assertEqual(db_record.iam_user.access_key_id, credentials["api_key"])
        self.assertEqual(
            db_record.iam_user.secret_access_key, credentials["secret_key"]
        )
        self.assertEqual(db_record.bucket, credentials["bucket"])
        self.assertEqual(db_record.region_name, credentials["location_constraint"])

    def test_unbind(self):
        data = test_data(binding_id="test-binding-id1")
        db_record = self.model().new_record(**data)
        db_record.binding_ids = ["test-binding-id1", "test-binding-id2"]
        db_record.iam_user = self.model.IamUser(
            access_key_id="access_key", secret_access_key="secret_key"
        )
        db_record.save()
        resp = self.client.unbind(data)
        self.assertEqual(resp.status_code, 200)
        db_record = self.model.get(data["instance_id"])
        self.assertEqual(len(db_record.binding_ids), 1)
        self.assertEqual(db_record.binding_ids[0], "test-binding-id2")

    def test_deprovision(self):
        data = test_data()
        resp = self.client.provision(data)
        self.assertResponse(resp)
        user = self.iam_client.get_user(UserName=data["bucket"])["User"]
        self.assertIsNotNone(user)
        resp = self.client.deprovision(data)
        self.assertResponse(resp)
        db_record = self.model.get(data["instance_id"])
        self.assertIsNone(db_record)
        with self.assertRaises(ClientError) as context:
            self.s3_resource.meta.client.head_bucket(Bucket=data["bucket"])
        self.assertIn("Not Found", str(context.exception))
        with self.assertRaises(ClientError) as context:
            self.iam_client.get_user(UserName=data["bucket"])
        self.assertIn("NoSuchEntity", str(context.exception))

    def test_provision_with_existing_instance_id_fails(self):
        data = test_data()
        db_record = self.model.new_record(**data)
        db_record.iam_user = self.model.IamUser(
            access_key_id="access_key", secret_access_key="secret_key"
        )
        db_record.save()
        resp = self.client.provision(data)
        self.assertEqual(resp.status_code, 409)

    def test_update_non_existent_instance_fails(self):
        data = test_data()
        resp = self.client.update(data)
        self.assertEqual(resp.status_code, 404)

    def test_update_bucket_lifecycle(self):
        data = test_data()
        resp = self.client.provision(data)
        self.assertResponse(resp)
        data["parameters"] = {"BucketLifecycle": example_lifecycle}
        resp = self.client.update(data)
        self.assertResponse(resp)
        self.assertIsNotNone(self.Bucket(data["bucket"]).lifecycle)

    def test_update_bucket_cors(self):
        data = test_data()
        resp = self.client.provision(data)
        self.assertResponse(resp)
        data["parameters"] = {"CORSConfiguration": example_cors}
        resp = self.client.update(data)
        self.assertResponse(resp)
        rules = self.Bucket(data["bucket"]).cors[0]
        self.assertEqual(
            rules["AllowedMethods"], example_cors["CORSRules"][0]["AllowedMethods"]
        )

    def test_deprecated_bucket_plan(self):
        data = test_data(plan_id="33e318f5-e82e-4b36-8b07-941dba3d9184")
        resp = self.client.provision(data)
        self.assertResponse(resp)
        location = self.Bucket(data["bucket"]).location
        self.assertEqual(location, "us-west-2")

    def test_provision_with_region_none(self):
        data = test_data(parameters={"Region": None})
        resp = self.client.provision(data)
        self.assertResponse(resp)
        location = self.Bucket(data["bucket"]).location
        self.assertIsNone(location)
        db_record = self.model.get(data["instance_id"])
        self.assertIsNotNone(db_record)

    def test_delete_bucket_cors(self):
        data = test_data(parameters={"CORSConfiguration": example_cors})
        resp = self.client.provision(data)
        self.assertResponse(resp)
        self.assertIsNotNone(self.Bucket(data["bucket"]).cors)
        data["parameters"] = {"CORSConfiguration": {}}
        resp = self.client.update(data)
        self.assertResponse(resp)
        self.assertIsNone(self.Bucket(data["bucket"]).cors)

    def test_delete_bucket_lifecycle(self):
        data = test_data(parameters={"BucketLifecycle": example_lifecycle})
        resp = self.client.provision(data)
        self.assertResponse(resp)
        self.assertIsNotNone(self.Bucket(data["bucket"]).lifecycle)
        data["parameters"] = {"BucketLifecycle": {}}
        resp = self.client.update(data)
        self.assertResponse(resp)
        self.assertIsNone(self.Bucket(data["bucket"]).lifecycle)

    def test_rotate_api_keys(self):
        data = test_data()
        resp = self.client.provision(data)
        self.assertResponse(resp)
        resp = self.client.bind(data)
        self.assertEqual(resp.status_code, 201)
        creds_old = resp.json["credentials"]
        data["parameters"] = {"RotateApiKey": True}
        resp = self.client.update(data)
        self.assertResponse(resp)
        resp = self.client.bind(data)
        self.assertEqual(resp.status_code, 201)
        creds_new = resp.json["credentials"]
        self.assertNotEqual(creds_old["api_key"], creds_new["api_key"])
        self.assertNotEqual(creds_old["secret_key"], creds_new["secret_key"])
        db_record = self.model.get(data["instance_id"])
        self.assertEqual(db_record.iam_user.access_key_id, creds_new["api_key"])
        self.assertEqual(db_record.iam_user.secret_access_key, creds_new["secret_key"])

    def test_advanced_lifecycle_configuration(self):
        lifecycle = {
            "Rules": [
                {
                    "Expiration": {"Days": 30},
                    "ID": "delete-with-filter",
                    "Filter": {"Prefix": "fake/subdir"},
                    "Status": "Disabled",
                }
            ]
        }
        data = test_data(parameters={"BucketLifecycle": lifecycle})
        resp = self.client.provision(data)
        self.assertResponse(resp)
        bucket_lifecycle = self.Bucket(data["bucket"]).lifecycle
        self.assertIsNotNone(bucket_lifecycle)
        self.assertEqual(bucket_lifecycle[0], lifecycle["Rules"][0])
