#! /bin/bash

cf_domain=$TF_VAR_cf_domain

if [[ "$TF_VAR_cf_for_k8s" == "true" ]]
then
  uaa_admin_secret=$(kubectl -n cf-system get secret uaa-admin-client-credentials-ver-1 -o yaml | yq e '.data."admin_client_credentials.yml"' - | base64 --decode | yq e '.oauth.clients.admin.secret' -)
else
  uaa_admin_secret=$(kubectl -n kubecf get secret cred-uaa-admin-client-secret -o yaml | yq e '.data.password' - | base64 --decode)
fi


access_token=$(curl -sb --location --request POST "https://uaa.${cf_domain}/oauth/token" \
--header 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'client_id=admin' \
--data-urlencode "client_secret=${uaa_admin_secret}" \
--data-urlencode 'scope=clients.read password.write clients.secret clients.write uaa.admin scim.write scim.read' \
--data-urlencode 'grant_type=client_credentials' | jq -r '.access_token')

ldap_provider_id=$(curl -sb --location --request GET "https://uaa.${cf_domain}/identity-providers?rawConfig=true" \
  --header "Authorization: Bearer ${access_token}" | jq -r '.[] | select(.type == "ldap") | .id')

if [[ -n "${ldap_provider_id}" ]];
then
  response_code=$(curl -s  -w '%{http_code}' --location --request DELETE "https://uaa.${cf_domain}/identity-providers/${ldap_provider_id}?rawConfig=false" \
    --header "Authorization: Bearer ${access_token}" --output /dev/null)
    if [[ response_code -eq 200 ]];
    then
      printf "Deleted preconfigured ldap identity provider [id: %s]\n" ${ldap_provider_id}
    else
      printf "Failed to delete ldap identity provider [id: %s]\n" ${ldap_provider_id}
      exit 1
    fi
fi

export KUBECF_VERSION=`kubectl get boshdeployment -n kubecf -o json| jq -r '.items[0].metadata.labels."app.kubernetes.io/version"'`
export ldap_dn=${ldap_dn}
export ldap_bind_pwd=${ldap_bind_pwd}
cat ops-ldap_uaa.yaml |envsubst > /tmp/out.yaml
myvar=`kubectl apply -f /tmp/out.yaml`
if [[ $myvar == *"unchanged"* ]]; then
	  exit 0;
fi
postion_of_ldap_configmap=`kubectl get boshdeployments -n kubecf -o json|jq -r '.items[0].spec.ops |length'`
kubectl patch boshdeployment kubecf  -n kubecf --type=json -p='[ { "op": "add", "path": "0/spec/ops/'$postion_of_ldap_configmap'", "value": { "name": "ops-ldap-uaa", "type": "configmap" } } ]'
response_code=$?
if [[ $response_code -eq 0 ]];
then
  printf "Successfully Patched uaa with ldap identity provider\n"
  (
    #wait for patch to work on uaa pod (with max timeout of 30 mins)
    kubectl wait --for=condition=Ready=false pod/uaa-0 -n kubecf  --timeout=30m
    sleep 2
    respone=0
    for i in {1..3}
    do
    	#wait for uaa pod to raise up
    	kubectl wait --for=condition=Ready pod/uaa-0 -n kubecf --timeout=30m
	respone=$?
    done
    if [[ $response -eq 0 ]];
    then
    	echo "UAA has been patched "
    	rm /tmp/out.yaml
    else
    	echo "Failed to patch"
    	exit 1;
    fi
    sleep 20 
    #Uaa is Up with all its contianer now
    uaac target uaa.${cf_domain}
    uaac token client get admin -s ${uaa_admin_secret}

    # Enable admin access for level3-support group users
    uaac group map --name scim.read "cn=level3-support,ou=Group,dc=identity,${ldap_dn}"
    uaac group map --name scim.write "cn=level3-support,ou=Group,dc=identity,${ldap_dn}"
    uaac group map --name cloud_controller.admin "cn=level3-support,ou=Group,dc=identity,${ldap_dn}"
    uaac group map --name uaa.admin "cn=level3-support,ou=Group,dc=identity,${ldap_dn}"

    # Create readonly admin group
    readonly_admin_group="cloud_controller.admin_read_only"
    group_filter="displayName+eq+%22${readonly_admin_group}%22&sortBy=lastModified&count=1&sortOrder=descending&startIndex=1"
    group_count=$(curl -sb --location --request GET "https://uaa.${cf_domain}/Groups?filter=${group_filter}" \
      --header "Authorization: Bearer ${access_token}" | jq -r '.totalResults')
    if [[ $group_count -eq 0 ]];
    then
      uaac group add cloud_controller.admin_read_only
    else
      printf "Readonly admin group already exists [group: %s]\n" ${readonly_admin_group}
    fi

    # Enable usercreates&orgs for level2-support group users
    uaac group map --name scim.read "cn=level2-support,ou=Group,dc=identity,${ldap_dn}"
    uaac group map --name scim.write "cn=level2-support,ou=Group,dc=identity,${ldap_dn}"
    uaac group map --name cloud_controller.admin "cn=level2-support,ou=Group,dc=identity,${ldap_dn}"

    # Enable readonly access for level4-support group users
    uaac group map --name scim.read "cn=level4-support,ou=Group,dc=identity,${ldap_dn}"
    uaac group map --name cloud_controller.admin_read_only "cn=level4-support,ou=Group,dc=identity,${ldap_dn}"
  )
  if [[ $? -ne 0 ]];
  then
    printf "Failed to enable access for support group users\n"
    exit 1
  fi
else
  printf "Failed to create new ldap identity provider [error: %s]\n" ${response_code}
  exit 1
fi

printf "Successfully setup UAA LDAP federation\n"
