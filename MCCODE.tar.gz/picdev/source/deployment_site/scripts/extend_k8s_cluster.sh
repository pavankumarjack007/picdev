#! /bin/bash
#Script to extend the k8s cluster with additional igs
#Requires:- kOps (v1.21), terraform (v1.0.4)
#Requires: kubectl (1.15.5), aws-cli, jq
#Requires aws access_key, secret and region to be set (For example via:- aws configure ...)
#Requires Route53 hosted zone with the name that matches cluster_name

#Defaulting number of nodes
export EXT_NODE_COUNT=1
export EXT_SIZE=m5.xlarge

while getopts c:p: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        c) conf=${OPTARG};;
        p) vars=${OPTARG};;
    esac
done

abort(){
  echo $1 && exit 1
}

abort_or_continue() {
  if [[ $1 -ne 0 ]];
  then
    echo "Bailing out ..."
    exit 1
  fi
}

log() {
    timestamp=`date +"%F %T"`
    echo -e "${timestamp} : $@";
}

## Setup paths for modules, configuration & profile
deployment="$(dirname $(dirname $(realpath $0)) )"
modules="$(dirname $(dirname $(realpath $0)) )/modules"
config="$(dirname $(dirname $(realpath $0)) )/configuration/${conf}.txt"
profile="$(dirname $(dirname $(realpath $0)) )/profiles/${vars}.tfvars"

## Setup env vars for terraform
chmod +x ./setup_env_vars.sh
source ./setup_env_vars.sh $profile

#default target to outpost if not provided in input profile
if [[ -z "${target_name}" ]]; then
  echo "The env var target_name was not set. Defaulting to outpost"
  export target_name=outpost
fi


SECONDS=0

echo "Cluster name is: ${TF_VAR_cluster_name}"

add_port_to_kops_config() {

    kops export kubecfg ${TF_VAR_cluster_name} --admin

    #Now add 6443 to kubecfg
    cp ~/.kube/config ~/.kube/config_orig_2
    export target_cluster_name=${TF_VAR_cluster_name}
    export k8s_api_server=$(yq e '.clusters[] | select(.name==env(target_cluster_name)) | .cluster | .server' ~/.kube/config)
    echo ${k8s_api_server}
    export k8s_api_server_with_port=$k8s_api_server:6443
    yq e '(.clusters[] | select(.name==env(target_cluster_name)).cluster.server) |= env(k8s_api_server_with_port)' -i ~/.kube/config  
}

login_to_k8s(){
  add_port_to_kops_config ${TF_VAR_cluster_name}
}

login_to_k8s
total_nodes=$(kubectl get nodes | grep Ready | wc -l)
echo "Initial number of nodes: ${total_nodes}"

(

  cd ${modules}/extend-cluster
  echo "Cluster name is: ${TF_VAR_cluster_name}"
  kops get ${TF_VAR_cluster_name} -o yaml > ./cluster-desired-config-private.yaml
  envsubst <./extend_cluster.tpl > ./extend_cluster.yaml
  cat ./extend_cluster.yaml >> ./cluster-desired-config-private.yaml
  abort_or_continue $?
  echo "Replacing kops cluster config"
  kops replace -f ./cluster-desired-config-private.yaml --name ${TF_VAR_cluster_name} --force
  abort_or_continue $?

  echo "Creating terraform module"
  kops update cluster --name=${TF_VAR_cluster_name} --out . --target terraform

  echo "Editing terraform module"

#TODO : for now SSF gets deployed on cloud, anything to be edited for SSF ?
  IFS=$'\n'
  if [ "$target_name" == "outpost" ]
  then
    #modify kubernetes.tf to add outposts arn
    
    lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_ebs_volume -e aws_subnet))
    for x in "${lines[@]}"; do
      echo Adding Outposts ARN to $x
      hcledit attribute append $x.outpost_arn "$outposts_arn" -f ./kubernetes.tf -u
    done
  fi

  lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_autoscaling_group))
  for x in "${lines[@]}"; do
    echo Removing load_balancers attribute in $x
    hcledit attribute rm $x.load_balancers -f ./kubernetes.tf -u
  done

  lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_elb -e aws_route53_record))
  for x in "${lines[@]}"; do
    echo Removing ELB/Router53Record $x
    hcledit block rm $x -f ./kubernetes.tf -u
  done

  #remove elb security groups
  lines=($(hcledit block list -f ./kubernetes.tf | grep '^resource.aws_security_group\..*-elb-.*'))
  for x in "${lines[@]}"; do
          echo Removing security group $x
          hcledit block rm $x -f ./kubernetes.tf -u
  done

  #remove security group rules
  lines=($(hcledit block list -f ./kubernetes.tf | grep '^resource.aws_security_group_rule\..*-elb-.*' | grep -v '^resource.aws_security_group_rule\..*from-bastion-elb-.*-tcp-22to22-.*'))
  for x in "${lines[@]}"; do
          echo Removing security group rule $x
          hcledit block rm $x -f ./kubernetes.tf -u
  done

  #update security group rule
  lines=($(hcledit block list -f ./kubernetes.tf | grep '^resource.aws_security_group_rule\..*from-bastion-elb-.*-tcp-22to22-.*'))
  for x in "${lines[@]}"; do
          echo Updating security group rule $x
          hcledit attribute rm $x.source_security_group_id -f ./kubernetes.tf -u
          hcledit attribute append $x.cidr_blocks '["0.0.0.0/0"]' -f ./kubernetes.tf -u
  done
  

  hcledit block append terraform backend.s3 -f ./kubernetes.tf -u

  wkspace="kops-${TF_VAR_environment}.${TF_VAR_domain_name}"
  lockTable="${TF_VAR_environment}.${TF_VAR_domain_name}"
  terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate" -backend-config="dynamodb_table=$lockTable" 

  found=$(terraform workspace list | grep "${wkspace}" | wc -l)
  if [[ $found -eq 0 ]]
  then
    terraform workspace new $wkspace
  else
    terraform workspace select $wkspace
  fi
  terraform plan -out ./extend_auto.plan
  terraform apply "./extend_auto.plan"
)

abort_or_continue $?

login_to_k8s

kops validate cluster ${TF_VAR_cluster_name} --wait 10m --count 3

total_nodes=${total_nodes}+${EXT_NODE_COUNT}

#verify cluster is "up"
while : ; do
    echo "Checking the number of nodes that are ready"
    result=$(kubectl get nodes | grep Ready | wc -l)
    echo "Expecting $total_nodes .. Current $result"
    if [[ $result -eq $total_nodes ]]
    then
      break
    fi
    sleep 10
done

