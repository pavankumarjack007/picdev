#!/bin/bash

eck_containers="1/1"
while : ; do
    echo "Checking if elastic operator is up"
    result=$(kubectl -n managed-es get pod elastic-operator-0 --no-headers --ignore-not-found | grep elastic-operator | awk '{ print $2 }')
    echo "Expecting $eck_containers .. Current $result"
    if [[ "$result" == "$eck_containers" ]]
    then
      break
    fi
    sleep 10
done

# TODO: remove when cert cronjob is done
kubectl get secret router-public-certificate --namespace=certificates -oyaml | grep -v '^\s*namespace:\s' | kubectl apply --namespace=managed-es -f -
kubectl get secret router-public-certificate --namespace=certificates -oyaml | grep -v '^\s*namespace:\s' | kubectl apply --namespace=managed-rmq -f -
