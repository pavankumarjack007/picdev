import graphene

from .instance_policies import InstancePolicies


class InstanceDetails(graphene.ObjectType):
    name = graphene.String()
    location = graphene.String()
    creation_date = graphene.String()
    policies = graphene.Field(InstancePolicies)

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_policies(details, _):
        return details
