![rabbitmq](https://www.rabbitmq.com/img/RabbitMQ-logo.svg)
# HSDP RabbitMQ Service Broker

## Run the command create_config.sh from the brokers/k8s-creds-generator folder
## Example: ./create_config.sh hsdp-rabbitmq https://api.outposts.hsop-test.com:6443
## copy the generated kubecfg file `kubeconfig_hsdp-rabbitmq.yaml` from the brokers/k8s-creds-generator/kubeconfig folder to the root folder of this app's source code.
## edit the manifest.yaml file to provide basic auth creds for the broker app
## cf push -f manifest.yaml
## cf create-service-broker k8srmqfull cf_broker_test Diego_broker_test_832 https://k8s-rmq-sb-app.<cfdomain>

cf enable-service-access hsdp-rabbitmq -b k8srmqfull


---
## Introduction
---
HSDP-RabbitMQ-CR is a Cloud Foundry service broker for [RabbitMQ][] version 3.7 deployed in kubernetes.

  [RabbitMQ]: https://www.rabbitmq.com/

The broker provides a bindable service that returns RabbitMQ credentials for a dedicated RabbitMQ cluster. The cluster is configured for high availability and is provided with persistent storage. Administrative access is provided through the [RabbitMQ management plugin][], and AMQP client connections are secured with TLS.

  [RabbitMQ management plugin]: https://www.rabbitmq.com/management.html

This service broker leverages the [CF-Broker-API][]

  [CF-Broker-API]: http://cf-broker-api-docs.cloud.phsdp.com/


## Kubernetes Overview
---
This section will briefly look at how Kubernetes is used and some information that may be relevant to troubleshooting the service.

- The namespace used by the broker is `hsdp-rabbitmq`
- Resources used by kubernetes will have labels for troubleshooting and billing purposes
- Each deployment is assigned a random resource ID and credentials


## Metrics Integration (TODO)
---
The broker should ideally create an internal ingress endpoint for the rabbitmq-exporter to allow a prometheus metrics service to scrape this service for metrics.  The internal ingress hostname to be scanned should be stored in the service's secret, under "data.exporter_ingress".  The scrape url could be `http://<exporter_ingress>/metrics` (on port 80).



## Broker Provisioning Failure Handling
---
Since this service is complex and creates a handful of kubernetes resources from configmaps to statefulsets, it is quite hard to manage and clean up if there is a failure on provision.  In an attempt to handle this, we have accounted for multiple failure scenarios.  In the case of a provisioning failure, the broker is designed to purge all kubernetes resources it may have created.  The service broker will return a failed provisioning error to the end user.  Failed update operations will not purge any resources.


## Caveats
---
- Using TLS/AMQPS will have a performance hit due to overhead of encryption and decryption of messages
- No support for password rotation

## Troubleshooting and FAQ
---
### Service instance is provisioning but never succeeds
If kubernetes runs out of resources, it will not return an error.  Instead it will attempt to move resources around or increase nodes to meet the demand.  The problem with this is that it in the case it cannot acquire the resources it needs, the service broker will have no knowledge of this.  The end user will endlessly wait for their service to come up not knowing there has been a failure.  This will require intervention with kubectl to see where the statefulset or pods have failed.

Hint: `kubectl -n hsdp-rabbitmq describe statefulset <rmq-(resource_id)>`

### Finding kubernetes statefulset in a space
The statefulsets running in kubernetes are randomly named to avoid name collisions. To search for the troubled service statefulset, you will need to get the CF instance id of the service.  Once you have the CF instance id, run the following command to find the kubernetes resources:

`kubectl -n hsdp-rabbitmq get statefulset,pods --selector=cf_instance_id=<cf_instance_id>`
