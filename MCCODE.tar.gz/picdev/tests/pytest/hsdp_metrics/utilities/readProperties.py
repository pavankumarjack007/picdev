import configparser

config = configparser.RawConfigParser()
config.read(".\\Configurations\\config.ini")

class ReadConfig:
    @staticmethod
    def getApplicationURL():
        url = config.get('common info', 'baseURL')
        return url

    @staticmethod
    def getUsername():
        username = config.get('common info', 'username')
        return username

    @staticmethod
    def getPassword():
        password = config.get('common info', 'password')
        return password

    @staticmethod
    def getConsoleURL():
        consoleurl = config.get('common info', 'consoleURL')
        return consoleurl

    @staticmethod
    def getruleDescription():
        rule_description = config.get('common info', 'rule_description')
        return rule_description

    @staticmethod
    def getruleDescriptionCPU():
        rule_description_cpu = config.get('common info', 'rule_description_cpu')
        return rule_description_cpu

    @staticmethod
    def getruleDescriptionDisk():
        rule_description_disk = config.get('common info', 'rule_description_disk')
        return rule_description_disk

    @staticmethod
    def getruleDescriptionLatency():
        rule_description_latency = config.get('common info', 'rule_description_latency')
        return rule_description_latency

    @staticmethod
    def getruleDescriptionRate():
        rule_description_rate = config.get('common info', 'rule_description_rate')
        return rule_description_rate

    @staticmethod
    def getruleDescriptionCode():
        rule_description_code = config.get('common info', 'rule_description_code')
        return rule_description_code

    @staticmethod
    def getruleDescriptionInstances():
        rule_description_instances = config.get('common info', 'rule_description_instances')
        return rule_description_instances

    @staticmethod
    def getThreshold():
        threshold = config.get('common info', 'threshold')
        return threshold

    @staticmethod
    def getThresholdDisk():
        threshold_disk = config.get('common info', 'threshold_disk')
        return threshold_disk

    @staticmethod
    def getThresholdLatency():
        threshold_latency = config.get('common info', 'threshold_latency')
        return threshold_latency

    @staticmethod
    def getThresholdRate():
        threshold_rate = config.get('common info', 'threshold_rate')
        return threshold_rate

    @staticmethod
    def getThresholdCodes():
        threshold_codes = config.get('common info', 'threshold_codes')
        return threshold_codes

    @staticmethod
    def getThresholdInstances():
        threshold_instances = config.get('common info', 'threshold_instances')
        return threshold_instances

    @staticmethod
    def getbenchmarkURL():
        benchmarkURL = config.get('common info', 'benchmarkURL')
        return benchmarkURL

    @staticmethod
    def getbenchmarkpassword():
        password_benchmark = config.get('common info', 'password_benchmark')
        return password_benchmark

    @staticmethod
    def gettupleRDS():
        exp_RDS_element = config.get('common info', 'exp_RDS_element')
        return exp_RDS_element

    @staticmethod
    def gettupleRedis():
        exp_Redis_element = config.get('common info', 'exp_Redis_element')
        return exp_Redis_element

    @staticmethod
    def gettupleRDSBrokers():
        exp_RDS_element_brokers = config.get('common info', 'exp_RDS_element_brokers')
        return exp_RDS_element_brokers

    @staticmethod
    def getcicd1Password():
        password_cicd1 = config.get('common info', 'password_cicd1')
        return password_cicd1

    @staticmethod
    def getcicd1URL():
        cicd1URL = config.get('common info', 'cicd1URL')
        return cicd1URL

    @staticmethod
    def getoutlookURL():
        outlook_url = config.get('common info', 'outlook_url')
        return outlook_url

    @staticmethod
    def getEmailID():
        email_ID = config.get('common info', 'email_ID')
        return email_ID

    @staticmethod
    def getPasswordOutlook():
        password_outlook = config.get('common info', 'password_outlook')
        return password_outlook

    @staticmethod
    def getsearchElementsOutlook():
        search_elements_outlook = config.get('common info', 'search_elements_outlook')
        return search_elements_outlook

    @staticmethod
    def getmessageVerify():
        message_verification_content = config.get('common info', 'message_verification_content')
        return message_verification_content