from unittest import TestCase

from cloud_mockery import mock_cf
from cloud_mockery.v2 import cf_backends

from broker import cloudfoundry
from tests import TEST_RESOURCES_FILE, test_config


def create_mock_cf_environment():
    backend = cf_backends[test_config.CF_API_ENDPOINT]
    backend.create_from_resources_file(TEST_RESOURCES_FILE)


class TestCloudFoundry(TestCase):

    MOCKS = [mock_cf()]

    @classmethod
    def setup_class(cls):
        super(TestCloudFoundry, cls).setUpClass()
        for mock in cls.MOCKS:
            mock.start()
        cls.cc_client = cloudfoundry.CloudController.new_instance(
            **test_config.cc_config
        )
        create_mock_cf_environment()

    @classmethod
    def teardown_class(cls):
        super(TestCloudFoundry, cls).tearDownClass()
        for mock in cls.MOCKS:
            mock.stop()

    def test_get_instances(self):
        instances = cloudfoundry.get_s3_instances(self.cc_client)
        self.assertEqual(len(instances), 1)

    def test_get_instance_permissions(self):
        permissions = self.cc_client.instance_permissions(
            "215b97be-ec77-4224-9c38-c4f2d86b56c1"
        )
        self.assertTrue(permissions.can_manage_instance)
