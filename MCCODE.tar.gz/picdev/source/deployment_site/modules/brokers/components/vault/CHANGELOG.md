# Changelog

## [v5] - 2019-08-05
### Added
- Service owners can enable or disable [periodic tokens][] as required through an update operation. Periodic tokens can be renewed indefinitely if they are renewed before the period of the token elapses ([CFSB-409][])

### Changed
- Approle creates periodic tokens by default (restoring the behavior of the initial release of the broker) ([CFSB-409][])

    [periodic tokens]: https://www.vaultproject.io/docs/concepts/tokens.html#periodic-tokens
    [CFSB-409]: https://healthsuite.atlassian.net/browse/CFSB-409

## [v4] - 2019-04-01
### Fixed
- Credential rotation for service instances created by earlier versions of the broker ([CFSB-337][])

    [CFSB-337]: https://healthsuite.atlassian.net/browse/CFSB-337

## [v3] - 2018-12-21
### Added
- Run smoke tests on deployment ([CFSB-272][])

    [CFSB-272]: https://healthsuite.atlassian.net/browse/CFSB-272

- Vault policy can be updated to allow secret deletion in `credentials.space_secret_path` ([CFSB-20][])

    [CFSB-20]: https://healthsuite.atlassian.net/browse/CFSB-20

- Documented transit key backup which is available in newer versions of Vault

### Changed
- Client tokens cannot be renewed past the TTL of 1 hour ([CFSB-18][])

    [CFSB-18]: https://healthsuite.atlassian.net/browse/CFSB-18

### Deprecated
- For new services, the path given in `credentials.org_secret_path` will no longer be created ([CFSB-45])

## [v2] - unreleased
### Added
- Credential rotation ([CFSB-17][])

    [CFSB-17]: https://healthsuite.atlassian.net/browse/CFSB-17

- Vault resource names created by the broker are added to the service record
- Config module
- Logging enhancements
- Retry Vault API requests on connection failures or if client token is expired
- For new services, the Vault endpoint provided by the broker for service bindings is the hostname of a publicly-accessible regional Vault proxy ([CFSB-32][])

    [CFSB-32]: https://healthsuite.atlassian.net/browse/CFSB-32

### Changed
- Refactored to use `cf-broker-api` package
- Use templates for Vault policy and approle parameters
