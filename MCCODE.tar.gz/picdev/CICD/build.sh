error_exit(){
	if [ $? -eq 0 ];then
		echo "--------------------------------$1 is success--------------------------------"
	else
		echo "--------------------------------$1 is failed---------------------------------"
		exit 1
	fi
}

terraformValidation() {

    config_file=${WORKSPACE}/source/deployment_stable/configuration/all.txt
    modules=${WORKSPACE}/source/deployment_stable/modules/

    while IFS= read -r line || [[ -n "$line" ]];
    do
        module_dir=$(echo $line)
        module="$modules/$module_dir"
        cd $module
        terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate"
        error_exit "Terraform Init $module_dir"

        terraform validate
        error_exit "Terraform validate $module_dir"

    done < $config_file
}


build(){
    terraformValidation

    if [[ $BUILD_TYPE =~ (GATED) ]]; then
	    SONAR_BRANCH="GATED"
	
    elif [[ $BUILD_TYPE =~ (DAY|NIGHTLY|RELEASE|UPDATE) ]]; then
        SONAR_BRANCH="DEV_NIGHTLY"
    fi
    
    export PATH=$PATH:/opt/sonar-scanner-4.5.0.2216-linux/bin/  
    export no_proxy=$no_proxy,${HSDP_SONARQUBE_URL_NEW}
    echo "################# SONAR_SCAN #################"
    cd ${WORKSPACE}/source/
	sonar-scanner -Dsonar.projectKey=${PSNAME}:${SONAR_BRANCH}  \
	-Dsonar.projectName=${PSNAME}_${SONAR_BRANCH}  \
    -Dsonar.exclusions=**/*.java,**/deployment_saas_services/*.* \
    -Dsonar.sources=. \
    -Dsonar.host.url=${HSDP_SONARQUBE_URL_NEW} \
	-Dsonar.projectVersion=1.0

    error_exit "Sonar Scan"
    
}

if [[ $BUILD_TYPE =~ ^(GATED|DAY|NIGHTLY|RELEASE|UPDATE) ]]; then
	build
elif [[ $BUILD_TYPE =~ ^(BLACKDUCK|FORTIFY) ]]; then
    echo " BUILD_TYPE IS: $BUILD_TYPE Running Build without SonarQube"
	//buildWithoutSonarQube
else
	echo "Not a CI or GATED build - Skipping SonareQube Scan"
fi  
