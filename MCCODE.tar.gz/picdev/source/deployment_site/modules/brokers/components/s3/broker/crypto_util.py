import sys

from argon2.low_level import Type, hash_secret_raw
from Crypto.Random import get_random_bytes

from broker.encrptor import DecryptReader, EncryptWriter


def encrypt(encrypt_key, data):
    salt = get_random_bytes(32)
    key = hash_secret_raw(
        secret=encrypt_key.encode("utf-8"),
        salt=salt,
        time_cost=1,
        memory_cost=64 * 1024,
        parallelism=4,
        hash_len=32,
        type=Type.ID,
    )
    nonce = get_random_bytes(8)
    cipher_text = [salt, int(0).to_bytes(1, sys.byteorder), nonce]
    encrypt_writer = EncryptWriter(key, nonce, cipher_text)
    encrypt_writer.write(data)
    return b"".join(cipher_text)


def decrypt(encrypt_key, data):
    salt = data[0:32]
    algo_id = data[len(salt) : len(salt) + 1]
    nonce = data[len(salt) + len(algo_id) : len(salt) + len(algo_id) + 8]
    data = data[len(salt) + len(algo_id) + len(nonce) :]
    key = hash_secret_raw(
        secret=encrypt_key.encode("utf-8"),
        salt=salt,
        time_cost=1,
        memory_cost=64 * 1024,
        parallelism=4,
        hash_len=32,
        type=Type.ID,
    )
    decrypt_reader = DecryptReader(key, salt, nonce)
    return decrypt_reader.read(data)
