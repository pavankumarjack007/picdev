#! /bin/bash

add_port_to_kops_config() {

kops export kubecfg ${1} --admin

#Now add 6443 to kubecfg
cp ~/.kube/config ~/.kube/config_orig_2
export target_cluster_name=${1}
export k8s_api_server=$(yq e '.clusters[] | select(.name==env(target_cluster_name)) | .cluster | .server' ~/.kube/config)
export k8s_api_server_with_port=$k8s_api_server:6443
yq e '(.clusters[] | select(.name==env(target_cluster_name)).cluster.server) |= env(k8s_api_server_with_port)' -i ~/.kube/config	
}

add_port_to_kops_config ${1}
