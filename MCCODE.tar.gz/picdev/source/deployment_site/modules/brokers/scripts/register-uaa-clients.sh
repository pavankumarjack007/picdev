#!/bin/bash

cf_domain=${cf_domain:=$TF_VAR_cf_domain}
#uaa_admin_secret=${uaa_admin_secret:=$(kubectl -n kubecf get secret var-uaa-admin-client-secret -o yaml | yq e '.data.password' - | base64 --decode)}

uaac target uaa.${cf_domain}
echo "uaa_admin_secret is : " ${uaa_admin_secret}
uaac token client get admin -s ${uaa_admin_secret}

addClient(){

uaaCmd="uaac client add "
clientId=$1
uaaParam=$2

var="$uaaCmd $clientId  $uaaParam"
echo "var" $var
result=$(eval $var)
echo $result

if [[ $result == *error* ]]
then
	echo "Failed to Create " $clientId
else
	echo "Successfully Created " $clientId
fi 

}

deleteClient() {
clientId=$1
echo "DELETE PARAM " $clientId
result=$(uaac client delete $clientId )
echo $result
var=$(echo $result | grep deleted)

echo $var
if [[ -z $var ]]
then

	echo "Failed to delete " $clientId
else

	echo "Successfuly deleted " $clientId
fi 

}


add_clients() {

addClient "hsdp-metrics-autoscaler"  "--authorized_grant_types 'refresh_token client_credentials' --authorities 'cloud_controller.admin' --access_token_validity 3600 --secret ${AUTOSCALER_UAA_CLIENT_SECRET}"
addClient "hsdp-prometheus"  "--scope 'cloud_controller.read cloud_controller_service_permissions.read openid' --authorized_grant_types 'refresh_token authorization_code' --authorities 'uaa.resource' --access_token_validity 3600 --refresh_token_validity 1800  --redirect_uri 'https://hsdp-metrics.$cf_domain/auth/cloudfoundry' --secret ${UAA_OAUTH_CLIENT_SECRET}"
addClient "hsdp-prometheus-sd-worker"  "--authorized_grant_types 'refresh_token client_credentials' --authorities 'cloud_controller.global_auditor cloud_controller.admin_read_only doppler.firehose' --access_token_validity 300 --refresh_token_validity 1800 --secret ${DEPLOY_CLIENT_SECRET}"

addClient "hsdp-dashboard"  "--scope 'cloud_controller.read,openid' --authorized_grant_types 'refresh_token,authorization_code,client_credentials,password' --redirect_uri 'https://console.$cf_domain' --authorities 'uaa.admin,cloud_controller.admin_read_only' --secret ${HSDP_DASHBOARD_SECRET}"

}

delete_clients() {

deleteClient "hsdp-metrics-autoscaler"
deleteClient "hsdp-prometheus"
deleteClient "hsdp-prometheus-sd-worker"
deleteClient "hsdp-dashboard"

}

addRemoveClients() {

addDel=$1
echo "PARAM " $addDel

if [[ "$addDel" == "add" ]]
then
 echo "Adding clients"
 add_clients
else
  echo "Deleting clients"
  delete_clients
fi

}

addRemoveClients $1 
