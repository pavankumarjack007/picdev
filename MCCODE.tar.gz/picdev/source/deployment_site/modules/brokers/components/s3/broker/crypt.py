import hashlib
import random
import string
from base64 import b64decode, b64encode

from Crypto.Cipher import AES

BLOCK_SIZE = 32
MODE = AES.MODE_CBC
INTERRUPT = u"\u0001"
PAD = u"\u0000"


class crypt:
    def __init__(self, **kwargs):
        k = kwargs.get("key", None)
        self.key = hashlib.sha256(k.encode("utf-8")).digest()
        self.iv = kwargs.get("iv", "").encode("utf-8")

    @staticmethod
    def generate_iv():
        values = "".join([string.digits, string.ascii_letters])
        iv = "".join(random.sample(values, 16))
        return iv

    def encrypt(self, data):
        data = data
        padded_data = self._add_padding(data)
        cipher = AES.new(self.key, MODE, self.iv)
        encrypted = cipher.encrypt(padded_data.encode("utf-8"))
        return b64encode(encrypted)

    def decrypt(self, data):
        encrypted_data = b64decode(data)
        cipher = AES.new(self.key, MODE, self.iv)
        decrypted = cipher.decrypt(encrypted_data).decode("utf-8")
        return self._strip_padding(decrypted)

    @staticmethod
    def _add_padding(data):
        # Strings must be encrypted in 32 byte chunks.  If a string is not
        # exactly 32 bytes long we need to make it 32 bytes long in order to
        # encrypt it properly.  This will pad a string with the interrupt char
        # followed by null chars.
        new_data = "".join([data, INTERRUPT])
        remaining_len = BLOCK_SIZE - len(new_data)
        to_pad_len = remaining_len % BLOCK_SIZE
        pad_string = PAD * to_pad_len
        return "".join([new_data, pad_string])

    @staticmethod
    def _strip_padding(data):
        # This removes the padding we added.
        return data.rstrip(PAD).rstrip(INTERRUPT)

    def __enter__(self):
        return self

    def __exit__(self, exception_type, exception_val, trace):
        if exception_type:
            raise exception_type(exception_val)
        else:
            return True
