import datetime
import random
import re
import secrets
import string
from base64 import b64decode, b64encode

import nacl.secret


def timestamp():
    now = datetime.datetime.utcnow().replace(microsecond=0).isoformat()
    return f"{now}Z"


def encrypt_data(data, key, iv=None):
    box = nacl.secret.SecretBox(key.encode("utf-8"))
    encrypted_value = box.encrypt(data.encode("utf-8"))
    return b64encode(encrypted_value).decode("utf-8")


def decrypt_data(data, key, iv=None):
    box = nacl.secret.SecretBox(key.encode("utf-8"))
    decrypted_value = box.decrypt(b64decode(data.encode("utf-8")))
    return decrypted_value.decode("utf-8")


def random_alphanum(length=20, lowercase=False):
    chars = string.digits
    if lowercase:
        chars += string.ascii_lowercase
    else:
        chars += string.ascii_letters
    return "".join(secrets.choice(chars) for _ in range(length))


def truncate_id(guid):
    return str(guid.split("-")[0])


def sanitize_label_value(value):
    # Transform CF object names into valid Kubernetes label values
    # See: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/#syntax-and-character-set

    # Truncate at max length
    value = value[0:63]
    # Replace invalid chars with underscore
    value = re.sub("[^a-zA-Z0-9_.-]+", "_", value)
    valid = re.compile("(([A-Za-z0-9][-A-Za-z0-9_.]*)?[A-Za-z0-9])?")
    if not valid.fullmatch(value):
        # Now we have either leading or trailing non-alphanum chars, trim
        # those away and re-validate. If this fails, give up and return an
        # empty string (which is a valid value)
        value = value.lstrip("_.-")
        value = value.rstrip("_.-")
        if not valid.fullmatch(value):
            value = ""
    return value


def generate_random_string(num_bytes):
    chars = string.ascii_letters + string.digits
    return "".join(random.SystemRandom().choice(chars) for _ in range(num_bytes))


def remove_dashes(uuid):
    return "".join(str(uuid).split("-"))


class ElasticSearchURI:
    def __init__(self, username=None, password=None, host=None, port=None, service_name=None, domain_name=None):
        self.username = username
        self.password = password
        self.host = host
        self.service_name = service_name
        self.domain_name = domain_name
        if port is not None:
            self.port = int(port)
        else:
            self.port = None
        self.port = int(30920)
    def __to_string__(self, hide_password=True):
        s = "https://"
        if self.username is not None:
            s += self.username
            if self.password is not None:
                s += ":" + ("[REDACTED]" if hide_password else self.password)
            s += "@"
        if self.service_name is not None:
            s += self.service_name
            s += ".es." + self.domain_name
        if self.port is not None:
            s += ":" + str(self.port) + "/"
        return s

    def __str__(self):
        return self.__to_string__(hide_password=False)

    def __repr__(self):
        return self.__to_string__()
