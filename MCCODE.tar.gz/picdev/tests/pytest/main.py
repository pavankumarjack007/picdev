import sys


def main():
    sys.exit(0)


if __name__ == "__main__":
    main()
