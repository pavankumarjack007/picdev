import base64
import kubernetes.client

from kubernetes.client import configuration
from kubernetes.client.rest import ApiException
from kubernetes import config, client
import base64


class KubernetesClient(object):

    def __init__(self, config):
        self.config = config
        certName = 'cert.pem'
        try:
            token =  self.config.K8S_BROKER_TOKEN
            k8s_cert =  self.config.K8S_CACERT

            # urllib3 insists on reading CA certs from a file object
            with open(certName, 'wb') as cert:
                cert.write(base64.b64decode(str.encode(k8s_cert)))
                cert.flush()

            # Configs can be set in Configuration class directly or using helper utility
            config = client.Configuration()
            config.host = self.config.K8S_API_ENDPOINT
            config.verify_ssl = False
            config.ssl_ca_cert = cert.name
            config.api_key["authorization"]=base64.b64decode(str.encode(token)).decode('utf-8')
            config.api_key_prefix["authorization"]= "Bearer"

            client.Configuration.set_default(config)

            self.client_config = kubernetes.client.Configuration()
            print("Init success:")
        except IOError as e:
            body = json.loads(e.body)
            print("IOError: ", body)

        # Create instances of the various API classes we need
        self.client = kubernetes.client.api_client.ApiClient(
            configuration=self.client_config)
        self.core_api = kubernetes.client.CoreV1Api(self.client)

        self.apps_api = kubernetes.client.AppsV1Api(self.client)
        self.policy_api = kubernetes.client.PolicyV1beta1Api(self.client)
        self.rbac_api = kubernetes.client.RbacAuthorizationV1Api(self.client)
        self.networking_api = kubernetes.client.NetworkingV1Api(self.client)
        self.ext_api = kubernetes.client.ExtensionsV1beta1Api(self.client)
        self.custom_api = kubernetes.client.CustomObjectsApi(self.client)
        self.yaml_client = self.client

