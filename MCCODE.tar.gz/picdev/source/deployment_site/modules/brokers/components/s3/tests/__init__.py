import os
import uuid
from unittest import TestCase

import boto3
from cf_broker_api.testing import TestClient
from moto import mock_dynamodb2, mock_iam, mock_organizations, mock_s3
from nose.tools import nottest

import broker.aws as aws
from broker import create_broker, manip_catalog
from broker.model import get_broker_model
from config import config_map

TEST_RESOURCES_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "resources/cf_env_for_tests.yml"
)

test_config = config_map["testing"]

example_lifecycle = {
    "Rules": [
        {
            "Status": "Enabled",
            "Prefix": "",
            "Transitions": [{"Days": 10, "StorageClass": "GLACIER"}],
            "ID": "Move to Glacier",
        }
    ]
}

example_cors = {
    "CORSRules": [
        {
            "AllowedHeaders": ["*"],
            "AllowedMethods": ["PUT", "POST", "DELETE"],
            "AllowedOrigins": ["sample.cloud.pcftest.com", "sample.philips.com"],
            "ExposeHeaders": [],
            "MaxAgeSeconds": 500,
        }
    ]
}

legacy_policy = """{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListAllMyBuckets"
            ],
            "Resource": "arn:{{ partition }}:s3:::*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket",
                "s3:GetBucketLocation"
            ],
            "Resource": [
                "arn:{{ partition }}:s3:::{{ aws_instance_id }}"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:DeleteObject"
            ],
            "Resource": [
                "arn:{{ partition }}:s3:::{{ aws_instance_id }}/*"
            ]
        }
    ]
}"""

sts_policy = """{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:{{ partition }}:s3:::{{ aws_instance_id }}"
            ]
        }
    ]
}"""


@nottest
def test_data(**kwargs):
    catalog = manip_catalog(test_config.AWS_DEFAULT_REGION)
    default_service_id = catalog[0]["id"]
    default_plan_id = next(
        plan["id"] for plan in catalog[0]["plans"] if plan["name"] == "s3_bucket"
    )
    instance_id = kwargs.get("instance_id", str(uuid.uuid4()))
    service_id = kwargs.get("service_id", default_service_id)
    plan_id = kwargs.get("plan_id", default_plan_id)
    plan = next(plan for plan in catalog[0]["plans"] if plan["id"] == plan_id)
    organization_guid = kwargs.get("organization_guid", "test-org-guid")
    space_guid = kwargs.get("space_guid", "test-space-guid")
    default_bucket_name = "{}-{}".format(test_config.INSTANCE_PREFIX, instance_id)
    bucket = kwargs.get("hostname", default_bucket_name)
    parameters = kwargs.get("parameters", {})
    default_context = {
        "platform": "cloudfoundry",
        "organization_guid": organization_guid,
        "space_guid": space_guid,
    }
    context = kwargs.get("context", default_context)
    binding_id = kwargs.get("binding_id", "test-binding-id")
    data = {
        "instance_id": instance_id,
        "bucket": bucket,
        "service_id": service_id,
        "plan_id": plan_id,
        "plan": plan,
        "organization_guid": organization_guid,
        "space_guid": space_guid,
        "parameters": parameters,
        "context": context,
        "binding_id": binding_id,
    }
    return data


class BaseTestCase(TestCase):

    MOCKS = [mock_iam(), mock_s3(), mock_dynamodb2(), mock_organizations()]

    config = config_map["testing"]

    app = None
    model = None

    iam_client = None
    s3_client = None
    s3_resource = None
    Bucket = None
    IAM = None

    @classmethod
    def setup_class(cls):
        super(BaseTestCase, cls).setUpClass()
        for mock in cls.MOCKS:
            mock.start()
        orgs_client = boto3.client("organizations", **cls.config.aws_config)
        orgs_client.create_organization(FeatureSet="ALL")
        cls.app = create_broker("testing")
        cls.client = TestClient(cls.app.test_client())
        cls.model = get_broker_model(cls.config)
        cls.s3_resource = boto3.resource("s3", **cls.config.aws_config)
        cls.s3_client = cls.s3_resource.meta.client
        cls.iam_client = boto3.client("iam", **cls.config.aws_config)
        cls.Bucket = aws.S3Bucket(**cls.config.aws_config)
        cls.IAM = aws.IamUser(**cls.config.aws_config)

    @classmethod
    def teardown_class(cls):
        super(BaseTestCase, cls).tearDownClass()
        for mock in cls.MOCKS:
            mock.stop()

    def assertResponse(self, resp):
        if self.config.BROKER_IS_ASYNC:
            self.assertEqual(resp.status_code, 202)
            self.assertEqual(resp.last_resp.json.get("state", "succeeded"), "succeeded")
            self.assertIn(resp.last_resp.status_code, (200, 410))
        else:
            self.assertIn(resp.status_code, (200, 201))
