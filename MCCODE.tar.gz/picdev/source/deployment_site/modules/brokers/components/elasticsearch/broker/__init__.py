import logging
import os

from cf_broker_api import ServiceBroker
from cf_broker_api.utils import init_logging

from config import config_map
from .dashboard import controller as dashboard_controller
from .model import get_broker_model
from .service import ElasticSearchBrokerService

LOG = logging.getLogger(__name__)


def create_broker(
    config_name=None, catalog=None, service_class=None, exc_mapper=None, parsers=None
):
    _config_name = config_name or os.getenv("BROKER_CONFIG", "default")
    _config = config_map[_config_name]

    init_logging(
        level=_config.LOGGING_LEVEL,
        log_format=_config.LOGGING_MSG_FORMAT,
        date_format="%Y-%m-%dT%H:%M:%SZ",
    )
    LOG.info("Using {} configuration...".format(_config_name))

    # _catalog = catalog or _config.service_catalog_filename
    _catalog = catalog or "catalog.yml"
    _model = get_broker_model(_config)
    _service = service_class or ElasticSearchBrokerService(model=_model, config=_config)
    _parsers = parsers or _service.get_param_parsers()
    _exc_mapper = exc_mapper or {}

    broker = ServiceBroker(
        service_catalog=_catalog,
        custom_parsers=_parsers,
        service_class=_service,
        exc_mapper=_exc_mapper,
        config=_config,
    )

    broker.register_blueprint(dashboard_controller)

    return broker
