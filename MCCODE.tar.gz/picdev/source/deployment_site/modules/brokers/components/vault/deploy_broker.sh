#! /bin/bash

abort_or_continue() {
  if [[ $1 -ne 0 ]];
  then
    echo "Bailing out ..."
    exit 1
  fi
}

role_id=$(kubectl -n vault exec vault-0 -- vault read auth/approle/role/service-broker/role-id  | grep role_id | awk '{ print $2}')
secret_id=$(kubectl -n vault exec vault-0 -- vault write -f auth/approle/role/service-broker/secret-id | grep -w secret_id | awk '{ print $2}')
export VAULT_ROLE_ID=$role_id
export VAULT_SECRET_ID=$secret_id

export BROKER_USERNAME=${1}
export BROKER_PASSWORD=${2}
export PORT=\$PORT

export VAULT_CLIENT_ENDPOINT=https://vproxy.${3}
export VAULT_ENDPOINT=https://vault.${3}

envsubst < manifest.tpl > manifest.yml
cf create-security-group all-brokered-services ./brokered-services.json
cf bind-running-security-group all-brokered-services
cf bind-staging-security-group all-brokered-services

cf push
abort_or_continue $?
cf create-service-broker vaultservicebroker $1 $2 https://vault-sb-app.${3}
cf enable-service-access hsdp-vault -b vaultservicebroker -p standard
