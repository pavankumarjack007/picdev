#!/usr/bin/env bash

# Variables used by the tests. They only need to be
# run once, so we put them in our pre-run script
#export UUID=$(uuidgen)
#export target_output=$(cf target)
#export api_endpoint=$(echo "$target_output"|grep "api endpoint"|sed -e 's|.*https://||')
#export org=$(echo "$target_output"|grep ^org:|awk '{print $2}'|tr 'A-Z' 'a-z')
#export space=$(echo "$target_output"|grep ^space:|awk '{print $2}')
# Added cf login to set the endpoint
pwd=$(grep  'cf_admin_password:' ../../source/deployment/modules/cloudfoundry/values/kubecf_ext-blobstore_kops.yaml.tpl | tail -n1 | awk '{ print $2}')
domainname=$(sudo cat ../../source/deployment/profiles/outposts-bothell-small.tfvars | grep domain | cut -d '=' -f2 | tr -d '"')
echo $domainname
url=https://api.cf.$domainname
echo $url
cf login -a $url -u admin -p $pwd -o hsop -s services --skip-ssl-validation
endpoint=$(cf target | grep endpoint | cut -f3 -d/)
# run the tests with bats test framework
date
bats cf-networking.bats
