#!/bin/bash
now=$(date +'%Y-%m-%d-%H-%M-%S')
LOG_FILE_NAME="k8s_smoke_result"
LOG_FILE=$(echo "${LOG_FILE_NAME}_${now}.txt")
exec > >(tee -i $(pwd)/$LOG_FILE)

echo "-------------------------------------------------------------------------------"
echo "-----------------------Data secret Test---------------------"
function create_secret(){
	create_out=$(kubectl create secret generic smoke-test --from-literal="mykey=mydata")
        if [[ $create_out == *"created"* ]]; then
          echo "Secret is created"
          pass=$((pass+1))
        else
          echo "Failed to create secret"
        fi
}
create_secret
function get_secret(){
	get_out=$(kubectl get secrets)
        if [[ $get_out == *"smoke-test"* ]]; then
          echo "Secret available"
          secret_out=$(kubectl get secrets smoke-test -o json)
          if [[ $secret_out == *"bXlkYXRh"* ]]; then
            echo "Secret is encoded"
          fi
          secret_values=$(kubectl get secrets smoke-test -o json | jq -r .data.mykey | base64 --decode)
          if [[ $secret_values == *"mydata"* ]]; then
            echo "Secret is verified"
            pass=$((pass+1))
          fi
         
        else
          echo "Failed in getting secret secret"
        fi
}
get_secret
function delete_secret(){
        del_out=$(kubectl delete secret smoke-test)
        if [[ $del_out == *"deleted"* ]]; then
          echo "Secret removed"
          pass=$((pass+1))
        else
          echo "Failed to remove secret"
        fi
}
delete_secret
echo "-----------------------Deployment Test---------------------"
function deploy_nginx(){
	apply_out=$(kubectl create deployment nginx --image=nginx)
	sleep 5
        if [[ $apply_out == *"deployment.apps/nginx created"* ]]; then
          echo "App deployment is success!"
	  pass=$((pass+1))
        else
          echo "Failed to perform deployment"
        fi
}
deploy_nginx
sleep 10
function get_pods(){
	POD_NAME=$(kubectl get pods -l app=nginx -o jsonpath="{.items[0].metadata.name}")
	sleep 5
}

get_pods
function port_forward(){
	kubectl port-forward $POD_NAME 8080:80 &
	sleep 5
}
port_forward
function testcurl(){
	curl_out=$(curl --head http://127.0.0.1:8080)
	if [[ $curl_out == *"200 OK"* ]]; then
	  echo "Application is UP!"
	  pass=$((pass+1))
  else
    echo "Failed to connect to app"
	fi
}
testcurl
function testlog(){
	kubelog=$(kubectl logs $POD_NAME)
        if [[ $kubelog == *"HEAD / HTTP/1.1"* ]]; then
          echo "App log can be viewed!"
	        pass=$((pass+1))
        else
          echo "Failed to view app log"
        fi
}
testlog
function testexec(){
	exec_out=$(kubectl exec $POD_NAME -- nginx -v 2>&1)
        echo "Output is $exec_out in Pod $POD_NAME"
        if [[ $exec_out == *"nginx version: nginx"* ]]; then
          echo "Able to kubectl exec!"
       	  pass=$((pass+1))
        else
          echo "Failed to exec"
        fi
}
testexec
function delete_nginx(){
	kubectl delete -n default deployment nginx
  kill %%
#	kill -9 $pid
}
delete_nginx
echo "-----------------------Statefulset---------------------"
function deployment(){
       apply_out=$(kubectl apply -f deployment.yml)
       if [[ $apply_out == *"persistentvolumeclaim/myclaim"* ]]; then
          echo "Deployed with persistent volume"
          pass=$((pass+1))
       else
          echo "Failed to perform deployment with persistance volume"
       fi
}
deployment
function check_pod_state(){
      pod_state=$(kubectl get pod web-0)
      if [[ $pod_state == *"web-0"* ]]; then
          echo "Pod is running"
          pass=$((pass+1))
      else
          echo "Failed - pod is not exist"
      fi
}
check_pod_state
function check_svc(){
      svc_state=$(kubectl get svc nginx)
      if [[ $svc_state == *"nginx"* ]]; then
          echo "ClusterIP service exists"
          pass=$((pass+1))
      else
         echo "Failed - Service ClusterIP not exist"
      fi
}
check_svc
function check_statefulset(){
      state_out=$(kubectl get statefulsets)
      if [[ $state_out == *"web"* ]]; then
          echo "Web statefulset exists"
          pass=$((pass+1))
      else
         echo "Failed - statefulset not exist"
      fi
}
check_statefulset
function cleanup_stateful(){
kubectl delete statefulset web
kubectl delete service nginx
kubectl delete pvc myclaim
}
cleanup_stateful
echo "-----------------------PodNetworking---------------------"
function deploy(){
      deploy_out=$(kubectl create deployment pingtest --image=busybox:1.33.1-uclibc --replicas=2 -- sleep infinity)
      if [[ $deploy_out == *"deployment.apps/pingtest created"* ]]; then
          echo "App created"
          pass=$((pass+1))
          sleep 5
      else
         echo "Failed deployment"
      fi
}
deploy
function test_networking(){
      pod1_ip=$(kubectl get pods --selector=app=pingtest --output=wide | awk '{print $6}' | awk 'NR==2')
      pod2_ip=$(kubectl get pods --selector=app=pingtest --output=wide | awk '{print $6}' | awk 'NR==3')
      pod2=$(kubectl get pods --selector=app=pingtest --output=wide | awk '{print $1}' | awk 'NR==3')
      sleep 15 
      exec2_out=$(kubectl exec $pod2 -- ping $pod1_ip -c 4 2>&1)
      echo "Out: $exec2_out POD2: $pod2 ip: $pod2_ip ip: $pod1_ip "
      if [[ $exec2_out == *"4 packets transmitted, 4 packets received, 0% packet loss"* ]]; then
          echo "Pod to pod communication is success"
          pass=$((pass+1))
      else
         echo "Failed pod to pod communication"
      fi
}
test_networking
function delete_deployment(){
       kubectl delete deployments.apps pingtest
}
delete_deployment
echo "--------------POD states accross namespace---------------"

function check_pod_status(){

    listOfNs=$(kubectl get ns | awk 'NR>1{print $1}')
    readarray lns <<< $listOfNs
    ok=0
    notok=0
    for i in ${lns[@]}
     do
       listPods=$(kubectl get po -n $i | awk 'NR>1{print $1}')
       readarray  arr <<<  $listPods
       for j in ${arr[@]}
        do
         echo -ne "$j ... "
         status=$(kubectl get po $j -n $i | grep $j | awk '{print $3}')
            if [[ ! $status =~ ^Running$|^Completed$  ]]  ; then
              echo -e "Unhealthy"
              let notok=notok+1
            else
              echo -e "OK!"
              let ok=ok+1
            fi
        done
    done
    pass=$((pass+1))
    echo "Healthy PODS: $ok"
    echo "Unhealthy PODS: $notok"
    if [[ $notok > 0 ]]; then
        echo "Failed - there are Unhealthy pods"
	 pass=$((pass-1))
    fi
}
check_pod_status

echo "--------------K8s smoke test Results---------------"
echo "Total Tests: 14"
echo "Passed     : $pass"
echo "---------------------------------------------------"
echo "-------------------------------------------------------------------------------"
