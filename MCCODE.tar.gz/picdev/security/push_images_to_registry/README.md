# How to run push_images.sh script

1. Kindly login to VM and verify wheather VM has docker proxy or not. 
	a. Open /etc/sysconfig/docker file and verify any proxy is added.
           EX: /etc/sysconfig/docker 
		INSECURE_REGISTRY="--insecure-registry=gcr.io --insecure-registry=130.147.139.20:8080 --insecure-registry=artifactory.pic.philips.com:50002 "
		DOCKER_OPTS=""
		DOCKER_STORAGE_OPTIONS="--storage-driver=overlay"
		HTTP_PROXY="http://185.46.212.98:10015"
		HTTPS_PROXY="http://185.46.212.98:10015"
		no_proxy=130.147.139.20,artifactory.pic.philips.com
	b. If this file (/etc/sysconfig/docker) contains any proxy details, kinldy remove or rename the file ex: /etc/sysconfig/docker.orig
	c. then restart docker with below commands.
	    systemctl daemon-reload; systemctl restart docker


2. Adding/modifying below details in push_images.sh 

docker_login="xxxxx" # Ex: 320020667
docker_password="abcdefghijkl"
docker_registry="hsop-local-docker.artifactory.pic.philips.com"
docker_registry='registry.it4rnd.philips.com'
docker_registry_directory="public_base_images/hsopmc"
docker_registry_directory="hsopmc"	

3. Execute the script
   bash push_images.sh
