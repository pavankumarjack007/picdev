import graphene

from .service_plan import ServicePlan


class CatalogSort(graphene.Enum):
    ALPHA_ASC = 1
    ALPHA_DESC = 2


class ServiceCatalog(graphene.ObjectType):
    name = graphene.String()
    plans = graphene.List(
        ServicePlan,
        sort=graphene.Argument(CatalogSort, default_value=CatalogSort.ALPHA_ASC.value),
    )

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_name(catalog, _):
        return catalog["name"]

    def resolve_plans(catalog, info, sort):
        plans = sorted(
            catalog["plans"],
            key=lambda p: ("0" if "s3_bucket" == p["name"] else p["name"].lower()),
            reverse=(sort == CatalogSort.ALPHA_DESC),
        )

        return plans
