import json

import graphene


class InstancePolicies(graphene.ObjectType):
    bucket = graphene.String()
    cors = graphene.String()
    lifecycle = graphene.String()

    ####################################################
    # Resolve Methods
    ####################################################

    def resolve_bucket(details, _):
        return json.dumps(details.policy, indent=2) if details.policy else None

    def resolve_cors(details, _):
        return json.dumps(details.cors, indent=2) if details.cors else None

    def resolve_lifecycle(details, _):
        return json.dumps(details.lifecycle, indent=2) if details.lifecycle else None
