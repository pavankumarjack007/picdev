from tests import BaseTestCase


class K8sClientTest(BaseTestCase):
    @classmethod
    def setUpClass(cls):
        pass
