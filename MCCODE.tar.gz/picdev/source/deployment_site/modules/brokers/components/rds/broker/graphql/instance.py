import graphene

from .event import Event
from .instance_details import InstanceDetails
from .log import Log
from .metric import Metric
from .snapshot import Snapshot


class LastOperationType(graphene.Enum):
    CREATE = 1
    UPDATE = 2
    DELETE = 3


class LastOperationState(graphene.Enum):
    IN_PROGRESS = 1
    SUCCEEDED = 2
    FAILED = 3


class LastOperation(graphene.ObjectType):
    type = graphene.Field(LastOperationType)
    state = graphene.Field(LastOperationState)
    description = graphene.String()
    updated_at = graphene.String()

    @staticmethod
    def resolve_type(self, _):
        switch = {
            'create': LastOperationType.CREATE,
            'update': LastOperationType.UPDATE,
            'delete': LastOperationType.DELETE
        }

        print(switch.get(self.get('type'), None))

        return switch.get(self.get('type'), None)

    @staticmethod
    def resolve_state(self, _):
        switch = {
            'in progress': LastOperationState.IN_PROGRESS,
            'succeeded': LastOperationState.SUCCEEDED,
            'failed': LastOperationState.FAILED
        }

        return switch.get(self.get('state'), None)

    @staticmethod
    def resolve_description(self, _):
        return self.get('description', None)

    @staticmethod
    def resolve_updated_at(self, _):
        return self.get('updated_at', None)


class Instance(graphene.ObjectType):
    guid = graphene.String()
    organization = graphene.String()
    space = graphene.String()
    name = graphene.String()
    created_at = graphene.String()
    plan_name = graphene.String()

    details = graphene.Field(InstanceDetails)
    snapshots = graphene.List(Snapshot)
    logs = graphene.List(Log)
    events = graphene.List(Event)
    metric = graphene.Field(Metric, metric=graphene.String())

    def resolve_created_at(instance, _):
        return instance.created_dt

    def resolve_details(instance, info):
        return info.context.instance_details(instance.guid)

    def resolve_snapshots(instance, info):
        return info.context.instance_snapshots(instance.guid)

    def resolve_logs(instance, info):
        return info.context.instance_logs(instance.guid)

    def resolve_events(instance, info):
        return info.context.instance_events(instance.guid)

    def resolve_metric(instance, info, metric):
        return info.context.instance_metrics(instance.guid, metric)

