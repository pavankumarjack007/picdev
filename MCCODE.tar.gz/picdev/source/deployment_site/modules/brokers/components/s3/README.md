# HSDP-S3 Service Broker for Cloud Foundry

[![Build](https://github.com/philips-internal/s3-service-broker/actions/workflows/build.yml/badge.svg)](https://github.com/philips-internal/s3-service-broker/actions/workflows/build.yml) 
[![Deploy](https://github.com/philips-internal/s3-service-broker/actions/workflows/deploy.yml/badge.svg)](https://github.com/philips-internal/s3-service-broker/actions/workflows/deploy.yml)
[![Documentation Status](https://repo-flair.cloud.phsdp.com/badges/jenkins/docs/s3-service-broker-docs)](https://jenkins.cloud.phsdp.com/job/s3-service-broker-docs/ "Documentation Status")
[![codecov](https://codecov.io/gh/philips-internal/s3-service-broker/branch/master/graph/badge.svg?token=242LEV4U23)](https://codecov.io/gh/philips-internal/s3-service-broker) 
[![Issues](https://repo-flair.cloud.phsdp.com/badges/jira/issues/CFSB?component=s3-service-broker)](https://healthsuite.atlassian.net/issues/?jql=project%20%3D%20CFSB%20AND%20resolution%20%3D%20Unresolved%20AND%20component%20%3D%20s3-service-broker "Issues") 
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black "Code style: black")

This is a [Cloud Foundry Service Broker](https://docs.cloudfoundry.org/services/overview.html) for the [Amazon Simple Cloud Storage Service (S3)](https://aws.amazon.com/s3/).

## Overview

A service provisioning call will create an S3 bucket and an IAM User with an inline IAM Policy to provide access controls on the bucket. A binding call will return the AWS access keys along with the S3 bucket name.

## Configuration

General configuration for the broker is provided by or overridden by the environment:

| Option                | Required | Type   | Description
|:----------------------|:--------:|:------ |:-----------
| BROKER_API_KEY        | Y        | String | Shared secret used to authorize requests from an HSDP Console application.
| BROKER_CONFIG         | Y        | String | Key specifying which configuration to use, e.g. `cloudfoundry`.  (Refer to [config.py](https://bitbucket.hsdp.io/projects/CFSB/repos/dynamodb-service-broker/browse/config.py) to see available keys.)
| BROKER_PASSWORD       | Y        | String | Broker Basic Auth Password
| BROKER_USERNAME       | Y        | String | Broker Basic Auth Username
| DYNAMODB_TABLE        | N        | String | DynamoDB table name for storing broker state.  Defaults to `hsdp_s3_service_broker`.  (If the table does not exist, it will be created.)
| ENCRYPTION_KEY        | Y        | String | Used to protect sensitive data stored in the Broker's DynamoDB table.
| HSDP_REGION           | Y        | String | Used to correlate the broker with a particular HSDP Console Dashboard, e.g. `na3`, `eu1`, etc..
| LOGGING_BLACKLIST     | N        | String | Comma-separated list of Python loggers whose output should be suppressed, e.g. `botocore.auth,botocore.session`.  Defaults to an empty list.
| LOGGING_LEVEL         | N        | String | Broker Python logging level.  Defaults to `INFO`.
| MAX_DOWNLOAD_SIZE     | N        | Number | The maximum size (in bytes) of an S3 object that the user will be allowed to download via the HSDP Console.  Default value is 32MB.

### AWS Credentials

| Option                       | Required | Type   | Description
|:-----------------------------|:--------:|:------ |:-----------
| AWS_ACCESS_KEY_ID            | Y        | String | The access key for the broker's AWS IAM user account.
| AWS_SECRET_ACCESS_KEY        | Y        | String | The secret key for the broker's AWS IAM user account.
| AWS_DEFAULT_REGION           | Y        | String | The AWS region associated with this broker, e.g. `us-west-1`, `us-west-2`, etc.

The broker's AWS IAM user policy must match the included [iam_policy.json](https://bitbucket.hsdp.io/projects/CFSB/repos/s3-service-broker/browse/iam_policy.json) file.

Additional AWS credentials can be supplied to allow the broker to provision S3 buckets across several accounts.  If additional credentials are supplied, the broker will create buckets in whichever account currently contains the fewest S3 bucket resources.

| Option                       | Required | Type   | Description
|:-----------------------------|:--------:|:------ |:-----------
| ADDTL_AWS_ACCESS_KEY_IDS     | N        | String | Comma-separated list of additional AWS access keys.
| ADDTL_AWS_SECRET_ACCESS_KEYS | N        | String | Comma-separated list of additional AWS secret keys.


### UAA Credentials

| Option                  | Required | Type   | Description
|:------------------------|:--------:|:------ |:-----------
| CF_API_ENDPOINT         | Y        | String | The API endpoint for the Cloud Foundry instance where this broker will be deployed.
| UAA_OAUTH_CLIENT_ID     | Y        | String | The unique identifier for the OAuth client that will be used by the broker to authenticate with the token server (UAA).
| UAA_OAUTH_CLIENT_SECRET | Y        | String | The shared secret the broker will use to authenticate with the token server (UAA).

The following command details the settings the UAA Client should possess:
```bash
uaac client add hsdp-s3-service-broker \
    --name 'HSDP S3 Service Broker' \
    --scope 'cloud_controller.read cloud_controller_service_permissions.read openid' \
    --authorized_grant_types 'refresh_token authorization_code' \
    --redirect_uri <BROKER_APP_ROUTE_URL> \
    --authorities uaa.none
```

## Development

A `Makefile` is provided to streamline setting up a development environment and running tests.

Run `make` by itself at the repository root to see a list of options.

Populate the generated `env/.env` file with `key=value` lines to provide environment variables to the `make` targets.

## Deployment

A Cloud Foundry manifest file is included in the repo for deployment as a Cloud Foundry application.  In order to push the app, you must provide a [variable substitution file](https://docs.cloudfoundry.org/devguide/deploy-apps/manifest.html#variable-substitution).

```bash
$ make -f deploy/Makefile
```

The above command will run the deployment in an isolated Docker container.  The variable substitution file will be automatically created (from the environment) and the application will be pushed to Cloud Foundry using a Blue/Green Deployment paradigm.