      sudo tee /usr/bin/ldap_pub_key >  /dev/null <<EOT
      #!/usr/bin/env bash
      uid=\$1
      binddn=\$(grep "^binddn.*" /etc/nslcd.conf| awk '{print \$2}')
      bindpw=\$(grep "^bindpw.*" /etc/nslcd.conf| awk '{print \$2}')
      ldap_uri=\$(grep "^uri.*" /etc/nslcd.conf| awk '{print \$2}')
      ldap_base=\$(grep "^base.*" /etc/nslcd.conf| awk '{print \$2}')
      ldapsearch -x -H "\$ldap_uri" -b "\$ldap_base" -D "\$binddn" -w "\$bindpw" '(&(objectClass=posixAccount)(uid='"\$uid"'))' \
              'sshPublicKey' | sed -n '/^ /{H;d};/sshPublicKey:/x;\$g;s/\\n *//g;s/sshPublicKey: //gp'
      EOT
      sudo sed -i "s/\\//g" /usr/bin/ldap_pub_key
      sudo chmod +x /usr/bin/ldap_pub_key
      sudo sed -i "s/^PasswordAuthentication.*/PasswordAuthentication no/g" /etc/ssh/sshd_config
      sudo sed -i "s/^#PubkeyAuthentication yes/PubkeyAuthentication yes/g" /etc/ssh/sshd_config
      sudo sed -i "s%^#AuthorizedKeysCommand none%AuthorizedKeysCommand /usr/bin/ldap_pub_key%g" /etc/ssh/sshd_config
      sudo sed -i "s%^#AuthorizedKeysCommandUser nobody%AuthorizedKeysCommandUser root%g" /etc/ssh/sshd_config
      sudo systemctl restart sshd
      sudo systemctl restart systemd-logind
      sudo pam-auth-update --enable mkhomedir
      sudo /etc/init.d/nscd restart
      sudo /etc/init.d/nslcd restart

