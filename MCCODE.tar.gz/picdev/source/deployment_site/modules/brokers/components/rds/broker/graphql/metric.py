import graphene


class Metric(graphene.ObjectType):
    current_value = graphene.String()
    x_values = graphene.List(graphene.String)
    y_values = graphene.List(graphene.String)
    label = graphene.String()
