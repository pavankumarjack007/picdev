#!/bin/bash
now=$(date +'%Y-%m-%d-%H-%M-%S')
bash build_report.sh
cat deployment_details.txt ../../smoke/scripts/k8s_smoke_result_*.txt ../../smoke/scripts/kubecf_smoke_result*.txt | sed -r "s/\x1B\[([0-9]{1,3}(;[0-9]{1,2})?)?[mGK]//g" >test_result_${now}.txt
./text2pdf   ./test_result_${now}.txt >../${TF_VAR_cluster_name}_result_${now}.pdf
rm ../../smoke/scripts/k8s_smoke_result_*.txt
rm ../../smoke/scripts/kubecf_smoke_result*.txt
cat test_result_${now}.txt
rm test_result_${now}.txt
rm deployment_details.txt