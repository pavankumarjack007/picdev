package testframe

import (
	"bytes"
	"crypto/tls"
	"fmt"
	"os"
	"testing"

	"encoding/json"
	"io/ioutil"

	http_helper "github.com/gruntwork-io/terratest/modules/http-helper"

	"github.com/gruntwork-io/terratest/modules/terraform"

	"github.com/stretchr/testify/assert"
	"github.com/zclconf/go-cty/cty"

	"github.com/hashicorp/hcl"
	"github.com/hashicorp/hcl2/gohcl"
	"github.com/hashicorp/hcl2/hclwrite"
)

func GetTestDeifinition(name string) TestCaseDefintion {

	return TestCaseDefintion{}
}

func Test_assert_output_delegate(t *testing.T) {

	t.Name()
	var testDef = GetTestDeifinition(t.Name())
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: testDef.Modulepath,
		//Vars: testDef.In_params_values,
	})

	// fill the variables

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

	output := terraform.Output(t, terraformOptions, "ten_tke_k8s_cf_kubernetes_cluster")
	fmt.Println(output)
	assert.Equal(t, "1623647003336954300", output)

}

func Test_assert_output(t *testing.T) {

	t.Run("Test_assert_output", func(t *testing.T) {
		for i := 0; i < len(data.AllTestCases); i++ {
			t.Run(data.AllTestCases[i].TestName, Test_assert_output_delegate)
		}
	})

}

var data AllTestCaseDefintion

//////##################

type MyTestCase struct {
	Name    string    `hcl:"name,label"`
	Outputs []string  `hcl:"outputs"`
	Inputs  cty.Value `hcl:"inputs"`
}
type Constraints struct {
	OS   string `hcl:"os"`
	Arch string `hcl:"arch"`
}
type App struct {
	Name string `hcl:"name"`
	Desc string `hcl:"description"`
	//	Constraints *Constraints `hcl:"constraints,block"`
	TestCases []MyTestCase `hcl:"mytestcase,block"`
}

///##################
//https://gitmemory.com/issue/zclconf/go-cty/17/508413998

func Test_Serialize_test(t *testing.T) {
	//tcDef := &TestCaseDefintion{TestName: "TestIt", Modulepath: "sfdsf", In_params_values: map[string]string{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}, Out_params_values: map[string]string{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}}
	// allTcDef := //&AllTestCaseDefintion{TestName: "sdfsf", Modulepath: "dsdfs"}

	// 	&AllTestCaseDefintion{AllTestCases: []TestCaseDefintion{
	// 		{TestName: "TestIt", Modulepath: "sfdsf", In_params_values: map[string]interface{}{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}, Out_params_values: map[string]interface{}{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}},
	// 		{TestName: "TestIt", Modulepath: "sfdsf", In_params_values: map[string]interface{}{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}, Out_params_values: map[string]interface{}{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}},
	// 		{TestName: "TestIt", Modulepath: "sfdsf", In_params_values: map[string]interface{}{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}, Out_params_values: map[string]interface{}{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}}}}

	// f := hclwrite.NewEmptyFile()
	// bdy := f.Body()
	// //gohcl.EncodeIntoBody(allTcDef, bdy)
	// s := string(f.Bytes())
	// fmt.Println(s)

	fakeInputs := cty.ObjectVal(map[string]cty.Value{
		"living": cty.StringVal("sdfsdf"),
		"age":    cty.NumberIntVal(123),
	})

	app := App{
		Name: "awesome-app",
		Desc: "Such an awesome application",
		TestCases: []MyTestCase{
			{
				Name:    "Test1",
				Outputs: []string{"./web", "--listen=:8080"},
				Inputs:  fakeInputs,
				// map[string]cty.Value{
				// 	"living": cty.StringVal("sdfsdf"),
				// 	"age":    cty.NumberIntVal(123),
				// },
			},
			{
				Name:    "Test1",
				Outputs: []string{"./web", "--listen=:8080"},
				Inputs:  fakeInputs,
				// map[string]cty.Value{
				// 	"living": cty.StringVal("sdfsdf"),
				// 	"age":    cty.NumberIntVal(123),
				// },
			},
		},
	}
	var TcDef map[string]interface{}

	f := hclwrite.NewEmptyFile()
	gohcl.EncodeIntoBody(&app, f.Body())
	sapp := string(f.Bytes())
	//ioutil.WriteFile("test.json", sapp, 0777)

	fmt.Println(sapp)

	appRead := App{}
	//appmapRead := map[string]interface{}{}

	file, _ := ioutil.ReadFile("test.json")

	sappread := string([]byte(file))

	err := hcl.Decode(&appRead, sappread)

	fmt.Println(err)
	inputs := appRead.TestCases[0].Inputs

	fmt.Println(inputs)

	//gohcl.DecodeBody(fileread.Body, nil, &TcDef)

	//type tempstruct struct {
	//	var TcDef map[string]interface{}
	//}
	//readAllTcDef := tempstruct{}

	//file, _ := ioutil.ReadFile("test.json")

	ss := string([]byte(file))
	fmt.Println(ss)
	hcl.Decode(TcDef, ss)
	//_ = hcl.Unmarshal([]byte(file), &readAllTcDef)

	fmt.Println(TcDef)
	/*
		jsonText, err := yaml.Marshal(allTcDef)
		ioutil.WriteFile("test.json", jsonText, 0777)

		fmt.Println(err)

		file, _ := ioutil.ReadFile("test.json")

		data := AllTestCaseDefintion{}

		_ = json.Unmarshal([]byte(file), &data)

	*/

}

func Test_serialize(t *testing.T) {

	myMap := AllTestCases{

		[]Test_Case{
			{
				"Test case name -1 ",
				"path of the module",
				"path of tfvar file ",

				[]Validation_Case{
					{
						/// Input_params
						map[string]interface{}{

							"param_int":    3435435,
							"param_string": "string",
							"param_map": map[string]interface{}{
								"param_int":    32434,
								"param_string": "string",
							},
							"param_list": []interface{}{"string_1", 344324, "string_2", 1232.432},
						},

						map[string]interface{}{

							"foo_foo": 3435435,
							"bar_baz": "cty.StringVal(sfddfs)",
							"listit":  []interface{}{"sdfsdf", 344324, "sfsfds"},
						},
						TFOut,
					},
				},
			},

			{
				"Test case name -2 ",
				"path of the module",
				"path of tfvar file ",
				[]Validation_Case{
					{
						/// Input_params
						map[string]interface{}{

							"param_int":    3435435,
							"param_string": "string",
							"param_map": map[string]interface{}{
								"param_int":    32434,
								"param_string": "string",
							},
							"param_list": []interface{}{"string_1", 344324, "string_2", 1232.432},
						},

						map[string]interface{}{

							"foo_foo": 3435435,
							"bar_baz": "cty.StringVal(sfddfs)",
							"listit":  []interface{}{"sdfsdf", 344324, "sfsfds"},
						},

						SSH,
					},
				},
			},
		},
	}
	myMapRead := AllTestCases{}
	buf, err := json.Marshal(myMap)
	//errr := json.Unmarshal(buf, &myMapRead )
	fmt.Println(string([]byte(buf)))

	//errr := hcl.Decode(&myMapRead, string([]byte(buf)))
	errr := json.Unmarshal(buf, &myMapRead)

	buf1, err1 := json.Marshal(myMapRead)
	fmt.Println(string([]byte(buf1)))

	fmt.Println(err, errr, err1)

}

func Test_output_asserting(t *testing.T) {

	// tcDef := &TestCaseDefintion{TestName: "TestIt", Modulepath: "sfdsf", In_params_values: map[string]interface{}{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}, Out_params_values: map[string]interface{}{"sfsdf": "sdfdsf", "sdfsfds": "sdfsdfd"}}

	// jsonText, err := json.Marshal(tcDef)
	// ioutil.WriteFile("test.json", jsonText, 0777)

	//fmt.Println(err)

	allTestDefs := GetTestDinitions()
	testCases := allTestDefs.AllTestCases

	t.Run("assert_output", func(t *testing.T) {

		for i := 0; i < len(testCases); i++ {

			t.Run(testCases[i].Name, func(t *testing.T) {

				var inputVars map[string]interface{} = GetInputParams(testCases[i], t)

				terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
					TerraformDir: testCases[i].Module_path,
					Vars:         inputVars,
				})

				// fill the variables

				defer terraform.Destroy(t, terraformOptions)

				terraform.InitAndApply(t, terraformOptions)

				outValid := ValidateOutput(terraform.OutputAll(t, terraformOptions), testCases[i], t) //(t, terraformOptions, "ten_tke_k8s_cf_kubernetes_cluster")

				assert.True(t, outValid)
			})
		}

	})

}

func Test_service_endpoint(t *testing.T) {

	//http_helper.HttpGetWithRetry(t, "http://google.com", nil, 200, "Hello, World!", 30, 5*time.Second)
	os.Setenv("https_proxy", "http://185.46.212.98:10015")
	os.Setenv("http_proxy", "http://185.46.212.98:10015")
	http_helper.HTTPDo(t, "GET", "https://google.com", bytes.NewReader([]byte("sdfsfdsf")), nil, &tls.Config{})

}
