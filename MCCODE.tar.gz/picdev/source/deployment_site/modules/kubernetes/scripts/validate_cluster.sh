#! /bin/bash

export KOPS_STATE_STORE=${1}
MASTERCOUNT=$TF_VAR_master_count
PROFILE=$TF_VAR_profile
ENV=$TF_VAR_environment
#Update kops config
chmod +x ./proxy_aware_kops_export_kubecfg.sh
./proxy_aware_kops_export_kubecfg.sh ${2}

kops validate cluster ${2} --wait 20m --count 3

if [[ "$PROFILE" == "small" ]] && [[ "$ENV" == "prod"  ]]
then
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_small_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_small_outposts_ebs.yaml)
  let "total_nodes=$NODE_COUNT+$MASTER_COUNT"
elif [[ "$PROFILE" == "small" ]] && [[ "$ENV" != "prod"  ]]
then
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_small_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_small_outposts_ebs.yaml)
  let "total_nodes=$NODE_COUNT+$MASTER_COUNT"
elif [[ "$PROFILE" == "large" ]]; then
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_large_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_large_outposts_ebs.yaml)
  LG_NODE_COUNT=$(yq eval .spec.workers.count2 ../plans/plan_large_outposts_ebs.yaml)
  let "total_nodes=$NODE_COUNT+$LG_NODE_COUNT+$MASTER_COUNT"
elif [[ "$PROFILE" == "medium" ]]; then
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_medium_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_medium_outposts_ebs.yaml)
  LG_NODE_COUNT=$(yq eval .spec.workers.count2 ../plans/plan_medium_outposts_ebs.yaml)
  let "total_nodes=$NODE_COUNT+$LG_NODE_COUNT+$MASTER_COUNT"
elif [[ "$PROFILE" == "xlarge" ]]; then
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_extra_large_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_extra_large_outposts_ebs.yaml)
  LG_NODE_COUNT=$(yq eval .spec.workers.count2 ../plans/plan_extra_large_outposts_ebs.yaml)
  let "total_nodes=$NODE_COUNT+$LG_NODE_COUNT+$MASTER_COUNT"
fi

#verify cluster is "up"
while : ; do
    echo "Checking the number of nodes that are ready"
    result=$(kubectl get nodes | grep Ready | grep -v NotReady | wc -l)
    echo "Expecting $total_nodes .. Current $result"
    if [[ $result -eq $total_nodes ]]
    then
      break
    fi
    sleep 10
done

#Adding timeout of 60 seconds for volume creation 
kubectl patch deployment \
  ebs-csi-controller \
  --namespace  kube-system \
  --type='json' \
  -p='[{"op": "add", "path": "/spec/template/spec/containers/1/args", "value": [
  "--csi-address=$(ADDRESS)",
  "--v=5",
  "--feature-gates=Topology=true",
  "--leader-election=true",
  "--extra-create-metadata=true",
  "--default-fstype=ext4",
  "--timeout=60s"
]}]'
