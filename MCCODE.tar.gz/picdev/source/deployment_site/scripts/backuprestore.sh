#! /bin/bash

set -e

getopts-extra () {
    declare i=1
    while [[ ${OPTIND} -le $# && ${!OPTIND:0:1} != '-' ]]; do
        OPTARG[i]=${!OPTIND}
        let i++ OPTIND++
    done
}

login_to_k8s(){
  found=$(aws s3 ls s3://$TF_VAR_bucket_name/kops/ | grep $TF_VAR_cluster_name | wc -l)
  if [[ $found -eq 1 ]];
  then
    (
      scripts="$modules/kubernetes/scripts"
      cd $scripts
      export KOPS_STATE_STORE="s3://${TF_VAR_bucket_name}/kops"
      chmod +x proxy_aware_kops_export_kubecfg.sh
      ./proxy_aware_kops_export_kubecfg.sh $TF_VAR_cluster_name >/dev/null
    )
  fi
}

verify_velero_exists(){
  found=$(kubectl -n velero get pods -l component=velero --no-headers -o custom-columns=":metadata.name" | grep velero | wc -l)
  if [[ $found -eq 0 ]]
  then
    cat << EOF
Unable to find HSOP backup module

  * Ensure the backup module is installed
  * Run deploy.sh script with a configuration file that includes the module named backup
EOF
    exit 0
  fi
}

run_velero_command(){
  kubectl -n velero exec $(kubectl -n velero get pods -l component=velero --no-headers -o custom-columns=":metadata.name" | grep velero) -c velero -- ./velero ${args[@]}
}

while getopts p:a: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        p) vars=${OPTARG};;
        a) getopts-extra "$@"
           args=( "${OPTARG[@]}" )
           ;;
    esac
done

## Setup paths for modules, configuration & profile
deployment="$(dirname $(dirname $(realpath $0)) )"
modules="$(dirname $(dirname $(realpath $0)) )/modules"
config="$(dirname $(dirname $(realpath $0)) )/configuration/${conf}.txt"
profile="$(dirname $(dirname $(realpath $0)) )/profiles/${vars}.tfvars"

## Setup env vars for terraform
chmod +x ./setup_env_vars.sh
source ./setup_env_vars.sh $profile

login_to_k8s
verify_velero_exists
run_velero_command