# pytest-example
pytest --html=report.html

## Code Structure

```

tests/
    __init__.py
    test_app.py
    mymodule/
         __init__.py
         test_xyz.py
         test_xyzz.py
```
###System should have
- CF cli
- kubectl
- Python and pip
- Vault client
- credhub

### export vars
- Fill export vars
- provide cluster name in conftest.py