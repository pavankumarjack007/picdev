import json
import unittest
from functools import partial

import boto3
from awspolicy import BucketPolicy
from awsretry import AWSRetry
from botocore.exceptions import ClientError
from cf_broker_api.testing import TestClient
from jinja2 import Environment
from nose.tools import assert_equal, assert_in, assert_is_not_none, assert_true

import broker.aws as aws
import broker.model as model
import broker.service as service
import broker.utils as utils
from broker import create_broker
from tests import example_lifecycle, legacy_policy, sts_policy, test_config, test_data


def teardown_module():
    broker_state = model.get_broker_model(test_config)
    broker_client = TestClient(create_broker(config_name="testing").test_client())
    # Delete any bucket resources created during testing.
    for item in broker_state.scan():
        # Just an extra safety check...
        assert_true(item.bucket.startswith("test-cf-s3"))
        data = {
            "instance_id": item.instance_id,
            "service_id": item.service_id,
            "plan_id": item.plan_id,
        }
        resp = broker_client.deprovision(data)
        assert_equal(
            resp.last_resp.status_code, 410, resp.last_resp.json.get("description")
        )
    # Remove DynamoDB table.
    broker_state.delete_table()


def get_s3_client_from_credentials(credentials):
    session = boto3.Session(
        aws_access_key_id=credentials["api_key"],
        aws_secret_access_key=credentials["secret_key"],
        region_name=test_config.AWS_DEFAULT_REGION,
    )
    s3_client = session.client("s3")
    return s3_client


def wait_for_resource_availability(bucket_name, ctx):
    try:
        waiter = ctx.s3_client.get_waiter("bucket_exists")
        waiter.wait(Bucket=bucket_name)
        waiter = ctx.iam_client.get_waiter("user_exists")
        waiter.wait(UserName=bucket_name)
    except Exception as e:
        # TODO: Should be able to remove this once s3v4 issues are addressed.
        # See https://healthsuite.atlassian.net/browse/CFSB-15
        print(str(e))


# We use a test generator here (nosetest feature), so we can't subclass unittest.TestCase.
class TestBucketOperations(object):
    class TestAWSContextManager(aws.ContextManager):
        """
        Special version of the AWS Context Manager class, which overrides the
        'account_with_fewest_buckets' property, allowing us to explicitly
        control the account where our test buckets will be created.
        """

        def __init__(self, primary_credentials, addtl_credentials, creds_to_test):
            super(TestBucketOperations.TestAWSContextManager, self).__init__(
                primary_credentials, addtl_credentials
            )
            # Here's our special override
            self.creds_to_test = creds_to_test

        @property
        def account_with_fewest_buckets(self):
            return self.creds_to_test

    class TestS3Service(service.S3ServiceInstanceService):
        """
        Special version of the S3ServiceInstanceService Context, which makes
        use of our TestAWSContextManager class.
        """

        def __init__(self, db_model, configuration, aws_config=None):
            super(TestBucketOperations.TestS3Service, self).__init__(
                db_model, configuration
            )
            self.aws_ctx_mngr = TestBucketOperations.TestAWSContextManager(
                primary_credentials=self.config.aws_config,
                addtl_credentials=self.config.addtl_aws_credentials,
                creds_to_test=aws_config,
            )

    @classmethod
    def setup_class(cls):
        cls.config = test_config
        cls.model = model.get_broker_model(cls.config)
        cls.all_aws_credentials = [
            cls.config.aws_config
        ] + cls.config.addtl_aws_credentials

    def _set_aws_context(self, aws_config):
        service_class = TestBucketOperations.TestS3Service(
            db_model=self.model, configuration=self.config, aws_config=aws_config
        )
        self.app = create_broker(config_name="testing", service_class=service_class)
        self.test_client = TestClient(self.app.test_client())
        self.s3_client = boto3.client("s3", **aws_config)
        self.s3_resource = boto3.resource("s3", **aws_config)
        self.iam_client = boto3.client("iam", **aws_config)
        self.s3 = aws.S3(**aws_config)

    @staticmethod
    def bucket_operations(ctx, creds):
        ctx._set_aws_context(creds)
        data = test_data()
        # Provision
        resp = ctx.test_client.provision(data)
        assert_equal(resp.status_code, 202)
        assert_equal(
            resp.last_resp.status_code, 200, resp.last_resp.json.get("description")
        )
        wait_for_resource_availability(data["bucket"], ctx)
        bucket = ctx.s3_resource.Bucket(data["bucket"])
        bucket_location = ctx.s3_client.get_bucket_location(Bucket=bucket.name)
        location_constraint = ctx.app.service_class.get_location_constraint(
            data["plan"], {}
        )
        assert_equal(location_constraint, bucket_location["LocationConstraint"])
        user = ctx.iam_client.get_user(UserName=bucket.name)["User"]
        assert_is_not_none(user)
        db_record = ctx.model.get(data["instance_id"])
        assert_is_not_none(db_record)
        # Update
        data["parameters"] = {"BucketLifecycle": example_lifecycle}
        resp = ctx.test_client.update(data)
        assert_equal(resp.status_code, 202)
        assert_equal(
            resp.last_resp.status_code, 200, resp.last_resp.json.get("description")
        )
        # Deprovision
        resp = ctx.test_client.deprovision(data)
        assert_equal(resp.status_code, 202)
        assert_equal(
            resp.last_resp.status_code, 410, resp.last_resp.json.get("description")
        )

    def test_basic_bucket_functions(self):
        for creds in self.all_aws_credentials:
            f = partial(self.bucket_operations, self, creds)
            aws_account = aws.get_aws_account_id_from_credentials(**creds)
            f.description = (
                "test bucket provision/update/deprovision in AWS "
                "account {}".format(aws_account)
            )
            yield (f,)

    @staticmethod
    def provision_plan(ctx, plan):
        data = test_data(plan_id=plan["id"])
        resp = ctx.test_client.provision(data)
        assert_equal(resp.status_code, 202)
        assert_equal(
            resp.last_resp.status_code, 200, resp.last_resp.json.get("description")
        )
        wait_for_resource_availability(data["bucket"], ctx)
        bucket = ctx.s3_resource.Bucket(data["bucket"])
        bucket_location = ctx.s3_client.get_bucket_location(Bucket=bucket.name)
        location_constraint = ctx.app.service_class.get_location_constraint(plan, {})
        assert_equal(location_constraint, bucket_location["LocationConstraint"])

    def test_each_plan(self):
        self._set_aws_context(self.config.aws_config)
        for plan in self.app.service_catalog.services[0]["plans"]:
            f = partial(self.provision_plan, self, plan)
            f.description = "test provision plan {}".format(plan["name"])
            yield (f,)

    @staticmethod
    def verify_iam_policy(ctx, policy_arn, required_policy):
        policy = ctx.iam_client.get_policy(PolicyArn=policy_arn)
        policy_version = ctx.iam_client.get_policy_version(
            PolicyArn=policy_arn, VersionId=policy["Policy"]["DefaultVersionId"]
        )
        iam_policy = policy_version["PolicyVersion"]["Document"]
        # If the policies differ, we want to see all differences.
        # noinspection PyUnresolvedReferences
        assert_equal.__self__.maxDiff = None
        assert_equal(iam_policy, required_policy)

    def test_iam_policy_permissions(self):
        for creds in self.all_aws_credentials:
            self._set_aws_context(creds)
            aws_partition = self.s3.partition
            with open("iam_policy.json") as f:
                required_policy = json.loads(
                    f.read().replace(":aws:", ":{}:".format(aws_partition))
                )
            aws_account = aws.get_aws_account_id_from_credentials(**creds)
            policy_arn = "arn:{}:iam::{}:policy/hsdp-s3-service-broker".format(
                aws_partition, aws_account
            )
            f = partial(self.verify_iam_policy, self, policy_arn, required_policy)
            f.description = "verify iam policy in AWS account {}".format(aws_account)
            yield (f,)

    @staticmethod
    def verify_sts_access(ctx):
        data = test_data()
        ctx.test_client.provision(data)
        resp = ctx.test_client.bind(data)
        sts_client = boto3.client(
            "sts",
            aws_access_key_id=resp.json["credentials"]["api_key"],
            aws_secret_access_key=resp.json["credentials"]["secret_key"],
        )
        policy = (
            Environment()
            .from_string(sts_policy)
            .render(aws_instance_id=data["bucket"], partition=ctx.s3.partition)
        )

        @AWSRetry.backoff(
            tries=30, delay=3, added_exceptions=["InvalidClientTokenId", "AccessDenied"]
        )
        def get_federation_token():
            response = sts_client.get_federation_token(
                Name="test-sts-user", Policy=policy
            )
            return response

        sts_credentials = get_federation_token()["Credentials"]
        s3_client = boto3.client(
            "s3",
            aws_access_key_id=sts_credentials["AccessKeyId"],
            aws_secret_access_key=sts_credentials["SecretAccessKey"],
            aws_session_token=sts_credentials["SessionToken"],
        )
        resp = s3_client.list_objects(Bucket=data["bucket"])
        assert_equal(resp["ResponseMetadata"]["HTTPStatusCode"], 200)

    def test_sts_federation_token_access(self):
        for creds in self.all_aws_credentials:
            self._set_aws_context(creds)
            aws_account = aws.get_aws_account_id_from_credentials(**creds)
            f = partial(self.verify_sts_access, self)
            f.description = "verify sts access in AWS account {}".format(aws_account)
            yield (f,)

    def test_bucket_policy(self):
        self._set_aws_context(self.config.aws_config)
        data = test_data()
        self.test_client.provision(data)

        # Verify accessibility by bucket owner
        credentials = self.test_client.bind(data).json["credentials"]
        s3_client = get_s3_client_from_credentials(credentials)

        @AWSRetry.backoff(
            tries=8, delay=3, added_exceptions=["InvalidAccessKeyId", "AccessDenied"]
        )
        def exercise_bucket():
            s3_client.put_object(
                Bucket=credentials["bucket"],
                Key="encrypted-key",
                Body=b"test encrypted bytes",
                ServerSideEncryption="AES256",
            )
            s3_client.get_object(Bucket=credentials["bucket"], Key="encrypted-key")
            resp = s3_client.list_objects_v2(Bucket=credentials["bucket"])
            assert_equal(len(resp["Contents"]), 1)

        exercise_bucket()

        fake_user_arn = "arn:aws:iam::012345678901:user/auser"
        data["parameters"] = {
            "EnforceServerSideEncryption": True,
            "EnforceSecureCommunications": True,
            "GrantAccess": [fake_user_arn, "emr"],
        }
        resp = self.test_client.update(data)
        assert_equal(resp.status_code, 202, resp)
        assert_equal(
            resp.last_resp.status_code, 200, resp.last_resp.json.get("description")
        )

        policy = BucketPolicy(serviceModule=s3_client, resourceIdentifer=data["bucket"])
        assert_in("GrantServiceAccess", policy.sids)
        grant_condition = policy.select_statement("GrantServiceAccess").Condition
        granted_org_guid = grant_condition["StringEquals"][
            "aws:PrincipalTag/Organization ID"
        ]
        assert_equal(granted_org_guid, data["organization_guid"])
        granted_aws_org = grant_condition["StringEquals"]["aws:PrincipalOrgID"]
        assert_equal(
            granted_aws_org, aws.get_aws_organization_id(**test_config.aws_config)
        )

        # Verify continued accessibility by bucket owner
        credentials = self.test_client.bind(data).json["credentials"]
        s3_client = get_s3_client_from_credentials(credentials)

        exercise_bucket()


class TestLegacyFunctionality(unittest.TestCase):

    model = None
    test_client = None

    @classmethod
    def setUpClass(cls):
        cls.config = test_config
        cls.model = model.get_broker_model(cls.config)
        cls.app = create_broker(config_name="testing")
        cls.test_client = TestClient(cls.app.test_client())
        cls.s3 = aws.S3(**test_config.aws_config)
        session = boto3.Session(**cls.config.aws_config)
        cls.s3_resource = session.resource(
            "s3", region_name=cls.s3.default_location_constraint
        )
        cls.s3_client = cls.s3_resource.meta.client
        cls.iam_client = session.client("iam")

    def test_broker_schema_change(self):
        data = test_data()
        credentials = {
            "api_key": "api-key",
            "bucket": data["bucket"],
            "endpoint": "s3-us-west-2.amazonaws.com",
            "location_constraint": None,
            "secret_key": "secret-key",
            "uri": "",
        }
        iv = utils.generate_iv()
        encrypted_creds = utils.encrypt_data(
            data=json.dumps(credentials), iv=iv, key=self.config.ENCRYPTION_KEY
        )
        dynamodb = boto3.resource("dynamodb", **self.config.aws_config)
        table = dynamodb.Table(self.config.DYNAMODB_TABLE)
        # Generate record using old schema (with credentials and iv attributes).
        table.put_item(
            Item={
                "instance_id": data["instance_id"],
                "organization_guid": data["organization_guid"],
                "plan_id": data["plan_id"],
                "service_id": data["service_id"],
                "space_guid": data["space_guid"],
                "binding_ids": [],
                "credentials": encrypted_creds,
                "iv": iv,
                "region_name": None,
            }
        )
        # Now read it in with new model.
        record = self.model.get(data["instance_id"])
        self.assertEqual(record.iam_user.access_key_id, credentials["api_key"])
        self.assertEqual(record.iam_user.secret_access_key, credentials["secret_key"])
        self.assertEqual(record.bucket, credentials["bucket"])
        self.assertIsNone(record.region_name)
        self.assertIsNone(record._iv)
        self.assertIsNone(record._encrypted_credentials)
        self.assertEqual(record.last_operation_state, "failed")
        self.assertFalse(record.deleted)
        record.delete()

    def test_legacy_bucket_policy_update(self):
        data = test_data()
        create_args = {"Bucket": data["bucket"]}
        location_constraint = self.app.service_class.get_location_constraint(
            data["plan"], {}
        )
        if location_constraint:
            bucket_config = {"LocationConstraint": location_constraint}
            create_args["CreateBucketConfiguration"] = bucket_config
        self.s3_client.create_bucket(**create_args)
        self.iam_client.create_user(UserName=data["bucket"])
        waiter = self.s3_client.get_waiter("bucket_exists")
        waiter.wait(Bucket=data["bucket"])
        waiter = self.iam_client.get_waiter("user_exists")
        waiter.wait(UserName=data["bucket"])
        policy = (
            Environment()
            .from_string(legacy_policy)
            .render(aws_instance_id=data["bucket"], partition=self.s3.partition)
        )
        policy_obj = self.iam_client.create_policy(
            PolicyName=data["bucket"], PolicyDocument=policy
        )
        legacy_policy_arn = policy_obj["Policy"].pop("Arn")
        self.iam_client.attach_user_policy(
            UserName=data["bucket"], PolicyArn=legacy_policy_arn
        )
        keys = self.iam_client.create_access_key(UserName=data["bucket"])
        api_key = keys["AccessKey"].pop("AccessKeyId")
        secret_key = keys["AccessKey"].pop("SecretAccessKey")
        credentials = {
            "api_key": api_key,
            "bucket": data["bucket"],
            "endpoint": "",
            "location_constraint": None,
            "secret_key": secret_key,
            "uri": "",
        }
        iv = utils.generate_iv()
        encrypted_creds = utils.encrypt_data(
            data=json.dumps(credentials), iv=iv, key=self.config.ENCRYPTION_KEY
        )
        dynamodb = boto3.resource("dynamodb", **self.config.aws_config)
        table = dynamodb.Table(self.config.DYNAMODB_TABLE)
        # Generate record using old schema (with credentials field).
        table.put_item(
            Item={
                "instance_id": data["instance_id"],
                "organization_guid": data["organization_guid"],
                "plan_id": data["plan_id"],
                "service_id": data["service_id"],
                "space_guid": data["space_guid"],
                "binding_ids": [],
                "region_name": None,
                "credentials": encrypted_creds,
                "iv": iv,
            }
        )
        # Now we have a legacy bucket, iam user, attached policy, and dynamo record.
        data["parameters"] = {"RefreshPolicy": True}
        resp = self.test_client.update(data)
        self.assertEqual(resp.status_code, 202)
        assert_equal(
            resp.last_resp.status_code, 200, resp.last_resp.json.get("description")
        )
        # Dedicated policy should have been removed.
        with self.assertRaises(ClientError) as context:
            self.iam_client.get_policy(PolicyArn=legacy_policy_arn)
        self.assertIn("NoSuchEntity", str(context.exception))


def test_bucket_upload():
    app = create_broker("testing")
    client = TestClient(app.test_client(), last_op_delay=60)
    data = test_data()
    client.provision(data)
    credentials = client.bind(data).json["credentials"]
    s3_client = get_s3_client_from_credentials(credentials)
    # We do not enable server-side encryption by default,
    # so both of these puts should succeed.
    s3_client.put_object(
        Bucket=data["bucket"], Key="unencrypted-key", Body=b"test bytes"
    )
    s3_client.put_object(
        Bucket=data["bucket"],
        Key="encrypted-key",
        Body=b"test encrypted bytes",
        ServerSideEncryption="AES256",
    )
    resp = s3_client.list_objects_v2(Bucket=data["bucket"])
    assert_equal(len(resp["Contents"]), 2)


def test_bucket_upload_encrypted():
    app = create_broker("testing")
    client = TestClient(app.test_client(), last_op_delay=60)
    data = test_data(parameters={"EnforceServerSideEncryption": True})
    client.provision(data)
    credentials = client.bind(data).json["credentials"]
    s3_client = get_s3_client_from_credentials(credentials)
    # We expect the unencrypted upload to fail.
    try:
        s3_client.put_object(
            Bucket=data["bucket"], Key="unencrypted-key", Body=b"test bytes"
        )
    except ClientError as e:
        if e.response["Error"]["Code"] != "AccessDenied":
            raise
    s3_client.put_object(
        Bucket=data["bucket"],
        Key="encrypted-key",
        Body=b"test encrypted bytes",
        ServerSideEncryption="AES256",
    )
    resp = s3_client.list_objects_v2(Bucket=data["bucket"])
    assert_equal(len(resp["Contents"]), 1)


def test_bucket_object_tagging():
    app = create_broker("testing")
    client = TestClient(app.test_client(), last_op_delay=60)
    data = test_data()
    client.provision(data)
    credentials = client.bind(data).json["credentials"]
    s3_client = get_s3_client_from_credentials(credentials)
    obj_key = "test-object-key"
    tag_set = {"TagSet": [{"Key": "PHI", "Value": "true"}]}
    s3_client.put_object(Bucket=data["bucket"], Key=obj_key, Body=b"test bytes")
    # Test Tagging.
    s3_client.put_object_tagging(Bucket=data["bucket"], Key=obj_key, Tagging=tag_set)
    resp = s3_client.get_object_tagging(Bucket=data["bucket"], Key=obj_key)
    assert_equal(resp["TagSet"], tag_set["TagSet"])
    # Test Tag Deletion.
    s3_client.delete_object_tagging(
        Bucket=data["bucket"],
        Key=obj_key,
    )
    resp = s3_client.get_object_tagging(Bucket=data["bucket"], Key=obj_key)
    assert_equal(len(resp["TagSet"]), 0)
