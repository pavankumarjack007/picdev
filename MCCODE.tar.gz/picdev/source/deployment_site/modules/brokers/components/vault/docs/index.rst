===========================================
HSDP-Vault Service Broker for Cloud Foundry
===========================================

.. toctree::
     :maxdepth: 2

Introduction
============

HSDP-Vault is a Cloud Foundry service broker for secure secret storage and
KMS features using `Vault <https://www.vaultproject.io/intro/index.html>`_.
Vault backend services are operated by HSDP.

The broker provides a bindable service that returns Vault
credentials. These credentials can be used by an application, or a human
(who can obtain credentials by creating a service key against a Vault
service instance) to authenticate to a regional Vault cluster and obtain
a Vault client token.

The client token has a Vault ACL policy allowing access to the following
Vault services:

- **Secret storage**: Read and write secrets or other sensitive runtime
  data to a durable storage path within Vault. Data written to this path
  are encrypted by Vault and unreadable without the Vault service itself
  and possession of a valid client token with permission to read the data

- **KMS (Key Management Service)**: Access to the Vault 'transit' backend.
  This is a unique encryption service which is similar in some respects to
  `AWS KMS <https://docs.aws.amazon.com/kms/latest/developerguide/concepts.html>`_,
  but provides other useful cryptographic features

This service broker implements a shared security model. This means that
applications running in the same org and space are assumed to be trusted
to share credentials and Vault resources for a given service instance.

See below for more details on how to use these services.

Service Plans
=============

Plan names correspond to the AWS regions where Vault backend services
are deployed:

- vault-us-east-1
- vault-us-west-2
- vault-eu-west-1
- vault-eu-west-2
- vault-ap-southeast-1
- vault-ap-southeast-2
- vault-ap-northeast-1
- vault-sa-east-1
- vault-cn-north-1

You will need to ensure that services are created using the appropriate
plan for the region containing your Cloud Foundry environment.

Service Instance Creation
=========================

Use the Cloud Foundry CLI to create a Vault service instance in your space:

.. code-block:: bash
   :caption: Example: Service instance creation in us-east-1 region

   cf create-service hsdp-vault vault-us-east-1 myvault

Service Binding
===============

A service binding will return credentials in the following format:

.. code-block:: javascript
   :caption: Service credentials format

   {
      "credentials": {
          "endpoint": "https://<vault_host>",
          "role_id": "<role_id>",
          "secret_id": "<secret_id>",
          "org_secret_path": "/v1/cf/<org_id>/secret"
          "space_secret_path": "/v1/cf/<space_id>/secret"
          "service_secret_path": "/v1/cf/<instance_id>/secret",
          "service_transit_path": "/v1/cf/<instance_id>/transit"
      }
   }

In the above example, ``credentials.role_id``, ``credentials.secret_id``
and ``<instance_id>`` are all v4 UUIDs, ``<org_id>`` and ``<space_id>``
are identifiers from your Cloud Foundry environment and ``<vault_host>``
is the FQDN for the Vault service in your region.

.. note::
   In all of the remaining examples, the full URL used to interact with Vault
   can be constructed by concatenating the value of ``credentials.endpoint``
   and the URI references (beginning with ``/v1``) provided. For example,
   here is the full URL an application running in the AWS us-east-1
   region and given the service ID shown would use to store secrets:

   .. code-block:: text
      :caption: Example: Full Vault URL for secret storage

      https://vproxy.us-east.philips-healthsuite.com/v1/cf/d597b6d5-2e73-495b-a628-02f8b82c716d/secret

.. note::
   `Vault API library users
   <https://www.vaultproject.io/docs/http/libraries.html>`_:
   Your library may abstract away the Vault API version, so the
   secret path for the previous example would instead be specified as
   ``cf/d597b6d5-2e73-495b-a628-02f8b82c716d/secret``. Be sure to check
   your library documentation to see if this is the case and adjust the
   paths accordingly.

The remaining sections cover how to use your credentials and interact
with Vault.

Accessing Vault Outside Cloud Foundry
=====================================

We support access to Vault through a dedicated proxy in each HSDP region,
which is accessible from any internet-connected system. The proxy is
intended to ease the integration of deployment tooling with your Vault
service instance, but can also be helpful for users just getting started
with Vault as it allows working with the Vault API directly from a
workstation. Consult the table below for the proxy endpoint to use.

+--------------------------+-------------------------------------------------+
| CF Region                | Proxy Endpoint                                  |
+==========================+=================================================+
| us-east                  | https://vproxy.us-east.philips-healthsuite.com  |
+--------------------------+-------------------------------------------------+
| us-west                  | https://vproxy.cloud.phsdp.com                  |
+--------------------------+-------------------------------------------------+
| eu-west (Ireland)        | https://vproxy.eu-west.philips-healthsuite.com  |
+--------------------------+-------------------------------------------------+
| eu-west (London)         | https://vproxy.uk1.hsdp.io                      |
+--------------------------+-------------------------------------------------+
| ap-northeast             | https://vproxy.ap-ne.philips-healthsuite.com    |
+--------------------------+-------------------------------------------------+
| ap-southeast (Singapore) | https://vproxy.ap-se.philips-healthsuite.com    |
+--------------------------+-------------------------------------------------+
| ap-southeast (Sydney)    | https://vproxy.ap3.hsdp.io                      |
+--------------------------+-------------------------------------------------+
| sa-east (São Paulo)      | https://vproxy.sa1.hsdp.io                      |
+--------------------------+-------------------------------------------------+
| cn-north                 | https://vproxy.cn1.philips-healthsuite.com.cn   |
+--------------------------+-------------------------------------------------+

.. note::
   As a security measure, Vault API access through the proxy
   is limited to requests for selected URIs (specifically, for
   authentication, token renewal, secret/transit paths provisioned
   by the broker and endpoints that support `response wrapping
   <https://www.vaultproject.io/docs/concepts/response-wrapping.html>`_),
   all other requests are rejected

Using Credentials
=================

Your credentials allow you to authenticate to Vault and fetch a Vault
client token, which has permission to use the secret storage and encryption
services provisioned for you:

#. Authenticate to Vault with an HTTP POST on the URI path
   ``/v1/auth/approle/login``. The request body must be a JSON
   object holding ``role_id`` and ``secret_id`` keys, with appropriate
   values from your credentials
#. In the JSON response object from Vault, read the value of
   ``auth.client_token``. This token must be presented in a
   ``X-Vault-Token`` header in *all* requests when using Vault secret
   storage and KMS services

Note that while all instances of your application share credentials,
each instance will need to perform authentication and use its own token.

Managing Client Token State
===========================

Users are **strongly** encouraged to configure their applications to
maintain token state and re-authenticate only when needed. This will
provide much better performance as it saves the authentication round-trip
that would otherwise be required for each request. Check your Vault client
library documentation as some can manage token state automatically.

If you are managing token state manually, you can check the current TTL of
a client token with the ``/v1/auth/token/lookup-self`` API endpoint. Read the
value of ``data.ttl`` in the response.

Periodic Tokens
===============

Vault client tokens can be configured to be `periodic
<https://www.vaultproject.io/docs/concepts/tokens.html#periodic-tokens>`_,
meaning that as long as your application is actively renewing the token at some
interval within the configured period (which is fixed at 1 hour), the token
does not expire.

Newly-created service instances issue periodic tokens by default, however
a previous version of the broker configured the service to issue non-periodic tokens.
Non-periodic tokens have a fixed TTL of 1 hour, and cannot be renewed once the TTL
expires, so re-authentication is required to obtain a new client token.

Unfortunately the response from the Vault ``lookup-self`` API endpoint does
not directly indicate whether or not your service is configured to issue
periodic tokens. However, you can infer this from the ``/v1/auth/token/renew-self``
API endpoint. Read the value of ``auth.lease_duration`` field in the response:

- If your tokens are **not** periodic this value will be less than ``3600``.
  In addition, the ``warnings`` array in the response will contain the following
  message (where ``<MM>`` and ``<SS>`` indicate the current number of minutes and
  seconds in the token TTL at the time renewal is requested):

  ``TTL of "1h0m0s" exceeded the effective max_ttl of "<MM>m<SS>s"; TTL value is capped accordingly``

- If your tokens are periodic, the ``auth.lease_duration`` field of a successful
  renewal will be ``3600``

You can enable or disable periodic tokens as required to meet your
organization's security policy. See the `Enable or Disable Periodic Tokens`_
section below for details.

.. note::
   Users of the Spring Vault library may want to ensure periodic tokens are
   enabled, to work around a known bug in the ``LifecycleAwareSessionManager`` class
   which can fail to re-authenticate following token expiry

Storing Secrets
===============

The Vault **secret_path** URIs provided for your application allow
secure storage of secrets or other sensitive runtime data needed by your
application. Again, the security model assumes trust (and coordination of the
usage of the namespace) between applications bound to a given Vault service
instance. The following table describes the usage of each secret path:

+---------------------------+----------------------------------+-----------------------------------------------------------------+
| Credential Key            | Path                             | Usage                                                           |
+===========================+==================================+=================================================================+
| ``org_secret_path``       | ``/v1/cf/<org_id>/secret``       | (Deprecated, see below)                                         |
+---------------------------+----------------------------------+-----------------------------------------------------------------+
| ``space_secret_path``     | ``/v1/cf/<space_id>/secret``     | Create/read/update access to shared secrets for a space         |
+---------------------------+----------------------------------+-----------------------------------------------------------------+
| ``service_secret_path``   | ``/v1/cf/<instance_id>/secret``  | Full CRUD (create/read/update/delete) access to service secrets |
+---------------------------+----------------------------------+-----------------------------------------------------------------+

See the `documentation for Vault's 'kv' backend
<https://www.vaultproject.io/docs/secrets/kv/>`_ (previously this was
called the 'secret' backend) for complete details on how to use the Vault
API to store your data. Keep these points in mind:

- Values cannot be larger than 512KB
- Values written to an existing key *replace the old value*. This is very
  important to understand to avoid data loss, especially if the value you
  have stored is a complex JSON object. To safely update a key, first perform
  a read to obtain the current value, make any updates needed then write the
  value back to the key
- You can create sub-keys below ``credentials.space_secret_path`` and
  ``credentials.service_secret_path`` using
  whatever naming scheme you like. For ``credentials.service_secret_path``,
  your client token has permission to delete sub-keys as needed
- Path/key names are *not* secret, only the values set on keys are encrypted
  by Vault. Do not store sensitive information as part of a secret's path or
  in the key name itself

For example, for the service ID from the example above, you could write
a Vault key called 'data' with an HTTP POST on this URL:

  ``https://vproxy.us-east.philips-healthsuite.com/v1/cf/d597b6d5-2e73-495b-a628-02f8b82c716d/secret/data``

.. note::
   The Vault documentation refers to a URI relative path prefix
   of ``secret/``, however the HSDP-Vault service instead uses a prefix
   beginning with ``cf/<id>``, just be aware of this when looking at
   the examples. You will always use the URI reference given for each
   of the space or service secret paths when using the Vault API to read or
   write secrets

Credential Rotation
===================

The Vault service broker supports credential rotation for existing service
instances. It's important to state again that the broker implements a
shared security model, meaning that a single service instance holds common
credentials that can be bound by many apps in a CF space. This means that
whenever credentials are rotated, you will need to ensure all apps using
the service instance are unbound, bound, and restarted to pick up the new
credentials. (Hint: check the output of ``cf services`` in your space and
look for the list of bound applications for your Vault service instance.)

Here is an example of credential rotation for a service instance ``myvault``
which has a single bound application ``myapp``:

#. Perform the update operation using the CF CLI. The broker accepts a
   case-sensitive, boolean parameter ``RotateSecretID`` that must be passed as
   a valid JSON object, either in-line or in a file. Here is an example with
   the parameter being passed in-line:

   .. code-block:: text

      cf update-service myvault -c '{"RotateSecretID": true}'

#. Unbind the application:

   .. code-block:: text

      cf unbind-service myapp myvault

#. Bind the application:

   .. code-block:: text

      cf bind-service myapp myvault

#. Restart (or push) your application to use the new credentials

.. important::
   If you have created any
   `service keys <https://docs.cloudfoundry.org/devguide/services/service-keys.html>`_
   for your service instance, you will also need to delete and recreate
   these keys to pick up the new credentials, they are *not* updated
   automatically

Policy Updates
==============

Currently the Vault service broker supports an update to the policy created
for your service instance. By default, client tokens do not have permission
to delete secrets created in the shared ``credentials.space_secret_path``,
this is intended to protect users from deleting keys in the shared path
that other apps may rely on.

To remove this restriction for a service instance ``myvault``, perform an
update operation using the CF CLI. The broker accepts a case-sensitive,
boolean parameter ``AllowSpaceSecretDeletion`` that must be passed as a
valid JSON object, either in-line or in a file. Here is an example with
the parameter being passed in-line:

.. code-block:: text

   cf update-service myvault -c '{"AllowSpaceSecretDeletion": true}'

If needed, the default configuration can be restored with:

.. code-block:: text

   cf update-service myvault -c '{"AllowSpaceSecretDeletion": false}'

Once updated, your policy takes effect immediately.

.. important::
   The policy update affects only your service instance, which means
   that other Vault service instances in the same space still enforce
   the default policy that does not allow secret deletion in the shared
   path. Make sure you do not delete keys that other apps may rely on!

Enable or Disable Periodic Tokens
=================================

The Vault service broker supports an update to either enable or disable
'periodic' tokens for your service instance.

To enable periodic tokens for a service instance ``myvault``, perform an
update operation using the CF CLI. The broker accepts a case-sensitive,
boolean parameter ``EnablePeriodicTokens`` that must be passed as a
valid JSON object, either in-line or in a file. Here is an example with
the parameter being passed in-line:

.. code-block:: text

   cf update-service myvault -c '{"EnablePeriodicTokens": true}'

If needed, periodic tokens can be disabled with:

.. code-block:: text

   cf update-service myvault -c '{"EnablePeriodicTokens": false}'

Your configuration is updated immediately, however applications must
re-authenticate in order for client tokens to reflect the changes.

KMS
===

We refer to the features provided by the Vault ``transit`` backend as a
'KMS' (Key Management Service), since the term is familiar to many users.
In addition to key management, the transit backend can sign and verify
data, and perform on-demand encryption of arbitrary data using a key of
your choice.

In the examples below, be sure to substitute the value for
``credentials.service_transit_path`` wherever ``<service_transit_path>``
is specified.

Refer to the Vault `transit documentation
<https://www.vaultproject.io/docs/secrets/transit/index.html>`_ for
complete details on how to use the Vault transit API to generate master
keys, encrypt on demand, deal with key rotation and more.

Creating Master Keys
--------------------

Vault supports the creation of any number of named encryption keys which
can be thought of as 'master keys' in the context of KMS. You can name
keys using any scheme you'd like.

To create a master key, make an HTTP post on the URI path
``<service_transit_path>/keys/<key_name>``, where ``<key_name>`` is a
meaningful identifier.

Introduction to Datakeys
------------------------

Datakeys are a convenient way to generate high-quality encryption
keys that are themselves encrypted with a master key. Any number of
datakeys can be created, this allows your application to ensure that
data for an individual user or device is envelope-encrypted with a
unique key that can later be decrypted only by your application. For
more on how envelope encryption works, see the `AWS KMS documentation
<https://docs.aws.amazon.com/kms/latest/developerguide/workflow.html>`_ (it
is described in the context of AWS services, but the concepts apply here).

.. important::
   Your application is responsible for maintaining the association between
   the user/device and the datakey, and for storing the ciphertext of
   the datakey.

Envelope Encryption Using Datakeys
----------------------------------

#. To create a datakey, make an HTTP POST on the URI path
   ``<transit_path>/datakey/plaintext/<key_name>``. The request
   body can optionally be a JSON object holding a ``bits`` key, with a
   value of the number of bits in the desired key (128, 256 or 512). If
   not specified, a 256-bit key will be returned
#. In the JSON response object from Vault, read the values of
   ``data.ciphertext`` and ``data.plaintext``
#. Use the plaintext of the datakey for symmetric encryption using an
   encryption algorithm that meets your security requirements, and store
   the ciphertext as appropriate

.. important::
   Use care to protect the plaintext of the datakey! Delete it from memory
   when not in use and never allow it to persist on any storage, get logged
   in debugging output, etc

Decryption Using Datakeys
-------------------------

Let's say you created a datakey, encrypted and stored some data in an S3
bucket, then stored the ciphertext of the datakey alongside the encrypted
data. The data can later be decrypted as follows:

#. First, decrypt the datakey. Make an HTTP POST on the URI path
   ``<service_transit_path>/decrypt/<key_name>``. The request body must
   be a JSON object holding a ``ciphertext`` key, with a value of the
   ciphertext of the datakey
#. In the JSON response object from Vault, read the value of
   ``data.plaintext``
#. Use the plaintext of the datakey to decrypt data as needed

Introduction to Direct Encryption
---------------------------------

Vault KMS can optionally be used to perform symmetric encryption for you,
on demand. Vault does *not* store data, rather, it encrypts plaintext with
a master key of your choice and returns the ciphertext back to you. This is
intended for use with small amounts of Base64-encoded data (Vault will not
accept a request size larger than 32 MB). Data is encrypted with AES-256
wrapped with GCM using a 12-byte nonce.

Direct Encryption Using Vault KMS
---------------------------------

#. Make an HTTP POST on the URI path
   ``<service_transit_path>/encrypt/<key_name>``. The request body must
   be a JSON object holding a ``plaintext`` key, with a value of the
   Base64-encoded data you want to encrypt
#. In the JSON response object from Vault, read the value of
   ``data.ciphertext``
#. Store the ciphertext as needed

Decryption Using Vault KMS
--------------------------

#. Make an HTTP POST on the URI path
   ``<service_transit_path>/decrypt/<key_name>``. The request body
   must be a JSON object holding a ``ciphertext`` key, with a value of
   previously-generated ciphertext
#. In the JSON response object from Vault, read the value of
   ``data.plaintext``

Advanced Usage: Master Key Rotation and Data Re-Encryption
----------------------------------------------------------

Master key rotation may be needed to meet security requirements. Vault
keeps track of the new key material by 'versioning' a master key whenever
the key is rotated. The current version of a given master key is encoded
in a version string prepended to ciphertext generated by that key. Master
keys are always versioned starting at 1 (so an example ciphertext would
be ``vault:v1:<ciphertext>``) and of course for every key rotation the
version is incremented. All data encryption by Vault will use the highest
available version of a master key, but ciphertext generated with previous
versions of that master key can still be decrypted.

At any time, ciphertext generated with previous versions of a master
key may be re-encrypted (or 'rewrapped', the term used by the Vault API)
with the latest master key.

To rotate a master key:

#. Make an HTTP POST on the URI path
   ``<service_transit_path>/keys/<key_name>/rotate``

To re-encrypt ciphertext generated by a previous master key version:

#. Make an HTTP POST on the URI path
   ``<service_transit_path>/rewrap/<key_name>``. The request body
   must be a JSON object holding a ``ciphertext`` key, with a value of
   previously-generated ciphertext
#. In the JSON response object from Vault, read the value of
   ``data.ciphertext`` and store it as needed

KMS Q&A
-------

**Is there a way to view the plaintext of a master key or otherwise back it up?**

By default, KMS enforces a contract: keys are never exposed outside
of Vault. However some users are faced with key escrow requirements, or
require the ability to backup/restore encryption keys for disaster recovery.

Assuming you understand the implications of exposing key material and accept
responsibility for secure storage outside of Vault, you can explicitly
configure key parameters that allow export and/or backup as necessary. Note
that once these parameters are enabled they **cannot** be disabled.
Vault records the most recent backup timestamp in the key metadata.

For key escrow, Vault supports exporting keys to plaintext as follows:

#. Make an HTTP POST on the URI path
   ``<service_transit_path>/<key_name>/config``. The request body must be
   a JSON object holding a boolean ``exportable`` key, set to ``true``
#. Select the key type to export (one of: ``encryption-key``,
   ``signing-key`` or ``hmac-key``)
#. Make an HTTP POST on the URI path
   ``<service_transit_path>/export/<key_type>/<key_name>``
#. In the JSON response object from Vault, the versioned keys can be found
   by reading ``data.keys``. You can optionally specify a specific version
   to export, see the `Vault Transit API documentation
   <https://www.vaultproject.io/api/secret/transit/index.html#export-key>`_
   for details

Key backups can be made as follows:

#. Make an HTTP POST on the URI path
   ``<service_transit_path>/<key_name>/config``. The request body must be
   a JSON object holding a boolean ``allow_plaintext_backup`` key,
   set to ``true``
#. Make an HTTP POST on the URI path
   ``<service_transit_path>/backup/<key_name>``
#. Securely store the entire JSON response object from Vault which contains
   all configuration data and all key versions along with the HMAC key

.. attention::
   For safety, Vault does not allow restoring a backup to an existing key.
   If you want to reuse the previous key name, you will first need to delete
   the existing key, then restore the backup. You may wish to restore the
   backup to a new key name to verify you are able to use it as expected
   before deleting the existing key

**Is there a way to prevent old versions of ciphertext from being decrypted?**

Yes. This may be required to comply with certain security requirements,
and is enforced by setting a minimum version of ciphertext allowed to be
decrypted. If you understand this will affect *all* ciphertext a master
key has ever generated below the minimum version (including datakeys!),
you can do the following (assuming you have already rotated the master key):

#. Make an HTTP POST on the URI path
   ``<service_transit_path>/<key_name>/config``. The request body must be
   a JSON object holding a ``min_decryption_version`` key, with a value
   of the minimum key version you would like to allow
#. Verify ciphertext from versions lower than ``min_decryption_version``
   can no longer be decrypted

Deleting Vault Services: A Gentle Warning
=========================================

The Vault backend services provisioned for your service instance are
removed when the service is deleted. It is important that all users
understand the following:

- All data stored at the path ``credentials.service_secret_path``
  is unrecoverable
- All KMS keys created at ``credentials.service_transit_path`` are
  destroyed. Any data encrypted by your KMS master keys (or datakeys)
  will be unrecoverable unless you have created backups of your keys
- Data in the paths given in ``credentials.org_secret_path`` and
  ``credentials.space_secret_path`` are preserved

Deprecated Features
===================

The following features have been deprecated in the Vault service broker
version indicated:

**org_secret_path** : v3
    The path at ``credentials.org_secret_path`` was intended to allow the
    sharing of secrets at the org level, however there is no self-service
    capability for org administrators to write to it. For new service
    instances, the path is no longer created, although it is still referenced
    in the credentials object. Users should not rely on reading or writing
    to this path

Vault Access for Humans
=======================

Refer to our `Vault CLI
<https://healthsuite.atlassian.net/wiki/spaces/HPO/pages/125944551/Using+the+Vault+CLI>`_
page for more information.
