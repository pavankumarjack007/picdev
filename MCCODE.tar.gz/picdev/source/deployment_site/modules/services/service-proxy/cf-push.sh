#!/bin/bash

while getopts d:a:o:s:h: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        d) domain=${OPTARG};;
        a) appname=${OPTARG};;
        o) organization=${OPTARG};;
        s) space=${OPTARG};;
        h) hostname=${OPTARG};;
    esac
done

cf target -o "$organization" -s "$space"
if [[ "$TF_VAR_cf_for_k8s" == "true" ]]
then
  cf push -f manifest-paketo.yml
  cf map-route "$appname" "apps.${domain}" --hostname "$hostname"
else
  cf push -f manifest.yml
  cf map-route "$appname" "$domain" --hostname "$hostname"
fi
