#!/bin/bash

if [[ "$TF_VAR_cf_for_k8s" == "true" ]]
then
  kubecfpods=$(kubectl -n cf-system get po)
else
  kubecfpods=$(kubectl -n kubecf get po)
fi

#cf api https://api."${1}"
#cf login -u ${2} -p ${3} -o smoketestorg -s smoketestspace
cf target -o smoketestorg -s smoketestspace

logs_folder=${PWD}/../../../smoketests.log
echo "##################### BEGIN SMOKE TEST RESULTS ##############" > ${logs_folder}

echo "${kubecfpods}" >> ${logs_folder}

if [[ "$TF_VAR_cf_for_k8s" == "false" ]]
then
  curl -s https://python-app."${1}"/test | grep -q "<h3>Containerized service brokers</h3>"
  if [ $? -eq 0 ]
    then
      echo "Smoke tests CF c2c networking -- PASSED" >> ${logs_folder}
    else
      echo "Smoke tests CF c2c networking -- FAILED" >> ${logs_folder}
  fi
fi

cf m >> ${logs_folder}

echo "##################### END SMOKE TEST RESULTS ##############" >> ${logs_folder}

echo "CHECK ${logs_folder} FOR SMOKE TEST RESULTS"

cat ${logs_folder}