import json
import logging
import unittest

import boto3
from cf_broker_api.testing import create_test_client
from cloud_mockery import mock_cf
from cloud_mockery.v2 import cf_backends
from graphql.error import GraphQLLocatedError
from snapshottest import TestCase as SnapshotTestCase

from broker.graphql import schema
from tests import TEST_RESOURCES_FILE, BaseTestCase, create_broker, test_data

# Stop nose sniffer from trying to run this as a test...
create_test_client.__test__ = False

LOG = logging.getLogger(__name__)


class TestGraphQL(SnapshotTestCase):

    MOCKS = BaseTestCase.MOCKS + [mock_cf()]

    @classmethod
    def setUpClass(cls):
        super(TestGraphQL, cls).setUpClass()
        for mock in cls.MOCKS:
            mock.start()
        cls.app = create_broker("testing")
        cls.app_client = cls.app.test_client()
        cls.broker_client = create_test_client("flask", test_client=cls.app_client)
        backend = cf_backends[cls.app.global_config.CF_API_ENDPOINT]
        backend.create_from_resources_file(TEST_RESOURCES_FILE)

    @classmethod
    def tearDownClass(cls):
        super(TestGraphQL, cls).tearDownClass()
        for mock in cls.MOCKS:
            mock.stop()

    def setUp(self):
        super(TestGraphQL, self).setUp()
        self.app_context = self.app.app_context()
        self.app_context.push()

    def tearDown(self):
        super(TestGraphQL, self).tearDown()
        self.app_context.pop()

    def _create_instance(self):
        data = test_data(
            instance_id="215b97be-ec77-4224-9c38-c4f2d86b56c1",
            organization_guid="e4de7294-4e76-44ac-bf40-08b01282f478",
            space_guid="70021a4c-2407-4625-9ed7-a7259bc9e261",
            plan_id="aeffc520-35d6-48e7-a9b0-b3239d02009b",
        )

        self.broker_client.provision(data)

        return data

    def assertMatchGraphQL(self, query, variables=None):
        if variables is None:
            variables = {}
        _vars = variables or {}
        res = self.app_client.get(
            "/graphql?query={}&variables={}".format(query, json.dumps(_vars)),
            headers={
                "X-User-Access-Token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
                ".eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4i"
                "OnRydWV9.TJVA95OrM7E2cBab30RMHrHDcEfxjoYZgeFONFh7HgQ"
            },
        )

        self.assertEqual(res.status_code, 200)

        json_res = json.loads(res.data)
        data = json_res["data"]

        self.assertFalse("errors" in json_res)
        self.assertMatchSnapshot(data)

    def test_catalog(self):
        self.assertMatchGraphQL(
            """
            {
                catalog {
                    name
                    plans {
                        name
                        bullets
                        description
                        restricted
                        deprecated
                    }
                }
            }
        """
        )

    def test_instances(self):
        self.assertMatchGraphQL(
            """
            {
                instances {
                    guid
                    name
                    organization
                }
            }
        """
        )

    def test_instance(self):
        data = self._create_instance()

        self.assertMatchGraphQL(
            """
        query ($id: String) {
            instance(id: $id) {
                guid
                name
            }
        }
        """,
            {"id": data["instance_id"]},
        )

    def test_instance_details(self):
        data = self._create_instance()

        self.assertMatchGraphQL(
            """
        query ($id: String) {
            instance(id: $id) {
                guid
                details {
                    name
                }
            }
        }
        """,
            {"id": data["instance_id"]},
        )

    @unittest.skip("metrics not supported by moto")
    def test_instance_metrics(self):
        data = self._create_instance()

        self.assertMatchGraphQL(
            """
        query ($id: String) {
            instance(id: $id) {
                guid
                metrics {
                    name
                    bucketSize
                }
            }
        }
        """,
            {"id": data["instance_id"]},
        )

    def test_object_search(self):
        data = self._create_instance()

        s3 = boto3.client("s3", **self.app.global_config.aws_config)
        s3.put_object(Bucket=data["bucket"], Key="some-key", Body=b"test bytes")

        self.assertMatchGraphQL(
            """
        query($instanceId: String!, $search: String) {
          searchObjects(instanceId: $instanceId, search: $search) {
            pageInfo {
              nextToken
              total
            }
            objects {
              name
              size
              storageClass
            }
          }
        }
        """,
            {"instanceId": data["instance_id"], "search": ""},
        )

    def test_introspection(self):
        try:
            schema.introspect()
        except GraphQLLocatedError as e:
            LOG.exception(e)
            self.fail("GraphQL failure!  Inspect introspection exception for details.")
