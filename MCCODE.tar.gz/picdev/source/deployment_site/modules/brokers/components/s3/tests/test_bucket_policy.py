from awspolicy import BucketPolicy
from botocore.exceptions import ClientError

from broker.aws import IamUser, get_aws_organization_id
from tests import BaseTestCase, test_data
from . import test_config


class TestBucketPolicy(BaseTestCase):
    def _get_bucket_policy(self, bucket):
        policy = BucketPolicy(serviceModule=self.s3_client, resourceIdentifer=bucket)
        return policy

    def test_provision_with_policy_options(self):
        data = test_data(
            parameters={
                "EnforceSecureCommunications": True,
                "EnforceServerSideEncryption": True,
                "GrantAccess": [
                    IamUser(**test_config.aws_config)("User1").create().arn,
                    "emr",
                ],
            }
        )
        resp = self.client.provision(data)
        self.assertResponse(resp)
        policy = self._get_bucket_policy(data["bucket"])
        expected_sids = [
            "DenyIncorrectEncryptionHeader",
            "DenyUnEncryptedObjectUploads",
            "DenyUnsecuredCommunications",
            "GrantOwner",
            "GrantPrincipalAccess",
            "GrantServiceAccess",
        ]
        self.assertEqual(set(expected_sids), set(policy.sids))

    def test_update_bucket_policy(self):
        data = test_data(
            parameters={
                "EnforceSecureCommunications": True,
                "EnforceServerSideEncryption": True,
            }
        )
        resp = self.client.provision(data)
        self.assertResponse(resp)
        data["parameters"] = {"EnforceSecureCommunications": False}
        resp = self.client.update(data)
        self.assertResponse(resp)
        policy = self._get_bucket_policy(data["bucket"])
        self.assertNotIn("DenyUnsecuredCommunications", policy.sids)
        self.assertIn("DenyUnEncryptedObjectUploads", policy.sids)

    def test_update_bucket_policy_grant_access(self):
        data = test_data()
        resp = self.client.provision(data)
        self.assertResponse(resp)

        iam_user = IamUser(**test_config.aws_config)
        user1 = iam_user("test_update_bucket_policy_grant_access_user_1").create()
        user2 = iam_user("test_update_bucket_policy_grant_access_user_2").create()

        principal_arns = [user1.arn, user2.arn]
        data["parameters"] = {"GrantAccess": principal_arns}
        resp = self.client.update(data)
        self.assertResponse(resp)

        policy = self._get_bucket_policy(data["bucket"])
        self.assertIn("GrantPrincipalAccess", policy.sids)
        grant_access_statement = policy.select_statement("GrantPrincipalAccess")
        granted_arns = grant_access_statement.Condition["ArnEquals"]["aws:PrincipalArn"]
        self.assertEqual(set(principal_arns), set(granted_arns))

    def test_update_bucket_policy_grant_access_cumulative(self):
        user1 = IamUser(**test_config.aws_config)(
            "test_update_bucket_policy_grant_access_cumulative_user_1"
        ).create()

        data = test_data(parameters={"GrantAccess": [user1.arn]})
        resp = self.client.provision(data)
        self.assertResponse(resp)
        policy = self._get_bucket_policy(data["bucket"])
        self.assertIn("GrantPrincipalAccess", policy.sids)
        grant_access_statement = policy.select_statement("GrantPrincipalAccess")
        granted_arns = grant_access_statement.Condition["ArnEquals"]["aws:PrincipalArn"]
        self.assertEqual({user1.arn}, set(granted_arns))

        user2 = IamUser(**test_config.aws_config)(
            "test_update_bucket_policy_grant_access_cumulative_user_2"
        ).create()

        data["parameters"] = {"GrantAccess": [user2.arn]}
        resp = self.client.update(data)
        self.assertResponse(resp)
        policy = self._get_bucket_policy(data["bucket"])
        self.assertIn("GrantPrincipalAccess", policy.sids)
        grant_access_statement = policy.select_statement("GrantPrincipalAccess")
        granted_arns = grant_access_statement.Condition["ArnEquals"]["aws:PrincipalArn"]
        self.assertEqual({user1.arn, user2.arn}, set(granted_arns))

    def test_update_bucket_policy_revoke_access(self):
        user1 = IamUser(**test_config.aws_config)(
            "test_update_bucket_policy_revoke_access_user_1"
        ).create()
        user2 = IamUser(**test_config.aws_config)(
            "test_update_bucket_policy_revoke_access_user2"
        ).create()

        data = test_data(parameters={"GrantAccess": [user1.arn, user2.arn]})
        resp = self.client.provision(data)
        self.assertResponse(resp)
        policy = self._get_bucket_policy(data["bucket"])
        self.assertIn("GrantPrincipalAccess", policy.sids)
        grant_access_statement = policy.select_statement("GrantPrincipalAccess")
        granted_arns = grant_access_statement.Condition["ArnEquals"]["aws:PrincipalArn"]
        self.assertEqual({user1.arn, user2.arn}, set(granted_arns))

        data["parameters"] = {"RevokeAccess": [user1.arn]}
        resp = self.client.update(data)
        self.assertResponse(resp)
        policy = self._get_bucket_policy(data["bucket"])
        self.assertIn("GrantPrincipalAccess", policy.sids)
        grant_access_statement = policy.select_statement("GrantPrincipalAccess")
        granted_arns = grant_access_statement.Condition["ArnEquals"]["aws:PrincipalArn"]
        self.assertEqual({user2.arn}, set(granted_arns))

        data["parameters"] = {"RevokeAccess": [user2.arn]}
        resp = self.client.update(data)
        self.assertResponse(resp)
        self.assertRaisesRegex(
            ClientError, "NoSuchBucketPolicy", self._get_bucket_policy, data["bucket"]
        )

    def test_update_bucket_policy_grant_revoke_emr_access(self):
        data = test_data(parameters={"GrantAccess": ["emr"]})
        resp = self.client.provision(data)
        self.assertResponse(resp)

        policy = self._get_bucket_policy(data["bucket"])
        self.assertIn("GrantServiceAccess", policy.sids)
        grant_service_access_statement = policy.select_statement("GrantServiceAccess")
        grant_condition = grant_service_access_statement.Condition

        granted_org_guid = grant_condition["StringEquals"][
            "aws:PrincipalTag/Organization ID"
        ]
        self.assertEqual(granted_org_guid, data["organization_guid"])

        granted_aws_org = grant_condition["StringEquals"]["aws:PrincipalOrgID"]
        self.assertEqual(
            granted_aws_org, get_aws_organization_id(**test_config.aws_config)
        )

        granted_service_matchers = grant_condition["StringLike"]["aws:PrincipalArn"]
        self.assertTrue(
            any("elasticmapreduce" in matcher for matcher in granted_service_matchers)
        )

        grant_owner_access_statement = policy.select_statement("GrantOwner")
        principal_arn = grant_owner_access_statement.Principal["AWS"]
        self.assertTrue(principal_arn.endswith("user/" + data["bucket"]))

        data["parameters"] = {"RevokeAccess": ["emr"]}
        resp = self.client.update(data)
        self.assertResponse(resp)
        self.assertRaisesRegex(
            ClientError, "NoSuchBucketPolicy", self._get_bucket_policy, data["bucket"]
        )

    def test_invalid_access_list_parameter_fails(self):
        def check_response(response):
            self.assertEqual(400, response.status_code)
            self.assertIn("not a valid ARN", response.json["description"])

        data = test_data(
            parameters={"GrantAccess": ["not-a-valid-arn-or-service-name"]}
        )
        resp = self.client.provision(data)
        check_response(resp)
        resp = self.client.update(data)
        check_response(resp)

        data = test_data(
            parameters={"RevokeAccess": ["not-a-valid-arn-or-service-name"]}
        )
        resp = self.client.update(data)
        check_response(resp)

    def test_grant_owner_statement_removed_when_no_other_grant_statements_exist(self):
        data = test_data(
            parameters={
                "EnforceSecureCommunications": True,
                "GrantAccess": ["emr", "arn://fake-arn"],
            }
        )
        resp = self.client.provision(data)
        self.assertResponse(resp)

        policy = self._get_bucket_policy(data["bucket"])
        expected_sids = [
            "DenyUnsecuredCommunications",
            "GrantOwner",
            "GrantServiceAccess",
            "GrantPrincipalAccess",
        ]
        self.assertEqual(set(expected_sids), set(policy.sids))

        data["parameters"] = {"RevokeAccess": ["arn://fake-arn"]}
        resp = self.client.update(data)
        self.assertResponse(resp)
        policy = self._get_bucket_policy(data["bucket"])
        expected_sids.remove("GrantPrincipalAccess")
        self.assertEqual(set(expected_sids), set(policy.sids))

        data["parameters"] = {"RevokeAccess": ["emr"]}
        resp = self.client.update(data)
        self.assertResponse(resp)
        policy = self._get_bucket_policy(data["bucket"])
        self.assertEqual(["DenyUnsecuredCommunications"], policy.sids)
