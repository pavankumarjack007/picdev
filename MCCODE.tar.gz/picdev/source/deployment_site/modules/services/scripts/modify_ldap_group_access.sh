#! /bin/bash

kubectl -n identity cp ./group_access.ldif \
 $(kubectl -n identity get po -l app=openldap --no-headers=true -o custom-columns=":metadata.name"):/etc/ldap -c openldap

kubectl -n identity exec $(kubectl -n identity get po -l app=openldap --no-headers=true -o custom-columns=":metadata.name") \
 -c openldap -- ldapmodify -h localhost -p 389 -D cn=admin,cn=config -w ${1} -f /etc/ldap/group_access.ldif

rm -f ./group_access.ldif