#! /bin/bash
#Script to provisions the base platform for MicroCloud.
#Requires:- kOps (v1.21), terraform (v1.0.4)
#Requires: kubectl (1.15.5), aws-cli, jq
#Requires aws access_key, secret and region to be set (For example via:- aws configure ...)
#Requires Route53 hosted zone with the name that matches cluster_name


## Setup env vars for terraform
while IFS= read -r line || [[ -n "$line" ]];
  do
    result=$(echo $line)
    if [[ ! "$line" =~ ^#.*$ ]]
    then
      export TF_VAR_$result
    fi
  done < ${1}
export TF_VAR_login_approle_role_id=${login_approle_role_id}
export TF_VAR_vault_generic_secret_path=${vault_generic_secret_path}
export TF_VAR_login_approle_secret_id=${login_approle_secret_id}
export ZONES=${TF_VAR_zones}
export TF_VAR_az=${ZONES}

export target_name=${TF_VAR_target_name}
export cf_type=${TF_VAR_cf_type}
export master_count=${TF_VAR_master_count}
export environment=${TF_VAR_environment}
### This is to override the default value for aws_region in vault deployment
export TF_VAR_aws_region=$(echo "${ZONES}" | rev | cut -c2- | rev)

export TF_VAR_outposts_zone=${ZONES}
	
#at some point this will be FFF,SSF, may be cloud as well( for testing)..
if [ "$target_name" == "outpost" ]
  then
  	outpost_details=$(aws outposts get-outpost --outpost-id $TF_VAR_outposts_id)

	export outposts_arn=$(echo "${outpost_details}" | jq '.Outpost.OutpostArn')
	export TF_VAR_outposts_arn=${outposts_arn}

  #given that availability zone is expected in input, use that instead of getting from details
	#export TF_VAR_outposts_zone=$(echo "${outpost_details}" | jq '.Outpost.AvailabilityZone')
	export TF_VAR_outposts_zone_id=$(echo "${outpost_details}" | jq '.Outpost.AvailabilityZoneId')
	export TF_VAR_outposts_name=$(echo "${outpost_details}" | jq '.Outpost.Name')
	
	export TF_VAR_storage_class_name="ebs-sc"
	export storage_class_name="ebs-sc"
	
elif [ "$target_name" == "cloud" ]
then
	export TF_VAR_storage_class_name="ebs-sc"
	export storage_class_name="ebs-sc"
	
elif [ "$target_name" == "sff" ]
then

	export TF_VAR_storage_class_name="rook-ceph-block"
	export storage_class_name="rook-ceph-block"
	
else

	echo unknown target type falling back to EBS storage type
	export TF_VAR_storage_class_name="ebs-sc"
	export storage_class_name="ebs-sc"

fi


export TF_VAR_cf_domain="cf.${TF_VAR_domain_name}"

export TF_VAR_cluster_name="k8s.${TF_VAR_domain_name}"
export TF_VAR_nodes_role="nodes.k8s.${TF_VAR_domain_name}"
export TF_VAR_k8s_cluster_name="k8s.${TF_VAR_domain_name}"

export TF_VAR_pagerduty_key=$PAGERDUTY_KEY

[[ -z "${TF_VAR_debug_mode}" ]] && export TF_VAR_debug_mode=false
[[ -z "${TF_VAR_backup_schedule}" ]] && export TF_VAR_backup_schedule="@every 72h"

### The current default for cf-for-k8s is false. This value should become true by default
### once this feature has been tested thoroughly.
[[ -z "${TF_VAR_cf_for_k8s}" ]] && export TF_VAR_cf_for_k8s=false

### The following variables are used specify an app registry/docker registry for cf-for-k8s to
### store the built images. I propose we normalize & use the same for broker images as well.
[[ -n "${APP_REGISTRY_HOSTNAME}" ]] && export TF_VAR_app_registry_hostname=${APP_REGISTRY_HOSTNAME}
[[ -n "${APP_REGISTRY_REPOSITORY_PREFIX}" ]] && export TF_VAR_app_registry_repository_prefix=${APP_REGISTRY_REPOSITORY_PREFIX}
[[ -n "${APP_REGISTRY_USERNAME}" ]] && export TF_VAR_app_registry_username=${APP_REGISTRY_USERNAME}
[[ -n "${APP_REGISTRY_PASSWORD}" ]] && export TF_VAR_app_registry_password=${APP_REGISTRY_PASSWORD}

[[ -n "${SMTP_FROM}" ]] && export TF_VAR_smtp_from=${SMTP_FROM} 
[[ -n "${SMTP_HOST}" ]] && export TF_VAR_smtp_host=${SMTP_HOST} 
[[ -n "${SMTP_PORT}" ]] && export TF_VAR_smtp_port=${SMTP_PORT} 
[[ -n "${SMTP_LOGIN}" ]] && export TF_VAR_smtp_login=${SMTP_LOGIN} 
[[ -n "${SMTP_PASSWORD}" ]] && export TF_VAR_smtp_password=${SMTP_PASSWORD} 

[[ -n "${TWILIO_AUTH_TOKEN}" ]] && export TF_VAR_twilio_auth_token=${TWILIO_AUTH_TOKEN}
[[ -n "${TWILIO_SID}" ]] && export TF_VAR_twilio_sid=${TWILIO_SID}
[[ -n "${TWILIO_FRIENDLY_NAME}" ]] && export TF_VAR_twilio_friendly_name=${TWILIO_FRIENDLY_NAME}


[[ -n "${HSOP_VERSION}" ]] && export TF_VAR_platform_version=${HSOP_VERSION}	

if [[ "${IGNORE_LOCAL_LSC_VARS}" == "false" ]]; then
  if [ "$ENABLE_CENTRAL_LDAP_SYNC" == "true" ] && [ -f "${PWD}/lsc.vars" ]
  then
      export TF_VAR_enable_central_ldap_sync=${ENABLE_CENTRAL_LDAP_SYNC}
      while IFS= read -r line || [[ -n "$line" ]];
        do
          result=$(echo $line)
          if [[ ! "$line" =~ ^#.*$ ]]
          then
            var="$( cut -d '=' -f 1 <<< "$line" )";
            val="$( cut -d '=' -f 2- <<< "$line" )";
            export TF_VAR_${var}="$val"
          fi
        done < ${PWD}/lsc.vars
  fi
else
  export TF_VAR_enable_central_ldap_sync=${ENABLE_CENTRAL_LDAP_SYNC}
fi