#! /bin/bash
#Script to provisions the base platform for MicroCloud.
#Requires:- kOps (v1.21), terraform (v1.0.4)
#Requires: kubectl (1.15.5), aws-cli, jq
#Requires aws access_key, secret and region to be set (For example via:- aws configure ...)
#Requires Route53 hosted zone with the name that matches cluster_name

while getopts c:p: flag
do
    # shellcheck disable=SC2220
    case "${flag}" in
        c) conf=${OPTARG};;
        p) vars=${OPTARG};;
    esac
done

abort(){
  echo $1 && exit 1
}

abort_or_continue() {
  if [[ $1 -ne 0 ]];
  then
    echo "Bailing out ..."
    exit 1
  fi
}

log() {
    timestamp=`date +"%F %T"`
    echo -e "${timestamp} : $@";
}

## Setup paths for modules, configuration & profile
deployment="$(dirname $(dirname $(realpath $0)) )"
modules="$(dirname $(dirname $(realpath $0)) )/modules"
config="$(dirname $(dirname $(realpath $0)) )/configuration/${conf}.txt"
profile="$(dirname $(dirname $(realpath $0)) )/profiles/${vars}.tfvars"
version="$(dirname $(dirname $(realpath $0)) )/version.txt"

export HSOP_VERSION=$(cat $version)

## Setup env vars for terraform
## Removed updating permissions to avoid unneccesary git status changes
#chmod +x ./setup_env_vars.sh
source ./setup_env_vars.sh $profile

SECONDS=0

show_banner(){
  (
    printf "\n"
    toilet -f pagga HealthSuite
    toilet -f pagga OnPremise
    printf "\n"
    toilet -f wideterm --metal MicroCloud $HSOP_VERSION
    printf "\n"
  )
}

login_to_k8s(){
  found=$(aws s3 ls s3://$TF_VAR_bucket_name/kops/ | grep $TF_VAR_cluster_name | wc -l)
  if [[ $found -eq 1 ]];
  then
    (
      scripts="$modules/kubernetes/scripts"
      cd $scripts
      export KOPS_STATE_STORE="s3://${TF_VAR_bucket_name}/kops"
      ## Removed updating permissions to avoid unneccesary git status changes
      #chmod +x proxy_aware_kops_export_kubecfg.sh
      ./proxy_aware_kops_export_kubecfg.sh $TF_VAR_cluster_name >/dev/null
    )
  fi
}

login_to_cf(){
  (
    echo "terraform {" > temp.tf
    echo "  backend \"s3\" {}" >> temp.tf
    echo "}" >> temp.tf
    stateLockTable="${TF_VAR_environment}.${TF_VAR_domain_name}"
    terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate" -backend-config="dynamodb_table=$stateLockTable"  >/dev/null
    if [[ $? -eq 0 ]];
    then
      wkspace="cloudfoundry-${TF_VAR_environment}.${TF_VAR_domain_name}"
      found=$(terraform workspace list | grep "${wkspace}" | wc -l)
      if [[ $found -eq 1 ]]
      then
        terraform workspace select "${wkspace}" >/dev/null
        force_unlock $wkspace
        if [[ $? -eq 0 ]];
        then
          domain=cf.$TF_VAR_domain_name
          cf_api="api.${domain}"
          (
            export VAULT_ADDR=$TF_VAR_login_vault_addr
            token=`curl --request POST --data '{"role_id": "'$login_approle_role_id'","secret_id": "'$login_approle_secret_id'"}' $VAULT_ADDR/v1/auth/approle/login| jq -r '.auth.client_token'`
            vault login token=$token
            cf_user=`vault read -format=json $vault_generic_secret_path/k8s.$TF_VAR_domain_name/cloudfoundry |jq -r '.data.cf_user'`
            cf_pwd=`vault read -format=json $vault_generic_secret_path/k8s.$TF_VAR_domain_name/cloudfoundry |jq -r '.data.cf_password'`
            cf l -a $cf_api -u $cf_user -p $cf_pwd -o system >/dev/null
          )
          rm -rf .terraform
        else
          echo "Failed to select workspace"
          rm temp.tf
          rm -rf .terraform
          exit 1
        fi
      else
        echo "Cloudfoundry has not been initialized."
        rm -rf .terraform
      fi
    else
      echo "Failed to initialize terraform"
      rm temp.tf
      exit 1
    fi
    rm temp.tf
  )
  abort_or_continue $?
}

prep_workspace(){
  found=$(terraform workspace list | grep "${1}" | wc -l)
  if [[ $found -eq 0 ]]
  then
    terraform workspace new $1 >/dev/null
  else
    terraform workspace select $1 >/dev/null
  fi
}

prepare_state_lock(){
stateLockTable=${TF_VAR_environment}.${TF_VAR_domain_name}
table=$(echo $(aws dynamodb list-tables|grep $stateLockTable))
[[ -n $table ]] ||  aws dynamodb create-table --table-name $stateLockTable --attribute-definitions AttributeName=LockID,AttributeType=S --key-schema AttributeName=LockID,KeyType=HASH --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5
}

force_unlock(){
stateLockTable=${TF_VAR_environment}.${TF_VAR_domain_name}
if [[ $FORCE_UNLOCK ==  "yes" ]]
then
  cmdd="aws dynamodb get-item --table-name $stateLockTable --key '{\"LockID\": {\"S\": \"$TF_VAR_bucket_name/env:/$1/tfstate\"}}' | grep -Ewo '[[:xdigit:]]{8}(-[[:xdigit:]]{4}){3}-[[:xdigit:]]{12}'"
  lockid=$(eval "$cmdd")
  [[ -z $lockid ]] || terraform force-unlock -force $lockid
fi
}

## Removed updating permissions to avoid unneccesary git status changes
#update_permissions(){
#  find "${modules}/brokers/components/" -type f -name "*.py" -not -path "${modules}/brokers/components/*/env/*" -exec chmod u+x {} \;
#  find "${modules}/brokers/components/" -type f -name "*.py" -not -path "${modules}/brokers/components/*/env/*" -exec dos2unix -q {} \;
#  find "${modules}/brokers/components/" -type f -name "Makefile" -exec dos2unix -q {} \;
#  find "${modules}" -type f -name "*.tf" -exec dos2unix -q {} \;
#  find "${modules}" -type f -name "*.sh" -exec dos2unix -q {} \;
#}

cleanup(){
  (
    cd $deployment
    find ./* -type d -name .terraform -exec rm -rf {} \; 2>/dev/null
    find ./* -type f -name .terraform.lock.hcl -exec rm -f {} \; 2>/dev/null
  )
}

show_banner
# TF manages separate locks per wkspace in same table
prepare_state_lock
login_to_k8s
login_to_cf
## Removed updating permissions to avoid unneccesary git status changes
#update_permissions
cleanup

export KOPS_STATE_STORE="s3://${TF_VAR_bucket_name}/kops"
## Setup modules

kops_upgrade(){
  printf "\nUpgrading kops cluster ...\n\n"
  cd modules/kubernetes
  stateLockTable="${TF_VAR_environment}.${TF_VAR_domain_name}"
  terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate"  -backend-config="dynamodb_table=$stateLockTable"  >/dev/null
  wkspace="kubernetes-${TF_VAR_environment}.${TF_VAR_domain_name}"
  prep_workspace $wkspace
  terraform taint null_resource.kops_cluster
  force_unlock $wkspace
  terraform plan -out "kubernetes.plan" -target="null_resource.kops_cluster" 
  if [[ $? -ne 0 ]];
  then
    echo "kubernetes plan failed."
    exit 1
  else
    terraform apply "kubernetes.plan"
    if [[ $? -ne 0 ]];
    then
      echo "kubernetes deployment failed."
      exit 1
    fi
    rm "kubernetes.plan"
    echo "kubernetes deployment completed."
  fi
}

if [[ "$TF_VAR_cluster_upgrade" == "true" ]]; then
  echo "Checking if the cluster is in ready state to be upgraded"
  if [[ `kops validate cluster --name ${TF_VAR_cluster_name} | grep 'ready'` ]]; then
    echo "Cluster is ready"
    echo "Starting cluster upgrade..."
    kops_upgrade
    abort_or_continue $?
  else
    echo "Cluster ${TF_VAR_cluster_name} is not in ready state to upgrade."
    echo "Kindly troubleshoot the cluster ${TF_VAR_cluster_name}"
  fi
else
  while IFS=$'\n' read -r line || [[ -n "$line" ]];
    do
      result=$(echo $line)
      if [ -z "$result" ];
      then
        continue
      fi
      (
          printf "\nDeploying module %s ...\n\n" $result
          module="$modules/$result"
          cd $module
          stateLockTable="${TF_VAR_environment}.${TF_VAR_domain_name}"
          terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate"  -backend-config="dynamodb_table=$stateLockTable"  >/dev/null
          wkspace="${result}-${TF_VAR_environment}.${TF_VAR_domain_name}"
          prep_workspace $wkspace
          n=0
          success=0
          until [ "$n" -ge 3 ]
          do
            force_unlock $wkspace
            terraform plan -out "${result}.plan"
            if [[ $? -ne 0 ]];
            then
              n=$((n+1))
              sleep 15
            else
              terraform apply "${result}.plan"
              if [[ $? -eq 0 ]];
              then
                success=1
                break
              fi
              n=$((n+1))
              sleep 15
            fi
          done
          if [[ $success -ne 1 ]];
          then
            echo "$result deployment failed."
            exit 1
          fi
          rm -f "${result}.plan"
          echo "$result deployment completed."
      )
      abort_or_continue $?

      let "minutes=$SECONDS/60"
      echo "Time taken for $result deployment was $minutes: minutes"
    done < $config

fi