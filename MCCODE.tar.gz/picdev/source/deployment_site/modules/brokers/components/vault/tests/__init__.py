from uuid import uuid4
from nose.tools import nottest

from .broker import service_catalog
from .config import config as config_map


config = config_map["testing"]


@nottest
def test_data(**kwargs):
    catalog = kwargs.get("service_catalog", service_catalog)
    default_service_id = catalog[0]["id"]
    default_plan_id = next(
        plan["id"] for plan in catalog[0]["plans"] if plan["name"] == "standard"
    )
    instance_id = kwargs.get("instance_id", str(uuid4()))
    service_id = kwargs.get("service_id", default_service_id)
    plan_id = kwargs.get("plan_id", default_plan_id)
    organization_guid = kwargs.get("organization_guid", "test-org-guid")
    space_guid = kwargs.get("space_guid", "test-space-guid")
    parameters = kwargs.get("parameters", {})
    default_context = {
        "platform": "cloudfoundry",
        "organization_guid": organization_guid,
        "space_guid": space_guid,
    }
    context = kwargs.get("context", default_context)
    binding_id = kwargs.get("binding_id", "test-binding-id")
    data = {
        "instance_id": instance_id,
        "service_id": service_id,
        "plan_id": plan_id,
        "organization_guid": organization_guid,
        "space_guid": space_guid,
        "parameters": parameters,
        "context": context,
        "binding_id": binding_id,
    }
    return data
