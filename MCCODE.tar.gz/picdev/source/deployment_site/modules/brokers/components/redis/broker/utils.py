import datetime
import random
import re
import secrets
import string
from base64 import b64decode, b64encode

import nacl.secret


def timestamp():
    now = datetime.datetime.utcnow().replace(microsecond=0).isoformat()
    return f"{now}Z"


def encrypt_data(data, key, iv=None):
    box = nacl.secret.SecretBox(key.encode("utf-8"))
    encrypted_value = box.encrypt(data.encode("utf-8"))
    return b64encode(encrypted_value).decode("utf-8")


def decrypt_data(data, key, iv=None):
    box = nacl.secret.SecretBox(key.encode("utf-8"))
    decrypted_value = box.decrypt(b64decode(data.encode("utf-8")))
    return decrypted_value.decode("utf-8")


def random_alphanum(length=20, lowercase=False):
    chars = string.digits
    if lowercase:
        chars += string.ascii_lowercase
    else:
        chars += string.ascii_letters
    return "".join(secrets.choice(chars) for _ in range(length))


def truncate_id(guid):
    return str(guid.split("-")[0])


def sanitize_label_value(value):
    # Transform CF object names into valid Kubernetes label values
    # See: https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/#syntax-and-character-set

    # Truncate at max length
    value = value[0:63]
    # Replace invalid chars with underscore
    value = re.sub("[^a-zA-Z0-9_.-]+", "_", value)
    valid = re.compile("(([A-Za-z0-9][-A-Za-z0-9_.]*)?[A-Za-z0-9])?")
    if not valid.fullmatch(value):
        # Now we have either leading or trailing non-alphanum chars, trim
        # those away and re-validate. If this fails, give up and return an
        # empty string (which is a valid value)
        value = value.lstrip("_.-")
        value = value.rstrip("_.-")
        if not valid.fullmatch(value):
            value = ""
    return value


def generate_password(num_bytes):
    chars = string.ascii_letters + string.digits
    return "".join(random.SystemRandom().choice(chars) for _ in range(num_bytes))
