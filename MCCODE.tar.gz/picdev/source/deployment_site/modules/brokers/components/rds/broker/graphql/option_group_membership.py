import graphene


class OptionGroupMembership(graphene.ObjectType):
    option_group_name = graphene.String()
    status = graphene.String()

    ####################################################
    # Resolve Methods
    ####################################################
