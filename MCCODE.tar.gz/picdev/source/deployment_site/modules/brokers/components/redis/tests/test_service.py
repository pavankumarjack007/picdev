from unittest import mock

from cf_broker_api.exceptions import (
    InvalidServiceParameter,
    ServiceInstanceAlreadyExists,
)

from broker.k8s import K8SClient
from tests import BaseTestCase, test_data


class TestServiceExceptions(BaseTestCase):
    def setUp(self):
        super(TestServiceExceptions, self).setUp()
        self.service = self.app.service_class

    def test_service_instance_already_exists(self):
        data = test_data()
        db_record = self.model.new_record(**data)
        db_record.save()
        with self.assertRaises(ServiceInstanceAlreadyExists):
            self.service.provision({}, data["instance_id"])

    @mock.patch.object(K8SClient, "delete_service", autospec=True)
    @mock.patch.object(K8SClient, "delete_stateful_set", autospec=True)
    @mock.patch.object(K8SClient, "namespace_exists", autospec=True)
    @mock.patch.object(K8SClient, "create_namespace", autospec=True)
    @mock.patch.object(K8SClient, "create_stateful_set", autospec=True)
    @mock.patch.object(K8SClient, "create_service", autospec=True)
    def test_invalid_operation_parameter(self, *args):
        data = test_data()
        self.client.provision(data)
        with self.assertRaises(InvalidServiceParameter) as context:
            self.service.last_operation({"operation": "invalid"}, data["instance_id"])
        exc = context.exception
        self.assertEqual(exc.code, 400)
        self.assertEqual(exc.description, "Invalid [operation] parameter: invalid")
