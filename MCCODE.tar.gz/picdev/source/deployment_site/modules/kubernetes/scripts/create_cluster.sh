#! /bin/bash
#Script to provisions the base platform for MicroCloud.
#Requires:- kOps (v1.21), terraform (v1.0.4)
#Requires: kubectl (1.15.5), aws-cli, jq
#Requires aws access_key, secret and region to be set (For example via:- aws configure ...)
#Requires Route53 hosted zone with the name that matches cluster_name

SECONDS=0

#default target to outpost if not provided in input profile
if [[ -z "${target_name}" ]]; then
  echo "The env var target_name was not set. Defaulting to outpost"
  export target_name=outpost
fi


if [ $# -eq 2 ]
then

  while [ "$1" != "" ]; do
      case $1 in
          -t | --target )
            shift
            target_name=$1
            echo "Final $target_name"
            ;;
      esac
      shift
  done
fi


## Setup env vars for terraform
chmod +x ./setup_env_vars.sh
source ./setup_env_vars.sh

#create ssh key pair
mkdir -p ../generated/ssh_keys
############# key_name is set in setup_env_vars.sh
#key_name=$(echo $cluster_name | tr '.' '_')

#echo "y" | ssh-keygen -b 4096 -t rsa -f ./ssh_keys/$key_name -q -N ''
#ssh-keygen -b 4096 -t rsa -f ../generated/ssh_keys/$key_name -q -N '' <<< ""$'\n'"y" 2>&1 >/dev/null
ssh_key="../generated/ssh_keys/$key_name.pub"

#use pe-defined profiles and overide sizing inputs from development.vars
MASTER_SIZE=m5.large
NODE_SIZE=m5.xlarge
NODE_COUNT=3
MASTER_COUNT=$TF_VAR_master_count

PROFILE=$TF_VAR_profile

ENV=$TF_VAR_environment

if [[ -z "${PROFILE}" ]]; then
  echo "The env var PROFILE was not set. Defaulting to small"
  export PROFILE="small"
fi


instaceType=m5
if [[ "$target_name" == "outpost" ]]
then
	instaceType=m5
	export TF_VAR_storage_class_name="ebs-sc"
	export storage_class_name="ebs-sc"

elif [[ "$target_name" == "cloud" ]]
then
	instaceType=c6i
	export TF_VAR_storage_class_name="ebs-sc"
    export storage_class_name="ebs-sc"
	
elif [[ "$target_name" == "sff" ]]
then
	instaceType=c5d
	export TF_VAR_storage_class_name="rook-ceph-block"
	export storage_class_name="rook-ceph-block"
else
	export TF_VAR_storage_class_name="ebs-sc"
    export storage_class_name="ebs-sc"
	echo UNKNOWN TARGET
fi

echo "profile is $PROFILE"
echo "Env is $ENV"

if [[ "$PROFILE" == "small" ]] && [[ "$ENV" == "prod"  ]]
then
  MASTER_SIZE=$(yq eval .spec.masters.size ../plans/plan_small_outposts_ebs.yaml)
  NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_small_outposts_ebs.yaml)
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_small_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_small_outposts_ebs.yaml)
  export NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_small_outposts_ebs.yaml)
  export NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_small_outposts_ebs.yaml)
  export MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_small_outposts_ebs.yaml)
  export TOTAL_NODECOUNT=$NODE_COUNT+$MASTER_COUNT
elif [[ "$PROFILE" == "small" ]] && [[ "$ENV" != "prod"  ]]
then
  MASTER_SIZE=$(yq eval .spec.masters.size ../plans/plan_small_outposts_ebs.yaml)
  NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_small_outposts_ebs.yaml)
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_small_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_small_outposts_ebs.yaml)
  export NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_small_outposts_ebs.yaml)
  export NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_small_outposts_ebs.yaml)
  export MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_small_outposts_ebs.yaml)
  export TOTAL_NODECOUNT=$NODE_COUNT+$MASTER_COUNT
elif [[ "$PROFILE" == "large" ]]
then
  MASTER_SIZE=$(yq eval .spec.masters.size ../plans/plan_large_outposts_ebs.yaml)
  NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_large_outposts_ebs.yaml)
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_large_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_large_outposts_ebs.yaml)
  LG_SIZE=$(yq eval .spec.workers.size2 ../plans/plan_large_outposts_ebs.yaml)
  LG_NODE_COUNT=$(yq eval .spec.workers.count2 ../plans/plan_large_outposts_ebs.yaml)
  TF_VAR_diego_cell_count=$(yq eval .spec.diegoCells.count ../plans/plan_large_outposts_ebs.yaml)
  export MASTER_SIZE=$(yq eval .spec.masters.size ../plans/plan_large_outposts_ebs.yaml)
  export NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_large_outposts_ebs.yaml)
  export NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_large_outposts_ebs.yaml)
  export MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_large_outposts_ebs.yaml)
  export LG_SIZE=$(yq eval .spec.workers.size2 ../plans/plan_large_outposts_ebs.yaml)
  export LG_NODE_COUNT=$(yq eval .spec.workers.count2 ../plans/plan_large_outposts_ebs.yaml)
  export TF_VAR_diego_cell_count=$(yq eval .spec.diegoCells.count ../plans/plan_large_outposts_ebs.yaml)
  export TOTAL_NODECOUNT=$NODE_COUNT+$LG_NODE_COUNT+$MASTER_COUNT
elif [[ "$PROFILE" == "medium" ]]
then
  MASTER_SIZE=$(yq eval .spec.masters.size ../plans/plan_medium_outposts_ebs.yaml)
  NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_medium_outposts_ebs.yaml)
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_medium_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_medium_outposts_ebs.yaml)
  LG_SIZE=$(yq eval .spec.workers.size2 ../plans/plan_medium_outposts_ebs.yaml)
  LG_NODE_COUNT=$(yq eval .spec.workers.count2 ../plans/plan_medium_outposts_ebs.yaml)
  TF_VAR_diego_cell_count=$(yq eval .spec.diegoCells.count ../plans/plan_medium_outposts_ebs.yaml)
  export MASTER_SIZE=$(yq eval .spec.masters.size ../plans/plan_medium_outposts_ebs.yaml)
  export NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_medium_outposts_ebs.yaml)
  export NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_medium_outposts_ebs.yaml)
  export MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_medium_outposts_ebs.yaml)
  export LG_SIZE=$(yq eval .spec.workers.size2 ../plans/plan_medium_outposts_ebs.yaml)
  export LG_NODE_COUNT=$(yq eval .spec.workers.count2 ../plans/plan_medium_outposts_ebs.yaml)
  export TF_VAR_diego_cell_count=$(yq eval .spec.diegoCells.count ../plans/plan_medium_outposts_ebs.yaml)
  export TOTAL_NODECOUNT=$NODE_COUNT+$LG_NODE_COUNT+$MASTER_COUNT
elif [[ "$PROFILE" == "xlarge" ]]
then
  MASTER_SIZE=$(yq eval .spec.masters.size ../plans/plan_extra_large_outposts_ebs.yaml)
  NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_extra_large_outposts_ebs.yaml)
  NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_extra_large_outposts_ebs.yaml)
  MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_extra_large_outposts_ebs.yaml)
  LG_SIZE=$(yq eval .spec.workers.size2 ../plans/plan_extra_large_outposts_ebs.yaml)
  LG_NODE_COUNT=$(yq eval .spec.workers.count2 ../plans/plan_extra_large_outposts_ebs.yaml)
  export MASTER_SIZE=$(yq eval .spec.masters.size ../plans/plan_extra_large_outposts_ebs.yaml)
  export NODE_SIZE=$(yq eval .spec.workers.size ../plans/plan_extra_large_outposts_ebs.yaml)
  export NODE_COUNT=$(yq eval .spec.workers.count ../plans/plan_extra_large_outposts_ebs.yaml)
  export MASTER_COUNT=$(yq eval .spec.masters.count ../plans/plan_extra_large_outposts_ebs.yaml)
  export LG_SIZE=$(yq eval .spec.workers.size2 ../plans/plan_extra_large_outposts_ebs.yaml)
  export LG_NODE_COUNT=$(yq eval .spec.workers.count2 ../plans/plan_extra_large_outposts_ebs.yaml)
  export TF_VAR_diego_cell_count=$(yq eval .spec.diegoCells.count ../plans/plan_extra_large_outposts_ebs.yaml)
  export TOTAL_NODECOUNT=$NODE_COUNT+$LG_NODE_COUNT+$MASTER_COUNT

fi

let "total_nodes=$TOTAL_NODECOUNT"


CF_FOR_K8S=$TF_VAR_cf_for_k8s

if [[ "$CF_FOR_K8S" == "true" ]]; then
  ### Currently using kubernetes v1.19.2 to support cf-for-k8s deployment. This version
  ### needs to be upgraded to the latest supported version at the earliest.
  echo "Using cf-for-k8s. Setting kubernetes version to v1.19.2"
  export KUBERNETES_VERSION="v1.19.2"
else
  echo "Using kubecf. Setting kubernetes version to v1.21.5"
  export KUBERNETES_VERSION="v1.21.5"
fi

# kops create cluster \
#     --cloud aws \
#     --node-count $NODE_COUNT \
#     --node-size $NODE_SIZE \
#     --master-size $MASTER_SIZE \
#     --master-count $MASTER_COUNT \
#     --zones $ZONES \
#     --topology private \
#     --networking flannel \
#     --bastion \
#     --etcd-storage-type gp2 \
#     --ssh-public-key $ssh_key \
#     --kubernetes-version $KUBERNETES_VERSION \
#     --vpc ${VPC_ID} \
#     --dns private \
#     --dns-zone ${HOSTED_ZONE_ID} \
#     ${cluster_name}

#fix error introduced by terraform aws provider v4.6.0
AWS_PROVIDER=$(cat <<EOF
{
      "source"  = "hashicorp/aws"
      "version" = ">= 3.34.0, <= 4.4.5"
    }
EOF
)

# export KOPS_STATE_STORE="s3://${TF_VAR_bucket_name}/kops"
# export IRSA_S3_BUCKET=s3://$TF_VAR_irsa_s3_bucket
export KOPS_STATE_STORE="s3://${var.bucket_name}/kops"
export IRSA_S3_BUCKET="s3://hsop-irsa-${TF_VAR_deployment_id}"
export ACC_ID=$(aws sts get-caller-identity | jq -r ".Account")
export VAULT_IAM_POLICY_ARN="arn:aws:iam::${ACC_ID}:policy/kms-policy-${TF_VAR_cluster_name}"
export VELERO_IAM_POLICY_ARN="arn:aws:iam::${ACC_ID}:policy/velero-${TF_VAR_cluster_name}"
export CERT_MANAGER_IAM_POLICY_ARN="arn:aws:iam::${ACC_ID}:policy/cert-manager-policy-${TF_VAR_cluster_name}"
export EXTERNAL_DNS_IAM_POLICY_ARN="arn:aws:iam::${ACC_ID}:policy/external-dns-policy-${TF_VAR_cluster_name}"

cluster_configuration(){
  echo "In kubernetes deployment"
  mkdir -p ../generated/terraform-k8s-private
  cp audit.yaml ../generated/ 
  cd ../generated/terraform-k8s-private
  #Get cluster config
  kops get ${cluster_name} -o yaml > ./cluster-desired-config-private.yaml
  #Modify cluster config
  yq -i e '(.spec|select(.role == "Bastion").rootVolumeType) |= "gp2"' ./cluster-desired-config-private.yaml
  yq -i e '(.spec|select(.role == "Master").rootVolumeType) |= "gp2"' ./cluster-desired-config-private.yaml
  yq -i e '(.spec|select(.role == "Node").rootVolumeType) |= "gp2"' ./cluster-desired-config-private.yaml
  yq -i e '(.|select(.kind == "Cluster").spec.cloudConfig.awsEBSCSIDriver.enabled) |= true' ./cluster-desired-config-private.yaml

  #Enable add-ons needed for IRSA on kops cluster
  # yq -i e '(.|select(.kind == "Cluster").spec.certManager.enabled) |= true' ./cluster-desired-config-private.yaml
  # yq -i e '(.|select(.kind == "Cluster").spec.certManager.managed) |= false' ./cluster-desired-config-private.yaml
  # yq -i e '(.|select(.kind == "Cluster").spec.podIdentityWebhook.enabled) |= true' ./cluster-desired-config-private.yaml
  #Managed subnets & security groups externally
  ##----------------------------------------------------------------------------------------------------------------------------------------------------##

  # add additional cidr
  yq -i e '.| select(.kind == "Cluster").spec.additionalNetworkCIDRs |= [env(INGRESS_CIDR)]' ./cluster-desired-config-private.yaml

  # add new subnet
  export ingress_subnet="ingress-${ZONES}"
  yq -i e '.| select(.kind == "Cluster").spec.subnets += [{"cidr": env(INGRESS_CIDR), "name": env(ingress_subnet), "type": "Public", "zone": env(ZONES)}]' ./cluster-desired-config-private.yaml

  yq -i e '(.| select(.kind == "Cluster").spec.subnets[] | select(.type == "Private")).id = env(PRIVATE_SUBNET_ID)' ./cluster-desired-config-private.yaml
  yq -i e '(.| select(.kind == "Cluster").spec.subnets[] | select(.type == "Utility")).id = env(UTILITY_SUBNET_ID)' ./cluster-desired-config-private.yaml
  yq -i e '(.| select(.kind == "Cluster").spec.subnets[] | select(.type == "Public")).id = env(INGRESS_SUBNET_ID)' ./cluster-desired-config-private.yaml
  yq -i e '(.| select(.kind == "Cluster").spec.subnets[]) |= .egress = "External"' ./cluster-desired-config-private.yaml

  yq -i e '(.|select(.kind == "InstanceGroup").spec|select(.role == "Bastion")).subnets |= [env(ingress_subnet)]' ./cluster-desired-config-private.yaml

  yq -i e '(.|select(.kind == "InstanceGroup").spec|select(.role == "Master")).securityGroupOverride |= env(MASTER_SG)' ./cluster-desired-config-private.yaml
  yq -i e '(.|select(.kind == "InstanceGroup").spec|select(.role == "Node")).securityGroupOverride |= env(NODE_SG)' ./cluster-desired-config-private.yaml
  yq -i e '(.|select(.kind == "InstanceGroup").spec|select(.role == "Bastion")).securityGroupOverride |= env(BASTION_SG)' ./cluster-desired-config-private.yaml

  ##----------------------------------------------------------------------------------------------------------------------------------------------------##

#  yq -i e '(.|select(.kind == "InstanceGroup").spec.machineType) |= "m5.large"' ./cluster-desired-config-private.yaml

  # #Setting up the mappings between k8s service accounts and AWS IAM policies
  # #Configure IRSA for Vault
  # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[0].name) |= "vault"'  ./cluster-desired-config-private.yaml
  # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[0].namespace) |= "vault"'  ./cluster-desired-config-private.yaml
  # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[0].aws.policyARNs[0]) |= env(VAULT_IAM_POLICY_ARN)'  ./cluster-desired-config-private.yaml
  # #Configure IRSA for Velero
  # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[1].name) |= "velero"'  ./cluster-desired-config-private.yaml
  # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[1].namespace) |= "velero"'  ./cluster-desired-config-private.yaml
  # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[1].aws.policyARNs[0]) |= env(VELERO_IAM_POLICY_ARN)'  ./cluster-desired-config-private.yaml
  # #Configure IRSA for Cert-Manager
  # # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[2].name) |= "cert-manager"'  ./cluster-desired-config-private.yaml
  # # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[2].namespace) |= "cert-manager"'  ./cluster-desired-config-private.yaml
  # # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[2].aws.policyARNs[0]) |= env(CERT_MANAGER_IAM_POLICY_ARN)'  ./cluster-desired-config-private.yaml
  # #Configure IRSA for External-DNS
  # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[2].name) |= "external-dns"'  ./cluster-desired-config-private.yaml
  # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[2].namespace) |= "kube-system"'  ./cluster-desired-config-private.yaml
  # yq -i e '(.|select(.kind == "Cluster").spec.iam.serviceAccountExternalPermissions[2].aws.policyARNs[0]) |= env(EXTERNAL_DNS_IAM_POLICY_ARN)'  ./cluster-desired-config-private.yaml
  #You may repeat the above 3 lines to configure IRSA for additional applications. Ensure IAM policy for that application is already created. Map it with k8s service account and namespace and IAM policy

  export localhost_ip=0.0.0.0
  echo $localhost_ip
  yq -i e '(.|select(.kind == "Cluster").spec.kubeProxy.metricsBindAddress) |= env(localhost_ip)' ./cluster-desired-config-private.yaml
  #yq -i e '(.|select(.kind == "InstanceGroup").spec.machineType) |= "m5.large"' ./cluster-desired-config-private.yaml

## Not required anymore, the bastion host runs on the cloud
##----------------------------------------------------------------------------------------------------------------------------------------------------##
  #Change bastion subnet
#  export utility_subnet="utility-${ZONES}"
#  export BASTION_NODE_SIZE=$MASTER_SIZE
#  yq -i e '(.|select(.kind == "InstanceGroup").spec|select(.role == "Bastion")).subnets |= [env(utility_subnet)]' ./cluster-desired-config-private.yaml
#  yq -i e '(.|select(.kind == "InstanceGroup").spec|select(.role == "Bastion")).machineType |= env(BASTION_NODE_SIZE)' ./cluster-desired-config-private.yaml
##----------------------------------------------------------------------------------------------------------------------------------------------------##

#  If profile is large, add an additional worker node group
   if [[ "$PROFILE" == "large" ]] || [[ "$PROFILE" == "xlarge" ]] || [[ "$PROFILE" == "medium" ]]
   then
     #In the terraform-k8s-private folder now
     envsubst < ../../templates/large_additional_ig.yaml > ../../templates/large_additional_ig_rep.yaml
     yq -i e '.spec.maxSize |= '"$LG_NODE_COUNT"'' ../../templates/large_additional_ig_rep.yaml
     yq -i e '.spec.minSize |= '"$LG_NODE_COUNT"'' ../../templates/large_additional_ig_rep.yaml
     cat ../../templates/large_additional_ig_rep.yaml >> ./cluster-desired-config-private.yaml
     export TF_VAR_diego_cell_count=3
   fi

  # Include additional user data for master
  sed -i 's/masterip/\$(curl -s http:\/\/169.254.169.254\/latest\/meta-data\/local-ipv4)/g' ../../templates/additionalud.yaml
  sed -i "s/oidc_issuer_url/${TF_VAR_domain_name}/g" ../../templates/additionalud.yaml
  sed -i '/sudo tee \/tmp\/ldap.sh/r ../../templates/ldap1.sh' ../../templates/additionalud.yaml
  sed -i '/sudo chmod +x \/tmp\/ldap.sh/r ../../templates/ldap3.sh' ../../templates/additionalud.yaml
  #sed -i '/sudo bash \/tmp\/ldap.sh/r ../../templates/ldap.sh' ../../templates/additionalud.yaml
  cat  ../../templates/ldap.sh >>  ../../templates/additionalud.yaml
  cp cluster-desired-config-private.yaml cluster-desired-config-private-copy.yaml
  sed  -i '/role: Master/i  \  compressUserData: true' cluster-desired-config-private-copy.yaml
  printf '0,/role: Master/-1 r ../../templates/additionalud.yaml\n,p\nq' |ed -s ./cluster-desired-config-private-copy.yaml | tr -d "?" >cluster-desired-config-private.yaml
  rm -rf ./cluster-desired-config-private-copy.yaml

  # Include additional user data for worker
  sed -i '/sudo tee \/tmp\/ldap.sh/r ../../templates/ldap1.sh' ../../templates/additionalud_worker.yaml
  sed -i '/sudo chmod +x \/tmp\/ldap.sh/r ../../templates/ldap3.sh' ../../templates/additionalud_worker.yaml
  cat  ../../templates/ldap.sh >>  ../../templates/additionalud_worker.yaml
  cp cluster-desired-config-private.yaml cluster-desired-config-private-copy.yaml
  sed  -i '/role: Node/i  \  compressUserData: true' cluster-desired-config-private-copy.yaml
  printf '0,/role: Node/-1 r ../../templates/additionalud_worker.yaml\n,p\nq' |ed -s ./cluster-desired-config-private-copy.yaml | tr -d "?" >cluster-desired-config-private.yaml
  rm -rf ./cluster-desired-config-private-copy.yaml

  #Include audit
  cp cluster-desired-config-private.yaml cluster-desired-config-private-copy.yaml
  printf '0,/cloudConfig:/-1 r ../audit.yaml\n,p\nq' | ed -s ./cluster-desired-config-private-copy.yaml | tr -d "?" > ./cluster-desired-config-private.yaml
  rm -rf ./cluster-desired-config-private-copy.yaml
#  rm -rf ../../templates/large_additional_ig_rep.yaml
}

hcl_configuration(){
  #TODO : for now SSF gets deployed on cloud, anything to be edited for SSF ?
  IFS=$'\n'
  if [ "$target_name" == "outpost" ]
  then
    #modify kubernetes.tf to add outposts arn
    
    sed -i 's/gp3/gp2/g' ./kubernetes.tf
    sed -i '/iops                  = 3000/d' ./kubernetes.tf
    sed -i '/throughput            = 125/d' ./kubernetes.tf
    lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_ebs_volume -e aws_subnet))
    for x in "${lines[@]}"; do
      echo Adding Outposts ARN to $x
      hcledit attribute append $x.outpost_arn "$outposts_arn" -f ./kubernetes.tf -u
    done
  fi

  lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_launch_template))
  for x in "${lines[@]}"; do
    echo Disable associate public ip address attribute in $x
    hcledit attribute set $x.network_interfaces.associate_public_ip_address 'false' -f ./kubernetes.tf -u
  done

  lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_autoscaling_group))
  for x in "${lines[@]}"; do
    echo Removing load_balancers attribute in $x
    hcledit attribute rm $x.load_balancers -f ./kubernetes.tf -u
  done

  lines=($(hcledit block list -f ./kubernetes.tf | grep -e aws_elb -e aws_route53_record))
  for x in "${lines[@]}"; do
    echo Removing ELB/Router53Record $x
    hcledit block rm $x -f ./kubernetes.tf -u
  done

  #remove elb security groups
  lines=($(hcledit block list -f ./kubernetes.tf | grep '^resource.aws_security_group\..*-elb-.*'))
  for x in "${lines[@]}"; do
          echo Removing security group $x
          hcledit block rm $x -f ./kubernetes.tf -u
  done

  #remove security group rules
  lines=($(hcledit block list -f ./kubernetes.tf | grep '^resource.aws_security_group_rule\..*-elb-.*' | grep -v '^resource.aws_security_group_rule\..*from-bastion-elb-.*-tcp-22to22-.*'))
  for x in "${lines[@]}"; do
          echo Removing security group rule $x
          hcledit block rm $x -f ./kubernetes.tf -u
  done

  #update security group rule
  lines=($(hcledit block list -f ./kubernetes.tf | grep '^resource.aws_security_group_rule\..*from-bastion-elb-.*-tcp-22to22-.*'))
  for x in "${lines[@]}"; do
          echo Updating security group rule $x
          hcledit attribute rm $x.source_security_group_id -f ./kubernetes.tf -u
          hcledit attribute append $x.cidr_blocks '["0.0.0.0/0"]' -f ./kubernetes.tf -u
  done
  

  hcledit block append terraform backend.s3 -f ./kubernetes.tf -u

  hcledit attribute set terraform.required_providers.aws "$AWS_PROVIDER" -f ./kubernetes.tf -u
  ## state lock already in force at this point
  terraform init -backend-config="bucket=$TF_VAR_bucket_name" -backend-config="key=tfstate"  >/dev/null
  wkspace="kops-${TF_VAR_environment}.${TF_VAR_domain_name}"
  found=$(terraform workspace list | grep "${wkspace}" | wc -l)
  if [[ $found -eq 0 ]]
  then
    terraform workspace new $wkspace
  else
    terraform workspace select $wkspace
  fi
  terraform plan -out ./full_auto.plan
  terraform apply "./full_auto.plan"
}


if [[ "$TF_VAR_cluster_upgrade" == "true" ]]; then
  echo "Starting cluster upgrade..."
  echo "Checking if the cluster is in ready state so it can be upgraded"
  if [[ `kops validate cluster --name ${TF_VAR_cluster_name} | grep 'ready'` ]]; then
    echo "Cluster is ready"

    cluster_configuration

    sed -i 's/kubernetesVersion: v1.21.5/kubernetesVersion: v1.22.0/g' ./cluster-desired-config-private.yaml
    kops replace -f ./cluster-desired-config-private.yaml --name ${cluster_name} --force
    #kops update cluster --name=${cluster_name} --out /tmp/kops --target terraform
    kops update cluster --name=${cluster_name} --out . --target terraform

    hcl_configuration

    kops rolling-update cluster ${cluster_name} --yes

  else
    echo "Cluster ${TF_VAR_cluster_name} is not in ready state to upgrade."
    echo "Kindly troubleshoot the cluster ${TF_VAR_cluster_name}"
  fi
else
  echo "Cluster named ${TF_VAR_cluster_name} doesn't exist"
  echo "Creating cluster ${TF_VAR_cluster_name}."


  kops create cluster \
      --cloud aws \
      --node-count $NODE_COUNT \
      --node-size $NODE_SIZE \
      --master-size $MASTER_SIZE \
      --master-count $MASTER_COUNT \
      --zones $ZONES \
      --topology private \
      --networking flannel \
      --discovery-store $IRSA_S3_BUCKET \
      --bastion \
      --etcd-storage-type gp2 \
      --ssh-public-key $ssh_key \
      --kubernetes-version $KUBERNETES_VERSION \
      --vpc ${VPC_ID} \
      --dns private \
      --dns-zone ${HOSTED_ZONE_ID} \
      ${cluster_name}

  cluster_configuration

  kops replace -f ./cluster-desired-config-private.yaml --name ${cluster_name} --force
  #kops update cluster --name=${cluster_name} --out /tmp/kops --target terraform
  kops update cluster --name=${cluster_name} --out . --target terraform

  hcl_configuration

fi
