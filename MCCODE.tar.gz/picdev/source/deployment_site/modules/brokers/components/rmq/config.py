import logging
import os
import uuid
from jinja2 import Environment, FileSystemLoader


class Config(object):
    # Flask-specific
    DEBUG = False
    TESTING = False

    BROKER_IS_ASYNC = True

    BROKER_USERNAME = os.getenv('BROKER_USERNAME', '')
    BROKER_PASSWORD = os.getenv('BROKER_PASSWORD', '')
    PORT = int(os.getenv('PORT', '8080'))

    DNS_ZONE = os.getenv('DNS_ZONE', '')
    K8S_API_ENDPOINT = os.getenv('K8S_API_ENDPOINT', '')
    K8S_CACERT = os.getenv('K8S_CACERT', '')
    K8S_NAMESPACE = os.getenv('K8S_NAMESPACE', 'managed-rmq')
    HSDP_REGION = os.getenv('HSDP_REGION', 'na1') 
    EXPORTER_IMAGE_TAG = os.getenv('EXPORTER_IMAGE_TAG', 'v0.29.0')
    DOCKER_REGISTRY_HOST = os.getenv('DOCKER_REGISTRY_HOST', '')
    DOCKER_IMAGE_NAME = os.getenv('DOCKER_IMAGE_NAME', '')
    RABBITMQ_IMAGE_VERSION = os.getenv('RABBITMQ_IMAGE_VERSION', '')

    CF_DOCKER_USERNAME = os.getenv('DOCKER_USERNAME', '')
    CF_DOCKER_PASSWORD = os.getenv('CF_DOCKER_PASSWORD', '')
    CF_DOCKER_REGISTRY = os.getenv('DOCKER_REGISTRY','')
    DOCKER_REGISTRY = os.getenv('DOCKER_REGISTRY','')
    DOCKER_USERNAME = os.getenv('DOCKER_USERNAME', '')
    DOCKER_REGISTRY_NAMESPACE = os.getenv('DOCKER_REGISTRY_NAMESPACE', '')
    DOCKER_REGISTRY_USER = os.getenv('DOCKER_REGISTRY_USER', '')
    DOCKER_REGISTRY_PASS = os.getenv('DOCKER_REGISTRY_PASS', '')
    STORAGE_CLASS = os.getenv('STORAGE_CLASS', '')
    BROKER_CONFIG = os.getenv('BROKER_CONFIG', '')
    K8S_BROKER_NAMESPACE = os.getenv('K8S_BROKER_NAMESPACE', '')
    K8S_BROKER_TOKEN = os.getenv('K8S_BROKER_TOKEN', '')
    GRAFANA_URL = os.getenv('GRAFANA_URL', '')
    DEPLOY_EXPORTER = os.getenv('DEPLOY_EXPORTER', 'true')
    DOMAIN_NAME = os.getenv("DOMAIN_NAME", "")

    RMQ_DOCKER_IMAGE = os.getenv('RMQ_DOCKER_IMAGE','')
    BROKER_API_KEY = os.getenv("BROKER_API_KEY", "<api_key>")
    GRAPHQL_SKIP_AUTH = False
    CF_API_ENDPOINT = os.getenv("CF_API_ENDPOINT", "<cf-api-endpoint>")
    UAA_OAUTH_CLIENT_ID = os.getenv("UAA_OAUTH_CLIENT_ID", "<client-id>")
    UAA_OAUTH_CLIENT_SECRET = os.getenv("UAA_OAUTH_CLIENT_SECRET", "<client-secret>")

    path = os.path.dirname(os.path.realpath(__file__))
    j2 = Environment(loader=FileSystemLoader(path), trim_blocks=True)
    broker_template = j2.get_template('broker/templates/broker.yaml')
    role_template = j2.get_template('broker/templates/role.yaml')
    rolebinding_template = j2.get_template('broker/templates/rolebinding.yaml')
    serviceaccount_template = j2.get_template(
        'broker/templates/serviceaccount.yaml'
    )
    service_template = j2.get_template('broker/templates/service.yaml')
    service_headless_template = j2.get_template(
        'broker/templates/service-headless.yaml'
    )
    credentials_template = j2.get_template('broker/templates/credentials.yaml')
    credentials_update_template = j2.get_template(
        'broker/templates/credentials_update.yaml'
    )
    configmap_template = j2.get_template('broker/templates/configmap.yaml')
    pdb_template = j2.get_template('broker/templates/pdb.yaml')
    statefulset_template = j2.get_template('broker/templates/statefulset.yaml')
    networkpolicy_template = j2.get_template(
        'broker/templates/networkpolicy.yaml'
    )
    exporter_role_template = j2.get_template(
        'broker/templates/exporter-role.yaml'
    )
    exporter_rolebinding_template = j2.get_template(
        'broker/templates/exporter-rolebinding.yaml'
    )
    exporter_serviceaccount_template = j2.get_template(
        'broker/templates/exporter-serviceaccount.yaml'
    )
    exporter_secret_template = j2.get_template(
        'broker/templates/exporter-secret.yaml'
    )
    exporter_deployment_template = j2.get_template(
        'broker/templates/exporter-deployment.yaml'
    )
    exporter_service_template = j2.get_template(
        'broker/templates/exporter-service.yaml'
    )
    exporter_networkpolicy_template = j2.get_template(
        'broker/templates/exporter-networkpolicy.yaml'
    )
    exporter_ingress_template = j2.get_template(
        'broker/templates/exporter-ingress.yaml'
    )

    log_format = logging.Formatter(
        '%(asctime)s [%(levelname)s] %(name)s: %(message)s')
    log_level = int(logging.DEBUG)

    @property
    def cc_config(self):
        return {
            "base_url": self.CF_API_ENDPOINT,
            "client_id": self.UAA_OAUTH_CLIENT_ID,
            "client_secret": self.UAA_OAUTH_CLIENT_SECRET,
        }


class DevelopmentConfig(Config):
    DEBUG = True


class TestingConfig(Config):
    TESTING = True
    DEBUG = False

    BROKER_USERNAME = ''
    BROKER_PASSWORD = ''

    # Table name uuid allows concurrent test runs.
    TEST_RUN_GUID = str(uuid.uuid4())

    PREFIX = 'wolf-test'

    GRAPHQL_SKIP_AUTH = True
    GRAPHIQL_ENABLED = True


class ProductionConfig(Config):
    DEBUG = False

    log_format = logging.Formatter('[%(levelname)s] %(name)s: %(message)s')
    log_level = int(logging.INFO)


class CloudFoundryConfig(ProductionConfig):
    LOGGING_MSG_FORMAT = os.getenv(
        'LOGGING_MSG_FORMAT', '%(levelname)s:%(name)s:%(message)s')

class DeploymentConfig(ProductionConfig):

    CF_APP_NAME = os.getenv("CF_APP_NAME", "hsdp-rabbitmq-test")
    BGD_CF_APP_NAME = "{}-new".format(CF_APP_NAME)

    CF_BUILDPACK = os.getenv("CF_BUILDPACK", "python_buildpack")
    CF_URL = os.getenv("CF_URL", "<cf-url>")
    CF_ORG = os.getenv("CF_ORG", "<cf-org>")
    CF_SPACE = os.getenv("CF_SPACE", "<cf-space>")
    CF_USER = os.getenv("CF_USER", "<cf-user>")
    CF_PASSWORD = os.getenv("CF_PASSWORD", "<cf-password>")

    DEPLOY_WITH_SMOKETESTS = os.getenv("DEPLOY_WITH_SMOKETESTS", "true")
    BROKER_CONFIG = os.getenv("BROKER_CONFIG", "production")


# Global config object
config_map = {
    'development': DevelopmentConfig(),
    'testing': TestingConfig(),
    'production': ProductionConfig(),
    'cloudfoundry': CloudFoundryConfig(),
    'default': DevelopmentConfig(),
    'deployment': DeploymentConfig()
}
