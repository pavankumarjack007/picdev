========================================
HSDP S3 Service Broker for Cloud Foundry
========================================

.. toctree::
     :maxdepth: 2

Overview
========

The HSDP S3 Service Broker can be used to create Amazon S3 buckets via the Cloud Foundry marketplace.
A new generic plan, **s3_bucket**, allows a bucket to be created in a user defined region
(`<http://docs.aws.amazon.com/general/latest/gr/rande.html#s3_region>`_).  When a bucket is created, an IAM
user and inline policy are also created.  The policy allows the API keys that were generated for the service
to have full control over the single bucket created as part of the request. The security policy will also
allow the bucket's API keys to use STS (Security Token Service)  to create temporary, limited-privilege
credentials for your S3 bucket.  The temporary credentials can then be granted to third parties or
applications to give them access to the resources needed for your use case.  For additional information
on the STS service visit the `Amazon STS documentation <http://docs.aws.amazon.com/STS/latest/APIReference/Welcome.html>`_.
The API keys, endpoint, and bucket name are all provided to any bound Cloud Foundry apps as part of the VCAP credentials.

.. note::

    - Plan names, corresponding to the AWS region still exist, but are being deprecated in favor of a generic **s3_bucket** plan.
    - For all CF brokers, except for China (**cn-north-1**), the default region for the bucket is **us-east-1**. China will default to **cn-north-1** (the only choice at this time).
    - Previously-created S3 Buckets can have their IAM User Policy updated to include the latest permissions using the `RefreshPolicy <#HSDPS3ServiceBrokerforCloudFoundry-RefreshPolicy>`_ parameter.

Optional Parameter Support
==========================

The HSDP S3 Service Broker supports the following optional parameters when creating or updating a service instance:

+-----------------------------+--------+--------+
| Parameter                   | Create | Update |
+=============================+========+========+
| Region                      | yes    | no     |
+-----------------------------+--------+--------+
| BucketLifecycle             | yes    | yes    |
+-----------------------------+--------+--------+
| EnforceSecureCommunications | yes    | yes    |
+-----------------------------+--------+--------+
| EnforceServerSideEncryption | yes    | yes    |
+-----------------------------+--------+--------+
| CORSConfiguration           | yes    | yes    |
+-----------------------------+--------+--------+
| RefreshPolicy               | no     | yes    |
+-----------------------------+--------+--------+
| GrantAccess                 | yes    | yes    |
+-----------------------------+--------+--------+
| RevokeAccess                | no     | yes    |
+-----------------------------+--------+--------+

**Region**
----------

Use this optional parameter with any plan to create the bucket in the specified region.  While **s3_bucket** should be the
only plan used going forward, the **Region** param will overwrite any region specific plans.   If **Region** is not passed,
the bucket will default to **us-east-1**, unless the CF deployment/broker is in China (**cn-north-1**) in which case the
bucket can only be created in **cn-north-1**. Any invalid region will result in a ``400 BAD REQUEST``.

A list of regions can be found here: `<http://docs.aws.amazon.com/general/latest/gr/rande.html#s3_region>`_ under the
region column.

Example JSON:

.. code-block:: javascript

   {"Region": "us-west-2"}

Example Cloud Foundry CLI commands:

.. code-block:: bash

   cf create-service hsdp-s3 s3_bucket <SERVICE_INSTANCE> -c '{"Region": "us-west-2"}'

**BucketLifecycle**
-------------------

Use this parameter to specify a custom lifecycle configuration for your S3 bucket (see AWS documentation for more information on supported configurations).

Example JSON:

.. code-block:: javascript
   :caption: bucketlifecycle.json

   {
     "BucketLifecycle": {
       "Rules": [
         {
           "Status": "Enabled",
           "Prefix": "",
           "Transitions": [
             {
               "Days": 10,
               "StorageClass": "GLACIER"
             }
           ],
           "ID": "Move to Glacier"
         }
       ]
     }
   }

Example Cloud Foundry CLI commands:

.. code-block:: bash
   :caption: Create bucket that moves all data to Glacier after 10 days

   cf create-service hsdp-s3 s3_bucket <SERVICE_INSTANCE> -c bucketlifecycle.json

.. code-block:: bash
   :caption: Remove bucket lifecycle configuration

   cf update-service <SERVICE_INSTANCE> -c '{"BucketLifecycle": {}}'

.. danger::

    Whatever you pass to the broker for your bucket Lifecycle configuration will **overwrite** whatever is already
    there.  If you want to append a new rule, for example, you'll need to get a copy of your existing bucket Lifecycle
    configuration (available via the `Service Dashboard <#HSDPS3ServiceBrokerforCloudFoundry-ServiceDashboard>`_),
    modify it as needed, and then pass the **complete** modified configuration to the broker on your next
    ``update-service`` command.

**EnforceSecureCommunications**
-------------------------------

Setting this parameter to true will disable HTTP access to an S3 bucket, limiting S3 traffic to only HTTPS requests.

Example Cloud Foundry CLI command:

.. code-block:: bash
   :caption: Disable HTTP access to a bucket

   cf update-service <SERVICE_INSTANCE> -c '{"EnforceSecureCommunications": true}'

**EnforceServerSideEncryption**
-------------------------------

Setting this parameter to *true* will prevent unencrypted objects from being uploaded to the S3 bucket.
If set to *false*, the bucket will not enforce server-side encryption and will accept both encrypted and
unencrypted object uploads.

.. note::

   When this feature is enabled, bucket uploads must specify **AES256** as the server-side encryption method.

Example Cloud Foundry CLI command:

.. code-block:: bash
   :caption: Prevent unencrypted uploads to an existing bucket

   cf update-service <SERVICE_INSTANCE> -c '{"EnforceServerSideEncryption": true}'

**CORSConfiguration**
---------------------

Use this parameter to specify a custom CORS configuration for your S3 bucket (see AWS documentation for more information on supported configurations).
Example JSON:

.. code-block:: javascript
   :caption: bucketcors.json

   {
     "CORSConfiguration": {
       "CORSRules": [
         {
           "AllowedHeaders": [
             "*"
           ],
           "AllowedMethods": [
             "PUT",
             "POST",
             "DELETE"
           ],
           "AllowedOrigins": [
             "http://example.com",
             "https://secure.example2.com"
           ],
           "ExposeHeaders": [],
           "MaxAgeSeconds": 500
         }
       ]
     }
   }

Example Cloud Foundry CLI commands:

.. code-block:: bash
   :caption: Create bucket with custom CORS configuration

   cf create-service hsdp-s3 s3_bucket <SERVICE_INSTANCE> -c bucketcors.json

.. code-block:: bash
   :caption: Remove bucket CORS configuration

   cf update-service <SERVICE_INSTANCE> -c '{"CORSConfiguration": {}}'

**RefreshPolicy**
-----------------

The IAM User Policy for HSDP-brokered S3 buckets is occasionally modified to grant newer permissions.  You can
use the *RefreshPolicy* parameter to ensure your bucket's IAM user credentials are up-to-date with the latest
permissions.

.. tip::

   Use this parameter only when your credentials are restricted from using newer permissions that you know the
   HSDP S3 Service Broker currently supports.

Example Cloud Foundry CLI Commands:

.. code-block:: bash
   :caption: Update IAM User Permissions

   cf update-service <SERVICE_INSTANCE> -c '{"RefreshPolicy": true}'

**GrantAccess**
---------------

Adds the AWS Principal (User, Role) in the specified list of ARNs to the bucket's resource policy, granting read/write
access.

.. note::

   The principal being granted bucket access must have have been granted permissions to access the bucket themselves.

Example Cloud Foundry CLI command:

.. code-block:: bash
   :caption: Grant bucket access to an EMR cluster role ARN

   cf update-service <SERVICE_INSTANCE> -c '{"GrantAccess": ["arn:aws:iam::123456789012:role/hadoop-core-123456"]}'


**RevokeAccess**
----------------

Removes the AWS Principal ARNs in the specified list from the bucket's resource policy, revoking any previously granted
read/write access.

Example Cloud Foundry CLI command:

.. code-block:: bash
   :caption: Revoke bucket access by an EMR cluster role ARN that was previously granted access.

   cf update-service <SERVICE_INSTANCE> -c '{"RevokeAccess": ["arn:aws:iam::123456789012:role/hadoop-core-123456"]}'

Service Credentials
===================

Example service credentials as stored in ``VCAP_SERVICES``:

.. code-block:: javascript

   {
    "VCAP_SERVICES": {
     "hsdp-s3": [
      {
       "credentials": {
        "api_key": "<api_key>",
        "bucket": "cf-s3-55555555-5555-5555-55555-555555555555",
        "endpoint": "s3-external-1.amazonaws.com",
        "location_constraint": null,
        "secret_key": "<secret_key>",
        "uri": "s3:/<api_key>:<secret_key>@s3-external-1.amazonaws.com/cf-s3-55555555-5555-5555-55555-555555555555"
       },
       "label": "hsdp-s3",
       "name": "s3-service-instance-name",
       "plan": "s3_bucket",
       "provider": null,
       "syslog_drain_url": null,
       "tags": [
        "AWS",
        "S3"
       ],
       "volume_mounts": []
      }
     ]
    }
   }

**Rotate API Key**
------------------

The Amazon API key/secret for your S3 Service Instance can be rotated using the cf cli:

.. code-block:: bash
   :caption: Rotate API Key

   cf update-service <SERVICE_INSTANCE>> -c '{"RotateApiKey": true}'

Upon successfully running the update command, follow the Cloud Foundry guidelines for
`updating your application's service credentials <https://docs.cloudfoundry.org/devguide/services/application-binding.html#update-credentials>`_.

Deleting Non-Empty Buckets
================================

.. attention::

    **Note** Deprovisioning your S3 Bucket service instance can take a very long time.  An empty bucket will
    be deleted immediately, but non-empty buckets must be purged of all objects first.  The service broker will
    do this for you, but it can take several minutes or even hours to clear out thousands of objects.

    In a worst-case scenario, where your bucket has hundreds of thousands or millions of objects, deprovisioning
    could take ~36-48 hours.

    If you re-use service instance names, be aware that your S3 Bucket instance name will **not** be available
    until the deprovision is complete.

Service Dashboard
=================

The HSDP S3 Service Broker implements a Service Dashboard that can be used to view the S3-specific properties of your
service instance and exposes some additional functionality not available through the Cloud Foundry CLI.

Each Cloud Foundry region has its own S3 Service Dashboard.

+--------+---------------------------------------------------------------+
| Region | URL                                                           |
+========+===============================================================+
| apac1	 | `<https://hsdp-s3.cloud.pcfdev.com/dashboard/>`_              |
+--------+---------------------------------------------------------------+
| apac2	 | `<https://hsdp-s3.ap-ne.philips-healthsuite.com/dashboard/>`_ |
+--------+---------------------------------------------------------------+
| cn1be	 | `<https://hsdp-s3.cn1.phsdp.com/dashboard/>`_                 |
+--------+---------------------------------------------------------------+
| eu1	 | `<https://hsdp-s3.eu1.phsdp.com/dashboard/>`_                 |
+--------+---------------------------------------------------------------+
| na1	 | `<https://hsdp-s3.cloud.pcftest.com/dashboard/>`_             |
+--------+---------------------------------------------------------------+
| na3    | `<https://hsdp-s3.cloud.phsdp.com/dashboard/>`_               |
+--------+---------------------------------------------------------------+

