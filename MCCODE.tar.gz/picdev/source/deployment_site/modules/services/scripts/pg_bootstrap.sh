#! /bin/bash

pg_containers="1/1"
  while : ; do
      echo "Checking if all containers for pg pod are ready"
      result=$(kubectl -n vault get po postgresql-postgresql-0 | grep postgresql-postgresql-0 | awk '{ print $2 }')
      echo "Expecting $pg_containers .. Current $result"
      if [[ "$result" == "$pg_containers" ]]
      then
        break
      fi
      sleep 10
  done

conn_str=postgres://postgres:${1}@postgresql.vault.svc.cluster.local:5432/vaultdb
kubectl -n vault exec -it postgresql-postgresql-0 -- psql $conn_str -c "`cat vault_create_schema.sql`"

#Update vault values file template to reflect the pg password
export vault_pg_pass=$1
export kms_key=$2
export aws_region=$3
export storage_class_name=$4
envsubst < ../templates/values-pg.tpl