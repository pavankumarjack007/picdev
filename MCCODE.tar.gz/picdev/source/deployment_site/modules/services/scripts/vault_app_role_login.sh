#! /bin/bash

root_token=$(kubectl -n vault get secret vault-root-token -o json | jq -r '.data.root_token' | base64 --decode)
result=$(kubectl -n vault exec vault-0 -- vault login -no-print ${root_token})

result=$(kubectl -n vault exec vault-0 -- vault secrets enable -path=/minio/kes kv)

result=$(kubectl -n vault cp ../values/minio-kes-policy.hcl vault-0:/home/vault)

result=$(kubectl -n vault exec vault-0 -- vault policy write minio-kes /home/vault/minio-kes-policy.hcl)

result=$(kubectl -n vault exec vault-0 -- vault auth enable approle)

result=$(kubectl -n vault exec vault-0 -- vault write -format=json auth/approle/role/minio-kes \
    bind_secret_id=true \
    policies=minio-kes \
    token_ttl=60m \
    token_max_ttl=120m)

ROLE_ID=$(kubectl -n vault exec vault-0 -- vault read -format=json auth/approle/role/minio-kes/role-id | jq -r '.data.role_id')
SECRET_ID=$(kubectl -n vault exec vault-0 -- vault write -format=json -f auth/approle/role/minio-kes/secret-id | jq -r '.data.secret_id')

echo $(jq -n --arg role_id "$ROLE_ID" --arg secret_id "$SECRET_ID" '{"role_id":$role_id, "secret_id": $secret_id}')