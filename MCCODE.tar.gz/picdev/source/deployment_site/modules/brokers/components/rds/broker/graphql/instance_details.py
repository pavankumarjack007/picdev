import graphene

from broker.graphql.db_parameter_group import DbParameterGroup
from broker.graphql.db_subnet_group import DbSubnetGroup
from broker.graphql.endpoint import Endpoint
from broker.graphql.option_group_membership import OptionGroupMembership

engine_lookup = {
    "aurora": "Aurora MySQL 5.6",
    "aurora-mysql": "Aurora MySQL 5.7",
    "aurora-postgresql": "Aurora PostgreSQL",
    "mysql": "MySQL",
    "postgres": "PostgreSQL",
    "sqlserver-ee": "SQL Server Enterprise Edition",
    "sqlserver-ex": "SQL Server Express Edition",
    "sqlserver-se": "SQL Server Standard Edition",
    "sqlserver-web": "SQL Server Web Edition",
}

storage_lookup = {
    "aurora": "DB Cluster",
    "gp2": "General Purpose (SSD)",
}


class InstanceDetails(graphene.ObjectType):
    engine = graphene.String()
    engine_version = graphene.String()
    storage_type = graphene.String()
    database_engine = graphene.String()
    disk_storage = graphene.String()
    license_model = graphene.String()
    instance_create_time = graphene.String()
    db_name = graphene.String()
    master_username = graphene.String()
    option_group_memberships = graphene.List(OptionGroupMembership)
    db_parameter_groups = graphene.List(DbParameterGroup)
    copy_tags_to_snapshot = graphene.Boolean()
    dbi_resource_id = graphene.String()
    availability_zone = graphene.String()
    db_subnet_group = graphene.Field(DbSubnetGroup)
    publicly_accessible = graphene.Boolean()
    endpoint = graphene.Field(Endpoint)
    iops = graphene.String()
    allocated_storage = graphene.String()
    max_allocated_storage = graphene.String()
    encrypted_storage = graphene.Boolean(
        deprecation_reason="Use storageEncrypted instead."
    )
    storage_encrypted = graphene.Boolean(description="Is the storage encrypted?")
    db_instance_status = graphene.String()
    multi_az = graphene.Boolean()
    backup_retention_period = graphene.String()
    latest_restorable_time = graphene.String()
    read_replica_db_instance_identifiers = graphene.List(graphene.String)
    auto_minor_version_upgrade = graphene.Boolean()
    preferred_maintenance_window = graphene.String()
    preferred_backup_window = graphene.String()
    pending_modified_values = graphene.String()
    is_clustered = graphene.Boolean()
    db_instance_class = graphene.String()
    character_set_name = graphene.String()
    exporter_hostname = graphene.String()

    def resolve_database_engine(self, _):
        engine_name = engine_lookup.get(self["engine"], self["engine"])
        return "{} {}".format(engine_name, self["engine_version"])

    def resolve_disk_storage(self, _):
        try:
            storage_type = storage_lookup[self["storage_type"]]
        except KeyError:
            storage_type = self["storage_type"]
        return storage_type

    def resolve_encrypted_storage(self, _):
        return self["storage_encrypted"]

    def resolve_is_clustered(self, _):
        return self["engine"].startswith("aurora")

    def resolve_pending_modified_values(details, _):
        return None

    def resolve_exporter_hostname(self, _):
        return self["exporterHostname"]
