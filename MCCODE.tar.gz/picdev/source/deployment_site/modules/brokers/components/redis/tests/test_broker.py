from unittest import mock

from broker.k8s import K8SClient
from tests import BaseTestCase, test_data


class TestBroker(BaseTestCase):
    def test_catalog(self):
        resp = self.client.catalog()
        self.assertEqual(resp.status_code, 200)

    @mock.patch.object(K8SClient, "namespace_exists", autospec=True)
    @mock.patch.object(K8SClient, "create_namespace", autospec=True)
    @mock.patch.object(K8SClient, "create_stateful_set", autospec=True)
    @mock.patch.object(K8SClient, "create_service", autospec=True)
    def test_provision(self, *args):
        data = test_data()
        resp = self.client.provision(data)
        self.assertEqual(resp.status_code, 202)
        db_record = self.model.get(data["instance_id"])
        self.assertIsNotNone(db_record)

    @mock.patch.object(K8SClient, "namespace_exists", autospec=True)
    @mock.patch.object(K8SClient, "create_namespace", autospec=True)
    @mock.patch.object(K8SClient, "create_stateful_set", autospec=True)
    @mock.patch.object(K8SClient, "create_service", autospec=True)
    def test_bind(self, *args):
        data = test_data()
        self.client.provision(data)
        resp = self.client.bind(data)
        self.assertEqual(resp.status_code, 201)
        credentials = resp.json["credentials"]
        db_record = self.model.get(data["instance_id"])
        self.assertEqual(len(db_record.binding_ids), 1)
        self.assertEqual(db_record.binding_ids[0], data["binding_id"])
        self.assertEqual(db_record.credentials.hostname, credentials["hostname"])
        self.assertEqual(db_record.credentials.password, credentials["password"])
        self.assertEqual(db_record.credentials.port, credentials["port"])

    # self.assertEqual(db_record.credentials.username, credentials["username"])

    def test_unbind(self):
        data = test_data(binding_id="test-binding-id1")
        db_record = self.model.new_record(**data)
        db_record.binding_ids = ["test-binding-id1", "test-binding-id2"]
        db_record.save()
        resp = self.client.unbind(data)
        self.assertEqual(resp.status_code, 200)
        db_record = self.model.get(data["instance_id"])
        self.assertEqual(len(db_record.binding_ids), 1)
        self.assertEqual(db_record.binding_ids[0], "test-binding-id2")

    @mock.patch.object(K8SClient, "namespace_exists", autospec=True)
    @mock.patch.object(K8SClient, "create_namespace", autospec=True)
    @mock.patch.object(K8SClient, "create_stateful_set", autospec=True)
    @mock.patch.object(K8SClient, "create_service", autospec=True)
    @mock.patch.object(K8SClient, "delete_service", autospec=True)
    @mock.patch.object(K8SClient, "delete_stateful_set", autospec=True)
    def test_deprovision(self, *args):
        data = test_data()
        resp = self.client.provision(data)
        self.assertEqual(resp.status_code, 202)
        resp = self.client.deprovision(data)
        self.assertEqual(resp.status_code, 202)
