import logging

from cf_broker_api import reqparse
from cf_broker_api.exceptions import (
    InvalidServiceParameter,
    ServiceInstanceAlreadyExists,
    ServiceInstanceGone,
    ServiceInstanceNotFound,
)

from . import cloudfoundry
from .operations import Deprovision, OpState, Provision
from .utils import generate_password, sanitize_label_value

LOG = logging.getLogger(__name__)


class ContextAwareRedisServiceInstanceService(object):
    def __init__(self, request, app, config):
        self.app = app
        self.config = config
        self.request = request
        self.service_class = self.app.service_class

        try:
            LOG.debug("creating cc")
            cc_args = config.cc_config.copy()
            cc_args.update({"access_token": request.headers["X-User-Access-Token"]})
            self.cc = cloudfoundry.CloudController.new_instance(**cc_args)
        except Exception as e:
            LOG.error("Failed to create CC client!:", exc_info=True)

            raise e

    def get_instances(self):
        print("Calling context aware")
        return cloudfoundry.get_instances(self.cc)

    def instance_permissions(self, instance_id):
        return self.cc.instance_permissions(instance_id)

    def service_catalog(self):
        plans = []
        name = self.app.service_catalog.services[0]["name"]
        for plan in self.app.service_catalog.services[0]["plans"]:
            plans.append(plan)

        res = self.cc.services().get_by_name(name, "label")
        service = res.resources[0]
        accessible_plans = []
        res = self.cc.services(service.guid, "service_plans").get()
        for plan in res.resources:
            accessible_plans.append(plan.unique_id)

        # Now set restrictions
        for plan in plans:
            if plan["id"] not in accessible_plans:
                plan["restricted"] = True

        return {"name": name, "plans": plans}

    def instance_details(self, instance_id):
        return self.service_class.instance_details(instance_id)


class RedisBrokerService:
    def __init__(self, config, model):
        self.config = config
        self.log = logging.getLogger(__name__)
        self.model = model
        self.prefix = self.config.SERVICE_PREFIX
        self._provision = Provision(config)
        self._deprovision = Deprovision(config)

    def get_service_record(self, instance_id):
        service_record = self.model.get(instance_id)
        if service_record is None:
            raise ServiceInstanceNotFound(instance_id)
        return service_record

    def provision(self, request, instance_id):
        self.log.info(f"Provisioning instanceId {instance_id}")
        if self.model.get(instance_id) is not None:
            raise ServiceInstanceAlreadyExists(instance_id)
        settings = request.plan["settings"]
        namespace = self.config.K8S_BROKER_NAMESPACE
        service_record = self.model.new_record(**request)
        service_record.instance_id = instance_id
        service_record.instance_name = sanitize_label_value(
            request.context.get("instance_name")
        )
        service_record.service_namespace = namespace
        service_record.organization_name = sanitize_label_value(
            request.context.get("organization_name")
        )
        service_record.plan_env = settings["env"]
        service_record.space_name = sanitize_label_value(
            request.context.get("space_name")
        )
        service_record.service_id = request.service_id
        service_record.service_name = f"redis-{instance_id}"
        service_record.credentials = self.model.Credentials(
            hostname=f"{service_record.service_name}.{namespace}.svc.cluster.local",
            port=6379,
            password=generate_password(32),
        )
        service_record.last_operation = {
            "state": OpState.IN_PROGRESS,
            "description": "CreateService",
        }
        service_record.save()
        self._provision.create_service(service_record)
        return {"operation": "provision"}

    def deprovision(self, request):
        service_record = self.get_service_record(request.instance_id)
        self._deprovision.delete_service(service_record)
        service_record.last_operation = {
            "state": OpState.IN_PROGRESS,
            "description": "DeleteService",
        }
        service_record.save()
        return {"operation": "deprovision"}

    def bind(self, request):
        service_record = self.get_service_record(request.instance_id)
        binding_id = request.binding_id
        if binding_id not in service_record.binding_ids:
            service_record.binding_ids.append(binding_id)
            service_record.save()
        else:
            self.log.warning(
                f"Binding {binding_id} already exists for instance {request.instance_id}"
            )
        return {"credentials": service_record.credentials.attribute_values}

    def unbind(self, request):
        service_record = self.get_service_record(request.instance_id)
        for index, value in enumerate(service_record.binding_ids):
            if value == request.binding_id:
                del service_record.binding_ids[index]
                service_record.save()
                break

    def last_operation(self, request, instance_id):
        service_record = self.get_service_record(instance_id)
        last_operation = request.get("operation")
        description = "Creating redis service instance"
        if last_operation == "provision":
            state = self._provision.state(service_record)
            service_record.last_operation = {
                "state": state,
                "description": description,
            }
            service_record.save()
        elif last_operation == "deprovision":
            description = "Deleting redis service instance "
            state = self._deprovision.state(service_record)
            if state == OpState.SUCCEEDED:
                service_record.delete()
                raise ServiceInstanceGone(instance_id)
        else:
            raise InvalidServiceParameter(
                "Invalid [operation] parameter: {}".format(last_operation)
            )
        return {"state": state, "description": description}

    def instance_details(self, instance_id):
        try:
            service_record = self.get_service_record(instance_id)
            endpoints = {}
            endpoints.update(
                {
                    "exporterHostname": f"redis-exporter-{instance_id}.{self.config.K8S_BROKER_NAMESPACE}.svc.cluster.local:9121",
                    "hostname": f"{service_record.service_name}.{self.config.K8S_BROKER_NAMESPACE}.svc.cluster.local:6379",
                }
            )
            return endpoints
        except Exception as e:
            if e.__class__.__name__ == 'ServiceInstanceNotFound':
                self.log.error('Instance guid does not exist: {}'.format(
                    instance_id))
                return None
            else:
                raise

    @staticmethod
    def get_param_parsers():
        base = reqparse.CustomParamsParser(bundle_errors=True)
        provision = base.copy()
        update = base.copy()
        return {"provision": provision, "update": update}
