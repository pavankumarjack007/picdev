#!/bin/bash

check_app_exists() {
  COMMAND="cf apps | grep -w --quiet ${CF_APP_NAME}"

  if eval $COMMAND; then
    export APP_EXISTS=true
    export APP_NAME="${CF_APP_NAME}-new"
  else
    export APP_EXISTS=false
    export APP_NAME="${CF_APP_NAME}"
  fi
}

update_apps_domain() {
  if [[ "$TF_VAR_cf_for_k8s" == "true" ]]
  then
    export APPS_DOMAIN="apps.${CF_DOMAIN}"
  else
    export APPS_DOMAIN="${CF_DOMAIN}"
  fi
}

run_smoke_tests() {
  if [[ -n "${SMOKETEST_ARG}" ]]; then
    chmod +x "${SMOKETEST_ARG}"
    app_fqdn="${APP_NAME}.${APPS_DOMAIN}"
    eval "${SMOKETEST_ARG} ${app_fqdn}"
  fi
}

blue_green_deploy() {
  check_app_exists
  update_apps_domain

  cf push ${APP_NAME} --vars-file env/.manifest-vars.yml ${APP_MANIFEST}
  cf map-route $APP_NAME $APPS_DOMAIN --hostname $APP_NAME

  run_smoke_tests
  if [ $? -ne 0 ]; then	
    exit 1
  fi

  if $APP_EXISTS; then
    cf delete -f ${CF_APP_NAME}
    cf unmap-route $APP_NAME $APPS_DOMAIN --hostname $APP_NAME
    cf rename $APP_NAME ${CF_APP_NAME}
    cf map-route $CF_APP_NAME $APPS_DOMAIN --hostname $CF_APP_NAME
  fi
}

blue_green_deploy "$@"
