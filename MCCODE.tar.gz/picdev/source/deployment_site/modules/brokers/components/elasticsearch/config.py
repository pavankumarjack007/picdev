import logging
from os import environ


class Config:
    DEBUG = False
    TESTING = False

    BROKER_IS_ASYNC = True
    BROKER_USERNAME = environ.get("BROKER_USERNAME", "")
    BROKER_PASSWORD = environ.get("BROKER_PASSWORD", "")
    BROKER_VERSION = environ.get("BROKER_VERSION", "")
    LOGGING_LEVEL = environ.get("LOGGING_LEVEL", logging.getLevelName(logging.DEBUG))
    LOGGING_MSG_FORMAT = environ.get(
        "LOGGING_MSG_FORMAT", "%(asctime)s %(levelname)s %(name)s %(message)s"
    )
    PORT = int(environ.get("PORT", "8080"))

    AWS_ACCESS_KEY_ID = environ.get("AWS_ACCESS_KEY_ID", "")
    AWS_SECRET_ACCESS_KEY = environ.get("AWS_SECRET_ACCESS_KEY", "")
    AWS_DEFAULT_REGION = environ.get("AWS_DEFAULT_REGION", "ap-south-1")
    DOCKER_REGISTRY_HOST = environ.get("DOCKER_REGISTRY_HOST", "docker.na1.hsdp.io")
    DOCKER_REGISTRY_USER = environ.get("DOCKER_REGISTRY_USER", "")
    DOCKER_REGISTRY_PASSWORD = environ.get("DOCKER_REGISTRY_PASSWORD", "")
    DYNAMODB_TABLE = environ.get("DYNAMODB_TABLE", "hsdp_elastic_service_broker")
    K8S_BROKER_NAMESPACE = environ.get("K8S_BROKER_NAMESPACE", "")
    K8S_API_ENDPOINT = environ.get("K8S_API_ENDPOINT", "")
    K8S_BROKER_TOKEN = environ.get("K8S_BROKER_TOKEN", "")
    K8S_CACERT = environ.get("K8S_CACERT", "")
    K8S_IMAGE_PULL_SECRET = environ.get("K8S_IMAGE_PULL_SECRET", "")
    STORAGE_CLASS = environ.get("STORAGE_CLASS", "hostpath")
    DYNAMO_DB_HOST = environ.get("DYNAMO_DB_HOST", None)
    ENCRYPTION_KEY = environ.get("ENCRYPTION_KEY", "")
    MONITORING_ENABLED = environ.get("MONITORING_ENABLED", "true")
    MONITORING_TAG = environ.get("MONITORING_TAG", "hsop-prometheus")
    REG_CRED = environ.get("REG_CRED", "regcred")
    DOMAIN_NAME = environ.get("DOMAIN_NAME", "")

    SERVICE_PREFIX = "elastic-"

    CONSOLE_URL = environ.get("CONSOLE_URL", "")

    DOCKER_USERNAME = environ.get('DOCKER_USERNAME', '')
    CF_DOCKER_PASSWORD = environ.get('CF_DOCKER_PASSWORD', '')
    DOCKER_REGISTRY = environ.get('DOCKER_REGISTRY','')

    ES_SB_DOCKER_IMAGE = environ.get('ES_SB_DOCKER_IMAGE','')

    @property
    def service_catalog_filename(self):
        from pathlib import Path

        # We assume catalog (and this config file) are in the same (project root) directory.
        root = Path(__file__).parent
        catalog_file = root / "catalog.yml"
        return str(catalog_file)


class DevelopmentConfig(Config):
    DEBUG = True


class TestingConfig(Config):
    TESTING = True
    DEBUG = False
    BROKER_USERNAME = ""
    BROKER_PASSWORD = ""


class ProductionConfig(Config):
    DEBUG = False
    LOGGING_LEVEL = environ.get("LOGGING_LEVEL", logging.getLevelName(logging.INFO))
    LOGGING_MSG_FORMAT = environ.get(
        "LOGGING_MSG_FORMAT", "%(levelname)s %(name)s %(message)s"
    )


class DeploymentConfig(ProductionConfig):

    CF_APP_NAME = environ.get("CF_APP_NAME", "hsdp-database-test")
    BGD_CF_APP_NAME = "{}-new".format(CF_APP_NAME)

    CF_BUILDPACK = environ.get("CF_BUILDPACK", "python_buildpack")
    CF_URL = environ.get("CF_URL", "<cf-url>")
    CF_ORG = environ.get("CF_ORG", "<cf-org>")
    CF_SPACE = environ.get("CF_SPACE", "<cf-space>")
    CF_USER = environ.get("CF_USER", "<cf-user>")
    CF_PASSWORD = environ.get("CF_PASSWORD", "<cf-password>")

    DEPLOY_WITH_SMOKETESTS = environ.get("DEPLOY_WITH_SMOKETESTS", "true")
    SMOKETEST_SERVICE_ID = environ.get(
        "SMOKETEST_SERVICE_ID", "f5ab96c0-b08e-471e-8b10-7e93cade8ea3"
    )
    SMOKETEST_PLAN_ID = environ.get(
        "SMOKETEST_PLAN_ID", "83a12df2-775f-430b-aa30-8cfedc28017b"
    )
    BROKER_CONFIG = environ.get("BROKER_CONFIG", "production")


# Global config object
config_map = {
    "development": DevelopmentConfig(),
    "testing": TestingConfig(),
    "production": ProductionConfig(),
    "deployment": DeploymentConfig(),
    "default": DevelopmentConfig(),
}
