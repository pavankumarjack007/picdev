import graphene


class Snapshot(graphene.ObjectType):
    identifier = graphene.String()
    type = graphene.String()
    status = graphene.String()
    create_time = graphene.String()

    def resolve_identifier(snapshot, _):
        return snapshot["name"]

    def resolve_type(snapshot, _):
        return snapshot["snapshot_type"]

    def resolve_status(snapshot, _):
        return snapshot["status"]

    def resolve_create_time(snapshot, _):
        # snapshot_create_time won't exist if snapshot status is creating
        return snapshot["create_time"]
