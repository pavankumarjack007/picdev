import base64
import logging
import os
import sys
import distutils.util
from cf_broker_api import reqparse
from cf_broker_api.exceptions import (
    ServiceInstanceNotFound, ServiceInstanceGone)
from cf_broker_api.reqparse import Namespace
from requests.exceptions import ConnectionError, HTTPError
from urllib3.exceptions import LocationValueError

from . import cloudfoundry
from .k8s import KubernetesClient
from .rmq import Client as RabbitmqClient
from .utils import generate_resource_id, generate_password, hash_password
from .operations import Provision, Deprovision, Read, Update, UpdateOp
from flask import redirect

LOG = logging.getLogger(__name__)


class ContextAwareRabbitMqServiceInstanceService(object):
    def __init__(self, request, app, config):
        self.app = app
        self.config = config
        self.request = request
        self.service_class = self.app.service_class

        try:
            LOG.debug("creating cc")
            cc_args = config.cc_config.copy()
            cc_args.update({"access_token": request.headers["X-User-Access-Token"]})
            self.cc = cloudfoundry.CloudController.new_instance(**cc_args)
        except Exception as e:
            LOG.error("Failed to create CC client!:", exc_info=True)

            raise e

    def get_instances(self):
        print("Calling context aware")
        return cloudfoundry.get_instances(self.cc)

    def instance_permissions(self, instance_id):
        return self.cc.instance_permissions(instance_id)

    def service_catalog(self):
        plans = []
        name = self.app.service_catalog.services[0]["name"]
        for plan in self.app.service_catalog.services[0]["plans"]:
            plans.append(plan)

        res = self.cc.services().get_by_name(name, "label")
        service = res.resources[0]
        accessible_plans = []
        res = self.cc.services(service.guid, "service_plans").get()
        for plan in res.resources:
            accessible_plans.append(plan.unique_id)

        # Now set restrictions
        for plan in plans:
            if plan["id"] not in accessible_plans:
                plan["restricted"] = True

        return {"name": name, "plans": plans}

    def instance_details(self, instance_id):
        return self.service_class.instance_details(instance_id)


class RabbitmqServiceInstanceService(object):

    def __init__(self, config=None):
        self.config = config
        self.log = logging.getLogger('broker')
        self.log_stdout = logging.StreamHandler(sys.stdout)
        self.log_stdout.setFormatter(
            logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        self.log_stdout.setLevel(logging.INFO)
        self.log.addHandler(self.log_stdout)
        self.log.setLevel(logging.INFO)
        self.client = KubernetesClient(self.config)
        self.namespace = self.config.K8S_NAMESPACE
        self.load_balancer_ready = False
        self.pods_ready = False
        self.details = Details()
        self.create = Provision()
        self.delete = Deprovision()
        self.view = Read()
        self.amend = Update()

    def update(self, request):
        service_record = self._get_service_record(request)
        if 'UpgradeVersion' in request.parameters:
            if request.parameters['UpgradeVersion']:
                details = self.details.info(
                    log=self.log,
                    service_record=service_record,
                    request_parameters=request.parameters,
                    client=self.client,
                    image_host=self.config.DOCKER_REGISTRY_HOST)
                UpdateOp(details)
                self._update_last_operation(request,
                                            state='in progress',
                                            description='Updating service')

        if 'RotatePassword' in request.parameters:
            if request.parameters['RotatePassword']:
                password = generate_password(16)
                password_hash = hash_password(password)
                details = self.details.info(
                    name=service_record.data['credentials'],
                    log=self.log,
                    namespace=self.namespace,
                    client=self.client)
                credentials = self.view.read_secret(details)
                rmq_api = RabbitmqClient(
                    'https://{}:15672'.format(credentials['hostname']),
                    'admin',
                    credentials['password'])
                body = {'tags': 'administrator',
                        'password_hash': password_hash}
                try:
                    rmq_api.create_users_by_name('admin', body)
                except HTTPError as e:
                    self.log.error('Password rotation failed: {}'.format(e))
                    self._update_last_operation(
                        request,
                        state='failed',
                        description='Unable to change password: {}'.format(e))
                    return

                self._update_credentials(record=service_record,
                                         password=password)
                self.log.info('Successfully updated admin password')
                self._update_last_operation(
                    request,
                    state='succeeded',
                    description='Successfully changed password.')

    def provision(self, request, **kwargs):
        print("in provision")
        service_record = {}
        try:
            service_record = self._get_service_record(request)
        except ServiceInstanceNotFound:
            pass

        self.log.info('Provision request: {}'.format(request))
        settings = self._generate_settings(request)
        name = 'rmq-{}'.format(settings['resource_id'])
        details = self.details.info(name=name,
                                    log=self.log,
                                    settings=settings,
                                    client=self.client,
                                    config=self.config,
                                    request=request,
                                    namespace=self.namespace,
                                    service_record=service_record)
        self.create.create_configmap(details, configmap='broker_template')
        self.create.create_role(details, role='node')
        self.create.create_rolebinding(details, binding='node')
        self.create.create_serviceaccount(details, account='node')
        self.create.create_networkpolicy(details, policy='node')
        self.create.create_service(details, svctype='node')
        self.create.create_headless_service(details)
        self.create.create_configmap(details, configmap='configmap_template')
        self.create.create_secret(details, secret='rabbit')
        # SOURI comment the 3 lines below.
        # self.create.create_service(details, svctype='exporter')
        # self.create.create_secret(details, secret='exporter')
        # self.create.create_ingress(details)
        self.create.create_statefulset(details)
        self.create.create_pdb(details)
        self._update_last_operation(request,
                                    state='in progress',
                                    description='Creating service')

    def deprovision(self, request):
        instance_id = request.instance_id
        service_record = self._get_service_record(request)
        self.log.info(
            'Deprovisioning service instance: {}'.format(instance_id))
        name = 'rmq-{}'.format(service_record.data['resource_id'])

        details = self.details.info(name=name,
                                    log=self.log,
                                    client=self.client,
                                    namespace=self.namespace,
                                    service_record=service_record,
                                    request=request)
        self.delete.all_resources(details)

        # Exporter resources
        name = 'rmq-exporter-{}'.format(service_record.data['resource_id'])
        exporter_details = self.details.info(name=name,
                                             log=self.log,
                                             client=self.client,
                                             namespace=self.namespace,
                                             service_record=service_record,
                                             request=request)
        self.delete.all_resources(details=exporter_details,
                                  resource='exporter')
        self._update_last_operation(request,
                                    state='succeeded',
                                    description='Service deleted')

    def manage_instance(self, instance_id):
        # Using a service instance ID, return the ConfigMap holding
        # broker state
        label_selector = 'cf_instance_id={},!app'.format(instance_id)
        details = self.details.info(log=self.log,
                                    namespace=self.namespace,
                                    client=self.client,
                                    misc=label_selector)
        try:
            service_record = self.view.list_configmap(details,
                                                      label='selector')
            resource_id = service_record.data['resource_id']

            grafana_url = os.getenv('GRAFANA_URL') + 'rmq-exporter-' + resource_id
            print('grafana url is ' + grafana_url)
            return redirect(grafana_url)

        # This is returned by the kubernetes client which apparently uses
        # requests/urllib3 to talk to the kubernetes api.  This exception
        # should only be thrown when provision is called and no existing
        # service records exist for the instance.
        except LocationValueError:
            service_record = {}
        return service_record

    def bind(self, request):
        body = {'data': {}}
        instance_id = request.instance_id
        binding_id = request.binding_id
        # SOURI -- changed the following line for compatibility with cloud rmq broker.
        # exclude = ['erlang_cookie', 'exporter_ingress']
        exclude = ['ssl_port']
        try:
            service_record = self._get_service_record(request)
        except ServiceInstanceNotFound:
            raise

        # Lookup name of default Secret
        credentials = service_record.data['credentials']

        if binding_id not in service_record.data:
            body['data'][binding_id] = credentials
            self._update_config_map(service_record.metadata.name, body)
            self.log.info(
                'Created binding {0} for service instance {1}'.format(
                    binding_id, instance_id))

        details = self.details.info(name=credentials,
                                    log=self.log,
                                    namespace=self.namespace,
                                    client=self.client)
        creds = self.view.read_secret(details)

        # SOURI -- Use ClusterIP for the hostname. Instead of the generated hostname.
        svcname = 'rmq-{}'.format(service_record.data['resource_id'])
        details = self.details.info(name=svcname,
                                    log=self.log,
                                    namespace=self.namespace,
                                    client=self.client)
        service = self.view.read_service(details)
        creds['hostname'] = service.spec.cluster_ip
        creds['uri'] = "amqp://" + creds['username'] + ":" + creds['password'] + "@" + creds[
            'hostname'] + ":5672" + "/vhost"
        creds['admin_password'] = creds['password']
        creds['admin_username'] = creds['username']
        # tmp_host
        creds['hostnames'] = [creds['hostname']]
        creds['monitoring_password'] = creds['password']
        creds['monitoring_username'] = creds['username']
        creds['ssl'] = "false"
        creds['uris'] = [creds['uri']]
        creds['vhost'] = "vhost"
        protocols = {}
        amqp = {}
        amqp["host"] = service.spec.cluster_ip
        amqp['username'] = creds['username']
        amqp['password'] = creds['password']
        amqp['port'] = 5672
        amqp['uri'] = creds['uri']
        amqp['ssl'] = "false"
        amqp['vhost'] = "vhost"
        protocols["amqp"] = amqp

        creds['cert_hostname'] = svcname + ".rmq." + self.config.DOMAIN_NAME + ":30671"

        creds["protocols"] = protocols
        # Remove unused credentials the end-user does not need to see.
        for e in exclude:
            creds.pop(e)
        return {'credentials': creds}

    def unbind(self, request):
        instance_id = request.instance_id
        binding_id = request.binding_id
        try:
            service_record = self._get_service_record(request)
        except ServiceInstanceNotFound:
            raise

        if binding_id in service_record.data:
            path = '/data/{}'.format(request.binding_id)
            body = [{'op': 'remove', 'path': path}]
            self.log.info(
                'Deleted binding {0} for service instance: {1}'.format(
                    binding_id, instance_id))
            self._update_config_map(service_record.metadata.name, body)

    def last_operation(self, request):
        service_record = self._get_service_record(request)
        annotations = service_record.metadata.annotations
        state = annotations['state']
        description = annotations['description']

        # SOURI -- NOT using ELB for now. So commented the check for elb status
        # Selb_ready = self._get_load_balancer_status(request)
        pods_ready = self._get_pods_status(request)

        # SOURI -- NOT using ELB for now. So commented the check for elb status
        # if elb_ready and pods_ready:
        if pods_ready is True:
            print("in pods_ready:")
            if description == 'Creating service':
                print("in last_op - creating:")
                self._deploy_rmq_monitoring(request, service_record)
            if description == 'Monitoring deployed':
                print("in last_op - monitorring:")
                # SOURI -- changed getting hostname to be based on service ClusterIP instead of the service_record as below
                # hostname = service_record.data['hostname']
                svcname = 'rmq-{}'.format(service_record.data['resource_id'])
                details = self.details.info(name=svcname,
                                            log=self.log,
                                            namespace=self.namespace,
                                            client=self.client)
                service = self.view.read_service(details)
                hostname = service.spec.cluster_ip
                # SOURI temporarily ignore the RMQ config stuff and set description to configured
                self._configure_rmq(request, service_record, hostname)
                self._update_last_operation(request,
                                            state='in progress',
                                            description='RabbitMQ configured')
            if description == 'Updating service':
                # Check the pod status using current_replicas instead of
                # ready_replicas instead.  More details in POC-37
                update_status = self._get_pods_status(request, update=True)
                if update_status is True:
                    state = 'succeeded'
                    description = 'Update successful'

        if description == 'RabbitMQ configured':
            state = 'succeeded'
            description = 'Service ready'
            self._update_last_operation(request, state, description)

        if description == 'Service deleted':
            name = service_record.metadata.name
            self._delete_service_record(name, request)
            raise ServiceInstanceGone(request.instance_id)

        self.log.info(
            'Last operation for service instance {0}: state: {1}, status: {2}'.
                format(request.instance_id, state, description))
        return {'state': state, 'description': description}

    def _generate_settings(self, request):
        default_pass = generate_password(16)
        monitoring_pass = generate_password(16)
        erlang_cookie = generate_password(24)

        settings = request.plan.get('settings', {})
        settings['namespace'] = self.config.K8S_NAMESPACE
        settings['cf_plan'] = request.plan.get('name')
        settings['resource_id'] = generate_resource_id()
        settings['cf_org'] = request.organization_guid
        settings['cf_space'] = request.space_guid
        settings['cf_service_id'] = request.service_id
        settings['cf_instance_id'] = request.instance_id
        settings['pdb_max_unavailable'] = settings['nodes']
        settings['image_host'] = self.config.DOCKER_REGISTRY_HOST
        settings['image_tag'] = self.config.RABBITMQ_IMAGE_VERSION
        settings['hostname'] = 'rmq-{0}.{1}'.format(settings['resource_id'],
                                                    self.config.DNS_ZONE)
        settings['exporter_ingress'] = 'rmq-exporter-{0}.internal.{1}.cluster.hsdp.io'.format(  # noqa: E501
            settings['resource_id'], self.config.HSDP_REGION)
        settings['storage_class'] = self.config.STORAGE_CLASS

        settings['erlang_cookie_b64'] = bytes.decode(
            base64.b64encode(str.encode(erlang_cookie)))
        settings['default_pass_b64'] = bytes.decode(
            base64.b64encode(str.encode(default_pass)))
        settings['username_b64'] = bytes.decode(
            base64.b64encode(str.encode(str(settings['default_user']))))
        settings['hostname_b64'] = bytes.decode(
            base64.b64encode(str.encode(str(settings['hostname']))))
        settings['service_port_b64'] = bytes.decode(
            base64.b64encode(str.encode(str(settings['service_port']))))
        settings['management_port_b64'] = bytes.decode(
            base64.b64encode(str.encode(str(settings['management_port']))))
        settings['monitoring_username_b64'] = bytes.decode(
            base64.b64encode(str.encode('monitoring')))
        settings['monitoring_pass_b64'] = bytes.decode(
            base64.b64encode(str.encode(monitoring_pass)))
        # settings['exporter_ingress_b64'] = bytes.decode(
        #    base64.b64encode(str.encode(settings['exporter_ingress'])))
        settings['ssl_port_b64'] = bytes.decode(base64.b64encode(str.encode(str(settings['ssl_port']))))  # noqa: E501
        settings['vhost_b64'] = bytes.decode(base64.b64encode(str.encode('/')))

        settings['org_name'] = request.context['organization_name']
        settings['org_space'] = request.context['space_name']
        settings['instance_name'] = request.context['instance_name']

        return settings

    def _update_credentials(self, record, **kwargs):
        name = record.data['credentials']
        password = kwargs.get('password', None)
        details = self.details.info(name=name,
                                    log=self.log,
                                    namespace=self.namespace,
                                    client=self.client,
                                    config=self.config,
                                    password=password)
        self.amend.update_secret(details)

    def _get_service_record(self, request):
        # Using a service instance ID, return the ConfigMap holding
        # broker state
        instance_id = request.instance_id
        label_selector = 'cf_instance_id={},!app'.format(instance_id)
        details = self.details.info(log=self.log,
                                    namespace=self.namespace,
                                    client=self.client,
                                    misc=label_selector)
        try:
            service_record = self.view.list_configmap(details,
                                                      label='selector')
        # This is returned by the kubernetes client which apparently uses
        # requests/urllib3 to talk to the kubernetes api.  This exception
        # should only be thrown when provision is called and no existing
        # service records exist for the instance.
        except LocationValueError:
            service_record = {}
        return service_record

    def _delete_service_record(self, name, request):
        details = self.details.info(
            name=name,
            log=self.log,
            client=self.client,
            namespace=self.namespace,
            service_record=self._get_service_record(request),
            request=request)
        self.delete.delete_configmap(details)

    def _update_last_operation(self, request, state, description):
        service_record = self._get_service_record(request)
        name = service_record.metadata.name
        body = {
            'metadata': {
                'annotations': {
                    'state': state,
                    'description': description
                }
            }
        }
        self._update_config_map(name, body=body)
        self.log.info(
            'Updated last operation for service instance {0}: state: '
            '{1}, status: {2}'.format(request.instance_id, state, description))

    def _update_config_map(self, name, body=None):
        details = self.details.info(name=name,
                                    log=self.log,
                                    namespace=self.namespace,
                                    client=self.client,
                                    config=self.config,
                                    misc=body)
        self.amend.update_configmap(details)

    def _get_load_balancer_status(self, request):
        # This is a basic readiness check for the ELB, we try to read
        # the hostname attribute of the Service, which is updated
        # asynchronously when the ELB hostname is available.
        service_record = self._get_service_record(request)
        name = service_record.data['service']
        details = self.details.info(name=name,
                                    log=self.log,
                                    namespace=self.namespace,
                                    client=self.client)
        service = self.view.read_service(details)
        if service is None:
            return False
        elif service.status.load_balancer.ingress is None:
            self.load_balancer_ready = False
        else:
            self.load_balancer_ready = True
        return self.load_balancer_ready

    def _get_pods_status(self, request, update=False):
        service_record = self._get_service_record(request)
        name = service_record.data['statefulset']
        # print(request)
        settings = request.plan.get('settings', {})
        details = self.details.info(name=name,
                                    log=self.log,
                                    namespace=self.namespace,
                                    client=self.client)
        statefulset = self.view.read_stateful_set(details)
        # print(statefulset)
        if statefulset is None:
            self.pods_ready = False
        # ready_replicas returns None when the statefulset is initially
        # created. This was causing the exporter to be created prematurely.
        # More details in CFSB-365.
        elif statefulset.status.ready_replicas is None:
            self.pods_ready = False
        # For update operations, the ready_replicas key cannot be used because
        # the pods are already up and running.  We must use current_replicas
        # as it is more indicative of the update status.
        elif update is True:
            if statefulset.status.current_replicas == settings['nodes']:
                self.pods_ready = True
            else:
                self.pods_ready = False
        elif statefulset.status.ready_replicas == settings['nodes'] and update is False:  # noqa: E501
            self.pods_ready = True
        print("Pod status: ", self.pods_ready)
        return self.pods_ready

    def _deploy_rmq_monitoring(self, request, service_record):
        deploy_exporters = os.getenv('DEPLOY_EXPORTER', False)
        if (bool(distutils.util.strtobool(deploy_exporters))):
            details = self.details.info(name=service_record.data['credentials'],
                                        log=self.log,
                                        namespace=self.namespace,
                                        client=self.client)
            credentials = self.view.read_secret(details)

            resource_id = service_record.data['resource_id']

            svcname = 'rmq-{}'.format(resource_id)
            details = self.details.info(name=svcname,
                                        log=self.log,
                                        namespace=self.namespace,
                                        client=self.client)
            service = self.view.read_service(details)
            hostname = service.spec.cluster_ip
            organization_name = service.metadata.labels['cf_org_name']
            space_name = service.metadata.labels['cf_space_name']
            instance_name = service.metadata.labels['cf_instance_name']

            name = 'rmq-exporter-{}'.format(resource_id)
            settings = {'resource_id': resource_id,
                        'cf_instance_id': request.instance_id,
                        'hostname': hostname,
                        'namespace': self.namespace,
                        'rabbitmq_password': credentials['password'],
                        'rabbimq_user': 'admin',
                        'org_name': organization_name,
                        'org_space': space_name,
                        'instance_name': instance_name,
                        'image_host': self.config.DOCKER_REGISTRY_HOST}

            details = self.details.info(name=name,
                                        log=self.log,
                                        settings=settings,
                                        client=self.client,
                                        config=self.config,
                                        request=request,
                                        namespace=self.namespace,
                                        service_record=service_record)
            # self.create.create_role(details, role='exporter')
            # self.create.create_rolebinding(details, binding='exporter')
            # self.create.create_serviceaccount(details, account='exporter')
            self.create.create_deployment(details)
            self.create.create_servicemonitor(details)
            self.create.create_service(details, svctype='exporter')
            # self.create.create_networkpolicy(details, policy='exporter')
        self._update_last_operation(request,
                                    state='in progress',
                                    description='Monitoring deployed')

    def _configure_rmq(self, request, service_record, hostname):
        # Configuration updates that must be made when RabbitMQ is running,
        # these are made through the management API
        details = self.details.info(name=service_record.data['credentials'],
                                    log=self.log,
                                    namespace=self.namespace,
                                    client=self.client)
        credentials = self.view.read_secret(details)

        # SOURI commented exporter stuff
        # exporter_details = self.details.info(
        #    name=service_record.data['exporter_secret'],
        #    log=self.log,
        #    namespace=self.namespace,
        #     client=self.client)
        # exporter_secret = self.view.read_secret(exporter_details)
        no_proxy = os.environ.get("no_proxy")
        if no_proxy is None:
            no_proxy = ''
        os.environ["no_proxy"] = hostname + ',' + no_proxy
        os.environ["NO_PROXY"] = hostname + ',' + no_proxy
        print(os.environ["no_proxy"])

        url = 'http://{}:15672'.format(hostname)
        self.log.info('Connecting to RabbitMQ management API {}'.format(url))
        rmq_api = RabbitmqClient(url, 'admin', credentials['password'])

        try:
            rmq_api.create_vhost('vhost')

            # Check if this is being run from jenkins. Smoke tests and
            # CI tests need to ignore monitoring user deployment.
            # JENKINS = os.getenv('BUILD_NUMBER', None)
            # if self.config.AWS_DEFAULT_REGION != 'us-east-1' and JENKINS is not None:  # noqa: E501
            #     self._update_last_operation(request,
            #                                 state='in progress',
            #                                 description='RabbitMQ configured')
            #     self.log.info(
            #         'DEBUG/TESTING config found. Disabling monitoring check.')
            #     return
            # # Create monitoring user and set permissions
            # monitoring_user = ''
            # monitoring_password = ''#exporter_secret['rabbit_password']
            # body = {'tags': 'monitoring', 'password': monitoring_password}
            # rmq_api.create_users_by_name(monitoring_user, body)
            # vhost = '/'
            # body = {'read': '.*', 'write': '^$', 'configure': '^$'}
            # rmq_api.create_permissions_by_vhost_and_user(vhost,
            #                                              monitoring_user,
            #                                              body)

            # rmq_api.create_vhost('vhost')
            # vhost = 'vhost'
            # body = {'read': '.*', 'write': '^$', 'configure': '^$'}
            # rmq_api.create_permissions_by_vhost_and_user(vhost,
            #                                              monitoring_user,
            #                                              body)
            # # Set RabbitMQ cluster name
            # body = {'name': cluster_id}
            # rmq_api.create_cluster_name(body)
            self.log.info('Successfully connected to RabbitMQ management API')
        except ConnectionError:
            # Tolerate connection failures here (DNS resolution, health checks
            # not yet passing, etc)
            self.log.info(
                'Unable to connect to RabbitMQ management API {}'.format(url))
        else:
            self.log.info(
                'RabbitMQ configuration updated for service instance: {}'.
                    format(request.instance_id))
            self._update_last_operation(request,
                                        state='in progress',
                                        description='RabbitMQ configured')

    def get_param_parsers(self):

        def allowed_versions(ver):
            if ver in ['3.7.17']:
                return ver
            raise ValueError('Invalid version: {}'.format(ver))

        update = reqparse.CustomParamsParser(bundle_errors=True)
        update.add_argument('UpgradeVersion',
                            type=allowed_versions,
                            store_missing=False)
        update.add_argument('RotatePassword',
                            type=bool,
                            store_missing=False)

        return {'update': update}

    # GraphQL required function
    def get_instance(self, instance_id=None):
        return instance_id

    def instance_details(self, instance_id):
        request = Req()
        request.instance_id = instance_id
        try:
            service_record = self._get_service_record(request)
            resource_id = service_record.data['resource_id']
            svcname = 'rmq-{}'.format(service_record.data['resource_id'])
            details = self.details.info(name=svcname,
                                        log=self.log,
                                        namespace=self.namespace,
                                        client=self.client)
            service = self.view.read_service(details)
            hostname = 'rmq-exporter-{0}.internal.{1}.cluster.hsdp.io'.format(
                resource_id, self.config.HSDP_REGION)
            endpoints = {}
            endpoints.update(
                {
                    "exporterHostname": f"rmq-exporter-{resource_id }.{self.namespace}.svc.cluster.local:9419",
                    "hostname": service.spec.cluster_ip,
                }
            )
            return endpoints
        except Exception as e:
            if e.__class__.__name__ == 'ServiceInstanceNotFound':
                self.log.error('Instance guid does not exist: {}'.format(
                    instance_id))
                return None
            else:
                raise


class Req(object):
    def __init__(self):
        self.instance_id = None


class Details(object):
    def info(self, **kwargs):
        details = Namespace()
        details.client = kwargs.get('client', '')
        details.config = kwargs.get('config', '')
        details.image_host = kwargs.get('image_host', '')
        details.log = kwargs.get('log', '')
        details.name = kwargs.get('name', '')
        details.namespace = kwargs.get('namespace', '')
        details.misc = kwargs.get('misc', '')
        details.password = kwargs.get('password', '')
        details.request = kwargs.get('request', '')
        details.request_parameters = kwargs.get('request_parameters', {})
        details.service_record = kwargs.get('service_record', '')
        details.settings = kwargs.get('settings', {})
        return details
