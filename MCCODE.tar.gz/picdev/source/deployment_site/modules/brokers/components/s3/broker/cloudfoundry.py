import urllib

import cf_api


class InstancePermissionsResponse(cf_api.CloudControllerResponse):
    @property
    def can_manage_instance(self):
        if not self.has_error and "manage" in self.data:
            return self.data["manage"]
        else:
            return False


class CloudController(cf_api.CloudController):
    def instance_permissions(self, instance_id):
        req = self.service_instances(instance_id, "permissions")
        req.set_response_class(InstancePermissionsResponse)
        resp = req.get()
        resp.raise_for_status()
        return resp


def get_uaa_logout_url(uaa=None, redirect=None, **uaa_args):
    if uaa is None:
        uaa = cf_api.new_uaa(no_auth=True, **uaa_args)
    url_args = {}
    if redirect:
        url_args["redirect"] = redirect
    return "?".join([uaa.get_url("logout.do"), urllib.urlencode(url_args)])


class ServiceInstance(object):
    def __init__(self, **kwargs):
        self.guid = kwargs.get("guid")
        self.organization = kwargs.get("organization")
        self.space = kwargs.get("space")
        self.name = kwargs.get("name")
        self.created_dt = kwargs.get("created_dt")
        self.plan_name = kwargs.get("plan_name")


def get_s3_instances(cc):
    def gen_guid_lookup_table(org_resources, space_resources, plan_resources):
        lookup_table = {}
        for plan in plan_resources:
            lookup_table[plan.guid] = plan.name
        for org in org_resources:
            lookup_table[org.guid] = org.name
        for space in space_resources:
            value = {"name": space.name, "org_name": lookup_table[space.org_guid]}
            lookup_table[space.guid] = value
        return lookup_table

    max_results_param = {"results-per-page": 100}

    orgs_req = cc.organizations().set_query(**max_results_param)
    orgs = cc.get_all_resources(orgs_req)

    spaces_req = cc.spaces().set_query(**max_results_param)
    spaces = cc.get_all_resources(spaces_req)

    s3_service = cc.services().search("label:hsdp-s3")
    plans = cc.services(s3_service.resource.guid, "service_plans").get()
    guid_lookups = gen_guid_lookup_table(orgs, spaces, plans.resources)

    plan_guids = [p.guid for p in plans.resources]

    instances_filter = "service_plan_guid IN {}".format(",".join(plan_guids))
    instances_params = dict(q=instances_filter)
    instances_params.update(**max_results_param)
    instances_req = cc.service_instances().set_query(**instances_params)
    instances = cc.get_all_resources(instances_req)

    service_instances = []
    for i in instances:
        instance = ServiceInstance(
            organization=guid_lookups[i.space_guid]["org_name"],
            space=guid_lookups[i.space_guid]["name"],
            name=i.name,
            created_dt=i["metadata"]["created_at"],
            plan_name=guid_lookups[i.service_plan_guid],
            bound_apps="",
            guid=i.guid,
        )
        service_instances.append(instance)
    service_instances = sorted(service_instances, key=lambda x: x.name.lower())

    return service_instances


def has_authorities(token, authorities):
    valid_authorities = set(authorities)
    current_authorities = set(token.get("authorities", []))
    return len(valid_authorities.intersection(current_authorities)) > 0
